#Genetic Construct - Copyright (C) 2010
#Released under the GPL3 License

import pygame
from interface import ConstructInterface, SequenceInterface


class Control(object):
    """
    Construct control.
    """
    def __init__(self, construct):
        self.construct = construct
        dna_color = self.construct.dna_color.copy()
        dna_patterns = self.construct.dna_patterns[:]
        for base in dna_color:
            dna_color[base] = self.hex_to_rgb(dna_color[base])
        self.dna_color = dna_color
        self.panel, self.panel_group = self.define_controls(dna_color,dna_patterns)
        self.set_seq_interface()
        self.mouse_pan = False
        self.save_image = False
        self.panel_interact = False
        pygame.key.set_repeat(100,10)
        self.clock = pygame.time.Clock()
        self.quit = False
        if self.construct.dna:
            self.check_events_set(True)
        else:
            self.check_events_set(False)
        self.control_place = None
        self.construct.control = self

    def define_controls(self, dna_color, dna_patterns):
        """Initiate interface panel."""
        panel = ConstructInterface(self.construct,self,dna_color,dna_patterns)
        panel_group = pygame.sprite.RenderUpdates(panel)
        return panel, panel_group

    def set_seq_interface(self):
        """Initiate sequence interface."""
        self.construct.seq_interface = SequenceInterface(self.construct,self)
        self.construct.seq_panel = pygame.sprite.RenderUpdates(self.construct.seq_interface)

    def check_events_set(self, active):
        """Set user input method."""
        if active:
            self.check_events = self.check_events_max
        else:
            self.check_events = self.check_events_min

    def check_events_max(self):
        """Check user input."""
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_UP, pygame.K_DOWN, pygame.K_RIGHT, pygame.K_LEFT):
                    ctrl = {pygame.K_UP:'u', pygame.K_DOWN:'d', pygame.K_RIGHT:'r', pygame.K_LEFT:'l'}
                    mod = pygame.key.get_mods()
                    if not mod:
                        self.construct.shift(ctrl[event.key])    #shift sequence
                    elif mod & pygame.KMOD_CTRL:
                        if mod & pygame.KMOD_SHIFT:
                            hyper_pan = True
                        else:
                            hyper_pan = False
                        self.construct.pan(ctrl[event.key], hyper_pan)      #pan display
                    elif mod & pygame.KMOD_ALT:
                        if mod & pygame.KMOD_SHIFT:
                            hyper_zoom = True
                        else:
                            hyper_zoom = False
                        self.construct.zoom(ctrl[event.key], hyper_zoom)     #zoom display
                    elif mod & pygame.KMOD_SHIFT:
                        self.construct.shift(ctrl[event.key], hyper_shift=True)    #shift sequence
                    self.panel.set_update()
                elif event.key == pygame.K_g:      #display G base
                    self.construct.base_switch({'G':True,'A':False,'T':False,'C':False})
                    ctrls = self.panel.get_control('G','A','T','C')
                    for ctrl in ctrls:
                        ctrls[ctrl].set_value('OFF')
                    ctrls['G'].set_value('ON')
                    self.panel.set_update()
                elif event.key == pygame.K_a:      #display A base
                    self.construct.base_switch({'G':False,'A':True,'T':False,'C':False})
                    ctrls = self.panel.get_control('G','A','T','C')
                    for ctrl in ctrls:
                        ctrls[ctrl].set_value('OFF')
                    ctrls['A'].set_value('ON')
                    self.panel.set_update()
                elif event.key == pygame.K_t:      #display T base
                    self.construct.base_switch({'G':False,'A':False,'T':True,'C':False})
                    ctrls = self.panel.get_control('G','A','T','C')
                    for ctrl in ctrls:
                        ctrls[ctrl].set_value('OFF')
                    ctrls['T'].set_value('ON')
                    self.panel.set_update()
                elif event.key == pygame.K_c:      #display C base
                    self.construct.base_switch({'G':False,'A':False,'T':False,'C':True})
                    ctrls = self.panel.get_control('G','A','T','C')
                    for ctrl in ctrls:
                        ctrls[ctrl].set_value('OFF')
                    ctrls['C'].set_value('ON')
                    self.panel.set_update()
                elif event.key == pygame.K_SPACE:  #display all bases
                    self.construct.reset()
                    self.panel.reset()
                    self.panel.set_update()
                elif event.key == pygame.K_RIGHTBRACKET:   #base run increase
                    ctrl = self.panel.get_control('Run')
                    value = ctrl.get_value()
                    if value < 25:
                        ctrl.set_value(value+1)
                        self.construct.base_repeat(1)
                    self.panel.set_update()
                elif event.key == pygame.K_LEFTBRACKET:    #base run decrease
                    ctrl = self.panel.get_control('Run')
                    value = ctrl.get_value()
                    if value > 1:
                        ctrl.set_value(value-1)
                        self.construct.base_repeat(-1)
                    self.panel.set_update()
                elif event.key == pygame.K_SLASH:  #center display
                    self.construct.center_image()
                    self.panel.set_update()
                elif event.key == pygame.K_s:
                    mod = pygame.key.get_mods()
                    if not mod:           #display sequence
                        self.construct.sequence_info_toggle('Sequence')
                        self.panel.get_control('Sequence').set_activated()
                    elif mod & pygame.KMOD_CTRL:   #snapshot
                        if not self.save_image:
                            image_saved = self.construct.seqimage_save()
                            self.panel.get_control('__SaveLabel').set_value(image_saved)
                            self.save_image = True
                elif event.key == pygame.K_x:
                    self.construct.sequence_info_toggle('Position')
                    self.panel.get_control('Position').set_activated()
                elif event.key == pygame.K_z:      #sequence viewer
                    self.panel.sequence_viewer()
                elif event.key == pygame.K_v:   #clipboard paste
                    mod = pygame.key.get_mods()
                    if mod & pygame.KMOD_CTRL:
                        self.construct.seq_interface.seq_paste()
                elif event.key == pygame.K_h:    #control info
                    self.construct.control_info()
                elif event.key == pygame.K_p:      #panel toggle
                    self.panel.set_moveable('Fixed')
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_s:
                    self.save_image = False
            elif event.type == pygame.QUIT:
                self.quit = True
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:       #pan display
                    if self.construct.pointer_interact(event.pos):
                        if not self.panel_interact:
                            self.mouse_pan = True
                            pygame.mouse.get_rel()
                            self.panel.deactivate()
                            self.panel.set_update(True)
                elif event.button == 2:     #seq display
                    self.construct.sequence_info_toggle('Position')
                    self.panel.get_control('Position').set_activated()
                elif event.button == 3:     #seq display
                    self.construct.sequence_info_toggle('Sequence')
                    self.panel.get_control('Sequence').set_activated()
            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    self.mouse_pan = False
                    self.panel.activate()
                    self.panel.set_update(False)
            elif event.type == pygame.MOUSEMOTION:
                if self.mouse_pan:
                    pos = pygame.mouse.get_rel()
                    if pygame.key.get_mods() & pygame.KMOD_SHIFT:
                        hyper_pan = True
                    else:
                        hyper_pan = False
                    self.construct.drag(pos, hyper_pan)

    def check_events_min(self):
        """Check user input."""
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_h:    #control info
                    self.construct.control_info()
                elif event.key == pygame.K_p:      #panel toggle
                    self.panel.set_moveable('Fixed')
                elif event.key == pygame.K_z:      #sequence viewer
                    self.panel.sequence_viewer()
                elif event.key == pygame.K_v:   #clipboard paste
                    mod = pygame.key.get_mods()
                    if mod & pygame.KMOD_CTRL:
                        self.construct.seq_interface.seq_paste()
                elif event.key == pygame.K_ESCAPE:
                    self.quit = True
            elif event.type == pygame.QUIT:
                self.quit = True

    def rgb_to_hex(self, color):
        """Convert color."""
        r,g,b = color
        return (hex(r*(256**2) + g*256 + b))

    def hex_to_rgb(self, color):
        """Convert color."""
        n = color
        return (n>>16)&0xff, (n>>8)&0xff, n&0xff

    def update(self):
        """Control update."""
        self.panel_group.update()
        if self.panel.is_update():
            self.panel_group.clear(self.construct.screen, self.construct.screen_base)
            update_rect = self.panel_group.draw(self.construct.screen)
            self.construct.update_list.extend(update_rect)
        if self.construct.dna:
            self.check_events()
        else:
            self.check_events_min()
        self.clock.tick(40)

