#Genetic Construct - Copyright (C) 2010
#Released under the GPL3 License

import interphase


class ConstructInterface(interphase.Interface):
    """
    Construct interface.
    """
    def __init__(self, construct, control, dna_color, dna_patterns):
        self.construct = construct
        self.control = control
        self.dna_color = dna_color
        self.seq_patterns = ['None', '']
        self.seq_patterns[1:1] = dna_patterns
        interphase.Interface.__init__(self, position=(self.construct.display_x//2, self.construct.display_y-50), image='panel.png', color=(143,150,158), size=(350,100), moveable=True, position_offset=(0,90), font_color=(255,255,255), info_fontcolor=(255,255,255), tips_fontcolor=(175,180,185), control_minsize=(29,29), control_size='auto', label_display=True, scroll_button='vertical')
        self.control_place = None
        self.sequence_info = False
        try:
            self.update_construct()
        except AttributeError:
            pass

    def add_controls(self):
        """Add interface controls."""
        self.add(
            identity = 'Control',
            control_type = 'function_select',
            position = (50,50),
            size = (40,40),
            control_image = ['none'],
            control_outline = False,
            control_list = ['__Construct', '__Controls', '__Patterns', '__Sequence', '__Exit'],
            link = [ ['DNA_Seq', '__SeqIDLabel', 'Files', '__FileLabel'], ['Tool', 'Compass', 'u', 'd', 'l', 'r', 'ul', 'ur', 'dl', 'dr'], ['G', 'A', 'T', 'C', 'Run', 'Pattern', 'Patterns'], ['Sequence', 'Position', 'Save', '__SaveLabel'], ['Exit'] ],
            link_activated = True,
            label_display = False)
        self.add(
            identity = 'Tool',
            control_type = 'function_toggle',
            position = (110,50),
            size = (30,30),
            control_list = ['__DNA', '__Pan', '__Zoom'],
            icon_list = ['control_dna.png', 'control_compass.png', 'control_zoom.png'],
            tip_list = ['Shift', 'Pan', 'Zoom'],
            link_activated = True,
            label_display = False)
        self.add(
            identity = 'Compass',
            control_type = 'control_toggle',
            position = (175,50),
            size = (25,25),
            control_list = [''],
            color = (0,20,30),
            activated_color = (60,60,100),
            activated_toggle = False,
            control_outline = True,
            label_display = False,
            control_response = 1000,
            hold_response = 0,
            delay_response = 500)
        for ident, tip, img, pos in ( ('u',[''],'control_u.png',(175,25)), ('d',[''],'control_d.png',(175,75)), ('l',[''],'control_l.png',(150,50)), ('r',[''],'control_r.png',(200,50)) ):
            self.add(
                identity = ident,
                control_type = 'control_toggle',
                position = pos,
                size = (25,25),
                control_list = [''],
                tip_list = tip,
                control_image = img,
                label_display = False,
                control_response = 10)
        for ident, tip, pos in ( ('ul',[''],(150,25)), ('ur',[''],(200,25)), ('dl',[''],(150,75)), ('dr',[''],(200,75)) ):
            self.add(
                identity = ident,
                control_type = 'control_toggle',
                position = pos,
                size = (25,25),
                control_list = [''],
                tip_list = tip,
                label_display = False,
                control_response = 10)
        self.add(
            identity = 'G',
            control_type = 'control_toggle',
            position = (110,35),
            size = 'min',
            control_list = ['ON', 'OFF'],
            tip_list = ['Guanine'],
            control_outline = True,
            color = (0,0,0),
            activated_color = self.dna_color['G'],
            control_response = 500)
        self.add(
            identity = 'A',
            control_type = 'control_toggle',
            position = (140,35),
            size = 'min',
            control_list = ['ON', 'OFF'],
            tip_list = ['Adenine'],
            control_outline = True,
            color = (0,0,0),
            activated_color = self.dna_color['A'],
            control_response = 500)
        self.add(
            identity = 'T',
            control_type = 'control_toggle',
            position = (170,35),
            size = 'min',
            control_list = ['ON', 'OFF'],
            tip_list = ['Thymidine'],
            control_outline = True,
            color = (0,0,0),
            activated_color = self.dna_color['T'],
            control_response = 500)
        self.add(
            identity = 'C',
            control_type = 'control_toggle',
            position = (200,35),
            size = 'min',
            control_list = ['ON', 'OFF'],
            tip_list = ['Cytosine'],
            control_outline = True,
            color = (0,0,0),
            activated_color = self.dna_color['C'],
            control_response = 500)
        self.add(
            identity = 'Run',
            control_type = 'control_select',
            position = (230,35),
            size = 'min',
            control_list = ['__numeric', (1,25)],
            tip_list = ['Sequence Run'])
        self.add(
            identity = 'Pattern',
            control_type = 'control_select',
            position = (110,75),
            size = (22,22),
            control_list = ['G', 'A', 'T', 'C', '<'],
            tip_list = ['Set'],
            loop = False)
        self.add(
            identity = 'Patterns',
            control_type = 'control_select',
            position = (190,75),
            size = (100,22),
            control_list = self.seq_patterns,
            tip_list = ['Sequence Pattern'],
            split_text = False,
            reverse = True,
            label_display = False)
        self.add(
            identity = 'Sequence',
            control_type = 'control_toggle',
            position = (175,25),
            size = (75,20),
            control_list = ['Sequence'],
            tip_list = ['Show DNA Sequence'],
            control_outline = True,
            split_text = False,
            label_display = False,
            activated_toggle = 'lock')
        self.add(
            identity = '__SeqLabel',
            control_type = 'label',
            position = (50,8),
            control_list = [''])
        self.add(
            identity = 'Position',
            control_type = 'control_toggle',
            position = (175,50),
            size = (75,20),
            control_list = ['Position'],
            tip_list = ['Show Sequence Position'],
            control_outline = True,
            split_text = False,
            label_display = False,
            activated_toggle = 'lock')
        self.add(
            identity = '__PosLabel',
            control_type = 'label',
            position = (330,8),
            control_list = [''])
        self.add(
            identity = 'Save',
            control_type = 'control_toggle',
            position = (175,75),
            size = (75,20),
            control_list = ['Image Save'],
            tip_list = ['Save Construct Image'],
            control_outline = True,
            split_text = False,
            label_display = False)
        self.add(
            identity = '__SaveLabel',
            control_type = 'label',
            position = (180,95),
            control_list = [''])
        self.add(
            identity = 'Files',
            control_type = 'control_select',
            position = (175,75),
            size = 'auto_width',
            control_list = ['__filelist', self.construct.seq_folder, '', ''],
            tip_list = ['Sequence Files'],
            label_display = False)
        self.add(
            identity = 'DNA_Seq',
            control_type = 'function_toggle',
            position = (175,50),
            size = 'min_width',
            control_list = ['Sequence'],
            tip_list = ['DNA Sequence'],
            control_outline = True,
            activated_toggle = 'lock',
            label_display = False)
        self.add(
            identity = 'Previous',
            control_type = 'control_toggle',
            position = (130,50),
            size = (20,20),
            control_list = ['<'],
            label_display = False,
            active = False)
        self.add(
            identity = 'Next',
            control_type = 'control_toggle',
            position = (220,50),
            size = (20,20),
            control_list = ['>'],
            label_display = False,
            active = False)
        self.add(
            identity = '__FileLabel',
            control_type = 'label',
            position = (184,20),
            control_list = [''])
        self.add(
            identity = '__SeqIDLabel',
            control_type = 'label',
            position = (184,30),
            control_list = [''])
        self.add(
            identity = 'Exit',
            control_type = 'control_toggle',
            position = (175,50),
            size = (40,40),
            control_list = ['Exit'],
            tip_list = ['Exit Program'],
            label_display = False)
        self.add(
            identity = '__Fix',
            control_type = 'control_toggle',
            position = (315,90),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['!'],
            control_image = ['none'],
            control_outline = True)
        self.add(
            identity = '__Help',
            control_type = 'control_toggle',
            position = (335,90),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['?'],
            control_image = ['none'],
            control_outline = True,
            activated_toggle = False)
        self.set_moveable('Fixed')
        if not self.construct.dna:
            self.get_control('Control').set_enabled(False)
        filelist = self.get_control('Files').get_list()
        filelist.insert(0,'-')
        self.get_control('Files').set_list(filelist)
        self.get_control('DNA_Seq').add_action(self.sequence_browse)
        self.get_control('Next').add_action(self.seq_control)
        self.get_control('Previous').add_action(self.seq_control)

    def sequence_browse(self, control=None, value=None, browse=True):
        self.construct.seq_viewer(browse)
        if control:
            for ctrl in ('Previous', 'Next'):
                self.get_control(ctrl).set_active(self.get_control(control).is_activated())
        else:
            self.get_control('DNA_Seq').set_activated(False)
            for ctrl in ('Previous', 'Next'):
                self.get_control(ctrl).set_active(False)
        self.control_place = None
        self.input_block()

    def seq_control(self, control, value):
        if control in ['Next', 'Previous']:
            if self.construct.seq_browse:
                self.construct.seq_interface.browse(control)

    def sequence_viewer(self):
        self.construct.seq_viewer()
        if not self.get_control('DNA_Seq').is_activated():
            self.control_place = self.get_control('Control').get_value()
            self.get_control('Control').set_value('__Construct')
        else:
            if self.control_place:
                self.get_control('Control').set_value(self.control_place)
                self.control_place = None
        self.get_control('DNA_Seq').set_activated()
        for ctrl in ('Previous', 'Next'):
            self.get_control(ctrl).set_active(self.get_control('DNA_Seq').is_activated())
        self.input_block()

    def input_block(self):
        if self.get_control('DNA_Seq').is_activated():
            self.control.check_events_set(False)
            if self.construct.sequence_info_check():
                self.construct.sequence_info_toggle()
                self.sequence_info = True
        else:
            self.control.check_events_set(True)
            if self.sequence_info:
                self.construct.sequence_info_toggle()
                self.sequence_info = False

    def update_construct(self):
        controls = self.get_control()
        values = self.get_value()
        base_change = {}
        for ctrl in ('G','A','T','C'):
            if values[ctrl] == 'OFF':
                base_change[ctrl] = {'ON':True,'OFF':False}[values[ctrl]]
        if base_change:
            self.construct.base_switch(base_change)
        if values['Run'] > 1:
            self.construct.base_repeat(values['Run']-1)
        if self.construct.seq_file:
            controls['__FileLabel'].set_value(self.construct.seq_file)
        else:
            controls['__FileLabel'].set_value('')
        controls['__SeqIDLabel'].set_value(self.construct.seq_id[:65])
        if self.construct.dna:
            if not controls['Control'].is_enabled():
                controls['Control'].set_enabled(True)
                self.control.check_events_set(True)

    def display_seq(self, seq):
        """Set sequence to display."""
        ctrl = self.get_control('__SeqLabel')
        if ctrl.get_value() != seq:
            ctrl.set_value(seq)

    def display_pos(self, pos):
        """Set sequence position to display."""
        ctrl = self.get_control('__PosLabel')
        if ctrl.get_value() != pos:
            ctrl.set_value(pos)

    def reset(self):
        """Reset interface controls."""
        for ctrl_id, ctrl in self.get_control('G','A','T','C').items():
            ctrl.set_value('ON')
        self.get_control('Run').set_value(1)

    def update(self):
        """Interface update."""
        interphase.Interface.update(self)
        state = self.get_state()
        self.control.panel_interact = state.panel_interact
        if state.control:
            if state.control == 'Control':
                state.controls['__SaveLabel'].set_value('')
                if state.button in ('Control_top', 'Control_bottom'):
                    self.sequence_browse(browse=False)
            elif state.control == 'Tool':
                self.tool = state.value[2:]
                state.controls['Compass'].set_activated(False)  
            elif state.control in ('u','d','l','r'):
                hyper = state.controls['Compass'].is_activated()
                function = state.values['Tool'][2:]
                if function == 'DNA':
                    self.construct.shift(state.control, hyper)
                elif function == 'Pan':
                    self.construct.pan(state.control, hyper)
                elif function == 'Zoom':
                    self.construct.zoom(state.control, hyper)
            elif state.control in ('ul','ur','dl','dr'):
                self.ctrl_counter = 0
                if state.values['Tool'][2:] == 'Pan':
                    hyper = state.controls['Compass'].is_activated()
                    self.construct.pan(state.control, hyper)
            elif state.control in ('G','A','T','C'):
                switch = {'ON':True,'OFF':False}[state.value]
                self.construct.base_switch({state.control:switch})
            elif state.control == 'Run':
                if state.button == 'Run_top':
                    self.construct.base_repeat(1)
                elif state.button == 'Run_bottom':
                    self.construct.base_repeat(-1)
            elif state.control == 'Pattern':
                if state.button == 'Pattern':
                    if state.value in ('G','A','T','C'):
                        patterns = state.controls['Patterns']
                        place = patterns.get_list_index()
                        if place == 0:
                            place = len(self.seq_patterns)-1
                            self.seq_patterns.append('')
                            patterns.set_list([''], append=True) 
                        elif place == len(self.seq_patterns)-1:
                            self.seq_patterns.append('')
                            patterns.set_list([''], append=True) 
                        self.seq_patterns[place] += state.value
                        patterns.set_list([self.seq_patterns[place][:10]], index=place)
                        patterns.set_list_index(place)
                        patterns.set_tip([self.seq_patterns[place]])
                        patterns.set_value(self.seq_patterns[place][-10:], change_index=False)
                    elif state.value == '<':
                        patterns = state.controls['Patterns']
                        place = patterns.get_list_index()
                        if place > 0:
                            if self.seq_patterns[place]:
                                self.seq_patterns[place] = self.seq_patterns[place][:-1]
                                patterns.set_list([self.seq_patterns[place][:10]], index=place)
                                patterns.set_tip([self.seq_patterns[place]])
                                patterns.set_value(self.seq_patterns[place][-10:], change_index=False)
            elif state.control == 'Patterns':
                place = state.controls['Patterns'].get_list_index()
                if self.seq_patterns[place] == 'None':
                    state.controls['Patterns'].set_tip(['Sequence Pattern'])
                else:
                    state.controls['Patterns'].set_tip([self.seq_patterns[place]])
                if state.button == 'Patterns':
                    self.reset()
                    self.construct.reset()
                    if state.value != 'None':
                        place = state.controls['Patterns'].get_list_index()
                        self.construct.sequence_pattern(self.seq_patterns[place])
                    else:
                        self.construct.sequence_pattern()
            elif state.control == 'Sequence':
                self.construct.sequence_info_toggle('Sequence')
            elif state.control == 'Position':
                self.construct.sequence_info_toggle('Position')
            elif state.control == 'Save':
                image_saved = self.construct.seqimage_save()
                state.controls['__SaveLabel'].set_value(image_saved)
            elif state.control == 'Files':
                if state.button == 'Files':
                    if state.value != '-':
                        self.construct.make_construct(seq_file=state.value)
                        self.update_construct()
            elif state.control == 'Exit':
                self.control.quit = True
            elif state.control == '__Fix':
                self.set_moveable('Fixed')
            elif state.control == '__Help':
                if state.controls['__Help'].is_activated():
                    for ctrl_id, ctrl in self.get_control('G','A','T','C').items():
                        ctrl.set_label_text(font_color=self.dna_color[ctrl_id])
                else:
                    for ctrl_id, ctrl in self.get_control('G','A','T','C').items():
                        ctrl.set_label_text(font_color=(255,255,255))
                self.set_tips_display()
        return state


class SequenceInterface(interphase.Interface):
    """
    Sequence interface.
    """

    def __init__(self, construct, control):
        interphase.Interface.__init__(self, identity='Interface_Doc', position=(250,200), color=(9,11,13), image='none', size=(430,320), font_color=(175,180,185), tips_display=False, scroll_button='vertical')
        self.construct = construct
        self.control = control
        self.next_move = 0
        self.prev_move = 0
        self.seq_id = ''

    def add_controls(self):
        self.sequence = self.add(
            identity = 'Seq',
            control_type = 'textbox',
            position = (230,0.5),
            color = (19,22,26),
            font_color = (255,255,255),
            font_size = 12,
            font_type = 'consolas, andalemono, courier, monospace',
            text_paste = True,
            label_display = False)
        textbox_size = self.sequence.get_size((50,20))
        self.sequence.resize_control(textbox_size)
        self.seq_num = self.add(
            identity = 'SeqNum',
            control_type = 'textbox',
            position = (25, 0.5),
            size = (50,textbox_size[1]),
            color = (9,11,13),
            font_color = (150,150,150),
            font_size = 12,
            font_type = 'consolas, andalemono, courier, monospace',
            text_margin = (5,0,5,0),
            control_button = False,
            label_display = False)
        self.sequence.add_format([self.remove_line, self.remove_leading_char, self.remove_space, self.upper_case, self.join_line])
        self.seq_num.add_format(['nowordwrap'])
        self.page_lines = self.sequence.get_line_max()
        self.sequence.add_action(self.seq_control)

    def remove_line(self, text):
        if text[0].startswith('>'):
            self.seq_id = text[0].lstrip('>').strip()
        else:
            self.seq_id = ''
        new_text = [line.strip() for line in text if not (line.startswith('>') or line.startswith(';'))]
        return new_text

    def remove_leading_char(self, text):
        for i, line in enumerate(text):
            text[i] = line.lstrip('0123456789 .')
        return text

    def remove_space(self, text):
        for i, line in enumerate(text):
            text[i] = line.replace(' ', '')
        return text

    def upper_case(self, text):
        for i, line in enumerate(text):
            text[i] = line.upper()
        return text

    def join_line(self, text):
        text = ''.join(text)
        return [text]

    def set_seq(self, seq=None):
        if seq:
            self.sequence.set_value(seq)
        seq = self.sequence.get_value(format_text=True)
        str_max = '00000000'
        while True:
            if self.seq_num.check_size(str_max)[0] < self.seq_num.size[0]:
                break
            str_max = str_max[:-1]
        width = len(str_max)
        number = []
        num = 1
        nm = str(num)
        sp = width - len(nm)
        number.append( (sp*' ') + nm )
        for line in seq[:-1]:
            num += len(line)
            nm = str(num)
            sp = width - len(nm)
            if sp < 0:
                nm = nm[abs(sp):]
                sp = 0
            number.append( (sp*' ') + nm )
        self.seq_num.set_value('\n'.join(number))
        seq = ''.join(seq)
        seq_id = self.seq_id
        return seq, seq_id

    def seq_paste(self):
        if self.construct.seq_browse:
            self.sequence.text_paste()
            self.seq_control('Seq_paste', True)

    def seq_control(self, ctrl, val):
        if ctrl == 'Seq_bottom':
            self.seq_num.next()
        elif ctrl == 'Seq_top':
            self.seq_num.previous()
        elif ctrl == 'Seq_paste':
            if val:
                sequence, sequence_id = self.set_seq()
                self.construct.make_construct(seq=sequence, seq_id=sequence_id)
                self.control.panel.update_construct()
                self.control.panel.get_control('Files').set_value('-')
                self.control.panel.input_block()
                self.control.panel.set_update()

    def browse(self, control, value=None):
        if control == 'Next':
            self.next_move = self.page_lines
        elif control == 'Previous':
            self.prev_move = self.page_lines

    def update(self):
        interphase.Interface.update(self)
        if self.next_move:
            self.sequence.next()
            self.seq_num.next()
            self.next_move -= 1
        elif self.prev_move:
            self.sequence.previous()
            self.seq_num.previous()
            self.prev_move -= 1

