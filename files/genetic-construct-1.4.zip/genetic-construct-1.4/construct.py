#!/usr/bin/env python
from __future__ import division

"""
Genetic Construct
Copyright (C) 2010 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Genetic Construct version 1.4
Download Site: https://gatc.ca
"""


try:
    import pygame
    from pygame import bufferproxy
    import numpy
except ImportError:
    raise ImportError("Pygame and Numpy modules are required.")
import math
import sys
import os
import re
import interphase
from control import Control


class Construct(object):
    """
    Genetic Construct.
    """
    def __init__(self, seq_file='', seq_path='', dna_color={}, size=(), bgcolor=-1, gamma=0.0, dna_patterns=[]):
        self.initialize(size, bgcolor, gamma)
        if dna_color:
            self.dna_color = dna_color      #construct bit color of DNA bases
        else:
            self.dna_color = {'G':0xd9d9d9, 'A':0x00ff00, 'T':0xff0000, 'C':0x0000ff}
        self.dna_color['N'] = self.screen_color
        self.dna_patterns = dna_patterns    #dna search patterns, can be initiated with patterns.ini
        self.update_list = []   #screen rects to be updated
        self.update_display = False     #if display requires updating
        self.control_list = []      #list of program controls for help display
        self.info = interphase.Text(self.screen)      #to display help
        self.info.set_font_color((200,200,200))
        self.sequence = ''
        self.seq_info = False   #if sequence info is displayed
        self.seq_view = False   #if sequence is displayed
        self.seq_display = ''   #sequence under pointer
        self.pos_view = False   #if position is displayed
        self.pos_display = ''   #position under pointer
        self.seq_pattern = ''   #sequence pattern to search
        self.seq_pattern_obj = None     #sequence pattern re obj
        self.seq_interface = None
        self.seq_panel = None
        self.seq_browse = False
        self.dna = []       #DNA sequence source for construct
        if not seq_path:
            self.seq_folder = os.path.expanduser('sequence')
        else:
            self.seq_folder = os.path.expanduser(seq_path)
        if seq_file:    #if sequence file entered at commandline
            try:
                seq_filename = os.path.basename(seq_file)
                seq_path = os.path.dirname(seq_file)
                if not seq_path:
                    seq_path = os.getcwd()
            except:
                seq_filename = ''
                seq_path = ''
            self.make_construct(seq_file=seq_filename, path=seq_path)     #make construct
        self.control = None

    def initialize(self, size, bgcolor, gamma):
        """Initialize program."""
        pygame.display.init()   #pygame.init()
        pygame.font.init()      #pygame.init()
        if size:
            self.display_x, self.display_y = size       #display dim
        else:
            self.display_x, self.display_y = 500, 500
        if gamma:
            gamma_set = pygame.display.set_gamma(gamma)     #screen gamma
        self.screen = pygame.display.set_mode((self.display_x,self.display_y))  #init pygame display surface
        if gamma and not gamma_set:   #if prior set_gamma failed
            gamma_set = pygame.display.set_gamma(gamma)
        self.screen_dna = pygame.display.get_surface()
        self.screen_base = pygame.Surface((self.display_x,self.display_y))
        self.screen_backup = pygame.Surface((self.display_x,self.display_y))
        self.image_zoomed = None
        if bgcolor == -1:
            bgcolor = 0x2e3436
        self.screen_color = (bgcolor)
        self.screen_base.fill(self.screen_color)
        self.screen.blit(self.screen_base, (0,0))
        pygame.display.set_caption('Genetic Construct')
        iconname = os.path.join('data', 'icon.png')
        icon = pygame.image.load(iconname)
        pygame.display.set_icon(icon)
        pygame.surfarray.use_arraytype('numpy')     #set numpy array for pygame

    def make_construct(self, seq=None, seq_id=None, seq_file=None, path=''):
        """Create construct from DNA sequence."""
        if seq:
            self.sequence = seq
            self.dna, self.dna_bit = self.dna_array(self.sequence)
            if seq_id is not None:
                self.seq_id = seq_id
            else:
                self.seq_id = ''
            self.seq_file = ''
        elif seq_file:
            self.sequence, self.seq_id = self.dna_input(seq_file, path)
            self.dna, self.dna_bit = self.dna_array(self.sequence)
            if seq_id is not None:
                self.seq_id = seq_id
        if not self.dna:
            return
        self.screen_base.fill(self.screen_color)
        self.screen.blit(self.screen_base, (0,0))
        pygame.display.update()
        self.x, self.y = 0.0, 0.0       #location of construct
        self.image_place_pre = [0.0, 0.0]   #location of construct of prior blit
        self.image_place_center = [0.0, 0.0]    #construct center
        self.image_zoom = 1.0       #construct zoom magnitude
        self.zoomed = False         #if previous display was zoomed
        self.image_morph = False    #if construct was morphed
        self.base_span = 0      #runs of base or pattern
        self.base_display = {'G':True, 'A':True, 'T':True, 'C':True, 'N':True}  #base to display in construct
        self.dna_to_bit()   #convert sequence base to color bit
        self.image = pygame.Surface((int(self.dna_length/self.dna_span),self.dna_span))   #construct
        self.surface_clear = self.image.copy()    #surface to clear construct
        self.image_size_pre = self.image.get_size()
        image_created = self.make_dna_image()   #construct image creation
        if image_created:
            self.center_image()
            self.update_display = True

    def dna_input(self, filename, path=None):
        """Load in DNA sequence."""
        self.seq_file = filename
        if not path:
            path = self.seq_folder
        try:
            if path:
                filename = os.path.join(path, filename)
            with open(filename) as seq_file:
                dna = seq_file.readlines()
        except IOError:
            dna = []
            seq_id = ''
        dna = ''.join(dna)
        if dna:
            seq, seq_id = self.seq_interface.set_seq(dna)
        else:
            seq = ''
            seq_id = ''
        return seq, seq_id

    def dna_array(self, seq):
        dna = [base.upper() for line in seq for base in line if base in ('G','A','T','C','N','g','a','t','c','n')]
        if dna:
            self.dna_length = len(dna)
            if self.dna_length < 1000:
                padding = self.dna_length
            else:
                padding = 1000
            dna.extend(['N']*padding)  #padding for various arrays
            self.dna_span = int(math.ceil(math.sqrt(self.dna_length)))  #generate square image
            self.dna_wrap = int(math.ceil(self.dna_length/self.dna_span))
        dna_bit = numpy.zeros(len(dna), 'i')    #numpy array for dna color bit
        return dna, dna_bit

    def dna_to_bit(self):
        """Translate DNA sequence to bit sequence."""
        dna_color = {}
        for base in self.base_display:
            if self.base_display[base]:
                dna_color[base] = self.dna_color[base]
        self.dna_bit.fill(0x000000)
        if not self.base_span and not self.seq_pattern_obj:
            for i, base in enumerate(self.dna):
                try:
                    self.dna_bit[i] = dna_color[base]
                except KeyError:
                    pass
        elif self.seq_pattern_obj:
            patterns = self.seq_pattern_obj.finditer(self.sequence)
            for match in patterns:
                span = match.span()
                for base in range(span[0],span[1]):
                    try:
                        self.dna_bit[base] = dna_color[self.dna[base]]
                    except KeyError:
                        pass
        elif self.base_span:
            start_base = self.dna[0]
            base_run = 0
            base_start = 0
            seq_end = len(self.dna)-1
            for i, base in enumerate(self.dna):
                if base == start_base:
                    base_run += 1
                    if i < seq_end:
                        continue
                if base_run >= self.base_span:
                    for bit in range(base_start, i):
                        try:
                            self.dna_bit[bit] = dna_color[start_base]
                        except KeyError:
                            pass
                start_base = base
                base_run = 0
                base_start = i

    def make_dna_image(self, shift=0):
        """Create construct matrix."""
        self.dna_span += shift      #user controlled change in dimension
        if self.dna_span < 1:
            self.dna_span = 1
        elif self.dna_span > self.dna_length:
            self.dna_span = self.dna_length
        self.dna_wrap = int(math.ceil(self.dna_length/self.dna_span))
        array_y = self.dna_span     #DNA sequence span
        array_x = self.dna_wrap     #DNA sequence wrap
        padding = (self.dna_span * self.dna_wrap) - self.dna_length  #array padded for 2d array
        self.construct_matrix = self.dna_bit[:self.dna_length+padding]  #construct matrix array
        try:
            self.construct_matrix.shape = (array_x, array_y)    #create 2d construct
        except ValueError:      #extra padding needed to create array shape
            if self.dna_length < 10000:
                xpad = self.dna_length
            else:
                xpad = 10000
            self.dna.extend(['N']*xpad)
            self.dna_bit = numpy.append(self.dna_bit, ([0x000000]*xpad))
            self.construct_matrix = self.dna_bit[:self.dna_length+padding]
            self.construct_matrix.shape = (array_x, array_y)
        self.construct_matrix = numpy.swapaxes(self.construct_matrix, 0, 1)     #reverse numpy axis
        try:
            image = pygame.Surface((self.construct_matrix.shape))    #construct image
            pygame.surfarray.blit_array(image, self.construct_matrix)
            self.image_new = image
            image_created = True
        except pygame.error:    #if dimensions too large
            self.make_dna_image(-shift)     #reset
            image_created = False
        return image_created

    def display_clear(self):
        """Clear construct image."""
        self.surface_clear = pygame.Surface(self.image_size_pre)
        self.surface_clear.fill(self.screen_color)
        rect = self.screen_dna.blit(self.surface_clear, self.image_place_pre)
        self.screen_base.blit(self.surface_clear, self.image_place_pre)
        self.update_list.append(rect)

    def display_dna_image(self):
        """Display construct image."""
        self.image = self.image_new
        x, y = self.image.get_size()
        if self.image_morph:    #adjust position with construct morphed
            self.x, self.y = [self.image_place_center[0]-(x/2), self.image_place_center[1]-(y/2)]
            self.image_morph = False
        if self.image_zoom < 1.01:
            self.image_zoomed = None
            if x < self.display_x or y < self.display_y:
                if self.zoomed:
                    self.screen_backup.fill(self.screen_color)
                    self.update_list.append(self.screen_dna.blit(self.screen_backup, (0,0)))
                    self.screen_base.blit(self.screen_backup, (0,0))
                    self.zoomed = False
                else:
                    self.display_clear()
                self.update_list.append(self.screen_dna.blit(self.image, (self.x,self.y)))
                self.screen_base.blit(self.image, (self.x,self.y))
            else:
                self.screen_backup.fill(self.screen_color)
                self.screen_backup.blit(self.image, (self.x,self.y))
                self.update_list.append(self.screen_dna.blit(self.screen_backup, (0,0)))
                self.screen_base.blit(self.screen_backup, (0,0))
        else:
            self.screen_backup.fill(self.screen_color)
            self.screen_backup.blit(self.image, (self.x,self.y))
            dx,dy = math.modf(self.x)[0], math.modf(self.y)[0]
            self.image_zoomed, offset = self.display_zoom(self.screen_backup)    #zoom an area of display
            xo,yo = int(offset[0]+(dx*self.image_zoom)), int(offset[1]+(dy*self.image_zoom))
            offset = xo,yo
            self.update_list.append(self.screen_dna.blit(self.image_zoomed, offset))
            self.screen_base.blit(self.image_zoomed, offset)
            self.zoomed = True
        self.image_place_center = [self.x+(x/2), self.y+(y/2)]
        self.image_place_pre = self.x, self.y
        self.image_size_pre = x, y

    def display_zoom(self, image):
        """Zoom construct image on display."""
        done = False
        while not done:
            try:
                subx = math.ceil(self.display_x/self.image_zoom) + 2     #subsurface dim to zoom
                suby = math.ceil(self.display_y/self.image_zoom) + 2
                if subx % 2:    #even rect dim to maintain center
                    subx += 1
                if suby % 2:
                    suby += 1
                done_sub = False
                while not done_sub:
                    try:
                        image_rect = pygame.Rect((0,0,subx,suby))   #rect of subsurface dim
                        image_rect.center = (self.display_x//2,self.display_y//2)
                        image_sub = image.subsurface(image_rect)    #create subsurface to zoom
                        done_sub = True
                    except ValueError:
                        subx = self.display_x
                        suby = self.display_y
                w, h = image_sub.get_size()
                image_zoomed = pygame.transform.smoothscale(image_sub, (int(w*self.image_zoom), int(h*self.image_zoom)))
                w, h = image_zoomed.get_size()
                offset = (self.display_x-w)/2, (self.display_y-h)/2     #offset to display dim
                done = True
            except pygame.error:    #error: Width or height is too large
                self.image_zoom -= 1.0  #reduce zoom and re-attempt scale
        return image_zoomed, offset

    def control_info(self):
        """Display help."""
        if not self.control_list:
            try:
                controls = open('control.txt', 'r')
                for item in controls:
                    key = item[:20].strip()
                    command = item[20:].strip()
                    control_item = { 'key':key, 'command':command }
                    self.control_list.append(control_item)
                controls.close()
            except IOError:
                return
        self.screen.fill((0,0,0))
        self.info.set_font_size(12)
        pos_x, pos_y = (self.display_x//2)-150, (self.display_y//2)-len(self.control_list)*8
        if pos_x < 0:
            pos_x = 0
        if pos_y < 0:
            pos_y = 0
        for control_item in self.control_list:
            self.info.add(control_item['key'])
            self.info.set_position((pos_x,pos_y))
            self.info()
            self.info.add(control_item['command'])
            self.info.set_position((pos_x+150,pos_y))
            self.info()
            pos_y += 15
        interrupt = False
        while not interrupt:
            self.control.clock.tick(40)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.control.quit = True
                    interrupt = True
                elif event.type == pygame.KEYDOWN:
                    interrupt = True
            pygame.display.flip()
        self.screen.blit(self.screen_base, (0,0))
        self.control.panel.set_update()
        if self.seq_browse:
            self.seq_interface.set_update()
        pygame.display.update()
        return

    def base_switch(self, change):
        """Set DNA base display."""
        if change:
            for base in change:
                self.base_display[base] = change[base]
        self.dna_to_bit()
        image_created = self.make_dna_image()
        if image_created:
            self.update_display = True

    def base_repeat(self, span=0):
        """Define base/pattern repeat."""
        if span:
            self.base_span += span
            if self.base_span < 0:
                self.base_span = 0
        else:
            self.base_span = 0
        if not self.seq_pattern:
            self.dna_to_bit()
        else:
            if span:
                if self.base_span:
                    spattern = self.seq_pattern*(self.base_span+1)
                else:
                    spattern = self.seq_pattern
                self.seq_pattern_obj = re.compile(spattern)
                self.dna_to_bit()
        image_created = self.make_dna_image()
        if image_created:
            self.update_display = True

    def sequence_pattern(self, pattern=None):
        """Define DNA pattern to display."""
        if pattern:
            self.seq_pattern = pattern
            self.seq_pattern_obj = re.compile(self.seq_pattern)
        else:
            self.seq_pattern = ''
            self.seq_pattern_obj = None
        self.dna_to_bit()
        image_created = self.make_dna_image()
        if image_created:
            self.update_display = True

    def reset(self):
        """Reset construct image."""
        self.seq_pattern = ''
        self.seq_pattern_obj = None
        self.base_span = 0
        self.base_switch({'G':True,'A':True,'T':True,'C':True})
        image_created = self.make_dna_image()
        if image_created:
            self.update_display = True

    def seqimage_save(self, filename='', path=''):
        """Save construct image as a png file."""
        if not filename:
            if self.seq_file:
                filename = self.seq_file.rsplit('.',1)[0] + '.png'
            else:
                if self.seq_id:
                    name = self.seq_id.split(' ')[0]
                    if len(name) > 10:
                        name = 'construct'
                else:
                    name = 'construct'
                filename = name + '.png'
        if not path:
            path = os.path.join(self.seq_folder, "images")
        if not os.path.isdir(path):
            try:
                os.mkdir(path)
            except:
                path = self.seq_folder
        fn = os.path.join(path, filename)
        image_saved = filename
        count = 1
        fn_exist = True
        while fn_exist:
            fn_exist = os.path.exists(fn)
            if fn_exist:
                image_saved = filename[:-4] + '_' + str(count) + filename[-4:]
                fn = os.path.join(path, image_saved)
                count += 1
        try:
            if not self.image_zoomed:
                save_image = self.image
            else:
                save_image = self.image_zoomed
            pygame.image.save(save_image, fn)
        except:
            print("Unable to save image.")
        return image_saved

    def sequence_info_toggle(self, switch=None):
        """Toggle DNA sequence displayed under cursor."""
        if not switch:
            self.seq_info = not self.seq_info
            return
        elif switch == 'Sequence':
            self.seq_view = not self.seq_view
            self.seq_display = ''
            self.control.panel.display_seq(self.seq_display)
        elif switch == 'Position':
            self.pos_view = not self.pos_view
            self.pos_display = ''
            self.control.panel.display_pos(self.pos_display)
        if self.seq_view or self.pos_view:
            self.seq_info = True
        else:
            self.seq_info = False

    def sequence_info_check(self, switch=None):
        """Check if sequence info is displayed."""
        if not switch:
            return self.seq_info
        elif switch == 'Sequence':
            return self.seq_view
        elif switch == 'Position':
            return self.pos_view

    def sequence_info(self):
        """Display DNA sequence under cursor."""
        pos_x,pos_y = pygame.mouse.get_pos()
        rect_interact = self.pointer_interact((pos_x,pos_y))
        if rect_interact:
            x, y = pos_x-rect_interact.x, pos_y-rect_interact.y
            seq_base = int ( ((y//self.image_zoom)*self.dna_span) + (x//self.image_zoom) )
            if seq_base < self.dna_length:
                if self.pos_view:
                    self.pos_display = str(seq_base+1)
                if self.seq_view:
                    start, end = seq_base-4, seq_base+5
                    if start < 0:
                        start = 0
                    if end > self.dna_length:
                        end = self.dna_length
                    self.seq_display = ''.join(self.dna[start:end])
            else:
                self.seq_display = ''
                self.pos_display = ''
        else:
            self.seq_display = ''
            self.pos_display = ''
        if self.pos_view:
            self.control.panel.display_pos(self.pos_display)
        if self.seq_view:
            self.control.panel.display_seq(self.seq_display)

    def shift(self, base_shift, hyper_shift=False):
        """Morph construct by shifting DNA sequence."""
        base = {'u':1,'d':-1,'l':-5,'r':5}[base_shift]
        hyper = {True:10, False:1}[hyper_shift]
        self.image_morph = True
        image_created = self.make_dna_image(base*hyper)
        if image_created:
            self.update_display = True

    def pan(self, direction, hyper_pan=False):
        """Pan construct."""
        move = {'u':(0,-10), 'd':(0,10), 'l':(-10,0), 'r':(10,0), 'ul':(-10,-10), 'ur':(10,-10), 'dl':(-10,10), 'dr':(10,10)}[direction]
        hyper = {True:5, False:1}[hyper_pan]
        self.x += ( (move[0] / self.image_zoom) * hyper )
        self.y += ( (move[1] / self.image_zoom) * hyper )
        self.update_display = True

    def drag(self, offset, hyper_pan):
        """Drag construct with pointer."""
        hyper = {True:10, False:1}[hyper_pan]
        self.x += ( (offset[0] / self.image_zoom) * hyper )
        self.y += ( (offset[1] / self.image_zoom) * hyper )
        self.update_display = True

    def zoom(self, level, hyper_zoom=False):
        """Zoom construct."""
        zoom = {'u':0.2,'d':-0.2,'l':-1.0,'r':1.0}[level]
        hyper = {True:10, False:1}[hyper_zoom]
        self.image_zoom += (zoom * hyper)
        if self.image_zoom < 1.0:
            self.image_zoom = 1.0
        elif self.image_zoom > 100.0:
            self.image_zoom = 100.0
        self.image_morph = True
        self.update_display = True

    def center_image(self):
        """Center construct."""
        pos_x, pos_y = self.image.get_size()
        self.x, self.y = [(self.display_x/2)-(pos_x/2), (self.display_y/2)-(pos_y/2)]
        self.update_display = True

    def pointer_interact(self, pos):
        """Check pointer interaction with construct."""
        x,y = self.image_place_center
        dx,dy = self.display_x//2, self.display_y//2
        if x < dx:          #adj position for zoom skew
            x += (x-dx)*(self.image_zoom-1)
        elif x > dx:
            x += (x-dx)*(self.image_zoom-1)
        if y < dy:
            y += (y-dy)*(self.image_zoom-1)
        elif y > dy:
            y += (y-dy)*(self.image_zoom-1)
        rect = self.image.get_rect(center=(x,y))
        rect.inflate_ip(rect.w*(self.image_zoom-1), rect.h*(self.image_zoom-1))     #zoom rect
        if rect.collidepoint(pos):
            return rect
        else:
            return None

    def seq_viewer(self, browse=True):
        if not self.seq_browse and browse:
            self.seq_interface.activate()
            self.seq_browse = True
        else:
            browse = False
        if not browse:
            self.seq_browse = False
            rect = (0,0,self.display_x,self.display_y-100)
            self.screen.blit(self.screen_base, (0,0), rect)
            pygame.display.update(rect)

    def update(self):
        """Update construct."""
        self.update_list = []
        if not self.seq_browse:
            if self.update_display:
                self.display_dna_image()   
                self.update_display = False
        else:
            self.seq_panel.update()
            if self.seq_interface.is_update():
                self.update_list.extend(self.seq_panel.draw(self.screen))
        if self.seq_info:
            self.sequence_info()


def config():
    seq_file = ''
    seq_folder = ''
    dna_color = {}
    display_size = ()
    display_color = -1
    display_gamma = 0
    dna_patterns = []
    try:
        seq_file = sys.argv[1]
    except: pass
    config = {'sequence_folder':None, 'dna_color':None, 'display_size':None, 'display_color':None, 'display_gamma':None, 'dna_patterns':None}
    try:
        config_file = open('config.ini')
        cfg_setting = [line.strip().split(' ',1) for line in config_file if line[:1].isalpha()]
        cfg_setting = dict(cfg_setting)
        for cfg in config:
            if cfg in cfg_setting:
                config[cfg] = cfg_setting[cfg].strip()
        config_file.close()
    except: pass
    if config['sequence_folder']:
        try:
            seq_folder = config['sequence_folder']
        except: pass
    if config['dna_color']:
        try:
            col = [obj.strip() for obj in config['dna_color'].split(',')]
            col = [obj.split(':') for obj in col]
            for setting in col:
                base = setting[0].upper()
                if base in ('G','A','T','C'):
                    dna_color[base] = int('0x'+setting[1],16)
        except: pass
    if config['display_size']:
        try:
            size = config['display_size'].split('x')
            display_size = int(size[0].strip()), int(size[1].strip())
        except: pass
    if config['display_color']:
        try:
            display_color = int('0x'+config['display_color'],16)
        except: pass
    if config['display_gamma']:
        try:
            display_gamma = float(config['display_gamma'])
        except: pass
    if config['dna_patterns']:
        try:
            pattern_file = open(config['dna_patterns'])
            dna_patterns = [line.strip().upper() for line in pattern_file if line[:1].isalpha()]
            dna_patterns = [pattern for pattern in dna_patterns if set(pattern) <= set('GATC')]
            pattern_file.close()
        except: pass
    return seq_file, seq_folder, dna_color, display_size, display_color, display_gamma, dna_patterns


def setup():
    configuration = config()
    construct = Construct(*configuration)
    control = Control(construct)
    pygame.display.update()
    return construct, control


def main():
    construct, control = setup()
    while not control.quit:
        construct.update()
        control.update()
        if construct.update_list:
            pygame.display.update(construct.update_list)

if __name__ == '__main__':
    main()

