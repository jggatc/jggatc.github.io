#!/usr/bin/env python
from __future__ import division

"""
Replicant
Copyright (C) 2009 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Replicant version 1.1
Download site: https://gatc.ca
"""

try:
    import pygame as pg
    from pygame import bufferproxy
except ImportError:
    raise ImportError("Pygame module required.")
import random
import math
import os
import sys
import optparse
from control import Control
from util import load_image, sin_table, cos_table

test = False
if not test:
    import warnings
    warnings.filterwarnings("ignore")

MATRIX_X = 500
MATRIX_Y = 500


class Matrix(object):

    def __init__(self):
        pg.init()
        pg.display.set_caption('Replicant')
        iconname = os.path.join('data', 'icon.png')
        icon = pg.image.load(iconname)
        pg.display.set_icon(icon)
        if config['display_gamma']:
            gamma_set = pg.display.set_gamma(config['display_gamma'])
        self.screen = pg.display.set_mode((MATRIX_X,MATRIX_Y))
        if config['display_gamma'] and not gamma_set:   #if prior set_gamma failed
            gamma_set = pg.display.set_gamma(config['display_gamma'])
        self.borders = self.matrix_borders()
        self.base_count = 0
        self.base_count_i = 20
        self.screen_matrix = pg.display.get_surface()
        self.control_list = []
        self.screen_base = pg.Surface((MATRIX_X,MATRIX_Y))
        self.base_image = load_image('base.png')
        self.screen_base.blit(self.base_image, (0,0))
        self.screen.blit(self.screen_base, (0,0))
        self.edge_check_count = 0   #interval to check edge
        self.update_list = []   #list of object to update display
        self.display_update = False
        self.check_count = 0
        self.check_rate = 10
        self.molecules = pg.sprite.OrderedUpdates()
        self.dna_add = False
        self.dna_move = False
        self.dna_replicate = False
        self.dna_manipulate = None
        self.dna_molecule = {}
        self.dna_count = 0
        self.dna_size = 1

    def setup(self):
        self.dna_molecule = {}
        self.dna_add = False
        self.dna_move = False
        self.dna_replicate = False
        self.dna_manipulate = None
        self.base_count = 0
        self.add_dna()
        self.base_count = self.base_count_i
        self.display_update = True
        self.matrix_update()

    def add_dna(self, x=MATRIX_X//2, y=MATRIX_Y//2, new_strand=True, bases=None):
        if new_strand == True:
            self.dna_count += 1
            replicant = Replicant()
            self.dna_molecule[self.dna_count] = replicant
        else:
            replicant = new_strand
        if bases == None:
            bases = self.base_count_i
        for i in range(bases):
            subunit = Subunit(x, y)
            replicant.subunit.add(subunit)
        return replicant

    def simulation_set(self, parameter=None):
        self.dna_add = False
        self.dna_move = False
        self.dna_replicate = False
        self.dna_manipulate = None
        if parameter == 'Add DNA':
            self.dna_add = not self.dna_add
        elif parameter == 'Move DNA':
            self.dna_move = not self.dna_move
        elif parameter == 'Replicate DNA':
            self.dna_replicate = not self.dna_replicate

    def dna_select(self, position):
        if self.dna_add:
            x,y = position
            self.add_dna(x,y)
        else:
            self.dna_manipulate = None
            for strand in self.dna_molecule:
                for base in self.dna_molecule[strand].subunit:
                    if base.rect.collidepoint(position):
                        self.dna_manipulate = self.dna_molecule[strand]
                        break
            if self.dna_manipulate:
                if self.dna_replicate:
                    self.dna_manipulate.initiate_replication()
                    self.dna_manipulate = None

    def matrix_borders(self):
        class Edge(pg.sprite.Sprite):
            def __init__(self, x, y, dim_x, dim_y, side):
                pg.sprite.Sprite.__init__(self)
                self.rect = pg.Rect(x,y,dim_x,dim_y)
                self.side = side
        borders = pg.sprite.Group()
        borders.add( Edge(0,0,MATRIX_X,1,'n') )
        borders.add( Edge(0,MATRIX_Y-2,MATRIX_X,1,'s') )
        borders.add( Edge(0,0,1,MATRIX_Y,'w') )
        borders.add( Edge(MATRIX_X-2,0,1,MATRIX_Y,'e') )
        return borders

    def matrix_update(self):
        if self.display_update:
            self.screen.blit(self.base_image, (0,0))
            self.screen_base.blit(self.base_image, (0,0))
        for strand in self.dna_molecule:
            self.dna_molecule[strand].update()
            if self.check_count > 10:
                base_at_edge = pg.sprite.groupcollide(matrix.dna_molecule[strand].subunit, self.borders, False, False)
                if base_at_edge:
                    for base in base_at_edge:
                        base.check_edge(base_at_edge[base])
                self.check_count = 0
            else:
                self.check_count += 1
            for base in self.dna_molecule[strand].subunit:
                self.molecules.add(base)
        self.molecules.clear(self.screen_matrix,self.screen_base)
        self.update_list.extend(self.molecules.draw(self.screen_matrix))
        self.molecules.empty()
        for strand in self.dna_molecule:
            self.dna_molecule[strand].molecular_bonds()

    def update(self):
        self.matrix_update()


class Subunit(pg.sprite.Sprite):
    """Nucleotide subunit of DNA molecule."""
    image = None
    mask = None

    def __init__(self, x, y):
        pg.sprite.Sprite.__init__(self)
        self.x = x
        self.y = y
        self.pos_x = float(self.x)     #float version
        self.pos_y = float(self.y)
        if not Subunit.image:  #load images on first instance
            image = load_image('molecule.png')
            Subunit.image = pg.transform.smoothscale(image, (30*matrix.dna_size,30*matrix.dna_size))
            Subunit.mask = pg.mask.from_surface(Subunit.image)
        self.direction = random.randrange(360)
        self.distance = random.randrange(1,10)
        self.image = Subunit.image
        self.rect = self.image.get_rect(center=(self.x,self.y))
        self.mask = Subunit.mask
        self.velocity = 1

    def location(self):
        """Moves distance up to 10 steps, then changes direction randomly."""
        if self.distance > 0:
            self.distance -= 1
        else:
            self.direction = random.randrange(360)
            self.distance = random.randrange(1,10)
        self.pos_x += +self.velocity*sin_table[self.direction]
        self.pos_y += -self.velocity*cos_table[self.direction]
        #self.pos_x += +self.velocity*math.sin(self.direction*math.pi/180)
        #self.pos_y += -self.velocity*math.cos(self.direction*math.pi/180)
        self.x, self.y = int(self.pos_x), int(self.pos_y)
        self.rect = self.image.get_rect(center=(self.x,self.y))

    def check_edge(self, borders):
        """Check if DNA enters border rects."""
        for border in borders:
            if border.side == 'n':
                self.direction = 180
                self.distance = 5
            elif border.side == 's':
                self.direction = 0
                self.distance = 5
            elif border.side == 'w':
                self.direction = 90
                self.distance = 5
            elif border.side == 'e':
                self.direction = 270
                self.distance = 5
        for i in range(self.distance):
            self.location()

    def shove(self, x, y):
        if self.x > x:
            distance_x = +1.0
        elif self.x < x:
            distance_x = -1.0
        else:
            distance_x = 0
        if self.y > y:
            distance_y = +1.0
        elif self.y < y:
            distance_y = -1.0
        else:
            distance_y = 0
        self.pos_x += distance_x
        self.x = int(self.pos_x)
        self.pos_y += distance_y
        self.y = int(self.pos_y)

    def update(self):
        self.location()


class Replicant(object):

    def __init__(self):
        self.subunit = pg.sprite.OrderedUpdates()
        self.replicating_fork = 0
        self.replicating_dna = None
        self.replicating_dna_new = None
        self.replication = False
        self.replication_rate = 20
        self.replication_count = self.replication_rate
        self.replicating = None    #replicating from parent dna

    def molecular_manipulate(self):
        base = matrix.dna_manipulate.subunit.sprites()[-1]
        x1 = base.x
        y1 = base.y
        x2,y2 = pg.mouse.get_pos()
        separation = math.sqrt( math.pow((x1-x2),2) + math.pow((y1-y2),2) )
        speed = 2
        if separation > 25*matrix.dna_size:
            if x1 < x2:
                x1 += speed
            elif x1 > x2:
                x1 -= speed
            if y1 < y2:
                y1 += speed
            elif y1 > y2:
                y1 -= speed
            base.x, base.y = x1, y1
            base.pos_x, base.pos_y = float(base.x), float(base.y)
            base.rect.center = (base.x, base.y)

    def molecular_interaction(self):
        speed = 1
        bases = []
        for base in self.subunit:
            bases.append(base)
        for i in range(len(bases)-1):
            try:
                x1 = bases[i].x
                y1 = bases[i].y
                x2 = bases[i+2].x
                y2 = bases[i+2].y
                separation = math.sqrt( math.pow((x1-x2),2) + math.pow((y1-y2),2) )
                if separation < 30*matrix.dna_size:
                    if x1 < x2:
                        x1 -= speed
                        x2 += speed
                    elif x1 > x2:
                        x1 += speed
                        x2 -= speed
                    if y1 < y2:
                        y1 -= speed
                        y2 += speed
                    elif y1 > y2:
                        y1 += speed
                        y2 -= speed
                    bases[i].x, bases[i].y = x1, y1
                    bases[i].pos_x, bases[i].pos_y = float(bases[i].x), float(bases[i].y)
                    bases[i].rect.center = (bases[i].x, bases[i].y)
                    bases[i+2].x, bases[i+2].y = x2, y2
                    bases[i+2].pos_x, bases[i+2].pos_y = float(bases[i+2].x), float(bases[i+2].y)
                    bases[i+2].rect.center = (bases[i+2].x, bases[i+2].y)
            except:
                pass
            speed = 1
            x1 = bases[i].x
            y1 = bases[i].y
            x2 = bases[i+1].x
            y2 = bases[i+1].y
            separation = math.sqrt( math.pow((x1-x2),2) + math.pow((y1-y2),2) )
            if separation > 21*matrix.dna_size:
                if separation < 25*matrix.dna_size:
                    speed = 1
                elif separation < 50*matrix.dna_size:
                    speed = 2
                else:
                    speed = 3
                if x1 < x2:
                    x1 += speed
                elif x1 > x2:
                    x1 -= speed
                if y1 < y2:
                    y1 += speed
                elif y1 > y2:
                    y1 -= speed
                bases[i].x, bases[i].y = x1, y1
                bases[i].pos_x, bases[i].pos_y = float(bases[i].x), float(bases[i].y)
                bases[i].rect.center = (bases[i].x, bases[i].y)
            elif separation < 19*matrix.dna_size:
                speed = 1
                if x1 < x2:
                    x1 -= speed
                elif x1 > x2:
                    x1 += speed
                if y1 < y2:
                    y1 -= speed
                elif y1 > y2:
                    y1 += speed
                bases[i].x, bases[i].y = x1, y1
                bases[i].pos_x, bases[i].pos_y = float(bases[i].x), float(bases[i].y)
                bases[i].rect.center = (bases[i].x, bases[i].y)

    def molecular_bonds(self):
        try:
            pts = []
            for base in self.subunit:
                pts.append((base.x,base.y))
            if self.replicating:
                bond_color = (255,105,120)
            else:
                bond_color = (95,105,120)
            rect = pg.draw.aalines(matrix.screen, bond_color, False, pts, 1)
            matrix.update_list.append(rect)
        except ValueError:
            pass

    def initiate_replication(self):
        if not self.replication and not self.replicating:
            self.replicating_dna = self
            self.replicating_dna_new = matrix.add_dna(new_strand=True,bases=0)
            self.replicating_dna_new.replication = True
            self.replicating_dna_new.replicating = self
            self.replication = True
            self.replication_count = self.replication_rate
            self.replicating_fork = 0

    def replicate(self):
        if not self.replicating:
            if self.replication_count >= self.replication_rate:
                if self.replicating_fork < len(self.replicating_dna.subunit):
                    x, y = self.replicating_dna.subunit.sprites()[self.replicating_fork].x, self.replicating_dna.subunit.sprites()[self.replicating_fork].y
                    x, y = x+(20*matrix.dna_size), y
                    matrix.add_dna(x,y,new_strand=self.replicating_dna_new,bases=1)
                    self.replicating_fork += 1
                    self.replication_count = 0
                else:
                    self.replicating_dna_new.replication = False
                    self.replicating_dna_new.replicating = None
                    self.replicating_dna = None
                    self.replicating_dna_new = None
                    self.replication = False
                    return
            else:
                self.replication_count += 1
        else:
            nt = self.replicating.subunit.sprites()
            for i, nucleotide in enumerate(self.subunit.sprites()):
                if i > self.replicating.replicating_fork - 5:
                    nucleotide.x, nucleotide.y = nt[i].x+(20*matrix.dna_size), nt[i].y
                    nucleotide.pos_x, nucleotide.pos_y = float(nucleotide.x), float(nucleotide.y)
                    nucleotide.rect.center = (nucleotide.x, nucleotide.y)

    def update(self):
        self.subunit.update()
        self.molecular_interaction()
        if matrix.dna_move and matrix.dna_manipulate:
            self.molecular_manipulate()
        if self.replication:
            self.replicate()


def program_options():
    config = {'display_gamma':None}
    try:
        conf = {}
        config_file = open('config.ini')
        cfg_setting = [line.strip().split(' ',1) for line in config_file if line[:1].isalpha()]
        cfg_setting = dict(cfg_setting)
        for cfg in config:
            if cfg in cfg_setting:
                conf[cfg] = cfg_setting[cfg].strip()
        config_file.close()
    except (IOError, ValueError):
        pass
    for cfg in conf:
        if cfg == 'display_gamma':
            try:
                config['display_gamma'] = float(conf['display_gamma'])
            except ValueError:
                pass
    program_usage = "%prog [options]"
    program_desc = ("Replicant")
    parser = optparse.OptionParser(usage=program_usage,description=program_desc)
    parser.add_option("-d", "--doc", dest="doc", action="store_true", help="display program documentation")
    parser.add_option("-g", dest="display_gamma", action="store", help="-g value (value: 0.5 to 3.0)")
    (options, args) = parser.parse_args()
    if options.doc:
        try:
            docfile = open('README.txt')
        except IOError:
            print("Documentation not found.")
            sys.exit()
        try:
            import textwrap
            doc = []
            for line in docfile.readlines():
                text = textwrap.wrap(line, 80)
                if text:
                    for l in text:
                        doc.append(l+'\n')
                else:
                    doc.append('\n')
        except ImportError:
            doc = docfile.readlines()
        docfile.close()
        for line in doc:
            print(line, end=' ')
        sys.exit()
    if options.display_gamma:
        try:
            gamma = float(options.display_gamma)
            if gamma > 0.0 and gamma < 0.5:
                gamma = 0.5
            elif gamma > 3.0:
                gamma = 3.0
            config['display_gamma'] = gamma
        except ValueError:
            config['display_gamma'] = None
    return config


def setup():
    global config, matrix, control, replicant
    config = program_options()
    matrix = Matrix()
    control = Control(matrix)
    matrix.setup()


setup()


def main():
    while True:
        matrix.update_list = []
        control.panel_group.clear(matrix.screen,matrix.screen_base)
        control.update()
        matrix.screen.blit(matrix.screen_base, (0,0))
        matrix.update()
        if control.panel.is_active():
            update_rect = control.panel_group.draw(matrix.screen)
            matrix.update_list.extend(update_rect)
        if not matrix.display_update:
            pg.display.update(matrix.update_list)
        else:
            matrix.display_update = False
            pg.display.flip()


if __name__ == '__main__':
    main()

