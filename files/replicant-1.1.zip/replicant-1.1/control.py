#Replicant - Copyright (C) 2009
#Released under the GPL3 License

import sys
import pygame as pg
import interphase


class MatrixInterface(interphase.Interface):

    def __init__(self, matrix, control):
        self.matrix = matrix
        self.control = control
        interphase.Interface.__init__(self, position=(250,450), image='panel.png', color=(43,50,58), size=(350,100), moveable=True, position_offset=(0,95), button_image='button.png', control_image='control.png', font_color=(175,180,185), tips_fontcolor=(175,180,185), pointer_interact=True, control_minsize=(65,65), control_size='auto', scroll_button='vertical')

    def add_controls(self):
        self.add(
            identity = 'Control',
            control_type = 'function_select',
            position = (50,50),
            size = (40,40),
            control_list = ['__Action', '__Sim'],
            icon_list = ['icon.png', 'control_restart.png'],
            link = [ ['DNA', 'Move', 'Replicate'], ['Restart', 'Exit'] ],
            link_activated = True,
            label_display = False)
        self.add(
            identity = 'DNA',
            control_type = 'control_toggle',
            position = (175,31),
            size = 'min_width',
            control_list = ['DNA'],
            tip_list = ['DNA Addition'],
            control_outline = True,
            activated_toggle = False)
        self.add(
            identity = 'Move',
            control_type = 'control_toggle',
            position = (175,55),
            size = 'min_width',
            control_list = ['Move'],
            tip_list = ['DNA Move'],
            control_outline = True,
            activated_toggle = False)
        self.add(
            identity = 'Replicate',
            control_type = 'control_toggle',
            position = (175,79),
            size = 'min_width',
            control_list = ['Replicate'],
            tip_list = ['DNA Replication'],
            control_outline = True,
            activated_toggle = False)
        self.add(
            identity = 'Restart',
            control_type = 'control_toggle',
            position = (130,50),
            size = (40,40),
            control_list = ['Restart'],
            tip_list = ['Restart Simulation'])
        self.add(
            identity = 'Exit',
            control_type = 'control_toggle',
            position = (230,50),
            size = (40,40),
            control_list = ['Exit'],
            tip_list = ['Exit Simulation'])
        self.add(
            identity = '__Fix',
            control_type = 'control_toggle',
            position = (315,90),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['!'],
            control_image = 'none',
            control_outline = True)
        self.add(
            identity = '__Help',
            control_type = 'control_toggle',
            position = (335,90),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['?'],
            control_image = 'none',
            control_outline = True)

    def update(self):
        interphase.Interface.update(self)
        state = self.get_state()
        self.control.panel_displayed = state.panel_interact
        if state.control:
            if state.control == 'DNA':
                self.get_control('Move').set_activated(False)
                self.get_control('Replicate').set_activated(False)
                if self.get_control('DNA').is_activated():
                    self.matrix.simulation_set('Add DNA')
                else:
                    self.matrix.simulation_set()
            elif state.control == 'Move':
                self.get_control('DNA').set_activated(False)
                self.get_control('Replicate').set_activated(False)
                if self.get_control('Move').is_activated():
                    self.matrix.simulation_set('Move DNA')
                else:
                    self.matrix.simulation_set()
            elif state.control == 'Replicate':
                self.get_control('DNA').set_activated(False)
                self.get_control('Move').set_activated(False)
                if self.get_control('Replicate').is_activated():
                    self.matrix.simulation_set('Replicate DNA')
                else:
                    self.matrix.simulation_set()
            elif state.control == 'Restart':
                self.get_control('DNA').set_activated(False)
                self.get_control('Move').set_activated(False)
                self.get_control('Replicate').set_activated(False)
                self.matrix.setup()
            elif state.control == 'Exit':
                pg.quit()
                sys.exit()
            elif state.control == '__Fix':
                self.set_moveable()
            elif state.control == '__Help':
                self.set_tips_display()
        return state


class Control(object):

    def __init__(self, matrix):
        self.matrix = matrix
        pg.key.set_repeat(100,10)
        self.panel, self.panel_group = self.define_controls()
        self.panel_displayed = False
        self.clock = pg.time.Clock()

    def define_controls(self):
        panel = MatrixInterface(self.matrix, self)
        panel_group = pg.sprite.RenderUpdates(panel)
        return panel, panel_group

    def check_events(self):
        for event in pg.event.get():
            if event.type == pg.MOUSEBUTTONDOWN and not self.panel_displayed:
                button1, button2, button3 = pg.mouse.get_pressed()
                if event.button == 1:
                    self.matrix.dna_select(event.pos)
            elif event.type == pg.KEYDOWN:
                if event.key == pg.K_TAB:    #pause toggle
                    pause = True
                    pg.event.set_grab(False)
                    while pause:
                        for event in pg.event.get():
                            if event.type == pg.KEYDOWN:
                                if event.key == pg.K_TAB or event.key == pg.K_ESCAPE:
                                    pause = False
                                    pg.event.set_grab(True)
                            elif event.type == pg.QUIT:
                                pg.quit()
                                sys.exit()
                        self.clock.tick(40)
            elif event.type == pg.QUIT:   #quit program
                pg.quit()
                sys.exit()

    def update(self):
        self.panel_group.update()
        self.check_events()
        self.clock.tick(40)

