Replicant

Project site:
https://gatc.ca/projects/replicant/

Replicant simulates the molecule of life, DNA. The source can be run with 'python replicant.py'. Replicant is released under the GPL3 License, see LICENSE.txt for further information.

Dependencies:
    Python 2.7+:    https://python.org/
    PyGame 1.9+:    https://pygame.org/

To run type 'python replicant.py' at command line.
Command line options:
    -h, --help        show this help message and exit
    -d, --doc         display program documentation
    -g DISPLAY_GAMMA  -g value (value: 0.5 to 3.0)
    >options can also be set in config.ini

