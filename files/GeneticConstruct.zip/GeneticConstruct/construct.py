#!/usr/bin/env python
from __future__ import division

"""
Genetic Construct
Copyright (C) 2010 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Genetic Construct version 1.2
Download Site: http://gatc.ca

Dependencies:
    Python 2.6:   http://www.python.org/
    PyGame 1.8:   http://www.pygame.org/
    Numpy 1.3:    http://numpy.scipy.org/
"""


try:
    import pygame
    from pygame.locals import *
    from pygame import bufferproxy
    import numpy
except ImportError:
    raise ImportError, "Pygame and Numpy modules are required."
import math
import sys
import os
import shutil
import re
import interphase


class Construct(object):
    """
    Genetic Construct.
    """
    def __init__(self, seq_file='', seq_path='', dna_color={}, size=(), bgcolor=-1, gamma=0.0, dna_patterns=[]):
        self.initialize(size, bgcolor, gamma)
        if dna_color:
            self.dna_color = dna_color      #construct bit color of DNA bases
        else:
            self.dna_color = {'G':0xd9d9d9, 'A':0x00ff00, 'T':0xff0000, 'C':0x0000ff}
        self.dna_color['N'] = self.screen_color
        self.dna_patterns = dna_patterns    #dna search patterns, can be initiated with patterns.ini
        self.update_list = []   #screen rects to be updated
        self.update_display = False     #if display requires updating
        self.control_list = []      #list of program controls for help display
        self.info = interphase.Text(self.screen)      #to display help
        self.info.set_font_color((82,96,116))
        self.seq_info = False   #if sequence info is displayed
        self.seq_view = False   #if sequence is displayed
        self.seq_display = ''   #sequence under pointer
        self.pos_view = False   #if position is displayed
        self.pos_display = ''   #position under pointer
        self.seq_pattern = ''   #sequence pattern to search
        self.seq_pattern_obj = None     #sequence pattern re obj
        self.dna = []       #DNA sequence source for construct
        if not seq_path:
            self.seq_folder = os.path.expanduser('sequence')
        else:
            self.seq_folder = os.path.expanduser(seq_path)
        if seq_file:    #if sequence file entered at commandline
            try:
                seq_filename = os.path.basename(seq_file)
                seq_path = os.path.dirname(seq_file)
                if not seq_path:
                    seq_path = os.getcwd()
            except:
                seq_filename = ''
                seq_path = ''
            self.make_construct(seq_filename, seq_path)     #make construct from DNA source

    def initialize(self, size, bgcolor, gamma):
        """Initialize program."""
        pygame.display.init()   #pygame.init()
        pygame.font.init()      #pygame.init()
        if size:
            self.display_x, self.display_y = size       #display dim
        else:
            self.display_x, self.display_y = 500, 500
        if gamma:
            gamma_set = pygame.display.set_gamma(gamma)     #screen gamma
        self.screen = pygame.display.set_mode((self.display_x,self.display_y))  #init pygame display surface
        if gamma and not gamma_set:   #if prior set_gamma failed
            gamma_set = pygame.display.set_gamma(gamma)
        self.screen_dna = pygame.display.get_surface()
        self.screen_base = pygame.Surface((self.display_x,self.display_y))
        self.screen_backup = pygame.Surface((self.display_x,self.display_y))
        self.image_zoomed = None
        if bgcolor == -1:
            bgcolor = 0x2e3436
        self.screen_color = (bgcolor)
        self.screen_base.fill(self.screen_color)
        self.screen.blit(self.screen_base, (0,0))
        pygame.display.set_caption('Genetic Construct')
        iconname = os.path.join('data', 'icon.png')
        icon = pygame.image.load(iconname)
        pygame.display.set_icon(icon)
        pygame.surfarray.use_arraytype('numpy')     #set numpy array for pygame

    def make_construct(self, seq_file, path=''):
        """Create construct from DNA sequence."""
        self.dna, self.seq_id, self.dna_bit = self.dna_input(seq_file, path)
        self.sequence = ''.join(self.dna)
        if not self.dna:
            return
        self.screen_base.fill(self.screen_color)
        self.screen.blit(self.screen_base, (0,0))
        pygame.display.update()
        self.x, self.y = 0.0, 0.0       #location of construct
        self.image_place_pre = [0.0, 0.0]   #location of construct of prior blit
        self.image_place_center = [0.0, 0.0]    #construct center
        self.image_zoom = 1.0       #construct zoom magnitude
        self.zoomed = False         #if previous display was zoomed
        self.image_morph = False    #if construct was morphed
        self.base_span = 0      #runs of base or pattern
        self.base_display = {'G':True, 'A':True, 'T':True, 'C':True, 'N':True}  #base to display in construct
        self.dna_to_bit()   #convert sequence base to color bit
        self.image = pygame.Surface((int(self.dna_length/self.dna_span),self.dna_span))   #construct
        self.surface_clear = self.image.copy()    #surface to clear construct
        self.image_size_pre = self.image.get_size()
        image_created = self.make_dna_image()   #construct image creation
        if image_created:
            self.center_image()
            self.update_display = True

    def dna_input(self, filename, path):
        """Load in DNA sequence."""
        self.seq_file = filename
        if not path:
            path = self.seq_folder
        seq_id = ''
        try:
            if path:
                filename = os.path.join(path, filename)
            with open(filename) as seq_file:
                seq_file.seek(0)
                line = seq_file.readline()
                if line.startswith('>'):
                    seq_id = line.lstrip('>').strip()   #obtain seq_id from fasta file
                seq_file.seek(0)
                DNA = [line for line in seq_file if not (line.startswith('>') or line.startswith(';'))]
        except IOError:
            DNA = []
        dna = [base.upper() for line in DNA for base in line if base in ('G','A','T','C','N','g','a','t','c','n')]
        if dna:
            self.dna_length = len(dna)
            if self.dna_length < 1000:
                padding = self.dna_length
            else:
                padding = 1000
            dna.extend(['N']*padding)  #padding for various arrays
            self.dna_span = int(math.ceil(math.sqrt(self.dna_length)))  #generate square image
            self.dna_wrap = int(math.ceil(self.dna_length/self.dna_span))
        dna_bit = numpy.zeros(len(dna), 'i')    #numpy array for dna color bit
        return dna, seq_id, dna_bit

    def dna_to_bit(self):
        """Translate DNA sequence to bit sequence."""
        dna_color = {}
        for base in self.base_display:
            if self.base_display[base]:
                dna_color[base] = self.dna_color[base]
        self.dna_bit.fill(0x000000)
        if not self.base_span and not self.seq_pattern_obj:
            for i, base in enumerate(self.dna):
                try:
                    self.dna_bit[i] = dna_color[base]
                except KeyError:
                    pass
        elif self.seq_pattern_obj:
            patterns = self.seq_pattern_obj.finditer(self.sequence)
            for match in patterns:
                span = match.span()
                for base in range(span[0],span[1]):
                    try:
                        self.dna_bit[base] = dna_color[self.dna[base]]
                    except KeyError:
                        pass
        elif self.base_span:
            start_base = self.dna[0]
            base_run = 0
            base_start = 0
            seq_end = len(self.dna)-1
            for i, base in enumerate(self.dna):
                if base == start_base:
                    base_run += 1
                    if i < seq_end:
                        continue
                if base_run >= self.base_span:
                    for bit in xrange(base_start, i):
                        try:
                            self.dna_bit[bit] = dna_color[start_base]
                        except KeyError:
                            pass
                start_base = base
                base_run = 0
                base_start = i

    def make_dna_image(self, shift=0):
        """Create construct matrix."""
        self.dna_span += shift      #user controlled change in dimension
        if self.dna_span < 1:
            self.dna_span = 1
        elif self.dna_span > self.dna_length:
            self.dna_span = self.dna_length
        self.dna_wrap = int(math.ceil(self.dna_length/self.dna_span))
        array_y = self.dna_span     #DNA sequence span
        array_x = self.dna_wrap     #DNA sequence wrap
        padding = (self.dna_span * self.dna_wrap) - self.dna_length  #array padded for 2d array
        self.construct_matrix = self.dna_bit[:self.dna_length+padding]  #construct matrix array
        try:
            self.construct_matrix.shape = (array_x, array_y)    #create 2d construct
        except ValueError:      #extra padding needed to create array shape
            if self.dna_length < 10000:
                xpad = self.dna_length
            else:
                xpad = 10000
            self.dna.extend(['N']*xpad)
            self.dna_bit = numpy.append(self.dna_bit, ([0x000000]*xpad))
            self.construct_matrix = self.dna_bit[:self.dna_length+padding]
            self.construct_matrix.shape = (array_x, array_y)
        self.construct_matrix = numpy.swapaxes(self.construct_matrix, 0, 1)     #reverse numpy axis
        try:
            image = pygame.Surface((self.construct_matrix.shape))    #construct image
            pygame.surfarray.blit_array(image, self.construct_matrix)
            self.image_new = image
            image_created = True
        except pygame.error:    #if dimensions too large
            self.make_dna_image(-shift)     #reset
            image_created = False
        return image_created

    def display_clear(self):
        """Clear construct image."""
        self.surface_clear = pygame.Surface(self.image_size_pre)
        self.surface_clear.fill(self.screen_color)
        rect = self.screen_dna.blit(self.surface_clear, self.image_place_pre)
        self.screen_base.blit(self.surface_clear, self.image_place_pre)
        self.update_list.append(rect)

    def display_dna_image(self):
        """Display construct image."""
        self.image = self.image_new
        x, y = self.image.get_size()
        if self.image_morph:    #adjust position with construct morphed
            self.x, self.y = [self.image_place_center[0]-(x/2), self.image_place_center[1]-(y/2)]
            self.image_morph = False
        if self.image_zoom < 1.01:
            self.image_zoomed = None
            if x < self.display_x or y < self.display_y:
                if self.zoomed:
                    self.screen_backup.fill(self.screen_color)
                    self.update_list.append(self.screen_dna.blit(self.screen_backup, (0,0)))
                    self.screen_base.blit(self.screen_backup, (0,0))
                    self.zoomed = False
                else:
                    self.display_clear()
                self.update_list.append(self.screen_dna.blit(self.image, (self.x,self.y)))
                self.screen_base.blit(self.image, (self.x,self.y))
            else:
                self.screen_backup.fill(self.screen_color)
                self.screen_backup.blit(self.image, (self.x,self.y))
                self.update_list.append(self.screen_dna.blit(self.screen_backup, (0,0)))
                self.screen_base.blit(self.screen_backup, (0,0))
        else:
            self.screen_backup.fill(self.screen_color)
            self.screen_backup.blit(self.image, (self.x,self.y))
            dx,dy = math.modf(self.x)[0], math.modf(self.y)[0]
            self.image_zoomed, offset = self.display_zoom(self.screen_backup)    #zoom an area of display
            xo,yo = int(offset[0]+(dx*self.image_zoom)), int(offset[1]+(dy*self.image_zoom))
            offset = xo,yo
            self.update_list.append(self.screen_dna.blit(self.image_zoomed, offset))
            self.screen_base.blit(self.image_zoomed, offset)
            self.zoomed = True
        self.image_place_center = [self.x+(x/2), self.y+(y/2)]
        self.image_place_pre = self.x, self.y
        self.image_size_pre = x, y

    def display_zoom(self, image):
        """Zoom construct image on display."""
        done = False
        while not done:
            try:
                subx = math.ceil(self.display_x/self.image_zoom) + 2     #subsurface dim to zoom
                suby = math.ceil(self.display_y/self.image_zoom) + 2
                if subx % 2:    #even rect dim to maintain center
                    subx += 1
                if suby % 2:
                    suby += 1
                done_sub = False
                while not done_sub:
                    try:
                        image_rect = pygame.Rect((0,0,subx,suby))   #rect of subsurface dim
                        image_rect.center = (self.display_x//2,self.display_y//2)
                        image_sub = image.subsurface(image_rect)    #create subsurface to zoom
                        done_sub = True
                    except ValueError:
                        subx = self.display_x
                        suby = self.display_y
                w, h = image_sub.get_size()
                image_zoomed = pygame.transform.smoothscale(image_sub, (int(w*self.image_zoom), int(h*self.image_zoom)))
                w, h = image_zoomed.get_size()
                offset = (self.display_x-w)/2, (self.display_y-h)/2     #offset to display dim
                done = True
            except pygame.error:    #error: Width or height is too large
                self.image_zoom -= 1.0  #reduce zoom and re-attempt scale
        return image_zoomed, offset

    def control_info(self):
        """Display help."""
        if not self.control_list:
            try:
                controls = open('control.txt', 'r')
                for item in controls:
                    key = item[:20].strip()
                    command = item[20:].strip()
                    control_item = { 'key':key, 'command':command }
                    self.control_list.append(control_item)
                controls.close()
            except IOError:
                return
        self.screen.fill((0,0,0))
        self.info.set_font_size(12)
        pos_x, pos_y = (self.display_x//2)-150, (self.display_y//2)-len(self.control_list)*8
        if pos_x < 0:
            pos_x = 0
        if pos_y < 0:
            pos_y = 0
        for control_item in self.control_list:
            self.info.add(control_item['key'])
            self.info.set_position((pos_x,pos_y))
            self.info()
            self.info.add(control_item['command'])
            self.info.set_position((pos_x+150,pos_y))
            self.info()
            pos_y += 15
        interrupt = False
        while not interrupt:
            control.clock.tick(40)
            for event in pygame.event.get():
                if event.type == QUIT:
                    control.quit = True
                    interrupt = True
                elif event.type == KEYDOWN:
                    interrupt = True
            pygame.display.flip()
        self.screen.blit(self.screen_base, (0,0))
        pygame.display.update()
        return

    def base_switch(self, change):
        """Set DNA base display."""
        if change:
            for base in change:
                self.base_display[base] = change[base]
        self.dna_to_bit()
        image_created = self.make_dna_image()
        if image_created:
            self.update_display = True

    def base_repeat(self, span=0):
        """Define base/pattern repeat."""
        if span:
            self.base_span += span
            if self.base_span < 0:
                self.base_span = 0
        else:
            self.base_span = 0
        if not self.seq_pattern:
            self.dna_to_bit()
        else:
            if span:
                if self.base_span:
                    spattern = self.seq_pattern*(self.base_span+1)
                else:
                    spattern = self.seq_pattern
                self.seq_pattern_obj = re.compile(spattern)
                self.dna_to_bit()
        image_created = self.make_dna_image()
        if image_created:
            self.update_display = True

    def sequence_pattern(self, pattern=None):
        """Define DNA pattern to display."""
        if pattern:
            self.seq_pattern = pattern
            self.seq_pattern_obj = re.compile(self.seq_pattern)
        else:
            self.seq_pattern = ''
            self.seq_pattern_obj = None
        self.dna_to_bit()
        image_created = self.make_dna_image()
        if image_created:
            self.update_display = True

    def reset(self):
        """Reset construct image."""
        self.seq_pattern = ''
        self.seq_pattern_obj = None
        self.base_span = 0
        self.base_switch({'G':True,'A':True,'T':True,'C':True})
        image_created = self.make_dna_image()
        if image_created:
            self.update_display = True

    def seqimage_save(self, filename='', path=''):
        """Save construct image as a png file."""
        if not filename:
            filename = self.seq_file.rsplit('.',1)[0] + '.png'
        if not path:
            path = os.path.join(self.seq_folder, "images")
        if not os.path.isdir(path):
            try:
                os.mkdir(path)
            except:
                path = self.seq_folder
        fn = os.path.join(path, filename)
        image_saved = filename
        count = 1
        available = True
        while available:
            available = os.path.exists(fn)
            if available:
                image_saved = filename[:-4] + '_' + str(count) + filename[-4:]
                fn = os.path.join(path, image_saved)
                count += 1
                if count > 10000:
                    print("Unable to save image.")
                    return
        try:
            if not self.image_zoomed:
                save_image = self.image
            else:
                save_image = self.image_zoomed
            pygame.image.save(save_image, fn)
        except:
            print("Unable to save image.")
        return image_saved

    def sequence_info_toggle(self, switch):
        """Toggle DNA sequence displayed under cursor."""
        if switch == 'Sequence':
            self.seq_view = not self.seq_view
            self.seq_display = ''
            control.panel.display_seq(self.seq_display)
        elif switch == 'Position':
            self.pos_view = not self.pos_view
            self.pos_display = ''
            control.panel.display_pos(self.pos_display)
        if self.seq_view or self.pos_view:
            self.seq_info = True
        else:
            self.seq_info = False

    def sequence_info(self):
        """Display DNA sequence under cursor."""
        pos_x,pos_y = pygame.mouse.get_pos()
        rect_interact = self.pointer_interact((pos_x,pos_y))
        if rect_interact:
            x, y = pos_x-rect_interact.x, pos_y-rect_interact.y
            seq_base = int ( ((y//self.image_zoom)*self.dna_span) + (x//self.image_zoom) )
            if seq_base < self.dna_length:
                if self.pos_view:
                    self.pos_display = str(seq_base+1)
                if self.seq_view:
                    start, end = seq_base-4, seq_base+5
                    if start < 0:
                        start = 0
                    if end > self.dna_length:
                        end = self.dna_length
                    self.seq_display = ''.join(self.dna[start:end])
            else:
                self.seq_display = ''
                self.pos_display = ''
        else:
            self.seq_display = ''
            self.pos_display = ''
        if self.pos_view:
            control.panel.display_pos(self.pos_display)
        if self.seq_view:
            control.panel.display_seq(self.seq_display)

    def shift(self, base_shift, hyper_shift=False):
        """Morph construct by shifting DNA sequence."""
        base = {'u':1,'d':-1,'l':-5,'r':5}[base_shift]
        hyper = {True:10, False:1}[hyper_shift]
        self.image_morph = True
        image_created = self.make_dna_image(base*hyper)
        if image_created:
            self.update_display = True

    def pan(self, direction, hyper_pan=False):
        """Pan construct."""
        move = {'u':(0,-10), 'd':(0,10), 'l':(-10,0), 'r':(10,0), 'ul':(-10,-10), 'ur':(10,-10), 'dl':(-10,10), 'dr':(10,10)}[direction]
        hyper = {True:5, False:1}[hyper_pan]
        self.x += ( (move[0] / self.image_zoom) * hyper )
        self.y += ( (move[1] / self.image_zoom) * hyper )
        self.update_display = True

    def drag(self, offset, hyper_pan):
        """Drag construct with pointer."""
        hyper = {True:10, False:1}[hyper_pan]
        self.x += ( (offset[0] / self.image_zoom) * hyper )
        self.y += ( (offset[1] / self.image_zoom) * hyper )
        self.update_display = True

    def zoom(self, level, hyper_zoom=False):
        """Zoom construct."""
        zoom = {'u':0.2,'d':-0.2,'l':-1.0,'r':1.0}[level]
        hyper = {True:10, False:1}[hyper_zoom]
        self.image_zoom += (zoom * hyper)
        if self.image_zoom < 1.0:
            self.image_zoom = 1.0
        elif self.image_zoom > 100.0:
            self.image_zoom = 100.0
        self.image_morph = True
        self.update_display = True

    def center_image(self):
        """Center construct."""
        pos_x, pos_y = self.image.get_size()
        self.x, self.y = [(self.display_x/2)-(pos_x/2), (self.display_y/2)-(pos_y/2)]
        self.update_display = True

    def pointer_interact(self, pos):
        """Check pointer interaction with construct."""
        x,y = self.image_place_center
        dx,dy = self.display_x//2, self.display_y//2
        if x < dx:          #adj position for zoom skew
            x += (x-dx)*(self.image_zoom-1)
        elif x > dx:
            x += (x-dx)*(self.image_zoom-1)
        if y < dy:
            y += (y-dy)*(self.image_zoom-1)
        elif y > dy:
            y += (y-dy)*(self.image_zoom-1)
        rect = self.image.get_rect(center=(x,y))
        rect.inflate_ip(rect.w*(self.image_zoom-1), rect.h*(self.image_zoom-1))     #zoom rect
        if rect.collidepoint(pos):
            return rect
        else:
            return None

    def update(self):
        """Update construct."""
        self.update_list = []
        if self.update_display:
            self.display_dna_image()   
            self.update_display = False
        if self.seq_info:
            self.sequence_info()


class ConstructInterface(interphase.Interface):
    """
    Construct interface.
    """
    def __init__(self, dna_color, dna_patterns):
        self.dna_color = dna_color
        self.seq_patterns = ['None', '']
        self.seq_patterns[1:1] = dna_patterns
        interphase.Interface.__init__(self, position=(construct.display_x//2,construct.display_y-50), image='panel.png', color=(143,150,158), size=(350,100), moveable=True, position_offset=(0,90), font_color=(255,255,255), info_fontcolor=(255,255,255), tips_fontcolor=(175,180,185), control_minsize=(29,29), control_size='auto', label_display=True)

    def add_controls(self):
        """Add interface controls."""
        self.add(
            identity = 'Control',
            control_type = 'function_select',
            position = (50,50),
            size = (40,40),
            control_image = ['none'],
            control_outline = False,
            control_list = ['__Construct', '__Controls', '__Patterns', '__Sequence', '__Exit'],
            link = [ ['Files', '__FileLabel', '__SeqIDLabel'], ['Tool', 'Compass', 'u', 'd', 'l', 'r', 'ul', 'ur', 'dl', 'dr'], ['G', 'A', 'T', 'C', 'Run', 'Pattern', 'Patterns'], ['Sequence', 'Position', 'Save', '__SaveLabel'], ['Exit'] ],
            link_activated = True,
            label_display = False)
        self.add(
            identity = 'Tool',
            control_type = 'function_toggle',
            position = (110,50),
            size = (30,30),
            control_list = ['__DNA', '__Pan', '__Zoom'],
            icon_list = ['control_dna.png', 'control_compass.png', 'control_zoom.png'],
            tip_list = ['Shift', 'Pan', 'Zoom'],
            link_activated = True,
            label_display = False)
        self.add(
            identity = 'Compass',
            control_type = 'control_toggle',
            position = (175,50),
            size = (25,25),
            control_list = [''],
            color = (0,20,30),
            activated_color = (60,60,100),
            activated_toggle = False,
            control_outline = True,
            label_display = False,
            control_response = 1000,
            hold_response = 0,
            delay_response = 500)
        for ident, tip, img, pos in ( ('u',[''],'control_u.png',(175,25)), ('d',[''],'control_d.png',(175,75)), ('l',[''],'control_l.png',(150,50)), ('r',[''],'control_r.png',(200,50)) ):
            self.add(
                identity = ident,
                control_type = 'control_toggle',
                position = pos,
                size = (25,25),
                control_list = [''],
                tip_list = tip,
                control_image = img,
                label_display = False,
                control_response = 0)
        for ident, tip, pos in ( ('ul',[''],(150,25)), ('ur',[''],(200,25)), ('dl',[''],(150,75)), ('dr',[''],(200,75)) ):
            self.add(
                identity = ident,
                control_type = 'control_toggle',
                position = pos,
                size = (25,25),
                control_list = [''],
                tip_list = tip,
                label_display = False,
                control_response = 0)
        self.add(
            identity = 'G',
            control_type = 'control_toggle',
            position = (110,35),
            size = 'min',
            control_list = ['ON', 'OFF'],
            tip_list = ['Guanine'],
            control_outline = True,
            color = (0,0,0),
            activated_color = self.dna_color['G'],
            control_response = 500)
        self.add(
            identity = 'A',
            control_type = 'control_toggle',
            position = (140,35),
            size = 'min',
            control_list = ['ON', 'OFF'],
            tip_list = ['Adenine'],
            control_outline = True,
            color = (0,0,0),
            activated_color = self.dna_color['A'],
            control_response = 500)
        self.add(
            identity = 'T',
            control_type = 'control_toggle',
            position = (170,35),
            size = 'min',
            control_list = ['ON', 'OFF'],
            tip_list = ['Thymidine'],
            control_outline = True,
            color = (0,0,0),
            activated_color = self.dna_color['T'],
            control_response = 500)
        self.add(
            identity = 'C',
            control_type = 'control_toggle',
            position = (200,35),
            size = 'min',
            control_list = ['ON', 'OFF'],
            tip_list = ['Cytosine'],
            control_outline = True,
            color = (0,0,0),
            activated_color = self.dna_color['C'],
            control_response = 500)
        self.add(
            identity = 'Run',
            control_type = 'control_select',
            position = (230,35),
            size = 'min',
            control_list = ['__numeric', (1,25)],
            tip_list = ['Sequence Run'])
        self.add(
            identity = 'Pattern',
            control_type = 'control_select',
            position = (110,75),
            size = (22,22),
            control_list = ['G', 'A', 'T', 'C', '<'],
            tip_list = ['Set'],
            loop = False)
        self.add(
            identity = 'Patterns',
            control_type = 'control_select',
            position = (190,75),
            size = (100,22),
            control_list = self.seq_patterns,
            tip_list = ['Sequence Pattern'],
            split_text = False,
            reverse = True,
            label_display = False)
        self.add(
            identity = 'Sequence',
            control_type = 'control_toggle',
            position = (175,25),
            size = (75,20),
            control_list = ['Sequence'],
            tip_list = ['Show DNA Sequence'],
            control_outline = True,
            split_text = False,
            label_display = False,
            activated_toggle = 'lock')
        self.add(
            identity = '__SeqLabel',
            control_type = 'label',
            position = (50,8),
            control_list = [''])
        self.add(
            identity = 'Position',
            control_type = 'control_toggle',
            position = (175,50),
            size = (75,20),
            control_list = ['Position'],
            tip_list = ['Show Sequence Position'],
            control_outline = True,
            split_text = False,
            label_display = False,
            activated_toggle = 'lock')
        self.add(
            identity = '__PosLabel',
            control_type = 'label',
            position = (330,8),
            control_list = [''])
        self.add(
            identity = 'Save',
            control_type = 'control_toggle',
            position = (175,75),
            size = (75,20),
            control_list = ['Image Save'],
            tip_list = ['Save Construct Image'],
            control_outline = True,
            split_text = False,
            label_display = False)
        self.add(
            identity = '__SaveLabel',
            control_type = 'label',
            position = (180,95),
            control_list = [''])
        self.add(
            identity = 'Files',
            control_type = 'control_select',
            position = (175,75),
            size = 'auto_width',
            control_list = ['__filelist', construct.seq_folder, '', ''],
            tip_list = ['Sequence Files'],
            label_display = False)
        self.add(
            identity = '__FileLabel',
            control_type = 'label',
            position = (184,20),
            control_list = [''])
        self.add(
            identity = '__SeqIDLabel',
            control_type = 'label',
            position = (184,30),
            control_list = [''])
        self.add(
            identity = 'Exit',
            control_type = 'control_toggle',
            position = (175,50),
            size = (40,40),
            control_list = ['Exit'],
            tip_list = ['Exit Program'],
            label_display = False)
        self.add(
            identity = '__Fix',
            control_type = 'control_toggle',
            position = (315,90),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['!'],
            control_image = ['none'],
            control_outline = True)
        self.add(
            identity = '__Help',
            control_type = 'control_toggle',
            position = (335,90),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['?'],
            control_image = ['none'],
            control_outline = True,
            activated_toggle = False)
        if not construct.dna:
            self.get_control('Control').set_active(False)

    def display_seq(self, seq):
        """Set sequence to display."""
        ctrl = self.get_control('__SeqLabel')
        if ctrl.get_value() != seq:
            ctrl.set_value(seq)

    def display_pos(self, pos):
        """Set sequence position to display."""
        ctrl = self.get_control('__PosLabel')
        if ctrl.get_value() != pos:
            ctrl.set_value(pos)

    def reset(self):
        """Reset interface controls."""
        for ctrl_id, ctrl in self.get_control('G','A','T','C').iteritems():
            ctrl.set_value('ON')
        self.get_control('Run').set_value(1)

    def update(self):
        """Interface update."""
        global construct
        interphase.Interface.update(self)
        state = self.get_state()
        control.panel_interact = state.panel_interact
        if state.control:
            if state.control == 'Control':
                state.controls['__SaveLabel'].set_value('')
            elif state.control == 'Tool':
                self.tool = state.value[2:]
                state.controls['Compass'].set_activated(False)  
            elif state.control in ('u','d','l','r'):
                hyper = state.controls['Compass'].is_activated()
                function = state.values['Tool'][2:]
                if function == 'DNA':
                    construct.shift(state.control, hyper)
                elif function == 'Pan':
                    construct.pan(state.control, hyper)
                elif function == 'Zoom':
                    construct.zoom(state.control, hyper)
            elif state.control in ('ul','ur','dl','dr'):
                self.ctrl_counter = 0
                if state.values['Tool'][2:] == 'Pan':
                    hyper = state.controls['Compass'].is_activated()
                    construct.pan(state.control, hyper)
            elif state.control in ('G','A','T','C'):
                switch = {'ON':True,'OFF':False}[state.value]
                construct.base_switch({state.control:switch})
            elif state.control == 'Run':
                if state.button == 'Run_top':
                    construct.base_repeat(1)
                elif state.button == 'Run_bottom':
                    construct.base_repeat(-1)
            elif state.control == 'Pattern':
                if state.button == 'Pattern':
                    if state.value in ('G','A','T','C'):
                        patterns = state.controls['Patterns']
                        place = patterns.get_list_index()
                        if place == 0:
                            place = len(self.seq_patterns)-1
                            self.seq_patterns.append('')
                            patterns.set_list([''], append=True) 
                        elif place == len(self.seq_patterns)-1:
                            self.seq_patterns.append('')
                            patterns.set_list([''], append=True) 
                        self.seq_patterns[place] += state.value
                        patterns.set_list([self.seq_patterns[place][:10]], index=place)
                        patterns.set_list_index(place)
                        patterns.set_tip([self.seq_patterns[place]])
                        patterns.set_value(self.seq_patterns[place][-10:], change_index=False)
                    elif state.value == '<':
                        patterns = state.controls['Patterns']
                        place = patterns.get_list_index()
                        if place > 0:
                            if self.seq_patterns[place]:
                                self.seq_patterns[place] = self.seq_patterns[place][:-1]
                                patterns.set_list([self.seq_patterns[place][:10]], index=place)
                                patterns.set_tip([self.seq_patterns[place]])
                                patterns.set_value(self.seq_patterns[place][-10:], change_index=False)
            elif state.control == 'Patterns':
                place = state.controls['Patterns'].get_list_index()
                if self.seq_patterns[place] == 'None':
                    state.controls['Patterns'].set_tip(['Sequence Pattern'])
                else:
                    state.controls['Patterns'].set_tip([self.seq_patterns[place]])
                if state.button == 'Patterns':
                    self.reset()
                    construct.reset()
                    if state.value is not 'None':
                        place = state.controls['Patterns'].get_list_index()
                        construct.sequence_pattern(self.seq_patterns[place])
                    else:
                        construct.sequence_pattern()
            elif state.control == 'Sequence':
                construct.sequence_info_toggle('Sequence')
            elif state.control == 'Position':
                construct.sequence_info_toggle('Position')
            elif state.control == 'Save':
                image_saved = construct.seqimage_save()
                state.controls['__SaveLabel'].set_value(image_saved)
            elif state.control == 'Files':
                if state.button == 'Files':
                    construct.make_construct(state.value)
                    base_change = {}
                    for ctrl in ('G','A','T','C'):
                        if state.values[ctrl] == 'OFF':
                            base_change[ctrl] = {'ON':True,'OFF':False}[state.values[ctrl]]
                    if base_change:
                        construct.base_switch(base_change)
                    if state.values['Run'] > 1:
                        construct.base_repeat(state.values['Run']-1)
                    state.controls['__FileLabel'].set_value(state.value)
                    state.controls['__SeqIDLabel'].set_value(construct.seq_id[:65])
                    if construct.dna:
                        if not state.controls['Control'].is_active():
                            state.controls['Control'].set_active(True)
                            control.check_events_set(True)
            elif state.control == 'Exit':
                control.quit = True
            elif state.control == '__Fix':
                self.set_moveable('Fixed')
            elif state.control == '__Help':
                if state.controls['__Help'].is_activated():
                    for ctrl_id, ctrl in self.get_control('G','A','T','C').iteritems():
                        ctrl.set_label_text(font_color=self.dna_color[ctrl_id])
                else:
                    for ctrl_id, ctrl in self.get_control('G','A','T','C').iteritems():
                        ctrl.set_label_text(font_color=(255,255,255))
                self.set_tips_display()
        return state


class Control(object):
    """
    Construct control.
    """
    def __init__(self):
        dna_color = construct.dna_color.copy()
        dna_patterns = construct.dna_patterns[:]
        for base in dna_color:
            dna_color[base] = self.hex_to_rgb(dna_color[base])
        self.dna_color = dna_color
        self.panel, self.panel_group = self.define_controls(dna_color,dna_patterns)
        self.mouse_pan = False
        self.save_image = False
        self.panel_interact = False
        pygame.key.set_repeat(100,10)
        self.clock = pygame.time.Clock()
        self.quit = False
        if construct.dna:
            self.check_events_set(True)
        else:
            self.check_events_set(False)

    def define_controls(self, dna_color, dna_patterns):
        """Initiate interface panel."""
        panel = ConstructInterface(dna_color,dna_patterns)
        panel_group = pygame.sprite.RenderUpdates(panel)
        return panel, panel_group

    def check_events_set(self, active):
        """Set user input method."""
        if active:
            self.check_events = self.check_events_max
        else:
            self.check_events = self.check_events_min

    def check_events_max(self):
        """Check user input."""
        for event in pygame.event.get():
            if event.type == KEYDOWN:
                if event.key in (K_UP, K_DOWN, K_RIGHT, K_LEFT):
                    ctrl = {K_UP:'u', K_DOWN:'d', K_RIGHT:'r', K_LEFT:'l'}
                    mod = pygame.key.get_mods()
                    if not mod:
                        construct.shift(ctrl[event.key])    #shift sequence
                    elif mod & KMOD_CTRL:
                        if mod & KMOD_SHIFT:
                            hyper_pan = True
                        else:
                            hyper_pan = False
                        construct.pan(ctrl[event.key], hyper_pan)      #pan display
                    elif mod & KMOD_ALT:
                        if mod & KMOD_SHIFT:
                            hyper_zoom = True
                        else:
                            hyper_zoom = False
                        construct.zoom(ctrl[event.key], hyper_zoom)     #zoom display
                    elif mod & KMOD_SHIFT:
                        construct.shift(ctrl[event.key], hyper_shift=True)    #shift sequence
                elif event.key == K_g:      #display G base
                    construct.base_switch({'G':True,'A':False,'T':False,'C':False})
                    ctrls = self.panel.get_control('G','A','T','C')
                    for ctrl in ctrls:
                        ctrls[ctrl].set_value('OFF')
                    ctrls['G'].set_value('ON')
                elif event.key == K_a:      #display A base
                    construct.base_switch({'G':False,'A':True,'T':False,'C':False})
                    ctrls = self.panel.get_control('G','A','T','C')
                    for ctrl in ctrls:
                        ctrls[ctrl].set_value('OFF')
                    ctrls['A'].set_value('ON')
                elif event.key == K_t:      #display T base
                    construct.base_switch({'G':False,'A':False,'T':True,'C':False})
                    ctrls = self.panel.get_control('G','A','T','C')
                    for ctrl in ctrls:
                        ctrls[ctrl].set_value('OFF')
                    ctrls['T'].set_value('ON')
                elif event.key == K_c:      #display C base
                    construct.base_switch({'G':False,'A':False,'T':False,'C':True})
                    ctrls = self.panel.get_control('G','A','T','C')
                    for ctrl in ctrls:
                        ctrls[ctrl].set_value('OFF')
                    ctrls['C'].set_value('ON')
                elif event.key == K_SPACE:  #display all bases
                    construct.reset()
                    self.panel.reset()
                elif event.key == K_RIGHTBRACKET:   #base run increase
                    ctrl = self.panel.get_control('Run')
                    value = ctrl.get_value()
                    if value < 25:
                        ctrl.set_value(value+1)
                        construct.base_repeat(1)
                elif event.key == K_LEFTBRACKET:    #base run decrease
                    ctrl = self.panel.get_control('Run')
                    value = ctrl.get_value()
                    if value > 1:
                        ctrl.set_value(value-1)
                        construct.base_repeat(-1)
                elif event.key == K_SLASH:  #center display
                    construct.center_image()
                elif event.key == K_s:
                    mod = pygame.key.get_mods()
                    if not mod:           #display sequence
                        construct.sequence_info_toggle('Sequence')
                        self.panel.get_control('Sequence').set_activated()
                    elif mod & KMOD_CTRL:   #snapshot
                        if not self.save_image:
                            image_saved = construct.seqimage_save()
                            self.panel.get_control('__SaveLabel').set_value(image_saved)
                            self.save_image = True
                elif event.key == K_x:
                    construct.sequence_info_toggle('Position')
                    self.panel.get_control('Position').set_activated()
                elif event.key == K_h:    #control info
                    construct.control_info()
                elif event.key == K_p:      #panel toggle
                    self.panel.set_moveable('Fixed')
            elif event.type == KEYUP:
                if event.key == K_s:
                    self.save_image = False
            elif event.type == QUIT:
                self.quit = True
            elif event.type == MOUSEBUTTONDOWN:
                if event.button == 1:       #pan display
                    if construct.pointer_interact(event.pos) and not self.panel_interact:
                        self.mouse_pan = True
                        pygame.mouse.get_rel()
                elif event.button == 3:     #seq display
                    construct.sequence_info_toggle('Sequence')
            elif event.type == MOUSEBUTTONUP:
                if event.button == 1:
                    self.mouse_pan = False
            elif event.type == MOUSEMOTION:
                if self.mouse_pan:
                    pos = pygame.mouse.get_rel()
                    if pygame.key.get_mods() & KMOD_SHIFT:
                        hyper_pan = True
                    else:
                        hyper_pan = False
                    construct.drag(pos, hyper_pan)

    def check_events_min(self):
        """Check user input."""
        for event in pygame.event.get():
            if event.type == KEYDOWN:
                if event.key == K_h:    #control info
                    construct.control_info()
                elif event.key == K_p:      #panel toggle
                    self.panel.set_moveable('Fixed')
                elif event.key == K_ESCAPE:
                    self.quit = True
            elif event.type == QUIT:
                self.quit = True

    def rgb_to_hex(self, color):
        """Convert color."""
        r,g,b = color
        return (hex(r*(256**2) + g*256 + b))

    def hex_to_rgb(self, color):
        """Convert color."""
        n = color
        return (n>>16)&0xff, (n>>8)&0xff, n&0xff

    def update(self):
        """Control update."""
        if construct.dna:
            self.check_events()
        else:
            self.check_events_min()
        self.panel_group.update()
        self.clock.tick(40)


def config():
    seq_file = ''
    seq_folder = ''
    dna_color = {}
    display_size = ()
    display_color = -1
    display_gamma = 0
    dna_patterns = []
    try:
        seq_file = sys.argv[1]
    except: pass
    try:
        if not os.path.exists('config.ini'):
            shutil.copy2('config', 'config.ini')
    except: pass
    try:
        if not os.path.exists('patterns.ini'):
            shutil.copy2('patterns', 'patterns.ini')
    except: pass
    config = {'sequence_folder':None, 'dna_color':None, 'display_size':None, 'display_color':None, 'display_gamma':None, 'dna_patterns':None}
    try:
        config_file = open('config.ini')
        cfg_setting = [line.strip().split(' ',1) for line in config_file if line[:1].isalpha()]
        cfg_setting = dict(cfg_setting)
        for cfg in config:
            if cfg in cfg_setting:
                config[cfg] = cfg_setting[cfg].strip()
        config_file.close()
    except: pass
    if config['sequence_folder']:
        try:
            seq_folder = config['sequence_folder']
        except: pass
    if config['dna_color']:
        try:
            col = [obj.strip() for obj in config['dna_color'].split(',')]
            col = [obj.split(':') for obj in col]
            for setting in col:
                base = setting[0].upper()
                if base in ('G','A','T','C'):
                    dna_color[base] = int('0x'+setting[1],16)
        except: pass
    if config['display_size']:
        try:
            size = config['display_size'].split('x')
            display_size = int(size[0].strip()), int(size[1].strip())
        except: pass
    if config['display_color']:
        try:
            display_color = int('0x'+config['display_color'],16)
        except: pass
    if config['display_gamma']:
        try:
            display_gamma = float(config['display_gamma'])
        except: pass
    if config['dna_patterns']:
        try:
            pattern_file = open(config['dna_patterns'])
            dna_patterns = [line.strip().upper() for line in pattern_file if line[:1].isalpha()]
            dna_patterns = [pattern for pattern in dna_patterns if set(pattern) <= set('GATC')]
            pattern_file.close()
        except: pass
    return seq_file, seq_folder, dna_color, display_size, display_color, display_gamma, dna_patterns


def setup():
    global construct, control
    configuration = config()
    construct = Construct(*configuration)
    control = Control()
    pygame.display.update()


def main():
    setup()
    while not control.quit:
        construct.update()
        control.panel_group.clear(construct.screen, construct.screen_base)
        control.update()
        if control.panel.is_active():
            update_rect = control.panel_group.draw(construct.screen)
            construct.update_list.extend(update_rect)
        pygame.display.update(construct.update_list)

if __name__ == '__main__':
    main()

