#Pyjsdl - Copyright (C) 2013 James Garnon <http://gatc.ca/>
#Released under the MIT License <http://opensource.org/licenses/MIT>

"""
Canvas object.
"""


canvas = None
frame = None
pyjs_mode = None

