#"""
#Interphase
#Copyright (C) 2009 James Garnon
#"""

from __future__ import division
from util import Text
from interface import Interface
from control import InterfaceControl
import pygame

class Textbox(Interface):

    def __init__(self, identity, position, size, color=(255,255,255), font_color=(0,0,0), font_size=10):
        Interface.__init__(self, identity, position, image=None)
        self._color = color
        self.position = position
        self.size = size
        self.color = color
        self.font_color = font_color
        self.font_size = font_size

    def set_text(self, txt):
        self.text = txt
        return None

    def get_text(self):
        return self.text

