"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
import java.lang


time_init = java.lang.System.nanoTime()/1000000


class Clock(object):

    def __init__(self):
        self.time = self.get_time()
        self.time_init = self.time
        self.time_diff = [25]*10
        self.pos = 0
        self.thread = java.lang.Thread()

    def get_time(self):
        return java.lang.System.nanoTime()/1000000

    def tick(self, framerate=0):
        if self.pos < 9:
            self.pos += 1
        else:
            self.pos = 0
        self.time = self.get_time()
        self.time_diff[self.pos] = (self.time-self.time_init)
        self.time_init = self.time
        if framerate:
            time_diff = sum(self.time_diff)/10
            time_pause = long( ((1.0/framerate)*1000) - time_diff )
            if time_pause > 0:
                self.thread.sleep(time_pause)

    def tick_busy_loop(self, framerate=0):
        self.tick(framerate)

    def get_ticks(self):
        return self.time_diff[self.pos]

    def get_fps(self):
        return 1000/(sum(self.time_diff)/10)

    def delay(self, time):
        start = self.get_time()
        java.lang.Thread.sleep(time)
        return self.get_time() - start

    def wait(self, time):
        pause = self.delay(time)
        return pause


def get_ticks():
    return (java.lang.System.nanoTime()/1000000) - time_init


def wait(time):
    java.lang.Thread.sleep(time)


def delay(time):
    java.lang.Thread.sleep(time)

