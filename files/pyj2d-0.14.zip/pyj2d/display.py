"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
import javax.swing
import java.awt
from java.awt.event import MouseListener
from java.awt.event import MouseMotionListener
import pyj2d.event
import pyj2d.surface
import pyj2d.env


class Frame(javax.swing.JFrame, MouseListener, MouseMotionListener):

    def __init__(self, title, size):
        javax.swing.JFrame.__init__(self, title)
        self.setDefaultCloseOperation(self.EXIT_ON_CLOSE)
        self.setResizable(False)
        self.setSize(size[0],size[1])
        self.setDefaultLookAndFeelDecorated(True)
        self.setBackground(java.awt.Color.BLACK)
        self.jpanel = Panel(size)
        self.getContentPane().add(self.jpanel)
        self.pack()
        self.addMouseListener(self)
        self.addMouseMotionListener(self)
        self.event = pyj2d.event

    def mousePressed(self, event):
        self.event.updateQueue(event)

    def mouseReleased(self, event):
        self.event.updateQueue(event)

    def mouseEntered(self, event):
        pass

    def mouseExited(self, event):
        pass

    def mouseClicked(self, event):
        pass

    def mouseMoved(self, event):
        self.event.updateQueue(event)

    def mouseDragged(self, event):
        pass


class Panel(javax.swing.JPanel):

    def __init__(self, size):
        javax.swing.JPanel.__init__(self)
        self.setPreferredSize(java.awt.Dimension(size[0],size[1]))
        self.surface = pyj2d.surface.Surface(size, java.awt.image.BufferedImage.TYPE_INT_RGB)
        self.setBackground(java.awt.Color.BLACK)

    def paintComponent(self, g):
        self.super__paintComponent(g)
        g.drawImage(self.surface, 0, 0, None)
        java.awt.Toolkit.getDefaultToolkit().sync()


class Display(object):

    def init(self):
        self.caption = ''
        self.icon = None
        if pyj2d.env.japplet:
            self.set_mode = self.applet_set_mode
            self.update = self.applet_update

    def applet_set_mode(self, size):
        self.jframe = pyj2d.env.japplet
        pyj2d.env.jframe = self.jframe
        self.jpanel = self.jframe.jpanel
        self.surface = self.jpanel.surface
        self.surface._display = self
        self.surface._g2d = self.surface.createGraphics()
        self.surface._g2d.setBackground(java.awt.Color.BLACK)
        self.clear()
        return self.surface

    def applet_update(self, rect_list=None):
        self.jframe.repaint()

    def set_mode(self, size):
        self.jframe = Frame(self.caption, size)
        pyj2d.env.jframe = self.jframe
        self.jpanel = self.jframe.jpanel
        self.surface = self.jpanel.surface
        self.surface._display = self
        self.surface._g2d = self.jpanel.surface.createGraphics()
        self.surface._g2d.setBackground(java.awt.Color.BLACK)
        self.clear()
        self.jframe_repaint = javax.swing.RepaintManager()
        self.jframe.setVisible(True)
        return self.surface

    def get_surface(self):
        return self.surface

    def get_frame(self):
        return self.jframe

    def quit(self):
        try:
            self.surface._g2d.dispose()
        except:
            pass

    def get_init(self):
        return True

    def set_caption(self, caption):
        self.caption = caption

    def set_icon(self, icon):
        self.icon = icon

    def clear(self):
        w, h = self.surface.getWidth(), self.surface.getHeight()
        self.surface._g2d.setColor(java.awt.Color.BLACK)
        self.surface._g2d.fillRect(0,0,w,h)

    def flip(self):
        self.jframe.repaint()

    def update(self, rect_list=None):
        try:
            for rect in rect_list:
                try:
                    self.jframe_repaint.addDirtyRegion(self.jpanel, rect.x,rect.y,rect.width,rect.height)
                except AttributeError:
                    self.jframe_repaint.addDirtyRegion(self.jpanel, *rect)
            self.jframe_repaint.paintDirtyRegions()
        except:
            self.jframe.repaint()

