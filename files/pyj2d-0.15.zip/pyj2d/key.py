"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

class Key(object):
    def get_focused(self):
        pass
    def get_pressed(self):
        pass
    def get_mods(self):
        pass
    def set_mods(self):
        pass
    def set_repeat(self):
        pass
    def get_repeat(self):
        pass
    def name(self):
        pass

