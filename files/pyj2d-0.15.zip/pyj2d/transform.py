"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
from math import pi
from java.awt import RenderingHints
from java.awt.geom import AffineTransform
from java.awt.image import BufferedImage, AffineTransformOp
import surface


class Transform(object):

    def __init__(self):
        self.deg_rad = pi/180

    def rotate(self, image, degree):
        at = AffineTransform()
        angle = -degree*self.deg_rad
        at.rotate(angle, image.getWidth()//2, image.getHeight()//2)
        bio = AffineTransformOp(at, AffineTransformOp.TYPE_BILINEAR)
        bi = bio.filter(image, None)
        newImage = surface.convert_bufferedimage(bi)
        try:
            newImage._colorkey = image.colorkey
        except AttributeError:
            pass
        return newImage

    def rotozoom(self, image, degree, size):
        newImage = self.rotate(image, degree)
        if size != 1.0:
            size_i = image.get_size()
            size_f = int(size_i[0]*size), int(size_i[1]*size)
            newImage = self.scale(newImage, size_f)
        return newImage

    def scale(self, image, size, dest=None):
        if not dest:
            surf = surface.Surface(size, BufferedImage.TYPE_INT_ARGB)    #check alpha/need fill?
        else:
            surf = dest
        g2d = surf.createGraphics()
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR)
        g2d.drawImage(image, 0, 0, size[0], size[1], None)
        g2d.dispose()
        colorkey = image.get_colorkey()
        if colorkey:
            surf.set_colorkey(colorkey)
        return surf

    def smoothscale(self, image, size):
        surf = self.scale(image, size)
        return surf

