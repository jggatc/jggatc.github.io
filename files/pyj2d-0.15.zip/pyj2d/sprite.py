"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division


all_groups = []


class Sprite(object):
    count = 0

    def __init__(self):
        Sprite.count += 1
        self._identity = Sprite.count
        self._rect_pre = None
        self.x = None
        self.y = None
        self.image = None
        self.rect = None

    def add(self, groups):
        for group in groups:
            if self not in group:
                group.add(self)
        return None

    def remove(self, groups):
        for group in groups:
            if self in group:
                group.remove(self)
        return None

    def kill(self):
        for group in all_groups:
            if self in group:
                remove(self)
        return None

    def alive(self):
        for group in all_groups:
            if self in group:
                return True
        return False

    def groups(self):
        member = []
        for group in all_groups:
            if self in group:
                member.append(group)
        return member

    def update(self):
        pass


class DirtySprite(Sprite):

    def __init__(self):
        Sprite.__init__(self)
        self.dirty = 1
        self.blendmode = 0
        self.source_rect = None
        self.visible = 1
        self.layer = 0 


class Group(list):

    def __init__(self, *sprites):
        if self not in all_groups:
            all_groups.append(self)
        if sprites:
            self.extend(sprites)
        self.surface_blits = []
        self.clear_active = False
        self.removed_sprite = []

    def sprites(self):
        return list(self)

    def copy(self):
        newgroup = self.__class__()
        newgroup.extend(self)
        return newgroup

    def add(self, *sprites):
        new_sprites = [sprite for sprite in sprites if sprite not in self]
        self.extend(new_sprites)
        return None

    def remove(self, *sprites):
        for sprite in sprites:
            try:
                self.pop(self.index(sprite))
                if self.clear_active:
                    self.removed_sprite.append(sprite)
            except ValueError:
                pass
        return None

    def has(self, *sprites):
        for sprite in sprites:
            if sprite not in self:
                return False
        return True

    def draw(self, surface):
        self.surface_blits = [(sprite.image,sprite.rect) for sprite in self]
        surface.blits(self.surface_blits)
        return None

    def clear(self, surface, background):
        self.clear_active = True
        self.surface_blits = []
        for group in (self.removed_sprite, self):
            for sprite in group:
                try:
                    x,y,w,h = sprite._rect_pre.x, sprite._rect_pre.y, sprite._rect_pre.width, sprite._rect_pre.height
                except AttributeError:
                    sprite._rect_pre = sprite.rect.copy()
                    continue
                try:
                    subsurf = background.subarea
                except AttributeError:
                    background(surface,sprite._rect_pre)
                    sprite._rect_pre = sprite.rect.copy()
                    continue
                subsurface, rect = subsurf((sprite._rect_pre.x, sprite._rect_pre.y, sprite._rect_pre.width, sprite._rect_pre.height))
                self.surface_blits.append((subsurface,rect))
                sprite._rect_pre = sprite.rect.copy()
        surface.blits(self.surface_blits)
        self.removed_sprite = []

    def empty(self):
        while True:
            try:
                sprite = self.pop()
                if self.clear_active:
                    self.removed_sprite.append(sprite)
            except IndexError:
                return None

    def update(self):
        for sprite in self:
            sprite.update()
        return None


class GroupSingle(Group):

    def __init__(self, sprite=None):
        if sprite:
            sprite = [sprite]
        Group.__init__(self, sprite)

    def add(self, sprite):
        try:
            self[0] = sprite
        except IndexError:
            self.append(sprite)
        return None

    def update(self):
        try:
            self[0].update()
        except IndexError:
            pass
        return None


class RenderUpdates(Group):

    def __init__(self, *sprites, **kwargs):
        Group.__init__(self, *sprites, **kwargs)     # *tuple unpack jythonc error, fix by adding **kwargs
        self.changed_areas = []

    def add(self, *sprites):
        new_sprites = [sprite for sprite in sprites if sprite not in self]
        self.extend(new_sprites)
        return None

    def draw(self, surface):
        if surface._display:
            changed_areas = self.changed_areas
            self.changed_areas = []
            changed_areas.extend([sprite.rect for sprite in self])
        Group.draw(self, surface)
        return changed_areas

    def clear(self, surface, background):
        if surface._display:
            for group in (self.removed_sprite, self):
                self.changed_areas.extend([sprite._rect_pre for sprite in group if sprite._rect_pre])
        Group.clear(self, surface, background)
        return None


class OrderedUpdates(RenderUpdates):
    pass


class LayeredUpdates(OrderedUpdates):

    def __init__(self, *sprites, **kwargs):
        OrderedUpdates.__init__(self, *sprites, **kwargs)     # *tuple unpack jythonc error, fix by adding **kwargs


class LayeredDirty(LayeredUpdates):
    pass


collide_mask = None


def spritecollide(sprite, group, dokill, collided = None):
    rect = sprite.rect
    collided = []
    for sprites in group:
        rectx = sprites.rect
        if rect.intersects(rectx):
            collided.append(sprites)
            if dokill:
                group.remove(sprites)
    return collided


def collide_rect(sprite1, sprite2):
    return sprite1.rect.intersects(sprite2.rect)


def groupcollide(group1, group2, dokill1, dokill2):
    collide = {}
    for sprite1 in group1:
        collide[sprite1] = []
        for sprite2 in group2:
            if sprite1.rect.intersects(sprite2.rect):
                collide[sprite1].append(sprite2)
    for sprite1 in collide:
        if collide[sprite1]:
            if dokill1:
                group1.remove(sprite1)
            if dokill2:
                for sprite2 in collide[sprite1]:
                    group2.remove(sprite2)


def spritecollideany(sprite, group):
    for sprites in group:
        if sprite.rect.intersects(sprites.rect):
            return True
    return False

