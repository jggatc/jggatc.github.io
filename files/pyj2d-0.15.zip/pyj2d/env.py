"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

japplet = None

jframe = None

