#!/usr/bin/env python
from __future__ import division

"""
Biomorph Entity
Copyright (C) 2009 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Biomorph Entity 1.02
Download Site: http://gatc.ca

Dependencies:
    Python 2.5:   http://www.python.org/
    Pygame 1.8:   http://www.pygame.org/
"""

version = '1.02'

try:
    import pygame
    from pygame.locals import *
    from pygame import bufferproxy
except ImportError:
    raise ImportError, "Pygame module required."

import random
import math
import os
import sys
import optparse

import interphase

test = False
if not test:
    import warnings
    warnings.filterwarnings("ignore")


MATRIX_X = 500
MATRIX_Y = 500
BG_COLOR = (0,0,0)


class Matrix(object):

    def __init__(self):
        pygame.display.init()
        pygame.font.init()
        pygame.display.set_caption('Biomorph Entity')
        iconname = os.path.join('data', 'icon.png')
        icon = pygame.image.load(iconname)
        pygame.display.set_icon(icon)
        if config['display_gamma']:
            gamma_set = pygame.display.set_gamma(config['display_gamma'])
        self.screen = pygame.display.set_mode((MATRIX_X,MATRIX_Y))
        if config['display_gamma'] and not gamma_set:   #if prior set_gamma failed
            gamma_set = pygame.display.set_gamma(config['display_gamma'])
        self.borders = self.matrix_borders()
        self.screen_matrix = pygame.display.get_surface()
        self.info = interphase.Text(self.screen)
        self.info.set_font_color((82,96,116))
        self.control_list = []
        self.screen_base = pygame.Surface((MATRIX_X,MATRIX_Y))
        self.screen_color = BG_COLOR
        self.screen_base.fill(self.screen_color)
        self.screen.blit(self.screen_base, (0,0))
        self.update_list = []   #list of object to update display
        self.display_update = False
        self.biomorph_add = False
        self.biomorph_count = 0
        self.segment_count = 50
        self.biomorph_type = 4
        self.biomorph_size = 1.0
        self.biomorphs = { 0.5:{}, 1.0:{}, 1.5:{}, 2.0:{}, 2.5:{} }
        self.biomorph_entity = pygame.sprite.OrderedUpdates()

    def setup(self, biomorph=True):
        self.biomorphs = { 0.5:{}, 1.0:{}, 1.5:{}, 2.0:{}, 2.5:{} }
        self.biomorph_add = False
        if biomorph:
            self.add_biomorph()
        self.display_update = True
        self.update()

    def add_biomorph(self, x=MATRIX_X//2, y=MATRIX_Y//2, segments=None):
        if segments == None:
            segments = self.segment_count
        self.biomorph_count += 1
        biomorph = Biomorph(x, y, segments, self.biomorph_type, self.biomorph_size)
        self.biomorphs[self.biomorph_size][self.biomorph_count] = biomorph
        return biomorph

    def simulation_set(self, parameter=None):
        self.biomorph_add = False
        if parameter == 'Add Biomorph':
            self.biomorph_add = not self.biomorph_add

    def biomorph_select(self, position):
        if self.biomorph_add:
            x,y = position
            self.add_biomorph(x,y)

    def matrix_borders(self):
        class Edge(pygame.sprite.Sprite):
            def __init__(self, x, y, dim_x, dim_y, side):
                pygame.sprite.Sprite.__init__(self)
                self.rect = pygame.Rect(x,y,dim_x,dim_y)
                self.side = side
        borders = pygame.sprite.Group()
        borders.add( Edge(0,0,MATRIX_X,1,'n') )
        borders.add( Edge(0,MATRIX_Y-2,MATRIX_X,1,'s') )
        borders.add( Edge(0,0,1,MATRIX_Y,'w') )
        borders.add( Edge(MATRIX_X-2,0,1,MATRIX_Y,'e') )
        return borders

    def update(self):
        if self.display_update:
            self.screen.blit(self.screen_base, (0,0))
        for biomorph_size in self.biomorphs:
            for biomorph in self.biomorphs[biomorph_size]:
                self.biomorphs[biomorph_size][biomorph].update()
                for segment in self.biomorphs[biomorph_size][biomorph].segment:
                    self.biomorph_entity.add(segment)
        self.biomorph_entity.clear(self.screen_matrix,self.screen_base)
        self.update_list.extend(self.biomorph_entity.draw(self.screen_matrix))
        self.biomorph_entity.empty()


class Segment(pygame.sprite.Sprite):
    """Biomorph Segment."""
    images = {}

    def __init__(self, x, y, segment_type, segment_size):
        pygame.sprite.Sprite.__init__(self)
        self.x = x
        self.y = y
        self.pos_x = float(self.x)     #float version
        self.pos_y = float(self.y)
        if not Segment.images:
            segment_num = 1
            for segment_image in ('segment1.png', 'segment2.png', 'segment3.png', 'segment4.png'):
                image_size = {}
                img = load_image(segment_image)
                for size in (0.5,1.0,1.5,2.0,2.5):
                    image = {}
                    for degree in xrange(0,360,10):
                        image[degree] = pygame.transform.rotozoom(img, -degree, 0.2*size)
                    image_size[size] = image
                Segment.images[segment_num] = image_size
                segment_num += 1
        self.direction = random.randrange(0,360,10)
        self.distance = random.randrange(1,10)
        self.image = Segment.images[segment_type][segment_size][self.direction]
        self.rect = self.image.get_rect(center=(self.x,self.y))
        self.velocity = 1 * segment_size

    def location(self):
        """Moves distance up to 10 steps, then changes direction randomly."""
        if self.distance > 0:
            self.distance -= 1
        else:
            self.direction = random.randrange(360)
            self.distance = random.randrange(1,10)
        self.pos_x += +self.velocity*sin_table[self.direction]
        self.pos_y += -self.velocity*cos_table[self.direction]
        #self.pos_x += +self.velocity*math.sin(self.direction*math.pi/180)
        #self.pos_y += -self.velocity*math.cos(self.direction*math.pi/180)
        self.x, self.y = int(self.pos_x), int(self.pos_y)
        self.rect = self.image.get_rect(center=(self.x,self.y))

    def update(self):
        self.location()


class Biomorph(object):

    def __init__(self, x, y, segments, biomorph_type, biomorph_size):
        self.type = biomorph_type
        self.size = biomorph_size
        self.segment = pygame.sprite.OrderedUpdates()
        self.segments = segments
        self.edge_contact = False
        self.edge_response = 0
        self.velocity =  1 * self.size
        count = 0
        for i in xrange(self.segments-1):
            if not count:
                x_initial = random.randrange(10, MATRIX_X-50)
                y_initial = random.randrange(10, MATRIX_Y-10)
                count = 2
            segment = Segment(x_initial+count*20, y_initial, self.type, self.size)
            self.segment.add(segment)
            count -= 1
        segment = Segment(x, y, self.type, self.size)
        self.segment.add(segment)
        segment.image = Segment.images[self.type][self.size][130]   #first segment

    def molecular_interaction(self):
        segments = []
        for segment in self.segment:
            segments.append(segment)
        segments.reverse()
        for i in xrange(len(segments)-1):
            try:
                x1 = segments[i].pos_x
                y1 = segments[i].pos_y
                x2 = segments[i+2].pos_x
                y2 = segments[i+2].pos_y
                separation = math.sqrt( math.pow((x1-x2),2) + math.pow((y1-y2),2) )
                if separation < 30 * self.size:
                    mid = ( abs((x1+x2)/2), abs((y1+y2)/2) )
                    x3 = segments[i+1].pos_x
                    y3 = segments[i+1].pos_y
                    mid3 = ( abs((mid[0]+x3)/2), abs((mid[1]+y3)/2) )
                    segments[i+1].pos_x, segments[i+1].pos_y = mid3[0], mid3[1]
                    segments[i+1].x, segments[i+1].y = int(segments[i+1].pos_x), int(segments[i+1].pos_y)
                    segments[i+1].rect.center = (segments[i+1].x, segments[i+1].y)
            except:
                pass
            x1 = segments[i].pos_x
            y1 = segments[i].pos_y
            x2 = segments[i+1].pos_x
            y2 = segments[i+1].pos_y
            separation = math.sqrt( math.pow((x1-x2),2) + math.pow((y1-y2),2) )
            if separation > 11 * self.size:
                if x1 < x2:
                    x1 += self.velocity
                elif x1 > x2:
                    x1 -= self.velocity
                if y1 < y2:
                    y1 += self.velocity
                elif y1 > y2:
                    y1 -= self.velocity
                segments[i].pos_x, segments[i].pos_y = x1, y1
                segments[i].x, segments[i].y = int(segments[i].pos_x), int(segments[i].pos_y)
                segments[i].rect.center = (segments[i].x, segments[i].y)
            elif separation < 9 * self.size:
                if x1 < x2:
                    x1 -= self.velocity
                elif x1 > x2:
                    x1 += self.velocity
                if y1 < y2:
                    y1 -= self.velocity
                elif y1 > y2:
                    y1 += self.velocity
                segments[i].pos_x, segments[i].pos_y = x1, y1
                segments[i].x, segments[i].y = int(segments[i].pos_x), int(segments[i].pos_y)
                segments[i].rect.center = (segments[i].x, segments[i].y)
        try:
            i = (self.segments) - 1
            j = i - 1
            x1 = segments[i].pos_x
            y1 = segments[i].pos_y
            x2 = segments[j].pos_x
            y2 = segments[j].pos_y
            separation = math.sqrt( math.pow((x1-x2),2) + math.pow((y1-y2),2) )
            if separation > 5 * self.size:
                if x1 < x2:
                    x1 += self.velocity
                elif x1 > x2:
                    x1 -= self.velocity
                if y1 < y2:
                    y1 += self.velocity
                elif y1 > y2:
                    y1 -= self.velocity
                segments[i].pos_x, segments[i].pos_y = x1, y1
                segments[i].x, segments[i].y = int(segments[i].pos_x), int(segments[i].pos_y)
                segments[i].rect.center = (segments[i].x, segments[i].y)
        except:
            pass

    def check_edge(self):
        segment_at_edge = pygame.sprite.spritecollide(self.segment.sprites()[self.segments-1], matrix.borders, False)
        if segment_at_edge:
            self.edge_contact = True
            self.edge_response = 10

    def interaction(self):
        self.check_edge()
        segments = []
        for segment in self.segment:
            segments.append(segment)
        segments.reverse()
        if self.edge_contact or (pygame.mouse.get_focused() and not control.panel_displayed):
            segment = segments[0]
            x1 = segment.pos_x
            y1 = segment.pos_y
            if self.edge_contact:
                x2,y2 = MATRIX_X//2, MATRIX_Y//2
                self.edge_response -= 1
                if not self.edge_response:
                    self.edge_contact = False
            else:
                x2,y2 = pygame.mouse.get_pos()
            separation = math.sqrt( math.pow((x1-x2),2) + math.pow((y1-y2),2) )
            if separation > 25:
                if x1 < x2:
                    x1 += self.velocity
                elif x1 > x2:
                    x1 -= self.velocity
                if y1 < y2:
                    y1 += self.velocity
                elif y1 > y2:
                    y1 -= self.velocity
                segment.pos_x, segment.pos_y = x1, y1
                segment.x, segment.y = int(segment.pos_x), int(segment.pos_y)
                segment.rect.center = (segment.x, segment.y)

    def update(self):
        self.segment.update()
        self.molecular_interaction()
        self.interaction()


def load_image(file_name, frames=1, path='data', colorkey=None, errorhandle=True):
    #Modified from PygameChimpTutorial
    full_name = os.path.join(path, file_name)
    try:
        if frames == 1:
            image = pygame.image.load(full_name)
        elif frames > 1:
            images = []
            image = pygame.image.load(full_name)
            width, height = image.get_size()
            width = width // frames
            for frame in xrange(frames):
                frame_num = width * frame
                image_frame = image.subsurface((frame_num,0), (width,height)).copy()
                images.append(image_frame)
            return images
    except pygame.error, message:
        if errorhandle:
            raise SystemExit, message
        else:
            print(message)
            return None
    if image.get_alpha():
        image = image.convert_alpha()
    else:
        image = image.convert()
    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0,0))
        image.set_colorkey(colorkey, RLEACCEL)
    return image


def trig_compute():
    sin_table = {}
    cos_table = {}
    for angle in xrange(0,360):
        angle_rad = angle * math.pi/180
        sin_angle = math.sin(angle_rad)
        cos_angle = math.cos(angle_rad)
        sin_table[angle] = sin_angle
        cos_table[angle] = cos_angle
    return sin_table, cos_table
sin_table, cos_table = trig_compute()


class MatrixInterface(interphase.Interface):

    def __init__(self):
        interphase.Interface.__init__(self, position=(MATRIX_X/2,MATRIX_Y-50), image='panel.png', color=(43,50,58), size=(350,100), moveable=True, position_offset=(0,95), button_image=['button.png'], control_image=['control.png'], font_color=(175,180,185), tips_fontcolor=(175,180,185), pointer_interact=True, control_minsize=(20,20), control_size='auto', label_display=True)

    def add_controls(self):
        self.add(
            identity = 'Control',
            control_type = 'function_select',
            position = (50,50),
            size = (40,40),
            control_list = ['__Action', '__Sim'],
            icon_list = ['icon.png', 'restart.png'],
            link = [ ['Biomorph', 'Type', 'Length', 'Width'], ['Restart', 'Exit'] ],
            link_activated = True,
            label_display = False)
        self.add(
            identity = 'Biomorph',
            control_type = 'control_toggle',
            position = (175,30),
            size = 'min_width',
            control_list = ['Biomorph'],
            tip_list = ['Biomorph Generate'],
            control_outline = True,
            activated_toggle = False,
            label_display=False)
        self.add(
            identity = 'Type',
            control_type = 'control_select',
            position = (130,70),
            size = 'min',
            control_list = ['__numeric', (1,4)],
            tip_list = ['Biomorph Type'],
            control_outline = True)
        self.add(
            identity = 'Length',
            control_type = 'control_select',
            position = (175,70),
            size = 'min',
            control_list = ['__numeric', (5,50)],
            tip_list = ['Biomorph Length'],
            control_outline = True)
        self.add(
            identity = 'Width',
            control_type = 'control_select',
            position = (220,70),
            size = 'min',
            control_list = ['__numeric', (1,5)],
            tip_list = ['Biomorph Size'],
            control_outline = True)
        self.add(
            identity = 'Restart',
            control_type = 'control_toggle',
            position = (130,50),
            size = (40,40),
            control_list = ['Restart'],
            tip_list = ['Restart Simulation'],
            label_display = False)
        self.add(
            identity = 'Exit',
            control_type = 'control_toggle',
            position = (230,50),
            size = (40,40),
            control_list = ['Exit'],
            tip_list = ['Exit Simulation'],
            label_display = False)
        self.add(
            identity = '__Fix',
            control_type = 'control_toggle',
            position = (315,90),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['!'],
            control_image = ['none'],
            control_outline = True)
        self.add(
            identity = '__Help',
            control_type = 'control_toggle',
            position = (335,90),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['?'],
            control_image = ['none'],
            control_outline = True)
        controls = self.get_control()
        controls['Type'].set_value(4)
        controls['Length'].set_value(50)
        controls['Width'].set_value(2)

    def update(self):
        interphase.Interface.update(self)
        state = self.get_state()
        control.panel_displayed = state.panel_interact
        if state.control:
            if state.control == 'Control':
                matrix.simulation_set()
            elif state.control == 'Biomorph':
                if self.get_control('Biomorph').is_activated():
                    matrix.simulation_set('Add Biomorph')
                else:
                    matrix.simulation_set()
            elif state.control == 'Type':
                matrix.biomorph_type = int(state.value)
            elif state.control == 'Length':
                matrix.segment_count = int(state.value)
            elif state.control == 'Width':
                matrix.biomorph_size = float(state.value)*0.5
            elif state.control == 'Restart':
                self.get_control('Biomorph').set_activated(False)
                matrix.setup(biomorph=False)
            elif state.control == 'Exit':
                control.quit = True
            elif state.control == '__Fix':
                self.set_moveable('Fixed')
            elif state.control == '__Help':
                self.set_tips_display()
        return state


class Control(object):

    def __init__(self):
        pygame.key.set_repeat(100,10)
        self.panel, self.panel_group = self.define_controls()
        self.panel_displayed = False
        self.clock = pygame.time.Clock()
        self.quit = False

    def define_controls(self):
        panel = MatrixInterface()
        panel_group = pygame.sprite.RenderUpdates(panel)
        return panel, panel_group

    def check_events(self):
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONDOWN and not self.panel_displayed:
                button1, button2, button3 = pygame.mouse.get_pressed()
                if event.button == 1:
                    matrix.biomorph_select(event.pos)
            elif event.type == KEYDOWN:
                if event.key == K_i:    #interface panel toggle
                    self.panel.set_moveable('Fixed')
                elif event.key == K_TAB:    #pause toggle
                    pause = True
                    while pause:
                        for event in pygame.event.get():
                            if event.type == KEYDOWN:
                                if event.key == K_TAB or event.key == K_ESCAPE:
                                    pause = False
                            elif event.type == QUIT:
                                pause = False
                                self.quit = True
                        self.clock.tick(40)
                elif event.key == K_q:         #quit program
                    if pygame.key.get_mods() & KMOD_CTRL:
                        self.quit = True
            elif event.type == QUIT:   #quit program
                self.quit = True

    def update(self):
        self.check_events()
        self.panel_group.update()
        self.clock.tick(40)


def program_options():
    config = {'display_gamma':None, 'display_size':None, 'background_color':None}
    try:
        conf = {}
        config_file = open('config.ini')
        cfg_setting = [line.strip().split(' ',1) for line in config_file if line[:1].isalpha()]
        cfg_setting = dict(cfg_setting)
        for cfg in config:
            if cfg in cfg_setting:
                conf[cfg] = cfg_setting[cfg].strip()
        config_file.close()
    except (IOError, ValueError):
        pass
    for cfg in conf:
        if cfg == 'display_gamma':
            try:
                config['display_gamma'] = float(conf['display_gamma'])
            except ValueError:
                pass
        elif cfg == 'display_size':
            config['display_size'] = [int(size) for size in conf['display_size'].split('x')]
        elif cfg == 'background_color':
            config['background_color'] = [int(color) for color in conf['background_color'].split(',')]
    program_usage = "%prog [options]"
    program_desc = ("Biomorph Entity")
    parser = optparse.OptionParser(usage=program_usage,description=program_desc)
    parser = optparse.OptionParser(version="Biomorph Entity "+version)
    parser.add_option("--license", dest="license", action="store_true", help="display program license")
    parser.add_option("-d", "--doc", dest="doc", action="store_true", help="display program documentation")
    parser.add_option("-g", dest="display_gamma", action="store", help="-g value (value: 0.5 to 3.0)")
    parser.add_option("-s", dest="display_size", action="store", help="-s value (value: WIDTHxHEIGHT)")
    parser.add_option("-c", dest="background_color", action="store", help="-c value (value: R,G,B)")
    (options, args) = parser.parse_args()
    if options.license:
        try:
            license_info = open('license.txt')
        except IOError:
            print("GNU General Public License version 3 or later: http://www.gnu.org/licenses/")
            sys.exit()
        for line_no, line in enumerate(license_info):
            print(line),
            if line_no and not line_no % 20:
                try:
                    answer = raw_input("press enter to continue, 'q' to quit: ")
                except:
                    sys.exit()
                if answer == 'q':
                    break
        license_info.close()
        sys.exit()
    if options.doc:
        try:
            documentation = open('readme.txt')
        except IOError:
            print("Documentation not found.")
            sys.exit()
        for line_no, line in enumerate(documentation):
            print line,
            if line_no and not line_no % 20:
                try:
                    answer = raw_input("press enter to continue, 'q' to quit: ")
                except:
                    sys.exit()
                if answer == 'q':
                    break
        documentation.close()
        sys.exit()
    if options.display_gamma:
        try:
            config['display_gamma'] = float(options.display_gamma)
        except ValueError:
            config['display_gamma'] = None
    if options.display_size:
        config['display_size'] = [int(size) for size in options.display_size.split('x')]
    if options.background_color:
        config['background_color'] = [int(color) for color in options.background_color.split(',')]
    for cfg in config:
        if config[cfg]:
            if cfg == 'display_gamma':
                if config[cfg] < 0.5:
                    config[cfg] = 0.5
                elif config[cfg] > 3.0:
                    config[cfg] = 3.0
            elif cfg == 'display_size':
                for i, size in enumerate(config[cfg]):
                    if size < 100:
                        config[cfg][i] = 100
                    elif size > 1024:
                        config[cfg][i] = 1024
            elif cfg == 'background_color':
                for i, clr in enumerate(config[cfg]):
                    if clr < 0:
                        config[cfg][i] = 0
                    elif clr > 255:
                        config[cfg][i] = 255
    return config


def setup():
    global config, matrix, control, MATRIX_X, MATRIX_Y, BG_COLOR
    config = program_options()
    if config['display_size']:
        MATRIX_X, MATRIX_Y = config['display_size']
    if config['background_color']:
        BG_COLOR = tuple(config['background_color'])
    matrix = Matrix()
    control = Control()
    matrix.setup()

setup()


def main():
    while not control.quit:
        matrix.update_list = []
        control.panel_group.clear(matrix.screen,matrix.screen_base)
        control.update()
        matrix.update()
        if control.panel.is_active():
            update_rect = control.panel_group.draw(matrix.screen)
            matrix.update_list.extend(update_rect)
        if not matrix.display_update:
            pygame.display.update(matrix.update_list)
        else:
            matrix.display_update = False
            pygame.display.flip()

if __name__ == '__main__':
    main()

