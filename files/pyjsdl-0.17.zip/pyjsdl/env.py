#Pyjsdl - Copyright (C) 2013 James Garnon

"""
Canvas object.
"""

canvas = None
frame = None    ###0.17

