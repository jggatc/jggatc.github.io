#Pyjsdl - Copyright (C) 2013 James Garnon

ver =   '0.17'

