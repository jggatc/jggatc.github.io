#!/usr/bin/env python3

#Brownian Motion Simulation - Copyright (C) 2021 James Garnon <https://gatc.ca/>
#Released under the GPL License https://opensource.org/licenses/GPL-3.0

#Version 1.1

import random
from random import random as _random, choice as _choice
from math import sqrt as _sqrt, log as _log
from math import sin as _sin, cos as _cos, pi as _pi

platform = None
# __pragma__ ('skip')
import os
if os.name in ('posix', 'nt', 'os2', 'ce', 'riscos'):
    import pygame as pg
    platform = 'pc'
elif os.name == 'java':
    import pyj2d as pg
    platform = 'jvm'
else:
    import pyjsdl as pg
    platform = 'js'
# __pragma__ ('noskip')
if platform is None:
    import pyjsdl as pg
    platform = 'js'


class Rand:

    def __init__(self):
        self.gauss_next = None
        self.pi2 = _pi * 2

    def gauss(self, mu, sigma):
        z = self.gauss_next
        self.gauss_next = None
        if z is None:
            x2pi = _random() * self.pi2
            g2rad = _sqrt(-2.0 * _log(1.0 - _random()))
            z = _cos(x2pi) * g2rad
            self.gauss_next = _sin(x2pi) * g2rad
        return mu + z * sigma


def randrange(i, f):
    return _choice(range(i, f))


if platform == 'js':
    if not hasattr(random, 'randrange'):
        random.randrange = randrange
    if not hasattr(random, 'gauss'):
        rand = Rand()
        random.gauss = rand.gauss


class Matrix:

    def __init__(self, display):
        self.obj_num = 500
        self.fps = 80
        self.display = display
        self.width = display.get_width()
        self.height = display.get_height()
        self.background = pg.Surface((self.width, self.height))
        self.clock = pg.time.Clock()
        self.particles = []
        for i in range(self.obj_num):
            particle = Particle(self)
            self.particles.append(particle)
        self.particle_track = None
        self.particle_track_x = 0
        self.particle_track_y = 0
        self.color = pg.Color(0,0,0)
        self.color_edge = pg.Color(100,120,140)
        self.color_track = pg.Color(200,0,0)
        self.pointer = Pointer()
        self.info_display = False
        self.info_update = False
        self.info_surf = None
        self.info_fps = None
        self.info_fps_index = -1
        self.info_time = 0
        self.font = pg.font.Font(None, 16)
        if platform == 'js':
            handler = TouchHandler(self)
            pg.env.event.touchlistener.add_callback(handler)
            self.pointer_event = pg.event.Event(pg.USEREVENT)
        self.clear_background()

    def input(self):
        quit = False
        for event in pg.event.get():
            if event.type == pg.MOUSEBUTTONDOWN:
                if event.button == 1:
                    self.select_particle(event.pos)
            elif event.type == pg.MOUSEMOTION:
                self.pointer.update(event.pos)
            elif event.type == pg.KEYDOWN:
                if event.key == pg.K_p:
                    self.add_particle()
                elif event.key == pg.K_i:
                    self.set_info_display()
                elif event.key == pg.K_r:
                    self.reset()
                elif event.key in (pg.K_q, pg.K_ESCAPE):
                    pg.quit()
                    quit = True
            elif event.type == pg.USEREVENT:
                self.pointer.set_display(False)
            elif event.type == pg.QUIT:
                pg.quit()
                quit = True
        return quit

    def clock_tick(self):
        self.clock.tick(self.fps)

    def clear_background(self):
        rect = self.background.fill(self.color)
        if platform != 'jvm':
            pg.draw.rect(self.background, self.color_edge,
                        (0,0,self.width,self.height), 1)
        else:
            pg.draw.rect(self.background, self.color_edge,
                        (0,0,self.width-1,self.height-1), 1)

    def set_info_display(self):
        self.info_display = not self.info_display
        if self.info_display:
            fps = int(self.clock.get_fps())
            if self.info_fps is not None:
                for i in range(100):
                    self.info_fps[i] = fps
            else:
                self.info_fps = []
                for i in range(100):
                    self.info_fps.append(fps)
            self.info_update = True

    def add_particle(self, number=100):
        self.obj_num += number
        for i in range(number):
            particle = Particle(self)
            self.particles.append(particle)
        if self.info_display:
            self.info_update = True

    def toggle_pointer(self, x, y):
        self.pointer.update((x,y))
        self.pointer.set_display(True)
        pg.time.set_timer(self.pointer_event, 2000, True)

    def select_particle(self, pos):
        if self.particle_track is not None:
            self.particle_track.set_track(False)
            self.particle_track = None
            self.pointer.set_active(False)
            self.clear_background()
        for particle in self.particles:
            if particle.rect.collidepoint(pos):
                self.particle_track = particle
                self.particle_track_x = particle.rect.x
                self.particle_track_y = particle.rect.y
                particle.set_track(True)
                self.pointer.set_active(True)
                break

    def reset(self):
        self.obj_num = 500
        self.particles = []
        for i in range(self.obj_num):
            particle = Particle(self)
            self.particles.append(particle)
        if self.particle_track is not None:
            self.particle_track.set_track(False)
            self.particle_track = None
            self.pointer.set_active(False)
            self.clear_background()

    def update(self):
        if not self.particle_track:
            self.display.blit(self.background, (0,0))
        else:
            particle = self.particle_track
            pg.draw.aaline(self.background, self.color_track,
                    (self.particle_track_x+3, self.particle_track_y+3),
                    (particle.rect.x+3, particle.rect.y+3))
            self.particle_track_x = particle.rect.x
            self.particle_track_y = particle.rect.y
            self.display.blit(self.background, (0,0))
        for particle in self.particles:
            particle.update()
            self.display.blit(particle.image,
                             (particle.rect.x, particle.rect.y))
        self.display.blit(self.pointer.image,
                         (self.pointer.rect.x, self.pointer.rect.y))
        if self.info_display:
            self.info_fps_index += 1
            if self.info_fps_index > 99:
                self.info_fps_index = 0
            self.info_fps[self.info_fps_index] = int(self.clock.get_fps())
            if pg.time.get_ticks() - self.info_time > 1000:
                self.info_update = True
                self.info_time = pg.time.get_ticks()
            if self.info_update:
                fps = int(sum(self.info_fps) / 100)
                info = 'Particle:' + str(self.obj_num) + ' FPS:' + str(fps) 
                self.image_surf = self.font.render(info, True, (255,0,0), (0,0,0))
                self.info_update = False
            self.display.blit(self.image_surf, (1,1))


class Particle:

    images = None
    area_top = None
    area_left = None
    area_right = None
    area_bottom = None

    __slot__ = ['image', 'rect', 'x', 'y']

    def __init__(self, matrix):
        if Particle.images is None:
            Particle.images = {}
            if platform == 'pc':
                image_file = os.path.join('data', 'particle1.png')
                image1 = pg.image.load(image_file).convert_alpha()
                image_file = os.path.join('data', 'particle2.png')
                image2 = pg.image.load(image_file).convert_alpha()
            else:
                image1 = pg.image.load('./data/particle1.png')
                image2 = pg.image.load('./data/particle2.png')
            image = pg.transform.smoothscale(image1, (7,7))
            Particle.images['particle'] = image
            image = pg.transform.smoothscale(image2, (7,7))
            Particle.images['track'] = image
            Particle.area_top = 1.0
            Particle.area_left = 1.0
            Particle.area_right = matrix.width - 8.0
            Particle.area_bottom = matrix.height - 8.0
        self.image = Particle.images['particle']
        self.rect = self.image.get_rect()
        self.x = float( random.randrange(1,
                        matrix.width - self.rect.width-1) )
        self.y = float( random.randrange(1,
                        matrix.height - self.rect.height-1) )

    def set_track(self, track):
        if not track:
            self.image = Particle.images['particle']
        else:
            self.image = Particle.images['track']

    def update(self):
        self.x += random.gauss(0,0.5)
        self.y += random.gauss(0,0.5)
        if self.x < self.area_left:
            self.x = self.area_left
        elif self.x > self.area_right:
            self.x = self.area_right
        if self.y < self.area_top:
            self.y = self.area_top
        elif self.y > self.area_bottom:
            self.y = self.area_bottom
        self.rect.x = int(self.x)
        self.rect.y = int(self.y)


class Pointer:

    images = None

    def __init__(self):
        if Pointer.images is None:
            Pointer.images = {}
            if platform == 'pc':
                image_file = os.path.join('data', 'pointer1.png')
                image1 = pg.image.load(image_file).convert_alpha()
                image_file = os.path.join('data', 'pointer2.png')
                image2 = pg.image.load(image_file).convert_alpha()
            else:
                image1 = pg.image.load('./data/pointer1.png')
                image2 = pg.image.load('./data/pointer2.png')
            image3 = pg.Surface((16,16), pg.SRCALPHA)
            Pointer.images['nonactive'] = image1
            Pointer.images['active'] = image2
            Pointer.images['blank'] = image3
        self.image = Pointer.images['nonactive']
        self.rect = self.image.get_rect()
        self.rect.x = -100
        self.rect.y = -100
        self.active = False

    def set_active(self, active):
        if not active:
            self.image = Pointer.images['nonactive']
            self.active = False
        else:
            self.image = Pointer.images['active']
            self.active = True

    def set_display(self, display):
        if display:
            self.set_active(self.active)
        else:
            self.image = Pointer.images['blank']

    def update(self, pos):
        self.rect.x = pos[0] - 8
        self.rect.y = pos[1] - 8


class TouchHandler(object):

    def __init__(self, matrix):
        self.matrix = matrix
        self.move = False
        self.pos = {'x':0, 'y':0}

    def onTouchInitiate(self, event):
        self.matrix.pointer.set_display(False)

    def onTouchStart(self, event):
        touch = event.touches.item(0)
        r = pg.env.canvas.getElement().getBoundingClientRect()
        self.pos['x'] = touch.clientX - round(r.left)
        self.pos['y'] = touch.clientY - round(r.top)
        pg.event.mouseMove['x'] = touch.clientX
        pg.event.mouseMove['y'] = touch.clientY
        if event.cancelable:
            event.preventDefault()

    def onTouchEnd(self, event):
        if not self.move:
            evt = pg.event.Event(pg.MOUSEBUTTONDOWN,
                     {'button':1, 'pos':(self.pos['x'],self.pos['y'])})
            pg.event.post(evt)
            self.matrix.toggle_pointer(self.pos['x'],self.pos['y'])
        else:
            self.move = False
        if event.cancelable:
            event.preventDefault()

    def onTouchMove(self, event):
        touch = event.touches.item(0)
        pg.event.mouseMove['x'] = touch.clientX
        pg.event.mouseMove['y'] = touch.clientY
        r = pg.env.canvas.getElement().getBoundingClientRect()
        x = pg.event.mouseMove['x'] - round(r.left)
        y = pg.event.mouseMove['y'] - round(r.top)
        if abs(x-self.pos['x']) < 50 and not self.move:
            if (y-self.pos['y']) > 100:
                evt = pg.event.Event(pg.KEYDOWN, {'key':pg.K_p})
                pg.event.post(evt)
                self.move = True
            if (self.pos['y']-y) > 100:
                evt = pg.event.Event(pg.KEYDOWN, {'key':pg.K_i})
                pg.event.post(evt)
                self.move = True
        elif abs(y-self.pos['y']) < 50 and not self.move:
            if (x-self.pos['x']) > 100:
                evt = pg.event.Event(pg.KEYDOWN, {'key':pg.K_r})
                pg.event.post(evt)
                self.move = True
            if (self.pos['x']-x) > 100:
                evt = pg.event.Event(pg.KEYDOWN, {'key':pg.K_q})
                pg.event.post(evt)
                self.move = True

    def onTouchCancel(self, event):
        pass


def setup(width, height):
    pg.init()
    display = pg.display.set_mode((width, height))
    pg.display.set_caption('Brownian Motion')
    if platform != 'js':
        image = pg.image.load(os.path.join('data', 'particle1.png'))
        image = pg.transform.smoothscale(image, (9,9))
        icon = pg.Surface((32,32), pg.SRCALPHA)
        for pos in ((7,7),(23,7),(15,16)):
            icon.blit(image, pos)
        pg.display.set_icon(icon)
    if platform == 'js':
        pg.surface.bounding_rect_return(False)
    pg.mouse.set_visible(False)
    return display


def program_exec(matrix):
    matrix.clock_tick()
    matrix.update()
    pg.display.update()
    quit = matrix.input()
    return quit


def run():
    program_exec(matrix)


matrix = display = None


def prerun():
    global matrix
    matrix = Matrix(display)
    pg.set_callback(run)


def main_js():
    global display
    display = setup(400,400)
    images = ['./data/particle1.png', './data/particle2.png',
              './data/pointer1.png', './data/pointer2.png']
    pg.setup(prerun, images)


def main():
    display = setup(400,400)
    matrix = Matrix(display)
    if platform == 'jvm':
        pg.bounding_rect_return(False)
    quit = False
    while not quit:
        quit = program_exec(matrix)


if __name__ == '__main__':
    if platform in ('pc', 'jvm'):
        main()
    elif platform == 'js':
        main_js()

