Brownian Motion Simulation

Brownian Motion is a simulation of the brownian motion phenomenon where microscopic particles move due to random molecule collisions, for instance collision by water molecules in motion. The app can run on several platforms, on the PC with Python/Pygame, JVM with Jython/PyJ2D, and in the web browser with Transcrypt/Pyjsdl-ts.

The app has the following controls: trace of the particle undergoing brownian motion activated with the mouse (touch). Option to add particles with key 'p' (swipe-down), display info with key 'i' (swipe-up), reset with key 'r' (swipe-right), and quit with key 'q' (swipe-left). In parentheses are controls for the web browser app on touchscreen devices such as mobile.

Dependencies for PC:
Python 2.7+ (https://www.python.org/)
Pygame 1.9+ (https://www.pygame.org/)

Dependencies for JVM:
PyJ2D (https://gatc.ca/projects/pyj2d/) / Jython 2.2.1+ (https://www.jython.org/)
>Optional to port Pygame app to Java environment of JVM 6.0+ (https://www.java.com).

Dependencies for web browser:
Pyjsdl-ts (https://gatc.ca/projects/pyjsdl-ts/) / Transcrypt (https://www.transcrypt.org/)
>Optional to port Pygame app to JS environment of web browser.

Instructions to run with for PyJ2D and Pyjsdl-ts can be found on the project pages. For JavaScript compilation using Pyjsdl from the Pyjsdl-ts package, download Pyjsdl-ts (https://gatc.ca/projects/pyjsdl-ts/) and unpack the pyjsdl folder into the script folder. Install Transcrypt (https://www.transcrypt.org/) and use the command 'transcrypt -n brownian.py' to compile the Python code to JavaScript in the __target__ folder. Running in the web browser requires brownian.html, the __target__ folder, and the data folder. The brownian.html file can then launch the JavaScript app in a web browser from a local server (python3 -m http.server) or online server.

Released under the GPL License (https://opensource.org/licenses/GPL-3.0).

