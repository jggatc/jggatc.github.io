#Pyjsdl - Copyright (C) 2013 James Garnon

#Not Implemented
#from __future__ import division
import env
from pyjamas import DOM    ###0.12

__docformat__ = 'restructuredtext'


class Mouse(object):
    """
    **pyjsdl.mouse**
    
    * pyjsdl.mouse.get_pressed
    * pyjsdl.mouse.get_pos
    * pyjsdl.mouse.get_rel
    """

    def __init__(self):
        """
        Provides methods to access the mouse function.
        
        Module initialization creates pyjs2d.mouse instance.
        """
        self.pos_rel = (0, 0)
        self._nonimplemented_methods()

    def get_pressed(self):
        """
        Return state of mouse buttons as a tuple of bool for button1,2,3.
        """
        try:
            button = env.canvas.event.mousePress.button + 1      ###0.12
        except AttributeError:
            button = None
        return (1==button,2==button,3==button)

    def get_pos(self):
        """
        Return x,y of mouse pointer.
        If the pointer is not in canvas, returns -1,-1
        """
        try:
            return env.canvas.event.mouseMove.pos      ###0.12
        except AttributeError:
            return (-1,-1)

    def get_rel(self):
        """
        Return relative x,y change of mouse position since last call.
        """
        pos = self.get_pos()
        rel = (pos[0]-self.pos_rel[0], pos[1]-self.pos_rel[1])
        self.pos_rel = pos
        return rel

    def set_visible(self, visible):     ###0.12
        """
        Set visibility of mouse cursor. Return bool of previous state.
        """
        cursor_visible = env.canvas.event.cursorVisible
        if visible:
            if not cursor_visible:
                DOM.setStyleAttribute(env.canvas.getElement(), 'cursor', 'default')
                env.canvas.event.cursorVisible = True
        else:
            if cursor_visible:
                DOM.setStyleAttribute(env.canvas.getElement(), 'cursor', 'none')
                env.canvas.event.cursorVisible = False
        return cursor_visible

    def _nonimplemented_methods(self):
        """
        Non-implemented methods.
        """
        self.set_pos = lambda *arg: None
        self.get_focused = lambda *arg: True
        self.set_cursor = lambda *arg: None
        self.get_cursor = lambda *arg: ()

