import random
import pygame as pg
from util import load_image


class Cell(pg.sprite.Sprite):
    """Members of the class cell will form a monolayer. Update will happen occasionally. Cells can be infected by the virus. When the virus complete replication cycle, cell will die. Growth of cells will be contact inhibited, and if neighbouring cells die, selected adjacent cells will begin growth cycle so as to divide, whereupon the new cell will move to injured area for healing."""

    image = None

    def __init__(self, x, y, matrix):
        pg.sprite.Sprite.__init__(self)
        self.matrix = matrix
        self.x = int( (x * 50.6) + 13 + (((y)%2)*15) )  #location in matrix
        self.y = int( (y * 50.6) + 13 + (((x)%2)*15) )
        self.grid_x = x
        self.grid_y = y
        self.grid = [(self.grid_x+x,self.grid_y+y) for x in [-1,0,1] for y in [-1,0,1] if self.grid_x+x>-1 and self.grid_x+x<self.matrix.width//50 and self.grid_y+y>-1 and self.grid_y+y<self.matrix.height//50]    #checking adjacent cells
        random.shuffle(self.grid)   #randomize order of checking
        self.grow_grid = ()         #growth for healing
        if not Cell.image:  #load images on first instance
            Cell.image = load_image('cell.png')
            Cell.image2 = load_image('cell_infect.png')
        self.image = Cell.image
        self.rect = self.image.get_rect(center=(self.x,self.y))
        self.area_position = ()     #region location
        self.isinfect = False
        self.isgrow = False
        self.isgrown = False
        self.rip = False
        self.infect_count = 0
        self.virus_variant = None
        self.grow_count = 0
        self.infect_time = 500
        self.grow_time = 500

    def infection(self, virus):
        """Checks whether virus gains infection, if so, set cell is infected, and disable if was growing. Returns isinfect and previous isgrown states. If virus is none, sets cell to infection state."""
        isinfect = False
        if not self.isinfect and not self.rip and not virus.infecting and virus.life_force:
            if virus.rect.collidepoint(self.rect.center):
                isinfect = True
                self.isinfect = True
                if self.isgrow or self.isgrown:
                    self.isgrow = False
                    self.isgrown = False
                    self.matrix.cell_map_update((self.grow_grid[0],self.grow_grid[1]), 0)    #restore to empty
                    self.grow_grid = ()
                self.image = Cell.image2
                self.rect = self.image.get_rect(center=(self.x,self.y))
        return isinfect

    def infect_set(self, virus_variant, infect_time=500):
        self.isinfect = True
        self.virus_variant = virus_variant
        self.infect_time = infect_time
        self.image = Cell.image2
        self.rect = self.image.get_rect(center=(self.x,self.y))

    def infected(self):
        if self.isinfect:
            if not self.rip:
                self.infect_count += 1
                if self.infect_count > self.infect_time:
                    self.infect_count = 0
                    self.rip = True
                    self.matrix.cell_map_update((self.grid_x,self.grid_y), 0)   #grid empty

    def regrowth(self):
        if not self.isinfect and not self.rip and not self.isgrow and not self.isgrown:
            for cell_next in self.grid:
                if not self.matrix.cell_map[cell_next[0],cell_next[1]]:
                    self.isgrow = True
                    self.grow_grid = cell_next
                    self.matrix.cell_map_update((cell_next[0],cell_next[1]), 2)   #grid reserved from regrowth
                    break
            if self.isgrow:
                return self
            else:
                return None

    def growth(self):
        if self.isgrow:
            if not self.isgrown:
                self.grow_count += 1
                if self.grow_count > self.grow_time:
                    self.grow_count = 0
                    self.isgrow = False
                    self.matrix.cell_map_update((self.grow_grid[0],self.grow_grid[1]), 1)     #grid regrown
                    self.isgrown = True

    def update(self):
        if self.isinfect:
            self.infected()
            return None
        elif self.isgrow:
            self.growth()
            return None
        else:
            check_regrowth_initialized = self.regrowth()
            return check_regrowth_initialized

