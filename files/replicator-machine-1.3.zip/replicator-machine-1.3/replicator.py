#!/usr/bin/env python
from __future__ import division

"""
Replicator Machine
Copyright (C) 2009 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Replicator Machine 1.3
Download site: https://gatc.ca
"""

try:
    import pygame as pg
    from pygame import bufferproxy
    import numpy as np
except ImportError:
    raise ImportError("Pygame and Numpy modules are required.")
import interphase
import random
import math
import os
import sys
import optparse
from nanobot import Nanobot
from cell import Cell
from macrophage import Macrophage
from virion import Virion
from control import Control
from util import load_image, load_sound, sin_table, cos_table

test = False
if not test:
    import warnings
    warnings.filterwarnings("ignore")

MATRIX_X = 1000
MATRIX_Y = 1000
DISPLAY_X = 500
DISPLAY_Y = 500


class Matrix(object):

    def __init__(self):
        self.width = MATRIX_X
        self.height = MATRIX_Y
        self.display_width = DISPLAY_X
        self.display_height = DISPLAY_Y
        pg.init()
        pg.display.set_caption('Replicator Machine')
        iconname = os.path.join('data', 'icon.png')
        icon = pg.image.load(iconname)
        pg.display.set_icon(icon)
        if config['display_gamma']:
            gamma_set = pg.display.set_gamma(config['display_gamma'])
        self.screen = pg.display.set_mode((self.display_width,self.display_height))
        if config['display_gamma'] and not gamma_set:   #if prior set_gamma failed
            gamma_set = pg.display.set_gamma(config['display_gamma'])
        pg.surfarray.use_arraytype('numpy')
        self.borders = self.matrix_borders()
        self.overlap = 50     #screen field overlap
        self.field_x = (self.width//2)-(self.display_width//2)   #for field scroll
        self.field_y = (self.height//2)
        self.virus = pg.sprite.RenderUpdates()
        self.virus_add = False
        self.virus_count = 0
        self.virus_count_i = ((self.width*self.height)//40000)
        self.virus_variant = 1
        self.virus_mutation = False
        self.screen_matrix = pg.display.get_surface()
        self.creatures = pg.sprite.OrderedUpdates()
        self.menu_area = [pg.Rect(180,y,165,30) for y in range(200, 351, 50)]
        self.info = interphase.Text(self.screen)
        self.info.set_font_color((82,96,116))
        self.control_list = []
        self.volume = 0.3
        self.ending = False
        self.signal_lost = load_sound("signal_lost.ogg")
        self.level = 1  #difficulty level
        self.bot = pg.sprite.GroupSingle()
        self.projectiles = pg.sprite.RenderUpdates()    #projectile group
        self.cells = pg.sprite.OrderedUpdates()      #cell group
        self.infected_cell = pg.sprite.RenderUpdates()      #cells infected with virus
        self.replicating_cell = pg.sprite.RenderUpdates()   #cells replicating for regrowth
        self.resting_cell = pg.sprite.RenderUpdates()   #cells not infected or replicating
        self.areas, self.area_rect, self.area_cell = self.matrix_rect()     #regions
        self.area_scan = 0
        self.cells_new = pg.sprite.OrderedUpdates()
        self.screen_base = pg.Surface((self.display_width,self.display_height))
        self.base_image = load_image('base.png')
        self.screen_base.blit(self.base_image, (0,0))
        self.screen.blit(self.screen_base, (0,0))
        self.macs = pg.sprite.RenderUpdates()
        self.macrophage_count = 0
        self.macrophage_count_i = ((self.width*self.height)//250000)
        self.cell_count = 0
        self.cell_count_i = (self.width//50) * (self.height//50)
        self.cell_map = np.ones((self.width//50,self.height//50), 'i')
        self.cell_randomized = []   #randomized list of cells
        pg.mixer.set_num_channels(132)   #lack of channels cause crash
        self.scroll_left = 0
        self.scroll_right = 0
        self.scroll_up = 0
        self.scroll_down = 0
        self.scroll = False
        self.edge_check_count = 0   #interval to check virus at edge
        self.update_list = []   #list of object to update display
        self.display_update = False   #update cells on screen
        self.macrophage_activated = False   #macrophages activated by vaccine pulse
        self.map_surface = pg.Surface((20,20))
        self.map_surface_zoom = pg.Surface((60,60))
        self.cell_map2 = np.ones((self.width//50,self.height//50), 'i')
        self.cell_map2.fill(0x232835)
        pg.surfarray.blit_array(self.map_surface, self.cell_map2)
        self.map_surface_zoom = pg.transform.smoothscale(self.map_surface, (60,60))
        self.map_update = 0
        self.life_surface = pg.Surface((60,5))
        self.check_count = 0
        self.check_rate = 10
        self.simulation = False
        self.cell = None
        self.warp = 0
        self.warp_speed = 20
        self.warp_time = 0
        self.warp_distance = 0
        self.warp_engaged = False
        self.destination = False
        self.map_display = True
        self.screen_temp = pg.Surface((self.display_width,self.display_height))
        self.screen_temp2 = pg.Surface((self.display_width,self.display_height))
        self.endgame_move = 0
        self.stage = 1      #three stages of outbreak before infection irradicated

    def opening(self, escape=False):
        self.menu()
        pg.mixer.stop()
        pg.event.set_grab(False)
        pg.mouse.set_visible(True)
        pg.event.set_allowed(pg.MOUSEBUTTONDOWN)
        quit = False
        while not quit:
            control.clock.tick(40)
            for event in pg.event.get():
                if event.type == pg.MOUSEBUTTONDOWN:
                    for i, rect in enumerate(self.menu_area):
                        if rect.collidepoint(event.pos):
                            if i == 0:
                                self.setup()
                                quit = True
                            elif i == 1:
                                self.setup(simulation=True)
                                quit = True
                            elif i == 2:
                                self.control_info()
                                self.menu()
                            elif i == 3:
                                control.quit = True
                                quit = True
                elif event.type == pg.KEYDOWN:
                    if event.key == pg.K_1:
                        self.setup()
                        quit = True
                    elif event.key == pg.K_2:
                        self.setup(simulation=True)
                        quit = True
                    elif event.key == pg.K_3:
                        self.control_info()
                        self.menu()
                    elif event.key == pg.K_4:
                        control.quit = True
                        quit = True
                    elif event.key == pg.K_ESCAPE:
                        if escape:
                            self.display_update = True
                            return True
                elif event.type == pg.QUIT:
                    control.quit = True
                    quit = True

    def menu(self):
        menu_list = [ ("Replicator Machine",32,(100,100)), ("1. Battle",24,(180,200)), ("2. Simulation",24,(180,250)), ("3. Control",24,(180,300)), ("4. Quit",24,(180,350)) ]
        self.screen.fill((0,0,0))
        for item in menu_list:
            self.info.add(item[0])
            self.info.set_font_size(item[1])
            self.info.set_position(item[2])
            self.info()
        pg.display.flip()
        return

    def control_info(self):
        if not self.control_list:
            try:
                controls = open('control.txt', 'r')
                for item in controls:
                    key = item[:20].strip()
                    command = item[20:].strip()
                    control_item = { 'key':key, 'command':command }
                    self.control_list.append(control_item)
                controls.close()
            except IOError:
                return
        self.screen.fill((0,0,0))
        self.info.set_font_size(12)
        count = 30
        for control_item in self.control_list:
            self.info.add(control_item['key'])
            self.info.set_position((100,count))
            self.info()
            self.info.add(control_item['command'])
            self.info.set_position((230,count))
            self.info()
            count += 15
        interrupt = False
        while not interrupt:
            control.clock.tick(40)
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    control.quit = True
                elif event.type == pg.KEYDOWN:
                    interrupt = True
            pg.display.flip()
        return

    def setup(self, level=1, simulation=False):
        if simulation:
            self.simulation = True
            pg.event.set_grab(False)
            pg.mouse.set_visible(True)
            pg.event.set_blocked([pg.MOUSEBUTTONDOWN, pg.MOUSEBUTTONUP, pg.MOUSEMOTION])
            control.panel.initialize()
        else:
            self.simulation = False
            if control.mouse_enabled:
                pg.event.set_grab(True)
                pg.mouse.set_visible(False)
                pg.event.set_allowed([pg.MOUSEBUTTONDOWN, pg.MOUSEBUTTONUP, pg.MOUSEMOTION])
            else:
                pg.event.set_grab(False)
                pg.mouse.set_visible(True)
                pg.event.set_blocked([pg.MOUSEBUTTONDOWN, pg.MOUSEBUTTONUP, pg.MOUSEMOTION])
        pg.mixer.stop()
        self.cells.empty()
        self.resting_cell.empty()
        self.infected_cell.empty()
        self.replicating_cell.empty()
        self.virus.empty()
        self.virus.empty()
        self.macs.empty()
        self.bot.empty()
        self.projectiles.empty()
        self.creatures.empty()
        for area in self.area_cell:      #empty cell regional grouping
            self.area_cell[area].empty()
        self.field_x = (self.width//2)-(self.display_width//2)   #for field scroll
        self.field_y = (self.height//2)
        self.cell_count = 0
        self.virus_count = 0
        self.macrophage_count = 0
        self.macrophage_activated = False
        self.virus_variant = 1
        self.virus_mutation = False
        self.level = 1
        self.stage = 1
        self.ending = False
        self.cell_map = np.ones((self.width//50,self.height//50) , 'i')
        for y in range(self.width//50):
            for x in range(self.height//50):
                self.add_creature('Cell', (x,y))
        if not simulation:
            for i in range(self.macrophage_count_i):
                self.add_creature('Macrophage')
            self.add_creature('Nanobot')
        infected_cells = random.sample(self.resting_cell.sprites(), self.virus_count_i)
        for cell in infected_cells:
            cell.infect_set(virus_variant=self.level, infect_time=random.randrange(490))
            self.cell_state(cell, 'infected')
        self.virus_count = self.virus_count_i
        self.cell_map2 = np.ones((self.width//50,self.height//50), 'i')
        self.cell_map2.fill(0x232835)
        pg.surfarray.blit_array(self.map_surface, self.cell_map2)
        self.map_surface_zoom = pg.transform.smoothscale(self.map_surface, (60,60))
        self.display_update = True
        self.matrix_update()

    def simulation_set(self, parameter):
        if not self.simulation:
            return
        if parameter == 'Variant Switch':
            if self.virus_variant < 4:
                self.virus_variant += 1
                for virus in self.virus:
                    virus.variant = self.virus_variant
                for cell in self.infected_cell:
                    cell.virus_variant = self.virus_variant
        elif parameter == 'Mutation Operational':
            self.virus_mutation = not self.virus_mutation
        elif parameter == 'Virus Addition':
            self.add_creature('Virus')
        elif parameter == 'Macrophage Addition':
            self.add_creature('Macrophage')
        elif parameter == 'Nanobot Addition':
            self.add_creature('Nanobot')

    def level_set(self):
        if not self.simulation:
            if self.level < 3:
                self.level += 1
                for cell in self.infected_cell:
                    cell.virus_variant += 1

    def endgame_check(self):
        if self.simulation:
            return False
        if not self.ending:
            if not (self.bot.sprite and self.virus_count > 0):
                self.ending = True
                if self.bot.sprite:
                    if self.stage < 3:
                        self.stage += 1
                        self.endgame_move = 1
                        return True
                    else:
                        self.endgame_move = 100
                        return True
                else:
                    self.endgame_move = -1
                    return True
            else:
                return False
        else:
            return True

    def endgame(self):
        if self.endgame_move == 1:
            gathering_signal = self.endgame_sequence('Gathering Signal')
            if gathering_signal:
                self.endgame_move = 2
        elif self.endgame_move == 2:
            gathering = self.endgame_sequence('Gathering')
            if gathering:
                self.endgame_move = 3
        elif self.endgame_move == 3:
            warp_initiate = self.endgame_sequence('Warp Initiate')
            if warp_initiate:
                self.endgame_move = 4
        elif self.endgame_move == 4:
            warp_engage = self.endgame_sequence('Warp')
            if warp_engage:
                self.endgame_move = 5
        elif self.endgame_move == 5:
            destination = self.endgame_sequence('Transwarp')
            if destination:
                self.endgame_move = 6
        elif self.endgame_move == 6:
            finale = self.endgame_sequence('Finale')
            if finale:
                self.endgame_move = 0
        elif self.endgame_move == 100:
            gathering_signal = self.endgame_sequence('Gathering Signal')
            if gathering_signal:
                self.endgame_move = 0
                self.endgame_sequence('Pandemic Averted')
        elif self.endgame_move == -1:
            signal_lost = self.endgame_sequence('Signal Lost')
            if signal_lost:
                self.endgame_move = 0

    def endgame_sequence(self, phase):
        if phase == 'Gathering Signal':
            if not self.bot.sprite.vaccine_released:
                if not self.bot.sprite.vaccine_pulse_load:
                    self.bot.sprite.vaccine_pulse_load = True
                self.matrix_update()
                return False
            else:
                self.bot.sprite.tractor_beam = True
                self.bot.sprite.tractor_beam_captured = True
                for mac in self.macs:
                    mac.activate_count = 1000
                    mac.girth = 100
                    mac.tractor_beam = True
                self.matrix_update()
                return True
        elif phase == 'Gathering':
            for mac in self.macs:   #behind bot
                if mac.y < self.bot.sprite.y+50:
                    mac.pos_y += 2
                    mac.y = int(mac.pos_y)
            self.matrix_update()
            for mac in self.macs:
                if ((mac.y>self.bot.sprite.y and mac.y<self.bot.sprite.y+150) or (mac.y >= self.height-50)) and (mac.x>self.bot.sprite.x-150 and mac.x<self.bot.sprite.x+150):
                    inplace = True
                else:
                    inplace = False
                    break
            if inplace:
                self.warp_engaged = True
                self.bot.sprite.rotate = 0
                self.bot.sprite.bot_velocity = 0
                self.bot.sprite.velocity = 0
                self.bot.sprite.velocity_l = 0
                self.bot.sprite.velocity_r = 0
                self.bot.sprite.toggle_forward = False
                self.bot.sprite.toggle_reverse = False
                self.bot.sprite.toggle_motion = False
                self.bot.sprite.toggle_left = False
                self.bot.sprite.toggle_right = False
                self.bot.sprite.toggle_strafeleft = False
                self.bot.sprite.toggle_straferight = False
                self.map_display = False
                return True
            else:
                return False
        elif phase == 'Warp Initiate':
            for y in range(self.width//50):
                for x in range(self.height//50):
                    cell = Cell(x, y, self)
                    self.cells_new.add(cell)
            field_x = (self.width//2)-(self.display_width//2)
            field_y = (self.height//2)
            self.screen_temp.blit(self.base_image, (0,0))
            self.creatures.add(self.cells_new.sprites())
            for bug in self.creatures:       #adjust display location
                bug.rect.centerx -= field_x
                bug.rect.centery -= field_y
            self.creatures.draw(self.screen_temp)
            for bug in self.creatures:       #restore location
                bug.rect.centerx += field_x
                bug.rect.centery += field_y
            self.creatures.empty()
            infected_cells = random.sample(self.cells_new.sprites(), self.virus_count_i)
            for cell in infected_cells:
                if self.level < 3:
                    variant = self.level+1
                else:
                    variant = self.level
                cell.infect_set(virus_variant=variant, infect_time=random.randrange(490))
            self.screen_temp2.blit(self.base_image, (0,0))
            self.cells_new.update()
            self.creatures.add(self.cells_new.sprites())
            for bug in self.creatures:       #adjust display location
                bug.rect.centerx -= field_x
                bug.rect.centery -= field_y
            self.creatures.draw(self.screen_temp2)
            for bug in self.creatures:       #restore location
                bug.rect.centerx += field_x
                bug.rect.centery += field_y
            self.creatures.empty()
            return True
        elif phase == 'Warp':
            scroll = self.matrix_scroll('u',self.warp_speed)
            if scroll:
                self.warp_distance += self.warp_speed
                self.bot.sprite.pos_y -= self.warp_speed
                self.bot.sprite.y -= self.warp_speed
                for mac in self.macs:
                    mac.pos_y -= self.warp_speed
                    mac.y -= self.warp_speed
                if self.bot.sprite.direction >= 10:
                    if self.bot.sprite.direction < 180:
                        self.bot.sprite.direction -= 10
                    else:
                        self.bot.sprite.direction += 10
                else:
                    self.bot.sprite.direction = 0
                self.matrix_update()
                return False
            else:
                self.field_y += self.warp_distance
                self.bot.sprite.pos_y += self.warp_distance
                self.bot.sprite.y += self.warp_distance
                for mac in self.macs:
                    mac.pos_y += self.warp_distance
                    mac.y += self.warp_distance
                self.warp_distance = 0
                if self.field_x < (self.width//2)-(self.display_width//2):       #adjust position to next level
                    field_adjust_x = ((self.width//2)-(self.display_width//2)) - self.field_x
                elif self.field_x > (self.width//2)-(self.display_width//2):
                    field_adjust_x = ((self.width//2)-(self.display_width//2)) - self.field_x
                else:
                    field_adjust_x = 0
                field_adjust_y = (self.height//2) - self.field_y
                self.field_x += field_adjust_x
                self.field_y += field_adjust_y
                self.bot.sprite.pos_x += field_adjust_x
                self.bot.sprite.x = int(self.bot.sprite.pos_x)
                self.bot.sprite.pos_y += field_adjust_y
                self.bot.sprite.y = int(self.bot.sprite.pos_y)
                for mac in self.macs:
                    mac.pos_x += field_adjust_x
                    mac.x = int(mac.pos_x)
                    mac.pos_y += field_adjust_y
                    mac.y = int(mac.pos_y)
                return True
        elif phase == 'Transwarp':
            if self.warp_time <= 5:
                self.warp += self.warp_speed
                if self.warp <= self.display_height:
                    self.screen.blit(self.screen_base, (0,self.warp), (0,0,self.display_width,self.display_height-self.warp))
                    if not self.destination:
                        self.screen.blit(self.screen_temp, (0,0), (0,self.display_height-self.warp,self.display_width,self.warp))
                    else:
                        self.screen.blit(self.screen_temp2, (0,0), (0,self.display_height-self.warp,self.display_width,self.warp))
                    if self.bot.sprite.direction >= 10:
                        if self.bot.sprite.direction < 180:
                            self.bot.sprite.direction -= 10
                        else:
                            self.bot.sprite.direction += 10
                    else:
                        self.bot.sprite.direction = 0
                    self.bot.update()
                    self.macs.update()
                    self.creatures.add([creature for creature in self.macs])
                    self.creatures.add(self.bot.sprite)
                    for bug in self.creatures:       #adjust display location
                        bug.rect.centerx -= self.field_x
                        bug.rect.centery -= self.field_y
                    self.creatures.draw(self.screen)
                    for bug in self.creatures:       #restore location
                        bug.rect.centerx += self.field_x
                        bug.rect.centery += self.field_y
                    self.creatures.empty()
                    self.display_update = True
                else:
                    self.warp = 0
                    self.warp_time += 1
                    if self.warp_time == 1:
                        self.screen_base = self.screen_temp.copy()
                    elif self.warp_time == 5:
                        self.destination = True
                return False
            else:
                self.warp = 0
                self.warp_time = 0
                self.destination = False
                self.display_update = True
                return True
        elif phase == 'Finale':
            self.cells.empty()
            self.resting_cell.empty()
            self.infected_cell.empty()
            self.replicating_cell.empty()
            self.virus.empty()
            self.cell_count = 0
            self.virus_count = 0
            for area in self.area_cell:
                self.area_cell[area].empty()
            self.cells = self.cells_new.copy()
            for cell in self.cells:
                self.cell_state(cell, 'resting')
                if cell.isinfect:
                    self.cell_state(cell, 'infected')
                self.cell_count += 1
            self.cell_map = np.ones((self.width//50,self.height//50), 'i')
            self.cell_map2 = np.ones((self.width//50,self.height//50), 'i')
            self.cell_map2.fill(0x101219)
            pg.surfarray.blit_array(self.map_surface, self.cell_map2)
            self.map_surface_zoom = pg.transform.smoothscale(self.map_surface, (60,60))
            self.virus_count = self.virus_count_i
            self.cells_new.empty()
            self.bot.sprite.life_force = 100
            self.bot.sprite.tractor_beam = False
            self.bot.sprite.tractor_beam_captured = None
            self.bot.sprite.velocity_max = 6.0
            for mac in self.macs:
                mac.activation_state = 0
                mac.tractor_beam = False
            self.macrophage_activated = False
            self.display_update = True
            self.map_display = True
            self.matrix_update()
            self.ending = False
            self.warp_engaged = False
            if self.level < 3:
                self.level += 1
            return True
        elif phase =='Pandemic Averted':  #After three stages of infection, bot vaccine programming complete
            while self.cell_count < self.cell_count_i:
                self.update_list = []    #rect list to be updated on display
                self.matrix_update()
                if not self.display_update:
                    pg.display.update(self.update_list)
                else:
                    pg.display.flip()
                    self.display_update = False
                control.update()
            else:
                self.opening()
        elif phase == 'Signal Lost':
            pg.mixer.stop()
            self.signal_lost.set_volume(self.volume)
            self.signal_lost.play(-1)
            pg.time.delay(500)
            interrupt = False
            for update in range(100):
                for i in range(5000):
                    size = random.randrange(1,3)
                    x = random.randrange(self.display_width-1)
                    y = random.randrange(self.display_height-1)
                    pg.draw.circle(self.screen_matrix, (225,225,225), (x,y), size, 0)
                pg.display.flip()
                control.clock.tick(40)
                self.screen_matrix.fill((10,10,10))
                if interrupt:
                    break
                for event in pg.event.get():
                    if event.type == pg.QUIT:
                        control.quit = True
                    elif event.type == pg.KEYDOWN:
                        if update > 25:
                            interrupt = True
            self.signal_lost.stop()
            self.opening()
            return True

    def set_volume(self):
        Nanobot.shot_sound.set_volume(self.volume)
        Macrophage.sound.set_volume(self.volume)

    def matrix_borders(self):
        class Edge(pg.sprite.Sprite):
            def __init__(self, x, y, dim_x, dim_y, side):
                pg.sprite.Sprite.__init__(self)
                self.rect = pg.Rect(x,y,dim_x,dim_y)
                self.side = side
        borders = pg.sprite.Group()
        borders.add( Edge(0,0,self.width,1,'n') )
        borders.add( Edge(0,self.height-2,self.width,1,'s') )
        borders.add( Edge(0,0,1,self.height,'w') )
        borders.add( Edge(self.width-2,0,1,self.height,'e') )
        return borders

    def matrix_rect(self):  #matrix divided into regions
        """Areas: rect: (250,250) position: (0,0), (250,0), (500,0), (750,0), (0,250), (250,250), (500,250), (750,250), (0,500), (250,500), (500,500), (750,500), (0,750), (250,750), (500,750), (750,750)"""
        class Area_rect(pg.sprite.Sprite):
            def __init__(self, position, size):
                pg.sprite.Sprite.__init__(self)
                self.position = position
                self.rect = pg.Rect(position,size)
        areas = []
        area_rect = pg.sprite.Group()
        area_cell = {}
        for y in range(0,self.height,250):
            for x in range(0,self.width,250):
                areas.append((x,y))
                area_rect.add( Area_rect((x,y),(250,250)) )
                area_cell[(x,y)] = pg.sprite.Group()
        return areas, area_rect, area_cell

    def cell_area_position(self, cell_group):
        area_cell = pg.sprite.groupcollide(self.area_rect, cell_group, False, False)
        for area, cells in area_cell.items():
            for cell in cells:
                if area.rect.collidepoint((cell.x,cell.y)):
                    self.area_cell[area.position].add(cell)
                    cell.area_position = area.position

    def cell_state(self, cell, state):
        if state == 'resting':
            self.resting_cell.add(cell)
            cell_group = pg.sprite.GroupSingle(cell)
            self.cell_area_position(cell_group)
            cell_group.empty()
        elif state == 'replicating':
            self.replicating_cell.add(cell)     #add to replicating cell group for updating
            self.resting_cell.remove(cell)
        elif state == 'infected':
            self.infected_cell.add(cell)
            self.resting_cell.remove(cell)     #remove for transfer to infected_cell
            self.replicating_cell.remove(cell)
            self.area_cell[cell.area_position].remove(cell)

    def add_creature(self, creature, location=None):
        new_creature = None
        if creature == 'Virus':
            if ( self.virus_count < self.virus_count_i*100 ):
                if not location:
                    x_initial = random.randrange(10, self.width-10)
                    y_initial = random.randrange(10, self.height-10)
                else:
                    x_initial, y_initial = location
                if not self.simulation:
                    virus_variant = matrix.level
                else:
                    virus_variant = self.virus_variant
                new_creature = Virion(x_initial, y_initial, virus_variant, self)
                self.virus.add(new_creature)
                self.virus_count += 1
        elif creature == 'Cell':
            if not location:
                x_initial = random.randrange(100, self.width-100)
                y_initial = random.randrange(100, self.height-100)
            else:
                x_initial, y_initial = location               
            new_creature = Cell(x_initial, y_initial, self)
            self.cells.add(new_creature)
            self.cell_state(new_creature, 'resting')
            self.cell_count += 1
        elif creature == 'Macrophage':
            if ( self.macrophage_count < self.macrophage_count_i*100 ):
                if not location:
                    x_initial = random.randrange(100, self.width-100)
                    y_initial = random.randrange(100, self.height-100)
                else:
                    x_initial, y_initial = location               
                new_creature = Macrophage(x_initial, y_initial, self)
                self.macs.add(new_creature)
                self.macrophage_count += 1
        elif creature == 'Nanobot':
            if not location:
                x_initial, y_initial = 250+self.field_x,250+self.field_y
            else:
                x_initial, y_initial = location
            new_creature = Nanobot(x_initial, y_initial, self)
            self.bot.add(new_creature)
        return new_creature

    def remove_creature(self, creature, obj):
        if creature == 'Virus':
            obj.kill()
            self.virus_count -= 1
        elif creature == 'Cell':
            obj.kill()
            self.cell_count -= 1

    def matrix_map(self):
        self.map_update += 1
        if self.map_update > 10:
            self.cell_map2 = np.where(self.cell_map==1, 0x232835, 0x000000)
            pg.surfarray.blit_array(self.map_surface, self.cell_map2)
            self.map_surface_zoom = pg.transform.smoothscale(self.map_surface, (60,60))
            self.map_update = 0
        map_surface = self.map_surface_zoom.copy()
        map_surface.lock()
        for virus in self.virus:
            map_surface.set_at((virus.x//(self.width//60), virus.y//(self.height//60)), virus.color)
        map_surface.unlock()
        for mac in self.macs:
            map_surface.blit(mac.imagex, ((mac.x//(self.width//60))-4, (mac.y//(self.height//60))-4))
        map_surface.lock()
        for projectile in self.projectiles:
            map_surface.set_at((projectile.x//(self.width//60), projectile.y//(self.height//60)), 0x59abe5)
        map_surface.unlock()
        try:
            w, h = self.bot.sprite.imagex[self.bot.sprite.direction].get_size()
            map_surface.blit(self.bot.sprite.imagex[self.bot.sprite.direction], ((self.bot.sprite.x//(self.width//60))-(w//2), (self.bot.sprite.y//(self.height//60))-(h//2)))
        except AttributeError:  #no bot
            pass
        map_rect = self.screen_matrix.blit(map_surface, (430,430))
        pg.draw.rect(self.screen_matrix, 0x0f1215, (429,429,62,62), 2)
        try:
            life_force = self.bot.sprite.life_force
            life_line = int((life_force/100)*60)   #bot life force
            self.life_surface.fill(0x680000)
            if life_force > 25:
                self.life_surface.fill(0x73d74b, (0,0,life_line,5))
            else:
                if random.random() > 0.2:
                    self.life_surface.fill(0x73d74b, (0,0,life_line,5))
                else:
                    self.life_surface.fill(0x680000, (0,0,life_line,5))
            life_rect = self.screen_matrix.blit(self.life_surface, (430,492))
            pg.draw.rect(self.screen_matrix, 0x0f1215, (429,491,62,7), 2)
        except AttributeError:
            life_rect = None
        return map_rect, life_rect

    def matrix_scroll(self, direction, field_change=10):
        if direction == 'u':
            if self.field_y >= field_change:
                self.field_y -= field_change
                self.display_update = True
                return True
            else:
                return False
        elif direction == 'd':
            if self.field_y <= self.height-self.display_height-field_change:
                self.field_y += field_change
                self.display_update = True
                return True
            else:
                return False
        elif direction == 'l':
            if self.field_x >= field_change:
                self.field_x -= field_change
                self.display_update = True
                return True
            else:
                return False
        elif direction == 'r':
            if self.field_x <= self.width-self.display_width-field_change:
                self.field_x += field_change
                self.display_update = True
                return True
            else:
                return False

    def bot_scroll(self):
        if self.bot.sprite:
            if self.bot.sprite.rect.centerx < self.field_x+10 and not self.scroll_left:
                self.scroll_left = 25
            elif self.bot.sprite.rect.centerx > self.field_x+self.display_width-10 and not self.scroll_right:
                self.scroll_right = 25
            if self.bot.sprite.rect.centery < self.field_y+10 and not self.scroll_up:
                self.scroll_up = 25
            elif self.bot.sprite.rect.centery > self.field_y+self.display_height-10 and not self.scroll_down:
                self.scroll_down = 25
            if self.scroll_left or self.scroll_right or self.scroll_up or self.scroll_down:
                self.scroll = True
            else:
                self.scroll = False
            if self.scroll_left:
                if self.field_x - 10 >= 0:
                    self.field_x -= 10
                    self.scroll_left -= 1
                else:
                    self.scroll_left = 0
            elif self.scroll_right:
                if self.field_x + 10 <= self.width-self.display_width:
                    self.field_x += 10
                    self.scroll_right -= 1
                else:
                    self.scroll_right = 0
            if self.scroll_up:
                if self.field_y - 10 >= 0:
                    self.field_y -= 10
                    self.scroll_up -= 1
                else:
                    self.scroll_up = 0
            elif self.scroll_down:
                if self.field_y + 10 <= self.height-self.display_height:
                    self.field_y += 10
                    self.scroll_down -= 1
                else:
                    self.scroll_down = 0
            return self.scroll

    def cell_map_update(self, position, state):
        """State of positions in cell map. State 0:Empty, 1:Fill, 2:Hold."""
        self.cell_map[position] = state

    def infection_check(self):
        event_onscreen = False
        area = self.areas[self.area_scan]
        cell_collide = pg.sprite.groupcollide(self.area_cell[area], self.virus, False, False)
        for cell, viruses in cell_collide.items():
            for virus in viruses:
                if not virus.infecting:
                    isinfect = cell.infection(virus)
                    if isinfect:
                        self.cell_state(cell, 'infected')
                        if cell.rect.centerx > 0+self.field_x-self.overlap//5 and cell.rect.centerx < self.display_width+self.field_x+self.overlap//5 and cell.rect.centery > 0+self.field_y-self.overlap//5 and cell.rect.centery < self.display_height+self.field_y+self.overlap//5:
                            event_onscreen = True    #only update if onscreen
                        if not self.simulation:
                            mutation = virus.mutate()
                        else:
                            if self.virus_mutation:
                                mutation = virus.mutate()
                            else:
                                mutation = False
                        if not mutation:
                            variant = virus.variant
                        else:
                            variant = virus.variant + 1
                        cell.virus_variant = variant
                        virus.infecting = True     #virus infecting cell
                        self.virus.remove(virus)   #virus count unchanged
                        break
        self.area_scan += 1
        if self.area_scan > 15:
            self.area_scan = 0
        return event_onscreen

    def infected_cell_check(self):
        event_onscreen = False
        for cell in self.infected_cell:
            if cell.rip:
                virus_variant = cell.virus_variant
                cell.virus_variant = None
                progeny = Virion.variants[virus_variant]['progeny']
                for i in range(progeny):
                    x_initial = cell.rect.centerx
                    y_initial = cell.rect.centery
                    self.virus.add(Virion(x_initial, y_initial, virus_variant, self))
                self.virus_count += progeny-1    #less one for infected virus
                if cell.rect.centerx > 0+self.field_x-self.overlap//5 and cell.rect.centerx < self.display_width+self.field_x+self.overlap//5 and cell.rect.centery > 0+self.field_y-self.overlap//5 and cell.rect.centery < self.display_height+self.field_y+self.overlap//5:
                    event_onscreen = True
                self.remove_creature('Cell', cell)
        return event_onscreen

    def cell_regrowth_check(self):
        event_onscreen = False
        for cell in self.replicating_cell:
            if cell.isgrown:
                cell.isgrown = False
                new_cell = self.add_creature('Cell', location=(cell.grow_grid[0],cell.grow_grid[1]))
                if new_cell.rect.centerx > 0+self.field_x-self.overlap//5 and new_cell.rect.centerx < self.display_width+self.field_x+self.overlap//5 and new_cell.rect.centery > 0+self.field_y-self.overlap//5 and new_cell.rect.centery < self.display_height+self.field_y+self.overlap//5:
                    event_onscreen = True
                self.replicating_cell.remove(cell)
                self.resting_cell.add(cell)    #transfer back to resting cell
        return event_onscreen

    def cell_check(self):
        try:
            cell = self.cell_randomized.pop()   #check cells occasionally, trigger cell regrowth programming
            if cell in self.resting_cell:
                check_regrowth_initialized = cell.update()
                if check_regrowth_initialized:          #cell initiated regrowth
                    self.cell_state(cell, 'replicating')
        except IndexError:
            self.cell_randomized = self.resting_cell.sprites()
            random.shuffle(self.cell_randomized)

    def matrix_update(self):
        if self.bot_scroll():
            self.display_update = True
        try:
            if self.bot.sprite.vaccine_released:
                self.display_update = True
        except AttributeError:
            pass

        event_onscreen = self.infection_check()
        if event_onscreen:
            self.display_update = True

        if self.check_count > self.check_rate:
            self.cell_check()
            event_onscreen = self.infected_cell_check()
            if event_onscreen:
                self.display_update = True
            event_onscreen = self.cell_regrowth_check()
            if event_onscreen:
                self.display_update = True

        self.infected_cell.update()
        self.replicating_cell.update()

        if self.display_update:
            for bug in self.cells:
                if bug.rect.centerx > 0+self.field_x-self.overlap and bug.rect.centerx < self.display_width+self.field_x+self.overlap and bug.rect.centery > 0+self.field_y-self.overlap and bug.rect.centery < self.display_height+self.field_y+self.overlap:
                    self.creatures.add(bug)
            self.screen.blit(self.base_image, (0,0))
            self.screen_base.blit(self.base_image, (0,0))
            for bug in self.creatures:       #adjust display location
                bug.rect.centerx -= self.field_x
                bug.rect.centery -= self.field_y
            self.creatures.draw(self.screen_base)
            for bug in self.creatures:       #restore location
                bug.rect.centerx += self.field_x
                bug.rect.centery += self.field_y
            self.creatures.empty()

        self.virus.update()
        if self.check_count > 10:
            virus_at_edge = pg.sprite.groupcollide(self.virus, self.borders, False, False)
            if virus_at_edge:
                for vir in virus_at_edge:
                    vir.check_edge(virus_at_edge[vir])
            self.check_count = 0
        else:
            self.check_count += 1
        for bug in self.virus:
            if bug.rect.centerx > 0+self.field_x-self.overlap//5 and bug.rect.centerx < self.display_width+self.field_x+self.overlap//5 and bug.rect.centery > 0+self.field_y-self.overlap//5 and bug.rect.centery < self.display_height+self.field_y+self.overlap//5:
                self.creatures.add(bug)      #draw cells that appear onscreen, with display overlap/5

        self.macs.update()
        for bug in self.macs:
            if bug.rect.centerx > 0+self.field_x-self.overlap*2 and bug.rect.centerx < self.display_width+self.field_x+self.overlap*2 and bug.rect.centery > 0+self.field_y-self.overlap*2 and bug.rect.centery < self.display_height+self.field_y+self.overlap*2:
                self.creatures.add(bug)

        self.bot.update()
        if self.bot.sprite:
            if self.bot.sprite.rect.centerx > 0+self.field_x-self.overlap//5 and self.bot.sprite.rect.centerx < self.display_width+self.field_x+self.overlap//5 and self.bot.sprite.rect.centery > 0+self.field_y-self.overlap//5 and self.bot.sprite.rect.centery < self.display_height+self.field_y+self.overlap//5:
                self.creatures.add(self.bot.sprite)      #draw cells that appear onscreen, with display overlap/5

        self.projectiles.update()
        for obj in self.projectiles:
            if obj.rect.centerx > 0+self.field_x-self.overlap//5 and obj.rect.centerx < self.display_width+self.field_x+self.overlap//5 and obj.rect.centery > 0+self.field_y-self.overlap//5 and obj.rect.centery < self.display_height+self.field_y+self.overlap//5:
                self.creatures.add(obj)      #draw cells that appear onscreen, with display overlap/5

        for bug in self.creatures:       #adjust display location
            bug.rect.centerx -= self.field_x
            bug.rect.centery -= self.field_y
        self.creatures.clear(self.screen_matrix,self.screen_base)
        self.update_list.extend(self.creatures.draw(self.screen_matrix))
        for bug in self.creatures:       #restore location
            bug.rect.centerx += self.field_x
            bug.rect.centery += self.field_y
        self.creatures.empty()

        try:
            if self.bot.sprite.vaccine_pulse_load:
                pg.draw.circle(self.screen_matrix, (255,0,0), (self.bot.sprite.x-self.field_x, self.bot.sprite.y-self.field_y), 50, 1)
            elif self.bot.sprite.vaccine_released:
                pg.draw.circle(self.screen_matrix, (255,0,0), self.bot.sprite.vaccine_location, 701-self.bot.sprite.vaccine_released, 1)
                self.bot.sprite.vaccine_released -= 50
        except AttributeError:
            pass

        if self.map_display:
            map_rect, life_rect = self.matrix_map()
            if map_rect:
                self.update_list.append(map_rect)
            if life_rect:
                self.update_list.append(life_rect)

    def update(self):
        if not self.endgame_check():
            self.matrix_update()
        else:
            self.endgame()
        if test:
            report()


def program_options():
    config = {'display_gamma':None, 'mouse_enabled':False}
    try:
        conf = {}
        config_file = open('config.ini')
        cfg_setting = [line.strip().split(' ',1) for line in config_file if line[:1].isalpha()]
        cfg_setting = dict(cfg_setting)
        for cfg in config:
            if cfg in cfg_setting:
                conf[cfg] = cfg_setting[cfg].strip()
        config_file.close()
    except (IOError, ValueError):
        pass
    for cfg in conf:
        if cfg == 'display_gamma':
            try:
                config['display_gamma'] = float(conf['display_gamma'])
            except ValueError:
                pass
        elif cfg == 'mouse_enabled':
            if conf[cfg].lower() == 'true':
                config['mouse_enabled'] = True
    program_usage = "%prog [options]"
    program_desc = ("Replicator Machine")
    parser = optparse.OptionParser(usage=program_usage,description=program_desc)
    parser.add_option("-d", "--doc", dest="doc", action="store_true", help="display program documentation")
    parser.add_option("-g", dest="display_gamma", action="store", help="-g value (value: 0.5 to 3.0)")
    parser.add_option("-m", "--mouse", dest="mouse_enabled", action="store_true", help="-m for mouse enabled")
    (options, args) = parser.parse_args()
    if options.doc:
        try:
            docfile = open('README.txt')
        except IOError:
            print("Documentation not found.")
            sys.exit()
        try:
            import textwrap
            doc = []
            for line in docfile.readlines():
                text = textwrap.wrap(line, 80)
                if text:
                    for l in text:
                        doc.append(l+'\n')
                else:
                    doc.append('\n')
        except ImportError:
            doc = docfile.readlines()
        docfile.close()
        for line in doc:
            print(line, end=' ')
        sys.exit()
    if options.display_gamma:
        try:
            gamma = float(options.display_gamma)
            if gamma > 0.0 and gamma < 0.5:
                gamma = 0.5
            elif gamma > 3.0:
                gamma = 3.0
            config['display_gamma'] = gamma
        except ValueError:
            config['display_gamma'] = None
    if options.mouse_enabled:
        config['mouse_enabled'] = True
    return config


def report():
    print_message.add("FPS:", int(control.clock.get_fps()))
    print_message.add("Cell:", matrix.cell_count)
    print_message.add("Virus:", matrix.virus_count)
    try:
        print_message.add("Virus:", matrix.bot.sprite.bot_velocity)
        print_message.add("Virus:", matrix.bot.sprite.bot_rotate)
    except:
        pass
    print_message()


config = program_options()
matrix = Matrix()
Control.matrix = matrix
control = Control(config)
print_message = interphase.Text(matrix.screen)
matrix.opening()


def main():
    while True:
        matrix.update_list = []
        if matrix.simulation:
            control.panel_group.clear(matrix.screen,matrix.screen_base)
        control.update()
        if control.quit:
            return
        matrix.update()
        if matrix.simulation:
            if control.panel.is_active():
                update_rect = control.panel_group.draw(matrix.screen)
                matrix.update_list.extend(update_rect)
        if not matrix.display_update:
            pg.display.update(matrix.update_list)
        else:
            matrix.display_update = False
            pg.display.flip()


if __name__ == '__main__':
    main()

