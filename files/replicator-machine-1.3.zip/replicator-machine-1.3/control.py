import pygame as pg
from interface import MatrixInterface


class Control(object):

    matrix = None

    def __init__(self, config):
        self.config = config
        pg.key.set_repeat(100,10)
        if self.config['mouse_enabled']:
            self.mouse_enabled = True
            pg.event.set_grab(True)
            pg.mouse.set_visible(False)
            pg.mouse.set_pos([self.matrix.display_width//2,self.matrix.display_height//2])
            pg.event.set_allowed([pg.MOUSEBUTTONDOWN,pg.MOUSEBUTTONUP,pg.MOUSEMOTION])
        else:
            self.mouse_enabled = False
            pg.event.set_grab(False)
            pg.mouse.set_visible(True)
            pg.event.set_blocked([pg.MOUSEBUTTONDOWN,pg.MOUSEBUTTONUP,pg.MOUSEMOTION])
        self.panel, self.panel_group = self.define_controls()
        self.rotate_control = True  #strafe/rotate control toggle
        self.clock = pg.time.Clock()
        self.quit = False

    def define_controls(self):
        panel = MatrixInterface(self.matrix)
        panel_group = pg.sprite.RenderUpdates(panel)
        return panel, panel_group

    def check_events(self):
        for event in pg.event.get():
            if event.type == pg.MOUSEBUTTONDOWN:
                button1, button2, button3 = pg.mouse.get_pressed()
                if event.button == 1:    #bot shoot
                    try:
                        self.matrix.bot.sprite.toggle_shot = True
                    except AttributeError: pass
                elif event.button == 2:   #bot tractor beam
                    try:
                        self.matrix.bot.sprite.activate_tool('Tractor Beam')
                    except AttributeError: pass
                elif event.button == 3:   #bot vaccine/annihilation pulse
                    if pg.key.get_mods() & pg.KMOD_SHIFT:   #bot annihilation pulse
                        try:
                            self.matrix.bot.sprite.activate_tool('Annihilation Pulse')
                        except AttributeError: pass
                    else:
                        try:
                            self.matrix.bot.sprite.activate_tool('Vaccine Pulse')
                        except AttributeError: pass
            elif event.type == pg.MOUSEBUTTONUP:
                button1, button2, button3 = pg.mouse.get_pressed()
                if event.button == 1:    #bot shoot
                    try:
                        self.matrix.bot.sprite.toggle_shot = False
                    except AttributeError: pass
            elif event.type == pg.MOUSEMOTION:
                x,y = pg.mouse.get_rel()
                if x:
                    try:
                        if self.rotate_control:
                            self.matrix.bot.sprite.control_entry = ('rotate', x/10.0)
                        else:
                            self.matrix.bot.sprite.control_entry = ('strafe', x/10.0)
                    except AttributeError: pass
            elif event.type == pg.KEYDOWN:
                if event.key == pg.K_UP or event.key == pg.K_KP8:   #bot forward
                    try:
                        if not self.matrix.warp_engaged:
                            self.matrix.bot.sprite.toggle_forward = True
                    except AttributeError:
                        self.matrix.matrix_scroll('u')
                    except AttributeError: pass
                elif event.key == pg.K_DOWN or event.key == pg.K_KP2:    #bot reverse
                    try:
                        if not self.matrix.warp_engaged:
                            self.matrix.bot.sprite.toggle_reverse = True
                    except AttributeError:
                        self.matrix.matrix_scroll('d')
                elif event.key == pg.K_LEFT or event.key == pg.K_KP4:    #bot left
                    try:
                        if not self.matrix.warp_engaged:
                            self.matrix.bot.sprite.toggle_left = True
                    except AttributeError:
                        self.matrix.matrix_scroll('l')
                elif event.key == pg.K_RIGHT or event.key == pg.K_KP6:   #bot right
                    try:
                        if not self.matrix.warp_engaged:
                            self.matrix.bot.sprite.toggle_right = True
                    except AttributeError:
                        self.matrix.matrix_scroll('r')
                elif event.key == pg.K_RCTRL or event.key == pg.K_KP5:    #bot dampen motion
                    try:
                        self.matrix.bot.sprite.toggle_motion = True
                    except AttributeError: pass
                elif event.key == pg.K_x or event.key == pg.K_KP1:    #bot sleft
                    try:
                        if not self.matrix.warp_engaged:
                            self.matrix.bot.sprite.toggle_strafeleft = True
                    except AttributeError: pass
                elif event.key == pg.K_c or event.key == pg.K_KP3:   #bot sright
                    try:
                        if not self.matrix.warp_engaged:
                            self.matrix.bot.sprite.toggle_straferight = True
                    except AttributeError: pass
                elif event.key == pg.K_SPACE or event.key == pg.K_KP0:    #shoot
                    try:
                        self.matrix.bot.sprite.toggle_shot = True
                    except AttributeError: pass
                elif event.key == pg.K_a or event.key == pg.K_KP_PERIOD:   #bot annihilation pulse
                    try:
                        self.matrix.bot.sprite.activate_tool('Annihilation Pulse')
                    except AttributeError: pass
                elif event.key == pg.K_z or event.key == pg.K_KP_MULTIPLY:   #bot vaccine pulse
                    try:
                        self.matrix.bot.sprite.activate_tool('Vaccine Pulse')
                    except AttributeError: pass
                elif event.key == pg.K_LCTRL or event.key == pg.K_KP_ENTER:   #bot tractor beam
                    try:
                        self.matrix.bot.sprite.activate_tool('Tractor Beam')
                    except AttributeError: pass
                elif event.key == pg.K_d:    #toggle map display
                    self.matrix.map_display = (not self.matrix.map_display)
                    self.matrix.display_update = True
                elif event.key == pg.K_v:    #add virus
                    self.matrix.simulation_set('Virus Addition')
                elif event.key == pg.K_m:    #add macrophage
                    self.matrix.simulation_set('Macrophage Addition')
                elif event.key == pg.K_n:      #add nanobot
                    self.matrix.simulation_set('Nanobot Addition')
                elif event.key == pg.K_i:    #infectious variant
                    ctrl = self.panel.get_control('Variant')
                    if ctrl.value != 'Variant 4':
                        ctrl.next()
                    else:
                        self.panel.disable_control('Variant')
                    self.matrix.simulation_set('Variant Switch')
                elif event.key == pg.K_g:      #genetic mutation
                    ctrl = self.panel.get_control('Mutation')
                    ctrl.next()
                    self.matrix.simulation_set('Mutation Operational')
                elif event.key == pg.K_BACKSLASH:  #mouse toggle
                    if self.matrix.simulation:
                        continue
                    if self.mouse_enabled:
                        self.mouse_enabled = False
                        pg.event.set_grab(False)
                        pg.mouse.set_visible(True)
                        pg.event.set_blocked([pg.MOUSEBUTTONDOWN, pg.MOUSEBUTTONUP, pg.MOUSEMOTION])
                    else:
                        self.mouse_enabled = True
                        pg.event.set_grab(True)
                        pg.mouse.set_visible(False)
                        pg.mouse.set_pos([self.matrix.display_width//2,self.matrix.display_height//2])
                        pg.event.set_allowed([pg.MOUSEBUTTONDOWN, pg.MOUSEBUTTONUP, pg.MOUSEMOTION])
                elif event.key == pg.K_t:  #forward thrust
                    try:
                        self.matrix.bot.sprite.control_entry = ('thrust', True)
                    except AttributeError: pass
                elif event.key == pg.K_r:  #rotate/strafe switch
                    self.rotate_control = not self.rotate_control
                elif event.key == pg.K_w:    #volume up
                    self.matrix.volume += 0.1
                    if self.matrix.volume > 0.9:
                        self.matrix.volume = 1.0
                    self.matrix.set_volume()
                elif event.key == pg.K_s:    #volume down
                    self.matrix.volume -= 0.1
                    if self.matrix.volume < 0.1:
                        self.matrix.volume = 0.0
                    self.matrix.set_volume()
                elif event.key == pg.K_RIGHTBRACKET:   #increase difficulty level
                    self.matrix.level_set()
                elif event.key == pg.K_TAB:    #pause toggle
                    if not self.matrix.warp_engaged:
                        pause = True
                        pg.event.set_grab(False)
                        while pause:
                            for event in pg.event.get():
                                if event.type == pg.KEYDOWN:
                                    if event.key == pg.K_TAB or event.key == pg.K_ESCAPE:
                                        pause = False
                                        if self.mouse_enabled:
                                            pg.event.set_grab(True)
                                elif event.type == pg.QUIT:
                                    pause = False
                                    self.quit = True
                            self.clock.tick(40)
                elif event.key == pg.K_ESCAPE:     #restart
                    if not self.matrix.warp_engaged:
                        resume = self.matrix.opening(escape=True)
                        if resume:
                            if self.matrix.simulation or not self.mouse_enabled:
                                pg.event.set_grab(False)
                                pg.mouse.set_visible(True)
                                pg.event.set_blocked([pg.MOUSEBUTTONDOWN, pg.MOUSEBUTTONUP, pg.MOUSEMOTION])
                            else:
                                pg.event.set_grab(True)
                                pg.mouse.set_visible(False)
                                pg.event.set_allowed([pg.MOUSEBUTTONDOWN, pg.MOUSEBUTTONUP, pg.MOUSEMOTION])
                            self.matrix.update()
                elif event.key == pg.K_h:    #control info
                    if not self.matrix.warp_engaged:
                        self.matrix.control_info()
                        self.matrix.display_update = True
                        self.matrix.update()
            elif event.type == pg.KEYUP:
                if event.key == pg.K_UP or event.key == pg.K_KP8:    #move bot forward
                    try:
                        self.matrix.bot.sprite.toggle_forward = False
                    except AttributeError: pass
                elif event.key == pg.K_DOWN or event.key == pg.K_KP2:    #move bot reverse
                    try:
                        self.matrix.bot.sprite.toggle_reverse = False
                    except AttributeError: pass
                elif event.key == pg.K_LEFT or event.key == pg.K_KP4:    #move bot left
                    try:
                        self.matrix.bot.sprite.toggle_left = False
                    except AttributeError: pass
                elif event.key == pg.K_RIGHT or event.key == pg.K_KP6:   #move bot right
                    try:
                        self.matrix.bot.sprite.toggle_right = False
                    except AttributeError: pass
                elif event.key == pg.K_RCTRL or event.key == pg.K_KP5:    #move bot dampen motion
                    try:
                        self.matrix.bot.sprite.toggle_motion = False
                    except AttributeError: pass
                elif event.key == pg.K_x or event.key == pg.K_KP1:    #move bot sleft
                    try:
                        self.matrix.bot.sprite.toggle_strafeleft = False
                    except AttributeError: pass
                elif event.key == pg.K_c or event.key == pg.K_KP3:   #move bot sright
                    try:
                        self.matrix.bot.sprite.toggle_straferight = False
                    except AttributeError: pass
                elif event.key == pg.K_SPACE or event.key == pg.K_KP0:    #bot shoot
                    try:
                        self.matrix.bot.sprite.toggle_shot = False
                    except AttributeError: pass
            elif event.type == pg.QUIT:   #quit program
                self.quit = True

    def update(self):
        self.panel_group.update()
        self.check_events()
        self.clock.tick(40)
