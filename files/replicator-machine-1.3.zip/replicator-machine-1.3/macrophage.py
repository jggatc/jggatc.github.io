import random
import pygame as pg
import numpy as np
from util import load_image, load_sound, sin_table, cos_table


class Macrophage(pg.sprite.Sprite):
    """Macrophages will help control infection by engulfing viruses. As they consume virus, they will grow. If grow too large on virus, will trigger cell aberration causing macrophage to attack bot. Bot will suffer drain of life energy. Bot will be able to make vaccines, which will be able to activate macrophages in their activity and their homing ability towards viruses."""

    images = {}
    masks = {}
    sound = None
    area = {}

    def __init__(self, x, y, matrix):
        pg.sprite.Sprite.__init__(self)
        self.matrix = matrix
        self.x = x
        self.y = y
        self.pos_x = float(self.x)     #float version
        self.pos_y = float(self.y)
        if not Macrophage.images:
            image = load_image("macrophage.png")
            size = (100,100)
            while size[0] <= 150:
                img = pg.transform.smoothscale(image, size)
                Macrophage.images[size[0]] = img
                Macrophage.masks[size[0]] = pg.mask.from_surface(img)
                size = tuple(x+1 for x in size)
            Macrophage.sound = load_sound("macrophage_sound.ogg")
            Macrophage.sound.set_volume(self.matrix.volume)
            class Area(pg.sprite.Sprite):
                def __init__(self, x, y, rect, expand):
                    pg.sprite.Sprite.__init__(self)
                    self.x = x
                    self.y = y
                    self.rect = rect
                    self.rect.size = tuple(axis+expand for axis in rect.size)
            area_rect = image.get_rect()
            Macrophage.area['s'] = Area(x,y,area_rect,expand=300)   #radar - short, medium, and long range
            Macrophage.area['m'] = Area(x,y,area_rect,expand=500)
            Macrophage.area['l'] = Area(x,y,area_rect,expand=700)
        self.size = (100,100)
        self.image = Macrophage.images[self.size[0]]
        self.rect = self.image.get_rect(center=(self.x,self.y))
        self.mask = Macrophage.masks[self.size[0]]
        self.imagex = pg.transform.smoothscale(self.image,(8,8))
        self.macrophage_sound = Macrophage.sound
        self.delay = 6
        self.pause = 0
        self.direction = random.randrange(360)
        self.distance = random.randrange(100,200)
        self.velocity = 1
        self.grow = 0
        self.growing = 0
        self.speed = 0.3
        self.attack = False
        self.attack_count = 0
        self.dormant_count = 0  #time since last virus
        self.girth = 100
        self.tracking = False   #tracking virus
        self.target = None
        self.sound = False      #macrophage sounding
        self.channel = None     #sound channel
        self.shot = False   #if shot
        self.tractor_beam = False   #bot tractor beam
        self.activated = False  #vaccine activation
        self.activate_count = 0 #activation duration
        self.activation_state = 0
        self.zip = 1    #speed increase with activation
        self.area = Macrophage.area     #radar

    def locate_coordinate(self,step,direction,change=True):
        """Calculates coordiate following step in a given direction from starting postion self.pos_x, self.pos_y. If change is True changes self.pos_x/self.pos_y, otherwise just return calculated position."""
        x = self.pos_x
        y = self.pos_y
        x += +step*sin_table[direction]
        y += -step*cos_table[direction]
        #x += +step*math.sin(direction*math.pi/180)
        #y += -step*math.cos(direction*math.pi/180)
        if change:
            self.pos_x = x
            self.pos_y = y
        return int(x), int(y)

    def direction_set(self, direction):
        if direction >= 360:
            direction -= 360
        elif direction < 0:
            direction += 360
        return direction

    def check_edge(self):   #edge check
        if self.x < 50 or self.x > self.matrix.width-50 or self.y < 50 or self.y > self.matrix.width-50:
            self.direction = random.randrange(360)
            if self.x < 50:
                self.x = 50
            elif self.x > self.matrix.width-50:
                self.x = self.matrix.width-50
            if self.y < 50:
                self.y = 50
            elif self.y > self.matrix.height-50:
                self.y = self.matrix.height-50
            self.pos_x, self.pos_y = float(self.x), float(self.y)

    def sense_virus(self, long_range=False):
        """Check for target in range around macrophage."""
        def check_inrange(virus_list, x, y, radius):
            if not virus_list:
                return None
            virus_target = None
            for virus in virus_list:
                x1 = x
                y1 = y
                x2 = virus.x
                y2 = virus.y
                separation = np.sqrt( np.power((x1-x2),2) + np.power((y1-y2),2) )
                if separation < radius:      #find closest target
                    virus_target = virus
                    radius = separation
            return virus_target
        target = None
        size = self.rect.size
        separation_target = 200 - ((self.matrix.level-1)*25)
        self.area['s'].rect.center = (self.x, self.y)
        virus_detected = pg.sprite.spritecollide(self.area['s'], self.matrix.virus, False)
        target = check_inrange(virus_detected, self.x, self.y, separation_target)
        if not target and long_range:
            separation_target = 400 - ((self.matrix.level-1)*50)
            self.area['m'].rect.center = (self.x, self.y)
            virus_detected = pg.sprite.spritecollide(self.area['m'], self.matrix.virus, False)
            target = check_inrange(virus_detected, self.x, self.y, separation_target)
        if not target and long_range and (self.matrix.level < 2):
            separation_target = 600
            self.area['l'].rect.center = (self.x, self.y)
            virus_detected = pg.sprite.spritecollide(self.area['l'], self.matrix.virus, False)
            target = check_inrange(virus_detected, self.x, self.y, separation_target)
        return target

    def check_interact(self):
        interact = None
        bot_bump = pg.sprite.spritecollide(self, self.matrix.bot, False, pg.sprite.collide_mask)  #bot avoidance
        if bot_bump and not self.attack:
            bot = bot_bump[0]
            interact = (bot.rect.centerx, bot.rect.centery)
            return interact
        macs_bump = pg.sprite.spritecollide(self, self.matrix.macs, False)  #macrophage avoidance
        for mac in macs_bump:
            if mac == self:
                continue
            elif (abs(mac.rect.centerx-self.rect.centerx) < 65 and abs(mac.rect.centery-self.rect.centery) < 65):
                interact = (mac.rect.centerx, mac.rect.centery)
        return interact

    def avoidance(self, mac_interact, amount=1.0):
        mac_x, mac_y = mac_interact
        self.direction = self.direction_set( self.direction + random.randrange(90,270) )
        if random.random() < 0.5:
            if self.rect.centerx > mac_x:
                self.pos_x += amount
                self.x = int(self.pos_x)
            else:
                self.pos_x -= amount
                self.x = int(self.pos_x)
        else:
            if self.rect.centery > mac_y:
                self.pos_y += amount
                self.y = int(self.pos_y)
            else:
                self.pos_y -= amount
                self.y = int(self.pos_y)

    def move(self):
        mac_interact = self.check_interact()
        if mac_interact:
            self.avoidance(mac_interact)
        self.x, self.y = self.locate_coordinate(self.speed*self.zip, self.direction)
        self.distance -= 1
        if self.distance <= 0:
            self.distance = random.randrange(100, 200)
            self.direction = self.direction_set( self.direction + random.randrange(-45,46) )

    def track(self):
        mac_interact = self.check_interact()
        if mac_interact:
            self.avoidance(mac_interact)
        if random.random() > 0.5:
            if self.target.x > self.x:
                self.pos_x += self.velocity*self.zip
            else:
                self.pos_x -= self.velocity*self.zip
        else:
            if self.target.y > self.y:
                self.pos_y += self.velocity*self.zip
            else:
                self.pos_y -= self.velocity*self.zip
        self.x = int(self.pos_x)
        self.y = int(self.pos_y)

    def growth(self):
        virus_collide = pg.sprite.spritecollide(self, self.matrix.virus, False, pg.sprite.collide_mask)
        for prey in virus_collide:
            if not self.attack:
                self.matrix.remove_creature('Virus', prey)
                if not self.activated:
                    self.grow += 1      #grow with virus consumption
                self.dormant_count = 0
            else:
                prey.shove(self.x, self.y)

    def go_berserk(self, calm=False):   #excess virus causes malignant macrophage
        self.attack_count += 1
        if self.attack_count > 500:
            self.attack_count = 0
            if random.random() > (0.4 + (0.1*self.matrix.level)):
                calm = True
        if ( calm and self.matrix.bot.sprite.shield_energized ) or not self.matrix.bot.sprite or self.matrix.ending:
            self.attack = False
            self.attack_count = 0
            self.activated = True
            self.activate_count = 1000  #trigger end of activation
            self.girth = 100
            return
        if not self.sound:
            self.channel = self.macrophage_sound.play(-1)
            self.sound = True
        x1 = self.x
        y1 = self.y
        x2 = self.matrix.bot.sprite.x
        y2 = self.matrix.bot.sprite.y
        d = np.sqrt( np.power((x1-x2),2) + np.power((y1-y2),2) )
        if d <= 800:
            vol = 1.0 - (d/800)
        else:
            vol = 0.0
        self.channel.set_volume(vol)
        mac_interact = self.check_interact()
        if mac_interact:
            self.avoidance(mac_interact, amount=4.0)
        mistaken = 0.1
        if random.random() > mistaken:   #mistaken direction
            vel = random.randrange(1,6)
            mistake = 1
        else:
            vel = random.randrange(1,3)
            mistake = -1
        if random.random() > 0.5:
            if self.matrix.bot.sprite.x > self.x:
                self.x += vel*mistake
            else:
                self.x -= vel*mistake
        else:
            if self.matrix.bot.sprite.y > self.y:
                self.y += vel*mistake
            else:
                self.y -= vel*mistake
        self.pos_x = float(self.x)
        self.pos_y = float(self.y)
        if abs(self.x-self.matrix.bot.sprite.x)<65 and abs(self.y-self.matrix.bot.sprite.y)<65:
            self.matrix.bot.sprite.shove(self.x, self.y)

    def condition(self):
        if self.shot:
            self.macrophage_sound.play()
            if not self.attack:
                if not self.matrix.ending:
                    self.grow += 1      #attack if shot too much
            else:
                if random.random() > 0.95:
                    self.go_berserk(calm=True)     #attack stops if shot enough
            self.shot = False
        if not self.activated and not self.attack and not self.matrix.ending:
            try:
                if not self.matrix.bot.sprite.shield_energized:
                    self.grow += 1
            except AttributeError:      #no bot
                pass
            self.dormant_count += 1
            if self.dormant_count > 500:
                self.dormant_count = 0
                if random.random() > (0.8 - (0.1*self.matrix.level)):
                    self.grow += 1

    def captured(self):
        if not self.matrix.bot.sprite:   #no bot
            self.tractor_beam = False
            return
        if not self.matrix.bot.sprite.tractor_beam:
            self.tractor_beam = False
        else:
            x1 = self.x
            y1 = self.y
            x2 = self.matrix.bot.sprite.pos_x
            y2 = self.matrix.bot.sprite.pos_y
            bot_reverse_direction = self.direction_set( self.matrix.bot.sprite.direction + 180 )
            x2 += +25*sin_table[bot_reverse_direction]     #coordinate behind bot
            y2 += -25*cos_table[bot_reverse_direction]
            separation = np.sqrt( np.power((x1-x2),2) + np.power((y1-y2),2) )
            if separation > 100:     #hold macrophage in tractor beam
                if separation > 125:
                    speed = 3
                elif separation > 100:
                    speed = 2
                if self.x < x2:
                    self.x += speed
                elif self.x > x2:
                    self.x -= speed
                if self.y < y2:
                    self.y += speed
                elif self.y > y2:
                    self.y -= speed
                self.pos_x, self.pos_y = float(self.x), float(self.y)
                self.rect.center = (self.x, self.y)

    def activation(self, stimuli=False):
        if stimuli:
            if self.attack:
                self.attack = False
                self.girth = 100
            self.activated = True
            return
        if not self.sound:
            if not self.activate_count:
                self.sound = True
                self.channel = self.macrophage_sound.play(-1)
        else:
            try:
                x1 = self.x
                y1 = self.y
                x2 = self.matrix.bot.sprite.x
                y2 = self.matrix.bot.sprite.y
                d = np.sqrt( np.power((x1-x2),2) + np.power((y1-y2),2) )
                if d <= 800:
                    vol = 1.0 - (d/800)
                else:
                    vol = 0.0
                self.channel.set_volume(vol)
            except AttributeError:  #no bot
                pass
        if not self.activate_count:
            self.activation_state = 1
            self.zip = 2
        if self.activate_count == 1000:
            self.activation_state = -1
            if self.sound:
                self.channel.stop()    #stop sound channel
                self.sound = False
            self.zip = 1
        self.activate_count += 1
        if not self.activation_state:
            self.tracking = False
            self.activate_count = 0
            self.activated = False
            self.matrix.macrophage_activated = False

    def shape_shift(self):
        def shift(size,change=1):
            size = tuple(x+change for x in size)
            self.image = Macrophage.images[size[0]]
            self.rect = self.image.get_rect(center=(self.x,self.y))
            self.mask = Macrophage.masks[size[0]]
            return size
        if not self.activated:
            self.pause += 1
            if self.pause >= self.delay:
                self.pause = 0
                if self.grow > ( 3 - self.matrix.level ) or self.growing:  #level inc. difficulty
                    if self.size[0] < 150:      #macrophage growth
                        self.size = shift(self.size)
                        self.girth = self.size[0]
                        self.grow = 0
                        self.growing += 1
                        if self.growing > 5:
                            self.growing = 0
                    else:
                        if self.matrix.bot.sprite:  #if bot exists
                            if not self.activated:
                                self.attack = True  #macrophage attack when large
                                self.grow = 0
                                self.growing = 0
        else:
            if self.activation_state == 1:
                self.grow = 0
                self.growing = 0
                if self.size[0] < 150:
                    self.size = shift(self.size)
            elif self.activation_state == -1:
                if self.size[0] > self.girth:
                    self.size = shift(self.size,change=-1)
                else:
                    self.activation_state = 0
                    self.girth = self.size[0]
        self.rect.center = (self.x, self.y)

    def update(self):
        self.check_edge()
        self.condition()
        if not self.attack:     #peaceful macrophage
            if self.activated:  #activated macrophage
                self.activation()
            if self.tractor_beam:
                self.captured()
            if self.tracking:
                if self.target.alive():
                    self.track()
                else:
                    self.tracking = False
            else:
                if not self.activated:
                    self.target = self.sense_virus()
                else:
                    self.target = self.sense_virus(long_range=True)
                if self.target:
                    self.tracking = True
                else:
                    self.move()    #no virus in vicinity
        else:   #aggressive macrophage
            self.go_berserk()   #anti-bot
        self.growth()
        self.shape_shift()

