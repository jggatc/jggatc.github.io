import pygame as pg
import math
import random
from projectile import Projectile
from util import load_image, load_sound, sin_table, cos_table


class Nanobot(pg.sprite.Sprite):
    """Bot combats the viral infection by shooting energy projectiles. Each virus shot yields viral biomaterial that will be used to generate a nanobot-generated vaccine. Release of the vaccine pulse activates macrophage towards the virus. Bot can generate a tractor beam to tow macrophage. Bot generates a field to reduce immune detection, and if lost all macrophage will attack the bot as a foreign invader. Bot power is derived from the lifeforce of cells, and restoration of power will diminish with the decrease in cells."""

    image = {}
    images = {}
    shot_sound = None

    def __init__(self, x, y, matrix):
        pg.sprite.Sprite.__init__(self)
        self.matrix = matrix
        self.x = x      #location in matrix
        self.y = y
        self.pos_x = float(self.x)     #float version
        self.pos_y = float(self.y)
        self.pos_x_previous = self.pos_x
        self.pos_y_previous = self.pos_y
        if not Nanobot.image:  #load images on first instance
            img = load_image('bot.png')
            for degree in range(0,360):
                Nanobot.image[degree] = pg.transform.rotozoom(img, -degree, 0.5)
            image = load_image('bots.png')
            width, height = image.get_size()
            frames = 11
            image_width = width // frames
            z = list(range(-5,6))
            for frame in range(frames):
                frame_num = image_width * frame
                image_frame = image.subsurface((frame_num,0), (image_width,height)).copy()
                Nanobot.images[z[frame]] = image_frame
            Nanobot.shot_sound = load_sound("shot_fx.ogg")
            Nanobot.shot_sound.set_volume(self.matrix.volume)
        self.image = Nanobot.image[0]
        self.rect = self.image.get_rect(center=(self.x,self.y))
        self.frame = 0
        self.imagex = {}
        for degree in range(0,360):
            w, h = Nanobot.image[degree].get_size()
            self.imagex[degree] = pg.transform.smoothscale(Nanobot.image[degree], (w//8,h//8))
        self.shot = Nanobot.shot_sound
        self.distance = 0
        self.direction = 0
        self.direction_previous = 0
        self.direction_change = False
        self.rotate = False
        self.velocity = 0       #forward velocity
        self.velocity_l = 0     #strafe left
        self.velocity_r = 0     #strafe right
        self.rotate = 0         #image rotation - none = 0, ccr = -1, cr =1
        self.rotate_count = 0
        self.gun_timer = 0
        self.toggle_forward = False     # toggle controls
        self.toggle_reverse = False
        self.toggle_motion = False
        self.toggle_left = False
        self.toggle_right = False
        self.toggle_strafeleft = False
        self.toggle_straferight = False
        self.toggle_shot = False
        self.vaccine_pulse = False    #vaccine pulse
        self.vaccine_pulse_load = False
        self.annihilation_pulse = False   #annihilation pulse
        self.tractor_beam = False   #tractor beam
        self.tractor_beam_captured = None   #captured held in tractor beam
        self.velocity_max = 6.0     #velocity
        self.velocity_thrust = 3.0  #coasting velocity
        self.velocity_spurt = 8.0   #spurt velocity
        self.bot_velocity = 0.0     #nanobot velocity
        self.bot_rotate = 0.0       #nanobot rotation
        self.control_entry = None
        self.life_force = 100.0     #energy from cell lifeforce
        self.active = True
        self.shield_energized = True  #cloaking shield
        self.weapon_energized = True  #weapon charge
        self.antigen = 0    #viral antigen to generate antibody and activate macrophage
        self.antigen_required = 10  #amount biomaterial required for vaccine generation
        self.vaccine_released = 0   #vaccine released
        self.vaccine_location = ()  #vaccine release location

    def locate_coordinate(self,step,direction,change=True):
        """Calculates coordiate following step in a given direction from starting postion self.pos_x, self.pos_y. If change is True changes self.pos_x/self.pos_y, otherwise just return calculated position."""
        x = self.pos_x
        y = self.pos_y
        x += +step*sin_table[direction]     #x += +step*math.sin(direction*math.pi/180)
        y += -step*cos_table[direction]     #y += -step*math.cos(direction*math.pi/180)
        if change:
            self.pos_x = x
            self.pos_y = y
        return int(x), int(y)

    def direction_set(self, direction):
        if direction >= 360:
            direction -= 360
        elif direction < 0:
            direction += 360
        return direction

    def location(self):
        def check_edge():
            centerx, centery = self.rect.center
            if centerx < 25 or centerx > self.matrix.width-25 or centery <= 25 or centery >= self.matrix.height-25:
                return True
            else:
                return False
        if self.toggle_forward:
            self.bot_velocity += 0.1
            if self.bot_velocity > self.velocity_max:
                self.bot_velocity = self.velocity_max
        if self.toggle_reverse:
            if self.bot_velocity > -3.0:
                self.bot_velocity -= 0.1
        elif self.bot_velocity < 0.0:
            self.bot_velocity += 0.05
        if self.toggle_motion:
            if self.bot_velocity > 0.0:
                self.bot_velocity -= 0.1
            if self.bot_velocity < 0.0:
                self.bot_velocity += 0.1
        if self.bot_velocity > self.velocity_thrust:
            self.bot_velocity -= 0.02
        if self.toggle_left:
            self.bot_rotate -= (1.0*abs(self.bot_rotate/20.0)+0.5)
            if self.bot_rotate < -5.0:
                self.bot_rotate = -5.0
            if self.bot_rotate < -1.0 and self.bot_rotate > -4.0:
                if self.bot_velocity < self.velocity_spurt:
                    self.bot_velocity += 0.1
            if self.frame > -5:
                self.frame -= 1
                self.rotate = True
        if self.toggle_right:
            self.bot_rotate += (1.0*abs(self.bot_rotate/20.0)+0.5)
            if self.bot_rotate > 5.0:
                self.bot_rotate = 5.0
            if self.bot_rotate > 1.0 and self.bot_rotate < 4.0:
                if self.bot_velocity < self.velocity_spurt:
                    self.bot_velocity += 0.1
            if self.frame < 5:
                self.frame += 1
                self.rotate = True
        if not self.toggle_left and not self.toggle_right:
            if self.bot_rotate:
                if self.bot_rotate < -1.0:
                    self.bot_rotate -= (self.bot_rotate/20.0)
                    if self.frame < 0:
                        self.frame += 1
                        self.rotate = True
                elif self.bot_rotate > 1.0:
                    self.bot_rotate -= (self.bot_rotate/20.0)
                    if self.frame > 0:
                        self.frame -= 1
                        self.rotate = True
                else:
                    self.bot_rotate = 0.0
            else:
                if self.frame != 0:
                    if self.frame > 0:
                        self.frame -= 1
                    else:
                        self.frame += 1
                    self.rotate = True
        if self.control_entry:
            if self.control_entry[0] == 'rotate':
                self.control(rotate=self.control_entry[1])
            elif self.control_entry[0] == 'strafe':
                self.control(strafe=self.control_entry[1])
            elif self.control_entry[0] == 'thrust':
                self.control(thrust=self.control_entry[1])
            self.control_entry = None
        self.velocity = self.bot_velocity
        self.direction = self.direction_set( self.direction + int(self.bot_rotate) )
        self.x, self.y = self.locate_coordinate(self.velocity, self.direction)
        if self.toggle_strafeleft and self.velocity_l < 3:
            self.velocity_l += 0.1
            direction = self.direction_set( self.direction - 90 )
            self.x, self.y = self.locate_coordinate(self.velocity_l, direction)
        elif self.velocity_l > 0:
            self.velocity_l -= 0.05
            direction = self.direction_set( self.direction - 90 )
            self.x, self.y = self.locate_coordinate(self.velocity_l, direction)
        if self.toggle_straferight and self.velocity_r < 3:
            self.velocity_r += 0.1
            direction = self.direction_set( self.direction + 90 )
            self.x, self.y = self.locate_coordinate(self.velocity_r, direction)
        elif self.velocity_r > 0:
            self.velocity_r -= 0.05
            direction = self.direction_set( self.direction + 90 )
            self.x, self.y = self.locate_coordinate(self.velocity_r, direction)
        if self.direction != self.direction_previous:
            self.direction_change = True
        else:
            self.direction_change = False
        if self.direction_change or self.rotate:
            if self.frame == 0:
                self.image = Nanobot.image[self.direction]
            else:
                self.image = pg.transform.rotate(Nanobot.images[self.frame], -self.direction)
            self.direction_previous = self.direction
            self.rotate = False
        self.rect = self.image.get_rect(center=(self.x, self.y))
        if check_edge():
            self.pos_x = self.pos_x_previous
            self.pos_y = self.pos_y_previous
            self.direction = self.direction_set( self.direction + random.choice((-1,1)) )
        else:
            self.pos_x_previous = self.pos_x
            self.pos_y_previous = self.pos_y

    def control(self, rotate=0, strafe=0, thrust=False):
        if rotate:
            if rotate < -2:
                rotate = -2
            elif rotate > 2:
                rotate = 2
            if rotate < 0:
                self.bot_rotate += rotate
                if self.bot_rotate < -5.0:
                    self.bot_rotate = -5.0
                if self.bot_rotate < -1.0 and self.bot_rotate > -4.0:
                    if self.bot_velocity < self.velocity_spurt:
                        self.bot_velocity += 0.1
                if self.frame > -5:
                    self.frame -= 1
                    self.rotate = True
            elif rotate > 0:
                self.bot_rotate += rotate
                if self.bot_rotate > 5.0:
                    self.bot_rotate = 5.0
                if self.bot_rotate > 1.0 and self.bot_rotate < 4.0:
                    if self.bot_velocity < self.velocity_spurt:
                        self.bot_velocity += 0.1
                if self.frame < 5:
                    self.frame += 1
                    self.rotate = True
        elif strafe:
            if strafe < 0:
                self.velocity_l += -strafe
                if self.velocity_l > 3:
                    self.velocity_l = 3
            elif strafe > 0:
                self.velocity_r += strafe
                if self.velocity_r > 3:
                    self.velocity_r = 3
        elif thrust:
            if self.velocity_thrust < 3.01:
                self.velocity_thrust = 3.01
                self.bot_velocity = 3.01
            elif self.velocity_thrust == 3.01:
                self.velocity_thrust = self.velocity_max
                self.bot_velocity = self.velocity_max
            else:
                self.velocity_thrust = 3.01
                self.bot_velocity = 3.01

    def shove(self, x, y):   #push bot
        if self.x > x:
            distance_x = +2.0
        elif self.x < x:
            distance_x = -2.0
        else:
            distance_x = 0
        if self.y > y:
            distance_y = +2.0
        elif self.y < y:
            distance_y = -2.0
        else:
            distance_y = 0
        self.pos_x += distance_x
        self.x = int(self.pos_x)
        self.pos_y += distance_y
        self.y = int(self.pos_y)
        if random.random() > 0.5 - (0.1*self.matrix.level):  #drains life force from bot
            damage = -1 * self.matrix.level    #level inc. difficulty
            self.condition(damage)

    def activate_tool(self, select):
        if select == 'Vaccine Pulse':
            if self.vaccine_pulse_load:
                self.vaccine_pulse = True
        elif select =='Annihilation Pulse':
            if self.vaccine_pulse_load:
                self.annihilation_pulse = True            
        elif select == 'Tractor Beam':
            if not self.tractor_beam:
                self.tractor_beam = True
            else:
                self.tractor_beam = False
                self.tractor_beam_captured = None
                self.velocity_max = 6.0
                self.velocity_spurt = 8.0

    def shoot(self):
        if self.toggle_shot:
            if self.weapon_energized:
                if self.gun_timer == 0:
                    self.shot.play()
                    x1 = self.pos_x +20*math.sin((self.direction+45)*math.pi/180)
                    y1 = self.pos_y -20*math.cos((self.direction+45)*math.pi/180)
                    x2 = self.pos_x +20*math.sin((self.direction-45)*math.pi/180)
                    y2 = self.pos_y -20*math.cos((self.direction-45)*math.pi/180)
                    direction1 = self.direction_set( self.direction - 3 )
                    direction2 = self.direction_set( self.direction + 3 )
                    self.matrix.projectiles.add(
                        Projectile(x1, y1, direction1, self.velocity, self.matrix, self))
                    self.matrix.projectiles.add(
                        Projectile(x2, y2, direction2, self.velocity, self.matrix, self))
                    self.gun_timer = 5
                    self.life_force -= 1.0
                else:
                    if self.gun_timer > 0:
                        self.gun_timer -= 1
            else:
                self.toggle_shot = False
        if not self.toggle_shot:
            self.gun_timer = 0
        if self.vaccine_pulse:    #vaccine pulse
            self.shot.play()
            for mac in self.matrix.macs:
                mac.activation(stimuli=True)
            self.matrix.macrophage_activated = True
            self.vaccine_pulse = False
            self.vaccine_pulse_load = False
            self.vaccine_location = (self.x-self.matrix.field_x,self.y-self.matrix.field_y)
            self.vaccine_released = 700
        if self.annihilation_pulse:
            self.shot.play()
            for direction in range(0,360,5):
                self.matrix.projectiles.add(
                    Projectile(self.x, self.y, direction, self.velocity, self.matrix, self, 'annihilation'))
            self.annihilation_pulse = False
            self.vaccine_pulse_load = False
        if self.tractor_beam:   #tractor beam
            if not self.tractor_beam_captured:
                mac_interact = pg.sprite.spritecollide(self, self.matrix.macs, False)
                for mac in mac_interact:
                    if (abs(mac.rect.centerx-self.rect.centerx) < 50 and abs(mac.rect.centery-self.rect.centery) < 50):
                        self.tractor_beam_captured = mac
                        break
                if self.tractor_beam_captured:
                    self.tractor_beam_captured.tractor_beam = True
                    self.velocity_max = 2.0
                    self.velocity_spurt = 2.0
                else:
                    self.tractor_beam = False

    def vaccine(self):
        """Bot collects biomaterial to make vaccine."""
        if self.antigen < ( self.antigen_required * self.matrix.level ):   #level inc. difficulty
            if not self.vaccine_pulse_load and not self.matrix.macrophage_activated:  
                self.antigen += 1
        else:
            self.vaccine_pulse_load = True
            self.antigen = 0
            self.antigen_required = random.randrange(10,21)

    def condition(self, damage=0):
        """Energy derived from cell population, drained by Mac attack but can slowly regain level."""
        if self.life_force < self.matrix.cell_count/4.0:
            self.life_force += ( 0.05 + (self.matrix.cell_count/8000.0) )    #recovery slower if less cells
        if damage:
            self.life_force -= 1
        if self.life_force > 20:    #immunity shield
            self.shield_energized = True
        else:
            self.shield_energized = False
        if self.life_force > 10:
            self.weapon_energized = True
        else:
            self.weapon_energized = False
        if self.life_force > 0:
            return True
        else:
            self.active = False
            return False    #bot destroyed

    def update(self):
        if self.condition():
            self.location()
            self.shoot()
        else:
            self.matrix.bot.remove(self)

