import pygame as pg
from util import load_image, sin_table, cos_table


class Projectile(pg.sprite.Sprite):
    """Energy projectiles shot by bot."""

    image = None
    mask = None

    def __init__(self, x, y, direction, distance_adj, matrix, bot, weapon_type='projectile'):
        pg.sprite.Sprite.__init__(self)
        self.matrix = matrix
        self.bot = bot
        self.x = int(x)
        self.y = int(y)
        self.pos_x = x
        self.pos_y = y
        self.direction = direction
        self.velocity = 12
        self.distance = 15 + distance_adj
        self.weapon_type = weapon_type
        if not Projectile.image:    #load images on first instance
            image = load_image('projectile.png')
            Projectile.image = pg.transform.smoothscale(image, (3,3))
            Projectile.mask = pg.mask.from_surface(Projectile.image)
        self.image = Projectile.image
        self.rect = self.image.get_rect(center=(self.x, self.y))
        self.mask = Projectile.mask
        self.arming = 4      #travel short distance before arming

    def locate_coordinate(self,step,direction,change=True):
        """Calculates coordiate following step in a given direction from starting postion self.pos_x, self.pos_y. If change is True changes self.pos_x/self.pos_y, otherwise just return calculated position."""
        x = self.pos_x
        y = self.pos_y
        x += +step*sin_table[direction]     #x += +step*math.sin(direction*math.pi/180)
        y += -step*cos_table[direction]     #y += -step*math.cos(direction*math.pi/180)
        if change:
            self.pos_x = x
            self.pos_y = y
        return int(x), int(y)

    def location(self):
        self.x, self.y = self.locate_coordinate(self.velocity, self.direction)
        self.rect = self.image.get_rect(center=(self.x,self.y))
        self.distance -= 1
        if self.distance <= 0:
            self.matrix.projectiles.remove(self)
            self.kill()

    def armed(self):
        if not self.arming:
            return True
        else:
            self.arming -= 1
            return False

    def hit(self):
        hit_target = False
        hits = pg.sprite.spritecollide(self, self.matrix.virus, False)
        for target in hits:
            target.damage()     #virus shot
            if self.weapon_type == 'projectile':
                if self.bot.active:
                    self.bot.vaccine()     #viral biomaterial to make vaccine
            hit_target = True
            return hit_target       #return on single virus hit
        if self.weapon_type == 'projectile':
            hits = pg.sprite.spritecollide(self, self.matrix.macs, False, pg.sprite.collide_mask)
            for target in hits:
                target.shot = True
                hit_target = True
                return hit_target   #return on single macrophage hit
        return hit_target

    def update(self):
        self.location()
        if self.armed():
            if self.hit() and self.weapon_type == 'projectile':
                self.matrix.projectiles.remove(self)

