import interphase


class MatrixInterface(interphase.Interface):

    def __init__(self, matrix):
        self.matrix = matrix
        interphase.Interface.__init__(self, position=(250,450), image='panel.png', color=(43,50,58), size=(350,100), moveable=True, position_offset=(0,95), button_image=['button.png'], control_image=['control.png'], font_color=(175,180,185), tips_fontcolor=(175,180,185), pointer_interact=True, control_minsize=(20,20), control_size='auto', scroll_button='vertical')

    def add_controls(self):
        self.add(
            identity = 'Control',
            control_type = 'function_select',
            position = (50,50),
            size = (40,40),
            control_list = ['__Compass', '__Action', '__Sim'],
            icon_list = ['control_compass.png', 'control_virus.png', 'control_restart.png'],
            link = [ ['Compass', 'N', 'S', 'W', 'E', 'NW', 'NE', 'SW', 'SE'], ['Virus', 'Macrophage', 'Variant', 'Mutation'], ['Restart', 'Exit'] ],
            link_activated = True,
            label_display = False)
        self.add(
            identity = 'Compass',
            control_type = 'control_toggle',
            position = (175,50),
            size = (25,25),
            control_list = [''],
            label_display = False)
        for ident, tip, img, pos in ( ('N',['North'],['control_n.png'],(175,25)), ('S',['South'],['control_s.png'],(175,75)), ('W',['West'],['control_w.png'],(150,50)), ('E',['East'],['control_e.png'],(200,50)) ):
            self.add(
                identity = ident,
                control_type = 'control_toggle',
                position = pos,
                size = (25,25),
                control_list = [''],
                tip_list = tip,
                control_image = img,
                label_display = False,
                control_response = 25)
        for ident, tip, pos in ( ('NW',['North-West'],(150,25)), ('NE',['North-East'],(200,25)), ('SW',['South-West'],(150,75)), ('SE',['South-East'],(200,75)) ):
            self.add(
                identity = ident,
                control_type = 'control_toggle',
                position = pos,
                size = (25,25),
                control_list = [''],
                tip_list = tip,
                label_display = False,
                control_response = 25)
        self.add(
            identity = 'Virus',
            control_type = 'control_toggle',
            position = (130,35),
            size = 'min_width',
            control_list = ['Virus'],
            tip_list = ['Add Virus'],
            control_outline = True,
            control_response = 30)
        self.add(
            identity = 'Macrophage',
            control_type = 'control_toggle',
            position = (130,65),
            size = 'min_width',
            control_list = ['Macrophage'],
            tip_list = ['Add Macrophase'],
            control_outline = True)
        self.add(
            identity = 'Variant',
            control_type = 'control_toggle',
            position = (230,35),
            size = 'min_width',
            control_list = ['Variant 1', 'Variant 2', 'Variant 3', 'Variant 4'],
            tip_list = ['Virus Variant'],
            split_text = False,
            control_outline = True)
        self.add(
            identity = 'Mutation',
            control_type = 'control_toggle',
            position = (230,65),
            size = 'min_width',
            control_list = ['Mutation OFF', 'Mutation ON'],
            tip_list = ['Toggle Mutation'],
            split_text = False,
            control_outline = True)
        self.add(
            identity = 'Restart',
            control_type = 'control_toggle',
            position = (130,50),
            size = (40,40),
            control_list = ['Restart'],
            tip_list = ['Restart Simulation'])
        self.add(
            identity = 'Exit',
            control_type = 'control_toggle',
            position = (230,50),
            size = (40,40),
            control_list = ['Exit'],
            tip_list = ['Exit Simulation'])
        self.add(
            identity = '__Fix',
            control_type = 'control_toggle',
            position = (315,90),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['!'],
            control_image = ['none'],
            control_outline = True)
        self.add(
            identity = '__Help',
            control_type = 'control_toggle',
            position = (335,90),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['?'],
            control_image = ['none'],
            control_outline = True)

    def initialize(self):
        controls = self.get_control('Control', 'Variant', 'Mutation')
        for control in controls:
            controls[control].reset()
        self.enable_control('Variant')

    def update(self):
        interphase.Interface.update(self)
        state = self.get_state()
        if state.control:
            if state.control == 'N':
                self.matrix.matrix_scroll('u')
            elif state.control == 'S':
                self.matrix.matrix_scroll('d')
            elif state.control == 'W':
                self.matrix.matrix_scroll('l')
            elif state.control == 'E':
                self.matrix.matrix_scroll('r')
            elif state.control == 'NW':
                self.matrix.matrix_scroll('u')
                self.matrix.matrix_scroll('l')
            elif state.control == 'NE':
                self.matrix.matrix_scroll('u')
                self.matrix.matrix_scroll('r')
            elif state.control == 'SW':
                self.matrix.matrix_scroll('d')
                self.matrix.matrix_scroll('l')
            elif state.control == 'SE':
                self.matrix.matrix_scroll('d')
                self.matrix.matrix_scroll('r')
            elif state.control == 'Map':
                self.matrix.map_display = (not self.matrix.map_display)
                self.matrix.display_update = True
            elif state.control == 'Virus':
                self.matrix.simulation_set('Virus Addition')
            elif state.control == 'Macrophage':
                self.matrix.simulation_set('Macrophage Addition')
            elif state.control == 'Nanobot':
                self.matrix.simulation_set('Nanobot Addition')
            elif state.control == 'Variant':
                self.matrix.simulation_set('Variant Switch')
                if state.value == 'Variant 4':
                    self.disable_control('Variant')
            elif state.control == 'Mutation':
                self.matrix.simulation_set('Mutation Operational')
            elif state.control == 'Restart':
                self.matrix.setup(simulation=True)
            elif state.control == 'Exit':
                resume = self.matrix.opening(escape=True)
                if resume:
                    self.matrix.update()
            elif state.control == '__Fix':
                self.set_moveable()
            elif state.control == '__Help':
                self.set_tips_display()
        return state

