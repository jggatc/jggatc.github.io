Replicator Machine

Project site:
https://gatc.ca/projects/replicator/

Dependencies:
    Python 2.7+:    https://python.org/
    PyGame 1.9+:    https://pygame.org/
    Numpy 1.4+:     https://numpy.org/

Replicator Machine is a viral infection simulation combined with nanobot combat. The source is run with 'python replicator.py'. Also available are executables that have Python dependencies included, and run with './replicator' (Linux) or 'replicator.exe' (Windows). Replicator Machine is released under the GPL3 License, see LICENSE.txt for further information.

Command line options:
    -h, --help        show this help message and exit
    -d, --doc         display program documentation
    -g DISPLAY_GAMMA  -g value (value: 0.5 to 3.0)
    -m, --mouse       -m for mouse enabled
    >options can also be set in config.ini

Controls:
    UP / KP8            bot forward / scroll up
    DOWN / K_KP2        bot reverse / scroll down
    LEFT / KP4          bot left / scroll left
    RIGHT / KP6         bot right / scroll right
    RCTRL / KP5         bot dampen motion
    x / KP1             bot sleft
    c / KP3             bot sright
    SPACE / KP0         bot shoot
    a / KP_*            bot annihilation pulse
    z / KP_PERIOD       bot vaccine pulse
    LCTRL / KP_ENTER    bot tractor beam
    d                   toggle map display
    v                   add virus (simulation)
    m                   add macrophage (simulation)
    n                   add nanobot (simulation)
    i                   infectious variant (simulation)
    g                   genetic mutation (simulation)
    \                   mouse toggle
    t                   forward thrust
    r                   rotate/strafe switch
    w                   volume up
    s                   volume down
    ]                   increase difficulty level
    TAB                 pause toggle
    ESC                 restart
    h                   control info
    mouse button 1      bot shoot
    mouse button 2      bot tractor beam
    mouse button 3      bot vaccine pulse
    mouse motion        bot strafe

