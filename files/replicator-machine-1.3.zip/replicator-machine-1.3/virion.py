import random
import pygame as pg
from util import load_image, sin_table, cos_table


class Virion(pg.sprite.Sprite):
    """Virus moves erratically, and infects cells for division."""

    variants = { 1:{'progeny':2,'lifespan':1000,'color':0xe1cf00},
                 2:{'progeny':3,'lifespan':666,'color':0xff8e00},
                 3:{'progeny':4,'lifespan':500,'color':0xf93003},
                 4:{'progeny':5,'lifespan':400,'color':0xc0c0c0} }
    images = {}
    mask = None

    def __init__(self, x, y, variant, matrix):
        pg.sprite.Sprite.__init__(self)
        self.matrix = matrix
        self.variant = variant    #virus variant
        self.x = x
        self.y = y
        self.pos_x = float(self.x)     #float version
        self.pos_y = float(self.y)
        if not Virion.images:  #load images on first instance
            variant = 1
            for virus_image in ('virus1.png', 'virus2.png', 'virus3.png', 'virus4.png'):
                image = {}
                img = load_image(virus_image)
                for degree in range(0,360):
                    image[degree] = pg.transform.rotozoom(img, -degree, 0.2)
                    Virion.images[variant] = image
                variant += 1
            Virion.mask = pg.mask.from_surface(pg.transform.smoothscale(Virion.images[1][0],(20,20)))
        self.direction = random.randrange(360)
        self.distance = random.randrange(1,10)
        self.direction_roll = self.direction
        self.roll = random.choice((-3,-2,-1,1,2,3))
        self.image = Virion.images[self.variant][self.direction]
        self.rect = self.image.get_rect(center=(self.x,self.y))
        self.mask = Virion.mask
        self.velocity = 1
        self.infecting = False     #infecting cell
        self.life_force = 2
        self.life_span = Virion.variants[self.variant]['lifespan'] * random.choice((1,2))
        self.progeny = Virion.variants[self.variant]['progeny']
        self.color = Virion.variants[self.variant]['color']

    def location(self):
        """Moves distance up to 10 steps, then changes direction randomly."""
        if self.distance > 0:
            self.distance -= 1
        else:
            self.direction = random.randrange(360)
            self.distance = random.randrange(1,10)
        self.pos_x += +self.velocity*sin_table[self.direction]
        self.pos_y += -self.velocity*cos_table[self.direction]
        #self.pos_x += +self.velocity*math.sin(self.direction*math.pi/180)
        #self.pos_y += -self.velocity*math.cos(self.direction*math.pi/180)
        self.x, self.y = int(self.pos_x), int(self.pos_y)
        self.direction_roll += (1*self.roll)
        if self.direction_roll >= 360:
            self.direction_roll -= 360
        elif self.direction_roll < 0:
            self.direction_roll += 360
        self.image = Virion.images[self.variant][self.direction_roll]
        self.rect = self.image.get_rect(center=(self.x,self.y))

    def check_edge(self, borders):
        """Check if virus enters border rects."""
        for border in borders:
            if border.side == 'n':
                self.direction = 180
                self.distance = 10
            elif border.side == 's':
                self.direction = 0
                self.distance = 10
            elif border.side == 'w':
                self.direction = 90
                self.distance = 10
            elif border.side == 'e':
                self.direction = 270
                self.distance = 10

    def shove(self, x, y):      #push virus
        if self.x > x:
            distance_x = +1.0
        elif self.x < x:
            distance_x = -1.0
        else:
            distance_x = 0
        if self.y > y:
            distance_y = +1.0
        elif self.y < y:
            distance_y = -1.0
        else:
            distance_y = 0
        self.pos_x += distance_x
        self.x = int(self.pos_x)
        self.pos_y += distance_y
        self.y = int(self.pos_y)

    def mutate(self):
        if self.variant > 3:
            return False
        mutation = random.random() > 0.95
        return mutation

    def damage(self):
        self.life_force -= 1
        if self.life_force < 0:
            self.life_force = 0

    def condition(self):
        self.life_span -= 1
        if not self.life_span:
            self.life_force = 0

    def update(self):
        self.condition()
        if self.life_force:
            self.location()
        else:
            self.matrix.remove_creature('Virus', self)   #lifespan reached naturally or being shot

