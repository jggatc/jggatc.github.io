"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division


class Event(object):
    def pump(self):
        pass
    def get(self):
        class Evt(object):
            def type(self):
                pass
        return [Evt()]
    def poll(self):
        pass
    def wait(self):
        pass
    def peek(self):
        pass
    def clear(self):
        pass
    def event_name(self):
        pass
    def set_blocked(self):
        pass
    def set_allowed(self):
        pass
    def get_blocked(self):
        pass
    def set_grab(self):
        pass
    def get_grab(self):
        pass
    def post(self):
        pass
    def Event(object):
        pass

