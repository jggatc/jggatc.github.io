"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division


class Mouse(object):
    def get_pressed(self):
        pass
    def get_pos(self):
        pass
    def get_rel(self):
        pass
    def set_pos(self):
        pass
    def set_visible(self, setting):
        pass
    def get_focused(self):
        pass
    def set_cursor(self):
        pass
    def get_cursor(self):
        pass

