import java.awt
import javax.swing
import java.awt.image
import pyj2d.surface
import pyj2d.japplet

##############################
#Applet configuration:
# Script name to import
# Applet size
# Program setup
# Program execution

import script as app    #import script

app_size = (400,300)    #applet size

class Program(object):

    def setup(self):

        app.program_setup()     #program setup

    def update(self):
        app.program_exec()      #program execution

##############################


class Applet(javax.swing.JApplet):

    def init(self):
        self.setBackground(java.awt.Color.BLACK)
        self.jp = Panel(app_size)
        self.addComp(self.jp)
        pyj2d.japplet.instance = self
        self.jp.setup()

    def addComp(self, jCom):
        self.getContentPane().add(jCom)


class Panel(javax.swing.JPanel):

    def __init__(self, size):
        javax.swing.JPanel.__init__(self)
        self.setPreferredSize(java.awt.Dimension(size[0],size[1]))
        self.surface = pyj2d.surface.Surface(size, java.awt.image.BufferedImage.TYPE_INT_RGB)
        self.setBackground(java.awt.Color.BLACK)
        self.program = Program()

    def setup(self):
        self.program.setup()

    def paintComponent(self, g):
        self.super__paintComponent(g)
        g.drawImage(self.surface, 0, 0, None)
        java.awt.Toolkit.getDefaultToolkit().sync()
        self.program.update()


if __name__ == '__main__':
    import pawt
    pawt.test(Applet(), size=app_size)

