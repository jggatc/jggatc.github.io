"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
import javax.imageio.ImageIO
import java.io.File
import surface
import japplet


class Image(object):

    def load(self, img_file):
        try:
            f = japplet.instance.class.getResource(img_file)
            if not f:
                raise
        except:
            f = java.io.File(img_file)      #make path os independent
        try:
            img = javax.imageio.ImageIO.read(f)
        except IOError:
            print 'Error reading', img_file
        bimage = surface.convert_bufferedimage(img)
        return bimage

