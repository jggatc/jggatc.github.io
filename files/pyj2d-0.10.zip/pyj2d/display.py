"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
import javax.swing
import java.awt
from surface import Surface
import japplet


class Frame(javax.swing.JFrame):

    def __init__(self, title, size):
        javax.swing.JFrame.__init__(self, title)
        self.setDefaultCloseOperation(self.EXIT_ON_CLOSE)
        self.setResizable(False)
        self.setSize(size[0],size[1])
        self.setDefaultLookAndFeelDecorated(True)

    def addComp(self, jCom):
        self.getContentPane().add(jCom)


class Panel(javax.swing.JPanel):

    def __init__(self, size):
        javax.swing.JPanel.__init__(self)
        self.setPreferredSize(java.awt.Dimension(size[0],size[1]))
        self.surface = Surface(size, java.awt.image.BufferedImage.TYPE_INT_RGB)
        self.setBackground(java.awt.Color.BLACK)

    def paintComponent(self, g):
        self.super__paintComponent(g)
        g.drawImage(self.surface, 0, 0, None)
        java.awt.Toolkit.getDefaultToolkit().sync()


class Display(object):

    def init(self):
        self.caption = ''
        self.icon = None
        if japplet.instance:
            self.set_mode = self.applet_set_mode
            self.update = self.applet_update

    def applet_set_mode(self, size):
        self.jf = japplet.instance
        self.jp = self.jf.jp
        self.surface = self.jp.surface
        self.surface._display = self
        self.surface._g2d = self.surface.createGraphics()
        self.surface._g2d.setBackground(java.awt.Color.BLACK)
        self.clear()
        return self.surface

    def applet_update(self, rect_list=None):
        self.jf.repaint()

    def set_mode(self, size):
        self.jf = Frame(self.caption, size)
        self.jf.setBackground(java.awt.Color.BLACK)
        self.jp = Panel(size)
        self.jf.addComp(self.jp)
        self.jf.pack()
        self.surface = self.jp.surface
        self.surface._display = self
        self.surface._g2d = self.jp.surface.createGraphics()
        self.surface._g2d.setBackground(java.awt.Color.BLACK)
        self.clear()
        self.jf_repaint = javax.swing.RepaintManager()
        self.jf.setVisible(True)
        return self.surface

    def get_surface(self):
        return self.surface

    def get_frame(self):
        return self.jf

    def quit(self):
        try:
            self.surface._g2d.dispose()
        except:
            pass

    def get_init(self):
        return True

    def set_caption(self, caption):
        self.caption = caption

    def set_icon(self, icon):
        self.icon = icon

    def clear(self):
        w, h = self.surface.getWidth(), self.surface.getHeight()
        self.surface._g2d.setColor(java.awt.Color.BLACK)
        self.surface._g2d.fillRect(0,0,w,h)

    def flip(self):
        self.jf.repaint()

    def update(self, rect_list=None):
        try:
            for rect in rect_list:
                try:
                    self.jf_repaint.addDirtyRegion(self.jp, rect.x,rect.y,rect.width,rect.height)
                except AttributeError:
                    self.jf_repaint.addDirtyRegion(self.jp, *rect)
            self.jf_repaint.paintDirtyRegions()
        except TypeError:
            self.jf.repaint()

