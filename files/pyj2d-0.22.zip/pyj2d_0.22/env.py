#PyJ2D - Copyright (C) 2011 James Garnon

"""
JApplet/JFrame objects.
"""

japplet = None

jframe = None

