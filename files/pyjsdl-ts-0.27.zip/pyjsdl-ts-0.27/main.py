import pyjsdl

window.pyjsdl = pyjsdl

