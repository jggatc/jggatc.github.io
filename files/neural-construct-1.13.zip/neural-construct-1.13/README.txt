Neural Construct
Version 1.13
http://gatc.ca/projects/neural-construct/

Neural Construct is coded in Python and Pygame. The construct is composed of a matrix of neurons that are responsive to stimuli. The individual neurons have been programmed and from the neural interconnections emerge complex signals.  The source is run with 'python neural.py', options can be set in config.ini. Also available are executables that have Python dependencies included, and run with './neural' (Linux) or 'neural.exe' (Windows). Neural Construct is released under the GPL3 License, see LICENSE.txt for further information.

Dependencies:
    Python 2.7+:   http://www.python.org/
    PyGame 1.8+:   http://www.pygame.org/

Controls:
T               tool select
F               random firing toggle
D               dampening toggle
S               show selected
X               neuron display
A               neuron types single/both
L               learning toggle
E               clear memory
N               network display
P               pause
C               panel toggle
H               control info
Up              response speed increase
Down            response speed decrease
Right           refraction duration increase
Left            refraction duration decrease
Esc             previous screen
Mouse 1/3       stimuli applied
Mouse 2         network termini
Mouse 2 + alt   neuron twitcher (shift:clear)
Mouse 2 + ctr   neuron deactivate (shift:clear)

