Neural Construct
Copyright (C) 2009 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Neural Construct version 1.12
Download Site: http://gatc.ca
Source:       Neural.zip
Executable:
    Linux:      Neural_exe.tar.gz
    Windows:    Neural_exe.zip

Dependencies:
    Python 2.5:   http://www.python.org/
    PyGame 1.8:   http://www.pygame.org/
    Psyco:        http://psyco.sourceforge.net/


Description:

The construct is composed of a matrix of neurons that are responsive to
stimuli. The individual neurons are have been programmed, and from the
neural interconnections emerge complex signals.


To run type 'python neural.py' at the command line.
Options can also be set in config.ini.
Also available are executables with Python dependencies
included, and run with './neural' (Linux) or 'neural.exe' (Windows).

Controls:
T               tool select
F               random firing toggle
D               dampening toggle
S               show selected
X               neuron display
A               neuron types single/both
L               learning toggle
E               clear memory
N               network display
P               pause
C               panel toggle
H               control info
Up              response speed increase
Down            response speed decrease
Right           refraction duration increase
Left            refraction duration decrease
Esc             previous screen
Mouse 1/3       stimuli applied
Mouse 2         network termini
Mouse 2 + alt   neuron twitcher (shift:clear)
Mouse 2 + ctr   neuron deactivate (shift:clear)
