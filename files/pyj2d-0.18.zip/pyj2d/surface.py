"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
from java.awt.image import BufferedImage, RasterFormatException
from java.awt import Color
from java.util import Hashtable
from rect import Rect
import locals


class Surface(BufferedImage):

    def __init__(self, *arg):
        try:
            width, height = arg[0]
            try:
                if arg[1] in (BufferedImage.TYPE_INT_ARGB, locals.SRCALPHA, (locals.SRCALPHA | locals.HWSURFACE)):
                    BufferedImage.__init__(self, width, height, BufferedImage.TYPE_INT_ARGB)
                else:
                    BufferedImage.__init__(self, width, height, BufferedImage.TYPE_INT_RGB)
            except IndexError:
                BufferedImage.__init__(self, width, height, BufferedImage.TYPE_INT_ARGB)
                self.fill((0,0,0))
        except TypeError:
            try:
                cm = arg[0].getColorModel()
                raster = arg[0].getRaster()
                isRasterPremultiplied = arg[0].isAlphaPremultiplied()
                properties = Hashtable()
                keys = arg[0].getPropertyNames()
                if keys != None:
                    for key in keys:
                        properties.put(key,arg[0].getProperty(key))
            except AttributeError:
                cm, raster, isRasterPremultiplied, properties = arg
            BufferedImage.__init__(self, cm, raster, isRasterPremultiplied, properties)
        self._display = None    #display surface
        self._super_surface = None
        self._offset = (0,0)
        self._colorkey = None

    def __repr__(self):
        return "%s(%s, %r)" % (self.__class__, self.toString(), self.__dict__)

    def dispose(self):
        try:
            self._g2d.dispose()
            del self._g2d
        except AttributeError:
            pass

    def get_size(self):
        return (self.width, self.height)

    def get_width(self):
        return self.width

    def get_height(self):
        return self.height

    def get_rect(self, **attr):
        rect = Rect(0, 0, self.width, self.height)
        for key in attr:
            rect.__setattr__(key,attr[key])
        return rect

    def copy(self):
        if not self._super_surface:
            img_properties = Hashtable()
            keys = self.getPropertyNames()
            if keys != None:
                for key in keys:
                    img_properties.put(key,self.getProperty(key))
            surface = Surface(
                              self.getColorModel(),
                              self.getData(),
                              self.isAlphaPremultiplied(),
                              img_properties
                             )
            surface._colorkey = self._colorkey
        else:
            surface = Surface((self.width,self.height), BufferedImage.TYPE_INT_ARGB)
            g2d = surface.createGraphics()
            g2d.drawImage(self, 0, 0, None)
            g2d.dispose()
            surface._colorkey = self._colorkey
        return surface

    def subsurface(self, *rect):
        try:
            x,y,w,h = rect[0].x, rect[0].y, rect[0].width, rect[0].height
        except AttributeError:
            try:
                x,y,w,h = rect[0]
            except ValueError:
                x,y = rect[0]
                w,h = rect[1]
        try:
            subsurf = self.getSubimage(x, y, w, h)
        except RasterFormatException:
            try:
                clip = self.get_rect().createIntersection( Rect(x, y, w, h) )
                x, y, w, h = clip.x, clip.y, clip.width, clip.height
                subsurf = self.getSubimage(x, y, w, h)
            except:     #rect outside surface
                return None
        surface = Surface(subsurf)
        surface._super_surface = self
        surface._g2d = surface.createGraphics()
        surface._offset = (x,y)
        surface._colorkey = self._colorkey
        return surface

    def subarea(self, *rect):
        try:
            x,y,w,h = rect[0].x, rect[0].y, rect[0].width, rect[0].height
        except AttributeError:
            try:
                x,y,w,h = rect[0]
            except ValueError:
                x,y = rect[0]
                w,h = rect[1]
        rect = Rect(x, y, w, h)
        try:
            subsurf = self.getSubimage(rect.x, rect.y, rect.width, rect.height)
        except RasterFormatException:
            try:
                clip = self.get_rect().createIntersection(rect)
                rect = Rect(clip.x, clip.y, clip.width, clip.height)
                subsurf = self.getSubimage(rect.x, rect.y, rect.width, rect.height)
            except:     #rect outside surface
                subsurf = None
        return subsurf, rect

    def blit(self, surface, position, area=None):
        try:
            x, y = position.x, position.y
        except AttributeError:
            x, y = position[0], position[1]
        try:
            if not area:
                rect = self.get_rect().createIntersection( Rect(x, y, surface.width, surface.height) )
                surface_rect = Rect(rect.x, rect.y, rect.width, rect.height)
            else:
                surface, surface_rect = surface.subarea(area)
        except AttributeError:
            return Rect(0,0,0,0)
        try:
            g2d = self._g2d
            surface_graphics = True
        except AttributeError:
            g2d = self.createGraphics()
            surface_graphics = False
        try:
            g2d.drawImage(surface, x, y, None)
        except TypeError:
            g2d.drawImage(surface, int(x), int(y), None)
        if not surface_graphics:
            g2d.dispose()
        return surface_rect

    def blits(self, surfaces):
        try:
            g2d = self._g2d
            for surface in surfaces:
                try:
                    x, y = surface[1].x, surface[1].y
                except AttributeError:
                    x, y = surface[1][0], surface[1][1]
                g2d.drawImage(surface[0], x, y, None)
        except AttributeError:
            g2d = self.createGraphics()
            for surface in surfaces:
                try:
                    x, y = surface[1].x, surface[1].y
                except AttributeError:
                    x, y = surface[1][0], surface[1][1]
                g2d.drawImage(surface[0], x, y, None)
            g2d.dispose()
        return None

    def convert(self, surface=None):
        return self

    def convert_alpha(self, surface=None):
        return self

    def set_alpha(self, value=None, flags=0):
        return None

    def get_alpha(self):
        return None

    def set_colorkey(self, color, flags=None):
        if self._colorkey:
            r,g,b = self._colorkey
            self.replace_color((r,g,b,0),(r,g,b,255))
            self._colorkey = None
        if color:
            self._colorkey = color
            self.replace_color(color)
        return None

    def get_colorkey(self):
        return self._colorkey

    def replace_color(self, color, new_color=None):
        pixels = self.getRGB(0,0,self.width,self.height,None,0,self.width)
        r,g,b = color
        if new_color:
            r2,g2,b2,a2 = new_color
        else:
            r2,g2,b2,a2 = color[0],color[1],color[2],0
        for i, pixel in enumerate(pixels):
            if pixel == Color(r,g,b).getRGB():
                pixels[i] = Color(r2,g2,b2,a2).getRGB()
        self.setRGB(0,0,self.width,self.height,pixels,0,self.width)
        return None

    def get_at(self, pos):
        x,y = pos       #*tuple unpack error in jython applet
        color = Color(self.getRGB(x,y))
        return color.getRed(), color.getGreen(), color.getBlue()

    def set_at(self, pos, color):
        R,G,B = color
        return self.setRGB(pos[0],pos[1],Color(R,G,B))

    def fill(self, color=(0,0,0), rect=None):
        try:
            g2d = self._g2d
            surface_graphics = True
        except AttributeError:
            g2d = self.createGraphics()
            surface_graphics = False
        r,g,b = color
        g2d.setColor(Color(r,g,b))
        if not rect:
            rect = Rect(0, 0, self.width, self.height)
            x,y,w,h = rect.x, rect.y, rect.width, rect.height
        else:
            try:
                x,y,w,h = rect.x, rect.y, rect.width, rect.height
            except AttributeError:
                rect = Rect(rect[0], rect[1], rect[2], rect[3])
                x,y,w,h = rect.x, rect.y, rect.width, rect.height
        g2d.fillRect(x,y,w,h)
        if not surface_graphics:
            g2d.dispose()
        return rect

    def get_parent(self):
        return self._super_surface   #if delete, delete subsurface...

    def get_offset(self):
        return self._offset

