"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
from rect import Rect
import mask


class Sprite(object):

    def __init__(self):
        self._rect_pre = None
        self.x = None
        self.y = None
        self.image = None
        self.rect = None

    def __repr__(self):
        return "%s(in %d groups)" % (self.__class__, len(self.groups()))

    def add(self, *groups):
        for group in groups:
            if self not in group:
                group.add(self)
        return None

    def remove(self, *groups):
        for group in groups:
            if self in group:
                group.remove(self)
        return None

    def kill(self):
        for group in Group.groups:
            if self in group:
                group.remove(self)
        return None

    def alive(self):
        for group in Group.groups:
            if self in group:
                return True
        return False

    def groups(self):
        return [group for group in Group.groups if self in group]

    def update(self, *args):
        pass


class DirtySprite(Sprite):
    pass


class Group(dict):

    groups = []

    def __init__(self, *sprites):
        Group.groups.append(self)
        if sprites:
            for sprite in sprites:
                self[id(sprite)] = sprite
        self.surface_blits = []
        self.clear_active = False
        self.removed_sprite = []

    def __repr__(self):
        return "%s(%d sprites)" % (self.__class__, len(self))

    def __iter__(self):
        return self.itervalues()

    def __contains__(self, sprite):
        return id(sprite) in self.iterkeys()

    def sprites(self):
        return self.values()

    def copy(self):
        newgroup = self.__class__()
        for sprite in self:
            newgroup[id(sprite)] = sprite
        return newgroup

    def add(self, *sprites):
        for sprite in sprites:
            self[id(sprite)] = sprite
        return None

    def remove(self, *sprites):
        for sprite in sprites:
            try:
                del self[id(sprite)]
                if self.clear_active:
                    self.removed_sprite.append(sprite)
            except KeyError:
                pass
        return None

    def has(self, *sprites):
        try:
            if not isinstance(sprites[0], Sprite):
                sprites = sprites[0]
        except IndexError:
            return False
        for sprite in sprites:
            if id(sprite) not in self.iterkeys():
                return False
        return True

    def draw(self, surface):
        self.surface_blits = [(sprite.image,sprite.rect) for sprite in self.itervalues()]
        surface.blits(self.surface_blits)
        return None

    def clear(self, surface, background):
        self.clear_active = True
        self.surface_blits = []
        for group in (self.removed_sprite, self.itervalues()):
            for sprite in group:
                try:
                    x,y,w,h = sprite._rect_pre.x, sprite._rect_pre.y, sprite._rect_pre.width, sprite._rect_pre.height
                except AttributeError:
                    sprite._rect_pre = sprite.rect.copy()
                    continue
                try:
                    subsurf = background.subarea
                except AttributeError:
                    background(surface,sprite._rect_pre)
                    sprite._rect_pre = sprite.rect.copy()
                    continue
                subsurface, rect = subsurf((sprite._rect_pre.x, sprite._rect_pre.y, sprite._rect_pre.width, sprite._rect_pre.height))
                self.surface_blits.append((subsurface,rect))
                sprite._rect_pre = sprite.rect.copy()
        surface.blits(self.surface_blits)
        self.removed_sprite = []

    def empty(self):
        if self.clear_active:
            self.removed_sprite.extend(self.values())
        super(Group, self).clear()

    def update(self, *args, **kwargs):
        for sprite in self.itervalues():
            sprite.update(*args, **kwargs)  #*tuple unpack jythonc error, fix by adding **kwargs
        return None


class GroupSingle(Group):

    def __init__(self, sprite=None):
        if sprite:
            Group.__init__(self, sprite)
        else:
            Group.__init__(self)

    def __getattr__(self, attr):
        if attr == 'sprite':
            try:
                return self.values()[0]
            except:
                return None

    def add(self, sprite):
        try:
            del self[self.keys()[0]]
        except:
            pass
        self[id(sprite)] = sprite
        return None

    def update(self, *args, **kwargs):
        self.values()[0].update(*args, **kwargs)     #*tuple unpack error kwargs fix
        return None


class RenderUpdates(Group):

    def __init__(self, *sprites, **kwargs):
        Group.__init__(self, *sprites, **kwargs)     #*tuple unpack error kwargs fix
        self.changed_areas = []

    def draw(self, surface):
        if surface._display:
            changed_areas = self.changed_areas
            self.changed_areas = []
            changed_areas.extend([sprite.rect for sprite in self.itervalues()])
        else:
            changed_areas = []
        Group.draw(self, surface)
        return changed_areas

    def clear(self, surface, background):
        if surface._display:
            for group in (self.removed_sprite, self.itervalues()):
                self.changed_areas.extend([sprite._rect_pre for sprite in group if sprite._rect_pre])
        Group.clear(self, surface, background)
        return None


class OrderedUpdates(RenderUpdates):

    def __init__(self, *sprites, **kwargs):
        self.order = {}
        self.place = {}
        self.range = 1000
        self.index = iter(xrange(self.range))
        self.sort = None
        for sprite in sprites:
            if sprite not in self:
                spriteID = id(sprite)
                index = self.index.next()
                self.order[index] = spriteID
                self.place[spriteID] = index
        RenderUpdates.__init__(self, *sprites, **kwargs)     #*tuple unpack error kwargs fix

    def sprites(self):
        try:
            order_sprite = iter(self.sort)
        except TypeError:
            keys = self.order.keys()
            keys.sort()
            self.sort = [self[self.order[key]] for key in keys]
            order_sprite = iter(self.sort)
        return [sprite for sprite in order_sprite]

    def copy(self):
        newgroup = RenderUpdates.copy(self)
        newgroup.order = self.order.copy()
        newgroup.place = self.place.copy()
        newgroup.range = self.range
        newgroup.index = iter(xrange(max(self.order.keys())+1,self.range))
        return newgroup

    def add(self, *sprites, **kwargs):
        for sprite in sprites:
            if sprite not in self:
                try:
                    index = self.index.next()
                    spriteID = id(sprite)
                    self.order[index] = spriteID
                    self.place[spriteID] = index
                except StopIteration:
                    keys = self.order.keys()
                    keys.sort()
                    if len(keys)*2 > self.range:
                        self.range = len(keys)*2
                    self.index = iter(xrange(self.range))
                    order = self.order
                    self.order = {}
                    self.place = {}
                    for key in keys:
                        index = self.index.next()
                        self.order[index] = order[key]
                        self.place[order[key]] = index
                    index = self.index.next()
                    spriteID = id(sprite)
                    self.order[index] = spriteID
                    self.place[spriteID] = index
        self.sort = None
        RenderUpdates.add(self, *sprites, **kwargs)     #*tuple unpack error kwargs fix
        return None

    def remove(self, *sprites, **kwargs):
        for sprite in sprites:
            try:
                spriteID = id(sprite)
                del self.order[self.place[spriteID]]
                del self.place[spriteID]
            except KeyError:
                continue
        self.sort = None
        RenderUpdates.remove(self, *sprites, **kwargs)     #*tuple unpack error kwargs fix
        return None

    def empty(self):
        self.order = {}
        self.place = {}
        self.index = iter(xrange(self.range))
        self.sort = None
        RenderUpdates.empty(self)

    def draw(self, surface):
        if surface._display:
            changed_areas = self.changed_areas
            self.changed_areas = []
            changed_areas.extend([sprite.rect for sprite in self.itervalues()])
        else:
            changed_areas = []
        try:
            order_sprite = iter(self.sort)
        except TypeError:
            keys = self.order.keys()
            keys.sort()
            self.sort = [self[self.order[key]] for key in keys]
            order_sprite = iter(self.sort)
        self.surface_blits = [(sprite.image,sprite.rect) for sprite in order_sprite]
        surface.blits(self.surface_blits)
        return changed_areas


class LayeredUpdates(OrderedUpdates):
    pass


class LayeredDirty(LayeredUpdates):
    pass


def spritecollide(sprite, group, dokill, collided=None):
    collide = []
    for sprites in group.itervalues():
        if sprite.rect.intersects(sprites.rect):
            if collided:
                if not collided(sprite,sprites):
                    continue
            collide.append(sprites)
            if dokill:
                group.remove(sprites)
    return collide


def collide_rect(sprite1, sprite2):
    return sprite1.rect.intersects(sprite2.rect)


def groupcollide(group1, group2, dokill1, dokill2):
    collide = {}
    for sprite1 in group1.itervalues():
        collide[sprite1] = []
        for sprite2 in group2.itervalues():
            if sprite1.rect.intersects(sprite2.rect):
                collide[sprite1].append(sprite2)
    for sprite1 in collide:
        if collide[sprite1]:
            if dokill1:
                group1.remove(sprite1)
            if dokill2:
                for sprite2 in collide[sprite1]:
                    group2.remove(sprite2)


def spritecollideany(sprite, group):
    for sprites in group.itervalues():
        if sprite.rect.intersects(sprites.rect):
            return True
    return False


def collide_mask(sprite1, sprite2):
    clip = sprite1.rect.createIntersection(sprite2.rect)
    if clip.width < 1 or clip.height < 1:
        return False
    x1,y1 = clip.x-sprite1.rect.x, clip.y-sprite1.rect.y
    x2,y2 = clip.x-sprite2.rect.x, clip.y-sprite2.rect.y
    masks = []
    for sprite in (sprite1, sprite2):
        try:
            masks.append(sprite.mask)
        except AttributeError:
            masks.append(mask.from_surface(sprite.image))
    for y in range(clip.height):
        try:
            if masks[0].bit[y1+y].get(x1, x1+clip.width).intersects(masks[1].bit[y2+y].get(x2, x2+clip.width)):
                return True
        except IndexError:
            continue
    return False

