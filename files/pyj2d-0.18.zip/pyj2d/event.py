"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
from java.lang import Thread
from java.awt.event import MouseEvent
import locals
import time


class Event(object):

    def __init__(self):
        self.eventQueue = [None] * 256      #max 256: Error: Event queue full
        self.eventNum = 0
        self.eventQueueTmp = [None] * 256   #used when main queue is locked
        self.eventNumTmp = 0
        self.eventAllowed = []
        self.eventBlocked = []
        self.queueLock = False
        self.queueAccess = False
        self.queue = []
        self.mousePress = None
        self.timer = time.Clock()
        self.eventName = {locals.MOUSEBUTTONDOWN:'MouseButtonDown', locals.MOUSEBUTTONUP:'MouseButtonUp', locals.MOUSEMOTION:'MouseMotion'}
        self.eventType = {locals.MOUSEBUTTONDOWN:MouseEvent.MOUSE_PRESSED, locals.MOUSEBUTTONUP:MouseEvent.MOUSE_RELEASED, locals.MOUSEMOTION:MouseEvent.MOUSE_MOVED}
        self.events = [MouseEvent.MOUSE_PRESSED, MouseEvent.MOUSE_RELEASED, MouseEvent.MOUSE_MOVED]

    def lock(self):
        self.queueLock = True   #block next event access
        while self.queueAccess:      #complete current event access
            Thread.sleep(1)       #~should be via separate Java event thread

    def unlock(self):
        self.queueLock = False

    def updateQueue(self, event):
        if event.getID() not in self.events:
            return
        self.queueAccess = True
        if not self.queueLock:
            if self.eventNumTmp:
                 self.appendMerge()
            self.append(event)
        else:
            self.appendTmp(event)
        self.queueAccess = False

    def append(self, event):
        try:
            self.eventQueue[self.eventNum] = event
            self.eventNum += 1
        except IndexError:
            pass

    def appendTmp(self, event):
        try:
            self.eventQueueTmp[self.eventNumTmp] = event
            self.eventNumTmp += 1
        except IndexError:
            pass

    def appendMerge(self):
        for i in range(self.eventNumTmp):
            self.append( self.eventQueueTmp[i] )
            self.eventQueueTmp[i] = None
        self.eventNumTmp = 0

    def pump(self):
        self.lock()
        self.eventNum = 0
        self.unlock()
        return None

    def get(self, eventType=None):
        self.lock()
        if not eventType:
            self.queue = [ self.JEvent(event) for event in self.eventQueue[0:self.eventNum] ]
            self.eventNum = 0
        else:
            pass
        self.unlock()
        return self.queue

    def poll(self):
        self.lock()
        try:
            evt = self.eventQueue.pop(0)
            self.eventNum -= 1
            self.eventQueue.append(None)
        except IndexError:
            evt = locals.NOEVENT
        self.unlock()
        return evt

    def wait(self):
        while True:
            try:
                self.lock()
                evt = self.eventQueue.pop(0)
                self.eventNum -= 1
                self.eventQueue.append(None)
                self.unlock()
                return evt
            except IndexError:
                self.unlock()
                Thread.sleep(10)

    def peek(self, eventType):
        if not self.eventNum:
            return False
        self.lock()
        evt = [event.getID() for event in self.eventQueue[0:self.eventNum]]
        self.unlock()
        try:
            for evtType in eventType:
                try:
                    if self.eventType[evtType] in evt:
                        return True
                except KeyError:
                    if evtType in evt:      #userevent
                        return True
        except TypeError:
            try:
                if self.eventType[eventType] in evt:
                    return True
            except KeyError:
                if eventType in evt:
                    return True
        return False

    def clear(self, eventType=None):
        if not self.eventNum:
            return None
        self.lock()
        if eventType is None:
            self.eventNum = 0
        else:
            queue = []
            try:
                evtType = [self.eventType[evt] for evt in eventType]
                for i in range(self.eventNum):
                    try:
                        if self.eventQueue[i].getID() not in evtType:
                            queue.append(self.eventQueue[i])
                    except KeyError:
                        pass
            except TypeError:
                for i in range(self.eventNum):
                    try:
                        if self.eventQueue[i].getID() != self.eventType[eventType]:
                            queue.append(self.eventQueue[i])
                    except KeyError:
                        pass
            if len(queue) != self.eventNum:
                self.eventNum = len(queue)
                for i in range(self.eventNum):
                    self.eventQueue[i] = queue[i]
        self.unlock()
        return None

    def event_name(self, eventType):
        try:
            return self.eventName[eventType]
        except KeyError:
            return None

    def set_blocked(self, eventType):
        if eventType is not None:
            try:
                for evtType in eventType:
                    try:
                        self.events.remove(self.eventType[evtType])
                    except (KeyError, ValueError):
                        pass
            except TypeError:
                try:
                    self.events.remove(self.eventType[eventType])
                except (KeyError, ValueError):
                    pass
        else:
            self.events = [self.eventType[evtType] for evtType in self.eventType]
        return None

    def set_allowed(self, eventType):
        if eventType is not None:
            try:
                try:
                    for evtType in eventType:
                        if self.eventType[evtType] not in self.events:
                            self.events.append(self.eventType[evtType])
                except KeyError:
                    pass
            except TypeError:
                try:
                    if self.eventType[eventType] not in self.events:
                        self.events.append(self.eventType[eventType])
                except KeyError:
                    pass
        else:
            self.events = []
        return None

    def get_blocked(self, eventType):
        try:
            if self.eventType[eventType] not in self.events:
                return True
            else:
                return False
        except KeyError:
            return False

    def set_grab(self):
        pass

    def get_grab(self):
        pass

    def post(self, event):
        self.lock()
        self.append(event)
        self.unlock()
        return None

    class Event(object):

        def __init__(self, eventType, attr=None, **kw_attr):
            self.type = eventType
            try:
                for name in attr:
                    self.__setattr__(self, name, attr[name])
            except TypeError:
                for name in kw_attr:
                    self.__setattr__(self, name, kw_attr[name])

        def __repr__(self):
            return "%s(%r)" % (self.__class__, self.__dict__)

        def __setattr__(self, name, value):
            if hasattr(self, name):
                raise AttributeError, "Attributes are read-only."
            object.__setattr__(self, name, value)

        def getID(self):
            return self.type

    class JEvent(object):
        __slots__ = ['event']
        jevt = {MouseEvent.MOUSE_PRESSED: locals.MOUSEBUTTONDOWN, MouseEvent.MOUSE_RELEASED: locals.MOUSEBUTTONUP, MouseEvent.MOUSE_MOVED: locals.MOUSEMOTION}

        def __init__(self, event):
            object.__setattr__(self, "event", event)

        def __repr__(self):
            return "%s(%s)" % (self.__class__, self.event.toString())

        def __getattr__(self, attr):
            if attr == 'type':
                return self.jevt[self.event.getID()]
            elif attr == 'button':
                return self.event.getButton()
            elif attr == 'pos':
                return ( self.event.getX(),self.event.getY() )

        def __setattr__(self, name, value):
            raise AttributeError, "Attributes are read-only."

        def getEvent(self):
            return self.event

