#!/usr/bin/env python
from __future__ import division

"""
Microbe - Microbial Simulation
Copyright (C) 2009 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Microbe version 1.22
Download Site: http://gatc.ca

Dependencies:
    Python 2.5:             http://www.python.org/
    Pygame 1.8:             http://www.pygame.org/
    Numpy 1.4:              http://numpy.scipy.org/
    Psyco (optional):       http://psyco.sourceforge.net/
"""

version = '1.22'

testing = False
profiling = False

try:
    import pygame
    from pygame.locals import *
    from pygame import bufferproxy
    import numpy
except ImportError:
    raise ImportError, "Pygame and Numpy modules are required."
if not profiling:
    try:
        import psyco
        psyco.full()
    except ImportError:
        if testing:
            print("Warning: Psyco module recommended.")
import random
import math
import os
import sys
import cPickle
import optparse
import interphase      #interface control
if os.name in ('posix', 'nt'):  #animate.c compiled
    try:
        import animate
    except:
        try:
            import animate_1_4 as animate
        except:
            pass
if not testing:
    import warnings
    warnings.filterwarnings("ignore")


MATRIX_X = 1500     #Matrix dimension
MATRIX_Y = 1500
DISPLAY_X = 500     #Display dimension
DISPLAY_Y = 500


class Matrix(object):
    """
    The virtual environment construct.
    """

    def __init__(self):
        pygame.display.init()
        pygame.font.init()
        pygame.display.set_caption('Microbe')
        iconname = os.path.join('data', 'icon.png')
        icon = pygame.image.load(iconname)
        pygame.display.set_icon(icon)
        pygame.mouse.set_visible(True)
        pygame.surfarray.use_arraytype('numpy')
        if gamma:
            gamma_set = pygame.display.set_gamma(gamma)
        self.screen = pygame.display.set_mode((DISPLAY_X,DISPLAY_Y))
        if gamma and not gamma_set:   #if prior set_gamma failed
            gamma_set = pygame.display.set_gamma(gamma)
        self.screen_toxin = pygame.display.get_surface()
        self.screen_microbe = pygame.display.get_surface()
        self.cells = {}
        self.cells['algae'] = pygame.sprite.RenderUpdates()
        self.cells['bacterium'] = pygame.sprite.RenderUpdates()
        self.cells['paramecium'] = pygame.sprite.RenderUpdates()
        self.cells['amoeba'] = pygame.sprite.RenderUpdates()
        self.cells['creatures'] = pygame.sprite.OrderedUpdates()
        self.species = [Algae, Bacterium, Paramecium, Amoeba, Ciliate]
        self.species_group = {Algae:self.cells['algae'], Bacterium:self.cells['bacterium'], Paramecium:self.cells['paramecium'], Amoeba:self.cells['amoeba'], Ciliate:self.cells['paramecium']}
        self.media = numpy.fromfunction(lambda xf,yf: ((1.0 / ((((xf-(MATRIX_X/2))**2) + (yf-(MATRIX_Y/2))**2) +1.0)) * 1000000), (MATRIX_X, MATRIX_Y))   #+1.0 to avoid div by zero
        self.media = numpy.where(self.media>2, self.media, 0)   #min diffuse level and defines circular edge
        self.media = self.media.astype('i')       #type for pygame.surfarray.blit_array()
        self.nutrient = numpy.zeros((MATRIX_X,MATRIX_Y), 'i')
        self.toxin_presense = False     #if toxin used
        self.trace = numpy.zeros((MATRIX_X,MATRIX_Y), 'B')      #bacteria scent trace
        self.trace_pos = numpy.zeros((DISPLAY_X,DISPLAY_Y), 'B')
        self.trace_update = 0
        self.trace_x = 0
        self.trace_y = 0
        self.trace_display = False  #visual display of bacterium trace
        self.field_x = 0       #field scroll
        self.field_y = 0
        self.overlap = 50     #screen field overlap?
        self.screen_update = True    #screen update at intervals
        self.screen_update_count = 0
        self.update_list = []    #list of all rect to be updated on display
        self.matrix_surface = pygame.Surface((DISPLAY_X,DISPLAY_Y))
        self.scroll_field = {'x': None, 'y': None}
        self.scroll_step = 2    #scroll_rate:5, bug_follow:2
        self.mouse_x = 0
        self.mouse_y = 0
        self.mouse_x_pre = 0
        self.mouse_y_pre = 0
        self.zoom_surface = pygame.display.get_surface()
        self.zoom_set = False   #Zoom settings
        self.zoom_power = 2
        self.zoom_init = False
        self.surface_clear = pygame.Surface((200,200))  #zoom clear
        self.bug_tag = None
        self.bug_follow = False  #when bug tagged, determine if view follows
        self.evolution = False  #evolve
        self.tag_display = True     #whether tag is displayed
        self.newspecies = {}    #newspecies objects

    def setup(self, algae=True, bacterium=True, paramecium=True, amoeba=True, ciliate=True):
        creatures = {Algae:algae, Bacterium:bacterium, Paramecium:paramecium, Amoeba:amoeba, Ciliate:ciliate}
        repeat = 3
        for i in range((MATRIX_X*MATRIX_Y)//150000):
            x = random.randrange(0,MATRIX_X)
            y = random.randrange(0,MATRIX_Y)
            self.gradient(x,y)
            if repeat:
                self.gradient(x,y)
                repeat -= 1
        for cell in self.species:
            if creatures[cell]:
                for num in xrange(cell.minimum):
                    self.add_creature(cell)

    def set_gradient(self, x, y, gradient_type='Nutrient'):
        if gradient_type == 'Nutrient':
            if not self.nutrient[x + self.field_x, y + self.field_y] > 1000000:     #max nutrient per locale
                self.gradient(x + self.field_x, y + self.field_y, gradient_type='Nutrient')
                self.screen_update_count = 0
                self.screen_update = True
        elif gradient_type == 'Toxin':
            if not self.toxin_presense:
                self.toxin = numpy.zeros((MATRIX_X,MATRIX_Y), 'i')
                self.toxinx = numpy.zeros((DISPLAY_X,DISPLAY_Y), 'i')
                self.toxin_presense = True
            if not self.toxin[x + self.field_x, y + self.field_y] > 1000000:     #max toxin per locale
                self.gradient(x + self.field_x, y + self.field_y, gradient_type='Toxin')
                self.screen_update_count = 0
                self.screen_update = True

    def gradient(self, x, y, gradient_type='Nutrient'):
        dx = abs(x - (MATRIX_X//2))   #position offset from matrix center
        dy = abs(y - (MATRIX_Y//2))
        if x <= MATRIX_X//2:        #define overlapping area of matrices to be combined
            matx1 = 0
            matx2 = MATRIX_X - dx
            medx1 = 0 + dx
            medx2 = MATRIX_X
        else:
            matx1 = 0 + dx
            matx2 = MATRIX_X
            medx1 = 0
            medx2 = MATRIX_X - dx
        if y <= MATRIX_Y//2:
            maty1 = 0
            maty2 = MATRIX_Y - dy
            medy1 = 0 + dy
            medy2 = MATRIX_Y
        else:
            maty1 = 0 + dy
            maty2 = MATRIX_Y
            medy1 = 0
            medy2 = MATRIX_Y - dy
        if gradient_type == 'Nutrient':
            self.nutrient[matx1:matx2,maty1:maty2] = numpy.add(self.nutrient[matx1:matx2,maty1:maty2],self.media[medx1:medx2,medy1:medy2])
        elif gradient_type == 'Toxin':
            self.toxin[matx1:matx2,maty1:maty2] = numpy.add(self.toxin[matx1:matx2,maty1:maty2],self.media[medx1:medx2,medy1:medy2])

    def add_creature(self, species, x=None, y=None, clone=False, identity=None, inherit=None):
        if x and y and not clone:   #x,y is matrix position when clone, mouse pos is coordinated to screen
            x += self.field_x
            y += self.field_y
        if species is Algae:
            if Algae.count < Algae.maximum:
                x = x or random.randrange(10, MATRIX_X-10)    #boundary -10 to remain in range
                y = y or random.randrange(10, MATRIX_Y-10)
                self.cells['algae'].add(Algae(x, y))
        elif species is Bacterium:
            if Bacterium.count < Bacterium.maximum:
                x = x or random.randrange(10, MATRIX_X-10)
                y = y or random.randrange(10, MATRIX_Y-10)
                self.cells['bacterium'].add(Bacterium(x, y, identity=identity, inherit=inherit))
        elif species is Paramecium:
            if Paramecium.count < Paramecium.maximum:
                x = x or random.randrange(100, MATRIX_X-100)
                y = y or random.randrange(100, MATRIX_Y-100)
                self.cells['paramecium'].add(Paramecium(x, y, identity=identity, inherit=inherit))
        elif species is Amoeba:
            if Amoeba.count < Amoeba.maximum:
                amoeba_color = random.choice((50,170,800,1000))
                x = x or random.randrange(100, MATRIX_X-100)
                y = y or random.randrange(100, MATRIX_Y-100)
                self.cells['amoeba'].add(Amoeba(x, y, color=amoeba_color, identity=identity, inherit=inherit))
        elif species is Ciliate:
            if Ciliate.count < Ciliate.maximum:
                x = x or random.randrange(100, MATRIX_X-100)
                y = y or random.randrange(100, MATRIX_Y-100)
                self.cells['paramecium'].add(Ciliate(x, y, identity=identity, inherit=inherit))
        elif species in self.newspecies.values():
            if species.count < species.maximum:
                x = x or random.randrange(100, MATRIX_X-100)
                y = y or random.randrange(100, MATRIX_Y-100)
                self.species_group[species.progenitor].add(species(x, y, identity=identity, inherit=inherit))

    def set_scroll(self, direction=None, field_change=None, scroll='manual'):
        if scroll == 'manual' and self.scroll_step == 2:
            self.scroll_step = 5    #manual
            self.matrix_change_x = numpy.zeros((self.scroll_step,DISPLAY_Y), 'i')
            self.matrix_change_surface_x = pygame.Surface((self.scroll_step,DISPLAY_Y))
            self.matrix_change_y = numpy.zeros((DISPLAY_X,self.scroll_step), 'i')
            self.matrix_change_surface_y = pygame.Surface((DISPLAY_X,self.scroll_step))
        elif scroll == 'auto' and self.scroll_step == 5:
            self.scroll_step = 2    #auto
            self.matrix_change_x = numpy.zeros((self.scroll_step,DISPLAY_Y), 'i')
            self.matrix_change_surface_x = pygame.Surface((self.scroll_step,DISPLAY_Y))
            self.matrix_change_y = numpy.zeros((DISPLAY_X,self.scroll_step), 'i')
            self.matrix_change_surface_y = pygame.Surface((DISPLAY_X,self.scroll_step))
        if field_change == 0:
            if direction in ('north', 'south', 'y'):
                self.scroll_field['y'] = None
            elif direction in ('west', 'east', 'x'):
                self.scroll_field['x'] = None
            return
        field_change = self.scroll_step
        if direction == 'north':
            if self.field_y >= field_change:
                self.scroll_field['y'] = direction
            else:
                self.scroll_field['y'] = None
        elif direction == 'south':
            if self.field_y < MATRIX_Y-DISPLAY_Y-field_change:
                self.scroll_field['y'] = direction
            else:
                self.scroll_field['y'] = None
        elif direction == 'west':
            if self.field_x >= field_change:
                self.scroll_field['x'] = direction
            else:
                self.scroll_field['x'] = None
        elif direction == 'east':
            if self.field_x < MATRIX_X-DISPLAY_X-field_change:
                self.scroll_field['x'] = direction
            else:
                self.scroll_field['x'] = None

    def scroll(self):
        step = self.scroll_step
        if self.scroll_field['y']:
            if self.scroll_field['y'] == 'north' and self.field_y >= step:
                self.field_y -= step
                self.matrix_change_y = self.nutrient[0+self.field_x:DISPLAY_X+self.field_x,0+self.field_y:0+self.field_y+step]
                if self.toxin_presense:
                    self.toxin_change_y = self.toxin[0+self.field_x:DISPLAY_X+self.field_x,0+self.field_y:0+self.field_y+step]
                    self.toxin_change_y = numpy.where(self.toxin_change_y>10000, self.toxin_change_y, 0)
                    self.matrix_change_y = numpy.subtract(self.matrix_change_y, self.toxin_change_y)
                pygame.surfarray.blit_array(self.matrix_change_surface_y, self.matrix_change_y)
                self.matrix_surface.blit(self.matrix_surface.copy(), (0,step), (0,0,DISPLAY_X,DISPLAY_Y-step))
                self.matrix_surface.blit(self.matrix_change_surface_y, (0,0))
            elif self.scroll_field['y'] == 'south' and self.field_y < MATRIX_Y-DISPLAY_Y-step:
                self.field_y += step
                self.matrix_change_y = self.nutrient[0+self.field_x:DISPLAY_X+self.field_x,DISPLAY_Y+self.field_y-step:DISPLAY_Y+self.field_y]
                if self.toxin_presense:
                    self.toxin_change_y = self.toxin[0+self.field_x:DISPLAY_X+self.field_x,DISPLAY_Y+self.field_y-step:DISPLAY_Y+self.field_y]
                    self.toxin_change_y = numpy.where(self.toxin_change_y>10000, self.toxin_change_y, 0)
                    self.matrix_change_y = numpy.subtract(self.matrix_change_y, self.toxin_change_y)
                pygame.surfarray.blit_array(self.matrix_change_surface_y, self.matrix_change_y)
                self.matrix_surface.blit(self.matrix_surface.copy(), (0,0), (0,step,DISPLAY_X,DISPLAY_Y-step))
                self.matrix_surface.blit(self.matrix_change_surface_y, (0,DISPLAY_Y-step))
            else:
                self.scroll_field['y'] = None
        if self.scroll_field['x']:
            if self.scroll_field['x'] == 'west' and self.field_x >= step:
                self.field_x -= step
                self.matrix_change_x = self.nutrient[0+self.field_x:0+self.field_x+step,0+self.field_y:DISPLAY_Y+self.field_y]
                if self.toxin_presense:
                    self.toxin_change_x = self.toxin[0+self.field_x:0+self.field_x+step,0+self.field_y:DISPLAY_Y+self.field_y]
                    self.toxin_change_x = numpy.where(self.toxin_change_x>10000, self.toxin_change_x, 0)
                    self.matrix_change_x = numpy.subtract(self.matrix_change_x, self.toxin_change_x)
                pygame.surfarray.blit_array(self.matrix_change_surface_x, self.matrix_change_x)
                self.matrix_surface.blit(self.matrix_surface.copy(), (step,0), (0,0,DISPLAY_X-step,DISPLAY_Y))
                self.matrix_surface.blit(self.matrix_change_surface_x, (0,0))
            elif self.scroll_field['x'] == 'east' and self.field_x < MATRIX_X-DISPLAY_X-step:
                self.field_x += step
                self.matrix_change_x = self.nutrient[DISPLAY_X+self.field_x-step:DISPLAY_X+self.field_x,0+self.field_y:DISPLAY_Y+self.field_y]
                if self.toxin_presense:
                    self.toxin_change_x = self.toxin[DISPLAY_X+self.field_x-step:DISPLAY_X+self.field_x,0+self.field_y:DISPLAY_Y+self.field_y]
                    self.toxin_change_x = numpy.where(self.toxin_change_x>10000, self.toxin_change_x, 0)
                    self.matrix_change_x = numpy.subtract(self.matrix_change_x, self.toxin_change_x)
                pygame.surfarray.blit_array(self.matrix_change_surface_x, self.matrix_change_x)
                self.matrix_surface.blit(self.matrix_surface.copy(), (0,0), (step,0,DISPLAY_X-step,DISPLAY_Y))
                self.matrix_surface.blit(self.matrix_change_surface_x, (DISPLAY_X-step,0))
            else:
                self.scroll_field['x'] = None
        if self.scroll_field['y'] or self.scroll_field['x']:
            self.screen.blit(self.matrix_surface, (0,0))
            self.update_list.append(self.screen.get_rect())

    def bug_track(self):
        adj = 0
        field_change = self.scroll_step-1
        xx, yy = self.bug_tag.rect.centerx-self.field_x, self.bug_tag.rect.centery-self.field_y
        if xx < (DISPLAY_X//2)-field_change-adj:
            self.set_scroll('west', field_change, scroll='auto')
        elif xx > (DISPLAY_X//2)+field_change+adj:
            self.set_scroll('east', field_change, scroll='auto')
        else:
            self.set_scroll('x', 0, scroll='auto')
        if yy < (DISPLAY_Y//2)-field_change-adj:
            self.set_scroll('north', field_change, scroll='auto')
        elif yy > (DISPLAY_Y//2)+field_change+adj:
            self.set_scroll('south', field_change, scroll='auto')
        else:
            self.set_scroll('y', 0, scroll='auto')

    def bug_select(self, x, y):
        for species in self.cells:
            for bug in self.cells[species]:
                if bug.rect.collidepoint(x + self.field_x, y + self.field_y):
                    return bug
        return None

    def bug_track_set(self, x, y, follow=True):
        bug = self.bug_select(x,y)
        if bug:
            if bug is not self.bug_tag:
                self.bug_tag = bug
            if follow:
                self.bug_follow = True
            else:
                self.bug_follow = False
            return bug
        else:
            self.bug_track_remove()
            return False

    def bug_track_remove(self, bug=None):
        if self.bug_tag and ( bug is self.bug_tag or not bug ):
            self.bug_tag = None
            self.bug_follow = False
            self.set_scroll('x', 0)
            self.set_scroll('y', 0)
            control.panel.info_active(False)
            self.screen_update = True
            return True
        else:
            return False

    def bug_remove(self, x, y):
        bug = self.bug_select(x,y)
        if bug:
            self.bug_track_remove(bug)
            bug.life = False
            return True
        else:
            return False

    def species_evolve_set(self, x, y):
        bug = self.bug_select(x,y)
        if bug:
            if not bug.species.evolving:
                if bug.gene:   #has genes specified
                    bug.species.evolving = True
                return True
            else:
                bug.species.evolving = 'pause'
                return False
        else:
            return False

    def bug_set_id(self, bug, identity):
        bug.identity = identity
        bug.id_tag = None

    def bug_set_gene(self, bug, gene, setting=0, allele=False):
        if not allele:
            genes = bug.gene.copy()
            genes[gene] = setting
            bug.set_gene(genes)
            return True
        else:
            settings = bug.species.alleles[gene]
            return settings

    def bug_save(self, bug, filename='species.dat', path='data', overwrite=False):
        try:
            bug_species_id = self.species.index(bug.species)    #save [Algae, Bacterium, Paramecium, Amoeba, Ciliate]
        except ValueError:
            bug_species_id = self.species.index(bug.species.progenitor)     #save newspecies
        bug_id = bug.identity
        bug_gene = bug.gene.copy()
        bug_info = bug_species_id, bug_id, bug_gene
        if path:
            fn = os.path.join(path, filename)
        check = os.path.exists(fn)
        if check and not overwrite:
            return False
        try:
            bug_file = open(fn, 'wb')
        except IOError:
            return False
        else:
            cPickle.dump(bug_info, bug_file)
            bug_file.close()
            return fn

    def bug_load(self, filename='species.dat', path='data', new_species=True):
        try:
            if path:
                fn = os.path.join(path, filename)
            check = os.path.exists(fn)
            if not check:
                return False
            bug_file = open(fn, 'rb')
            bug_info = cPickle.load(bug_file)
            bug_file.close()
            bug_species_id, bug_id, bug_gene = bug_info
            bug_species = self.species[bug_species_id]
            img = filename[:-4] + '.png'    #load png of same name if present
            if path:
                imgfile = os.path.join(path, img)
            check = os.path.exists(imgfile)
            if not check:
                img = None
        except IOError:
            print("Load error")
            return False
        mouse_x, mouse_y = pygame.mouse.get_pos()
        if new_species:     #load as newspecies
            species = filename[:-4]
            if species not in self.newspecies or (species in self.newspecies and not issubclass(self.newspecies[species],bug_species)):     #create newspecies class
                newSpecies = self.create_species(bug_species, mouse_x+self.field_x, mouse_y+self.field_y, cell_image=img, frames=None, identity=bug_id, inherit=bug_gene, mutation_rate=0)
                self.species_group[bug_species].add(newSpecies)
                if species in self.newspecies:   #rename if already present, in case saved file was changed
                    key = species
                    while key in self.newspecies:
                        key = key + '_'
                    self.newspecies[key] = self.newspecies[species]
                    del self.newspecies[species]
                self.newspecies[species] = newSpecies.species
            else:   #add instance to created newspecies class
                if self.newspecies[species].count < self.newspecies[species].maximum:
                    self.species_group[bug_species].add(self.newspecies[species](mouse_x+self.field_x, mouse_y+self.field_y, identity=bug_id,inherit=bug_gene, mutation_rate=0))

    def create_species(self, Progenitor, x, y, cell_image=None, frames=2, identity=None, inherit=None, mutation_rate=0):
        class NewSpecies(Progenitor):
            image = None
            count = 0
            minimum = Progenitor.minimum
            maximum = Progenitor.maximum
            id = 0
            evolving = False
            gene = Progenitor.gene
            alleles = Progenitor.alleles
            progenitor = Progenitor
            image_file = None
            def __init__(self, x, y, cell_image=None, frames=None, identity=None, inherit=None, mutation_rate=0.5):
                self.species = self.__class__
                if not self.species.image_file:
                    progenitors = { Algae:('algae.png',1), Bacterium:('bacterium.png',1), Paramecium:('paramecium.png',2), Ciliate:('ciliate.png',2), Amoeba:(None,1) }
                    if not cell_image:
                        cell_image, frames = progenitors[Progenitor]
                        self.species.image_file = cell_image, frames
                    else:
                        frames = progenitors[Progenitor][1]
                        self.species.image_file = cell_image, frames
                else:
                    cell_image, frames = self.species.image_file
                Progenitor.__init__(self, x, y, cell_image, frames, identity, inherit, mutation_rate)
        newSpecies = NewSpecies(x, y, cell_image, frames, identity, inherit, mutation_rate)
        return newSpecies

    def bug_trace_update(self):
        self.trace_update += 1
        if self.trace_update > 2:   #update trace decay at rate that gradient detectable over cell
            self.trace_pos = numpy.greater(self.trace[0+(DISPLAY_X*self.trace_x):DISPLAY_X+(DISPLAY_X*self.trace_x),0+(DISPLAY_Y*self.trace_y):DISPLAY_Y+(DISPLAY_Y*self.trace_y)], 9)
            self.trace[0+(DISPLAY_X*self.trace_x):DISPLAY_X+(DISPLAY_X*self.trace_x),0+(DISPLAY_Y*self.trace_y):DISPLAY_Y+(DISPLAY_Y*self.trace_y)] -= self.trace_pos *10
            self.trace_update = 0
            self.trace_x += 1
            if self.trace_x > 2:
                self.trace_x = 0
                self.trace_y += 1
            if self.trace_y > 2:
                self.trace_x = 0
                self.trace_y = 0
            if self.trace_display:
                trace_temp = numpy.array(self.trace[0+self.field_x:DISPLAY_X+self.field_x,0+self.field_y:DISPLAY_Y+self.field_y])
                pygame.surfarray.blit_array(self.screen, trace_temp)
                self.update_list.append(self.screen.get_rect())

    def set_evolution(self, setting='Toggle'):
        if setting == 'Toggle':
            self.evolution = not self.evolution
        elif setting in (True,False):
            self.evolution = setting

    def set_tag_display(self, setting='Toggle'):
        if setting == 'Toggle':
            self.tag_display = not self.tag_display
        elif setting in (True,False):
            self.tag_display = setting

    def set_screen_update(self):
        self.screen_update = True

    def zoom_activate(self, display=True, power=1, zoom_reset=True):
        if display:
            if not self.zoom_set:
                if not self.bug_follow and not self.scroll_field['x'] and not self.scroll_field['y']:
                    pygame.mouse.set_visible(False)
                    self.zoom_set = True
            else:
                if power == 1:
                    if self.zoom_power < 10:
                        self.zoom_power += power
                    else:
                        if zoom_reset:
                            self.zoom_power = 2
                elif power == -1:
                    if self.zoom_power > 2:
                        self.zoom_power += power
        else:
            if self.zoom_set:
                pygame.mouse.set_visible(True)
                self.zoom_set = False
                self.zoom_init = False
                self.screen_update = True     #surface_clear instead?

    def field_zoom(self, action):
        "Microscopic zoom centered on mouse pointer"
        if action == 'clear':
            self.mouse_x, self.mouse_y = pygame.mouse.get_pos()
            if self.mouse_x < 100: self.mouse_x = 100
            elif self.mouse_x > DISPLAY_X-100: self.mouse_x = DISPLAY_X-100
            if self.mouse_y < 100: self.mouse_y = 100
            elif self.mouse_y > DISPLAY_Y-100: self.mouse_y = DISPLAY_Y-100
            if not self.zoom_init:
                self.mouse_x_pre = self.mouse_x
                self.mouse_y_pre = self.mouse_y
                self.surface_clear = self.screen.subsurface((self.mouse_x_pre-100, self.mouse_y_pre-100, 200,200)).copy()
                self.zoom_init = True
            clear_rect = self.screen.blit(self.surface_clear, (self.mouse_x_pre-100,self.mouse_y_pre-100))
            self.update_list.append(clear_rect)
        elif action == 'activate':
            self.surface_clear = self.screen.subsurface((self.mouse_x-100,self.mouse_y-100,200,200)).copy()
            clear_rect = self.surface_clear.get_rect(center=(self.mouse_x,self.mouse_y))
            self.zoom_surface = self.screen.subsurface((self.mouse_x-100//self.zoom_power,self.mouse_y-100//self.zoom_power,200//self.zoom_power,200//self.zoom_power)).copy()
            self.zoom_surface = pygame.transform.smoothscale(self.zoom_surface, (200,200))
            pygame.draw.rect(self.zoom_surface, (70,130,180), (0,0,200,200), 1)
            zoom_rect = self.zoom_surface.get_rect(center=(self.mouse_x,self.mouse_y))
            zoom_rect = self.screen.blit(self.zoom_surface, (self.mouse_x-100,self.mouse_y-100))
            self.update_list.append(zoom_rect)
            self.mouse_x_pre = self.mouse_x
            self.mouse_y_pre = self.mouse_y

    def display(self):
        if self.screen_update:   #only update at intervals
            if not self.screen_update_count:
                self.matrixx = self.nutrient[0+self.field_x:DISPLAY_X+self.field_x,0+self.field_y:DISPLAY_Y+self.field_y]    #Matrix     #overlap?
                if self.toxin_presense:
                    self.toxinx = numpy.array(self.toxin[0+self.field_x:DISPLAY_X+self.field_x,0+self.field_y:DISPLAY_Y+self.field_y])  #require numpy.array or slice?
                    self.toxinx = numpy.where(self.toxinx>10000, self.toxinx, 0)
                    self.matrixx = numpy.subtract(self.matrixx, self.toxinx)
                pygame.surfarray.blit_array(self.matrix_surface, self.matrixx)
            self.screen.blit(self.matrix_surface, (0,0))
            self.update_list.append(self.screen.get_rect())
            self.screen_update = False
        self.screen_update_count += 1
        if self.screen_update_count > 1000:    #change update to compensate for computer load
            self.screen_update_count = 0       #during update, zoom blinks screen...
            self.screen_update = True

    def creature_inview(self, creature):
        if creature in self.cells['creatures']:
            return True
        else:
            return False

    def creatures_update(self):
        "Update all creatures and populate update_list of creatures on screen for display"
        self.cells['algae'].update()
        self.cells['bacterium'].update()
        self.cells['amoeba'].update()
        self.cells['paramecium'].update()
        #update creatures in view
        self.cells['creatures'].empty()     #have bug check and report if onscreen?
        #algae update
        for bug in self.cells['algae']:
            if bug.life_check():
                if bug.rect.centerx > 0+self.field_x-self.overlap//5 and bug.rect.centerx < DISPLAY_X+self.field_x+self.overlap//5 and bug.rect.centery > 0+self.field_y-self.overlap//5 and bug.rect.centery < DISPLAY_Y+self.field_y+self.overlap//5:
                    self.cells['creatures'].add(bug)    #draw cells onscreen, with display overlap/5
            else:
                self.bug_track_remove(bug)
                self.cells['algae'].remove(bug)
        #bacterium update
        for bug in self.cells['bacterium']:
            if bug.life_check():
                if bug.rect.centerx > 0+self.field_x-self.overlap//5 and bug.rect.centerx < DISPLAY_X+self.field_x+self.overlap//5 and bug.rect.centery > 0+self.field_y-self.overlap//5 and bug.rect.centery < DISPLAY_Y+self.field_y+self.overlap//5:
                    self.cells['creatures'].add(bug)      #draw cells onscreen, with display overlap/5
            else:
                self.bug_track_remove(bug)
                self.cells['bacterium'].remove(bug)
        #amoeba update
        for bug in self.cells['amoeba']:
            if bug.life_check():
                if bug.rect.centerx > 0+self.field_x-self.overlap and bug.rect.centerx < DISPLAY_X+self.field_x+self.overlap and bug.rect.centery > 0+self.field_y-self.overlap and bug.rect.centery < DISPLAY_Y+self.field_y+self.overlap:
                    self.cells['creatures'].add(bug)
            else:
                self.bug_track_remove(bug)
                self.cells['amoeba'].remove(bug)
        #paramecium update
        for bug in self.cells['paramecium']:
            if bug.life_check():
                if bug.rect.centerx > 0+self.field_x-self.overlap and bug.rect.centerx < DISPLAY_X+self.field_x+self.overlap and bug.rect.centery > 0+self.field_y-self.overlap and bug.rect.centery < DISPLAY_Y+self.field_y+self.overlap:
                    self.cells['creatures'].add(bug)    #draw cells onscreen, with display overlap
            else:
                self.bug_track_remove(bug)
                self.cells['paramecium'].remove(bug)
        #Display label
        if self.bug_tag and not self.bug_follow:
            if self.tag_display:
                self.bug_tag.display_tag()
            else:
                self.bug_tag.display_tag(False)
        if self.evolution:
            for bug in self.cells['creatures']:
                if bug.species.evolving:
                    if self.tag_display:
                        bug.display_tag()
                    else:
                        bug.display_tag(False)
        #Update creatures currently on screen
        for bug in self.cells['creatures']:       #adjust display location
            bug.rect.centerx -= self.field_x
            bug.rect.centery -= self.field_y
        self.cells['creatures'].clear(self.screen_microbe, self.matrix_surface)
        self.update_list.extend(self.cells['creatures'].draw(self.screen_microbe))
        for bug in self.cells['creatures']:       #restore location
            bug.rect.centerx += self.field_x
            bug.rect.centery += self.field_y
        self.bug_trace_update()

    def update(self):
        self.update_list = []
        self.display()
        if self.scroll_field['x'] or self.scroll_field['y']:
            self.scroll()
        if self.bug_tag and self.bug_follow:
            self.bug_track()
        control.panel_group.clear(self.screen, self.matrix_surface)
        if not self.zoom_set:
            self.creatures_update()
        else:
            self.field_zoom('clear')
            self.creatures_update()
            self.field_zoom('activate')


class Evolve(object):
    """
    Manages the evolutional process.
    """

    def genetics(self, inherit=None, mutation_rate=0.5, genome=None, alleles=None):
        """Set genetics of organism. Parameters: inherit - contain copy of self.gene, otherwise, organism genetic makeup set randomly from possibilities in alleles; mutation_rate - rate at which heritable genes are mutated; genome - number of genes; alleles - ranges from which gene settings will be chosen."""
        if matrix.evolution and genome:     #evolve trait parameters
            self.inherit = inherit
            gene = {}
            mutation = random.random() < mutation_rate    #if inherit with mutation
            if not inherit or mutation:     #set genes chosen randomly from alleles
                for genex in xrange(1,genome+1):
                    gene[genex] = random.randrange(*alleles[genex])
                if mutation:
                    mutant_gene = random.choice((gene.keys()))  #mutate single gene
                    mutant_trait = { mutant_gene: gene[mutant_gene] }
            if inherit:
                gene = inherit  #clonal division
                if random.random() > 0.9:   #crossover
                    group = matrix.species_group[self.species]
                    gene_xo = random.choice(group.sprites()).gene
                    gene_select = random.sample(range(1,len(gene)+1), len(gene)//2)
                    for gen in gene_select:
                        gene[gen] = gene_xo[gen]
                if mutation:    #clonal division with single mutation
                    gene[mutant_gene] = mutant_trait[mutant_gene]
            return gene

    def evolution(self, cycle=500, division_threshold=18):    #selection
        """Evolutionary selection. Parameters: cycle - rate of cell update; division_threshold - energy required for division."""
        if self.life:   #prosper or perish
            self.exist += 1
            self.ingest -= 1.0/cycle  #energy expenditure
            self.fitness = self.ingest/division_threshold * 100
            if self.exist > 100:
                self.exist = 0
                if self.fitness >= 100:   #replicate when reserves sufficient
                    self.ingest = division_threshold / 4
                    if self.species.count < self.species.maximum:
                        matrix.add_creature(self.species, self.x, self.y, clone=True, identity=self.identity, inherit=self.gene.copy())     #give copy of self.gene, so that it's not modified
                elif self.fitness <= 0:   #possible decrease when reserves depleted
                    if random.random() > ( 0.9 - abs(self.fitness*0.1) ):
                        self.life = False
                if self.species.count < self.species.minimum:  #fresh supply to gene pool, and stop extinction
                    matrix.add_creature(self.species)


class Cell(pygame.sprite.Sprite,Evolve):
    """
    Cell class is the base class of cells.
    """

    image = None
    count = 0
    minimum = (MATRIX_X*MATRIX_Y)//250000
    maximum = 100
    id = 0  #id when created
    evolving = False    #species evolving
    gene = {}
    alleles = {}

    def __init__(self, x, y, cell_image=None, frames=1, identity=None, inherit=None, mutation_rate=0.5):
        pygame.sprite.Sprite.__init__(self)
        self.species = self.__class__
        self.species.count += 1     #number of species in matrix
        self.species.id += 1
        self.identity = self.species.id
        self.gene = {}
        self.x = x  #location in matrix
        self.y = y
        self.pos_x = float(self.x)     #float version
        self.pos_y = float(self.y)
        self.distance = 0       #Distance to move before changing direction, unless adjustment with sense
        self.direction = random.randrange(360)
        self.direction_adj_i = 0    #fine directional adjustment
        self.direction_adj_f = 0    #full directional adjustment
        self.move_x = 1
        self.move_y = 1
        self.velocity = 1
        self.reverse = False    #if in avoidance behaviour
        self.reverse_redux = False
        self.rotate = 0     #image rotation - none = 0, ccr = -1, cr =1
        self.rotate_count = 0   #?
        self.interact = 0   #response taken to bumping other paramecium
        self.life = True
        self.exist = 0    #time since instance created
        self.ingest = 0
        self.fitness = 100
        self.fission = 0
        self.phenotype(self.species, cell_image, frames)     #default image
        if identity:
            self.identity = identity
        self.gene, self.trait = self.genotype(inherit,mutation_rate)
        self.rotate_image = True   #rotate with direction change
        self.sensing = True     #if sensing
        self.label_display = True
        self.id_tag = None  #text id label
        try:
            if self.species.image[0].get_size()[0] <= 10:
                self.label_size = 6
            else:
                self.label_size = 10
        except:
            self.label_size = 10
        self.print_tag = interphase.Text(matrix.screen, font_size=self.label_size)
        self.growth_rate = 1.0

    def set_trait(self, gene):
        "Set in species class"
        trait = {}
        return trait

    def genotype(self, inherit, mutation_rate):
        if not inherit:
            gene = self.species.gene.copy()
        else:
            gene = inherit
        if 'File' in gene:      #For evolved species, gene in file
            fn = os.path.join('data', gene['File'])
            bug_file = open(fn, 'rb')
            gene = cPickle.load(bug_file)
            bug_file.close()
        if matrix.evolution and self.species.evolving:
            genome = len(gene)
            alleles = self.species.alleles.copy()
            gene = self.genetics(inherit,mutation_rate,genome,alleles)
        trait = self.set_trait(gene)
        return gene, trait

    def set_gene(self, gene):
        self.gene = gene
        self.trait = self.set_trait(gene)

    def evolve(self):
        self.evolution()

    def phenotype(self, species, cell_image, frames):
        if cell_image:
            if not species.image:       #load images on first instance
                species.image = []
                image = load_image(cell_image)
                width, height = image.get_size()
                image_width = width // frames
                for frame in xrange(frames):
                    frame_num = image_width * frame
                    image_frame = image.subsurface((frame_num,0), (image_width,height)).copy()
                    species.image.append(image_frame)
            self.image = species.image[0].copy()
            self.rect = self.image.get_rect(center=(self.x,self.y))
            if frames == 1:
                self.image_multiframe = 0    #single_frame
            else:
                self.image_multiframe = frames    #multi_frame
            self.image_frame = 0    #current image frame
            self.image_frame_counter = 0    #frame switch timer

    def display_tag(self, display=True):
        if display:
            if not self.rotate_image:
                if not self.id_tag:
                    self.id_tag = self.print_tag.font[self.label_size].render(str(self.identity), True, (255,0,0))
                imagex,imagey = self.image.get_rect().center
                self.image.blit(self.id_tag, (imagex-3,imagey-3) )
        else:
            self.image = pygame.transform.rotozoom(self.species.image[self.image_frame], -self.direction, 1.0)

    def life_check(self):
        if self.life:
            return True
        else:
            self.species.count -= 1
            return False

    def motion(self):
        self.direction = random.randrange(360)

    def move(self):
        self.motion()
        self.locate()

    def sense(self):    #sense() in species
        pass

    def growth(self):
        pass

    def locate(self):
        self.x, self.y = self.locate_coordinate(self.velocity, self.direction)
        self.check_interact()   #check if pass edge, adjust position accordingly
        if matrix.creature_inview(self):   #image update if inview
            if self.image_multiframe:
                self.image_frame_counter += 1
                if self.image_frame_counter > 2:
                    self.image_frame_counter = 0
                    self.image_frame += 1
                    if self.image_frame >= self.image_multiframe:
                        self.image_frame = 0
                self.rotate_image = True
            if self.rotate_image:   #rotozoom better quality than rotate
                self.image = pygame.transform.rotozoom(self.species.image[self.image_frame], -self.direction, 1.0)
                self.rotate_image = False
        self.rect = self.image.get_rect(center=(self.x,self.y))

    def check_interact(self):
        self.check_edge()

    def check_edge(self, margin_x=0, margin_y=0):
        left_edge = 0 + margin_x
        right_edge = MATRIX_X-1 - margin_x
        top_edge = 0 + margin_y
        bottom_edge = MATRIX_Y-1 - margin_y
        if self.x < left_edge or self.x > right_edge or self.y < top_edge or self.y > bottom_edge:
            if self.x < left_edge:
                self.x = left_edge
            elif self.x > right_edge:
                self.x = right_edge
            if self.y < top_edge:
                self.y = top_edge
            elif self.y > bottom_edge:
                self.y = bottom_edge
            self.pos_x, self.pos_y = float(self.x), float(self.y)
            return True
        else:
            return False

    def locate_coordinate(self, step, direction, change=True):
        """Calculates coordinate following step in a given direction from starting position self.pos_x, self.pos_y.
           If change is True changes self.pos_x/self.pos_y, otherwise just return calculated position."""
        x = self.pos_x
        y = self.pos_y
        x += +step*sin_table[direction]     # x += +step*math.sin(direction*math.pi/180)
        y += -step*cos_table[direction]     # y += -step*math.cos(direction*math.pi/180)
        if change:      #maintain float position
            self.pos_x = x
            self.pos_y = y
        return int(x), int(y)

    def direction_set(self, direction):
        if direction >= 360:
            direction -= 360
        elif direction < 0:
            direction += 360
        return direction

    def cell_division(self, time=500):
        if self.fission:
            self.fission += 1
            if self.fission > time:
                self.fission = 0
                return True
            else:
                return False
        else:
            return False

    def activity(self):
        self.move()
        self.growth()

    def update(self):
        self.activity()
        if matrix.evolution and self.species.evolving:
            if self.species.evolving != 'pause':
                self.evolve()
            else:
                self.display_tag(False)
                self.species.evolving = False


class Algae(Cell):
    """
    Algae species.
    """

    image = None
    count = 0
    minimum = (MATRIX_X*MATRIX_Y)//225000
    maximum = (MATRIX_X*MATRIX_Y)//22500
    id = 0
    evolving = False
    gene = {}
    alleles = {}

    def __init__(self, x, y, cell_image='algae.png', frames=1, identity=None, inherit=None, mutation_rate=0.5):
        Cell.__init__(self, x, y, cell_image, frames, identity, inherit, mutation_rate)

    def display_tag(self, display=True):
        pass


class Bacterium(Cell):
    """
    Bacterium species.
    """

    image = None
    count = 0
    minimum = (MATRIX_X*MATRIX_Y)//25000
    maximum = (MATRIX_X*MATRIX_Y)//4500
    id = 0
    evolving = False
    gene = { 1:1, 2:11 }
    alleles = { 1:(0,2), 2:(2,12) }
    gene_info = { 1:'Sense[0]', 2:'Sense[1]' }

    def __init__(self, x, y, cell_image='bacterium.png', frames=1, identity=None, inherit=None, mutation_rate=0.5):
        Cell.__init__(self, x, y, cell_image, frames, identity, inherit, mutation_rate)
        self.sense_previous = 0
        self.sense_previous_toxin = 0
        self.sense_bacteria = 1 #sense bacterium trace, to gauge bacteria density
        self.growth_rate = 1.0  #rate of growth starting at 100%, modulated by population density
        self.ingest = 25000     #initial reserves
        self.velocity = 2

    def set_trait(self, gene):
        trait = { 'sense': lambda: random.randrange(gene[1],gene[2]) }
        return trait

    def evolve(self):
        self.evolution(cycle=1, division_threshold=100000)    #evolve

    def sense(self, substance='nutrient'):
        if self.sensing:    #at high density - allow to explore fresh pastures
            attract = 1
        else:
            if matrix.nutrient[self.x,self.y] > 100:
                attract = -1
            else:
                self.sensing = True
                attract = 1
        if substance is 'nutrient':
            if matrix.nutrient[self.x,self.y] > self.sense_previous:
                self.sense_previous = matrix.nutrient[self.x,self.y]
                return self.trait['sense']() * 0.02 * attract      #evolve = random.randrange(1,11)
            else:
                self.sense_previous = matrix.nutrient[self.x,self.y]
                return 0.0
        elif substance is 'toxin':
            if matrix.toxin_presense:
                if matrix.toxin[self.x,self.y] < self.sense_previous_toxin:
                    self.sense_previous_toxin = matrix.toxin[self.x,self.y]
                    return (random.randrange(1,11) * 0.02)
                else:
                    self.sense_previous_toxin = matrix.toxin[self.x,self.y]
                    return 0.0
            else:
                return 0.0

    def motor_check(self):
        if random.random() > ( (0.1*self.velocity) - (self.sense('nutrient')*self.velocity) - (self.sense('toxin')*self.velocity) ):    #need adjustment with velocity
            motive = True   #1:forward 0:tumble
        else:
            motive = False
        return motive

    def motion(self):
        if not self.fission:
            if self.motor_check():
                direction = 0
            else:
                direction = random.randrange(360)
                self.rotate_image = True
        else:
            if random.random() > 0.2:
                reverse_direction = self.direction_set( self.direction + 180 )
                direction = random.choice((self.direction,reverse_direction))
            else:
                direction = 0
        if direction:
            self.direction = direction

    def bacterium_trace(self):
        global matrix
        matrix.trace[self.x,self.y] = 250      #bacteria scent trace
        #trace not continuous, gaps between steps

    def bacteria_detect(self):
        "Bacterium detection of bacteria trace, to judge local bacterium density so as to avoid overcrowding"
        if matrix.trace[self.x,self.y] > 150:
            if self.sense_bacteria < 100:
                self.sense_bacteria += 1
        else:
            if self.sense_bacteria > 1:
                self.sense_bacteria -= 1
        if self.sensing:
            if self.sense_bacteria == 100:
                if random.random() > 0.95:
                    self.sensing = False
        else:
            if random.random() > 0.995:
                self.sensing = True
        self.growth_rate = 1.0 / math.sqrt(self.sense_bacteria)  #high density causes reduce growth rate

    def growth(self):
        if (not self.fission) and (self.species.count < self.species.maximum):
            max_ingest = 10000
            if (matrix.nutrient[self.x,self.y] * 0.01) < max_ingest:
                consumption = (matrix.nutrient[self.x,self.y] * 0.01) * self.growth_rate
            else:
                consumption = max_ingest * self.growth_rate
            self.ingest += consumption
            if self.ingest > 100000 and not self.species.evolving:
                if not random.randrange(10):    #random start of fission
                    self.fission = 1
                    self.ingest = 0
                    self.velocity = 1
            matrix.nutrient[self.x,self.y] -= consumption
            if matrix.nutrient[self.x,self.y] < 0:
                matrix.nutrient[self.x,self.y] = 0
        if self.cell_division():
            matrix.add_creature(self.species, self.x, self.y, clone=True, inherit=self.gene.copy())
            self.velocity = 2
            if random.random() < 0.9:
                self.sensing = True
                self.sense_bacteria = 1
            else:
                self.sensing = False    #random chance to migrate
                self.sense_bacteria = 1

    def activity(self):
        Cell.activity(self)
        self.bacteria_detect()
        self.bacterium_trace()


class Paramecium(Cell):
    """
    Paramecium species.
    """

    image = None
    count = 0
    minimum = (MATRIX_X*MATRIX_Y)//250000
    maximum = (MATRIX_X*MATRIX_Y)//45000
    id = 0
    evolving = False
    gene = { 1:3, 2:2, 3:0, 4:1, 5:0, 6:1, 7:50, 8:100, 9:-2, 10:3, 11:45, 12:90 }
    alleles = { 1:(2,6), 2:(2,6), 3:(0,2), 4:(2,6), 5:(0,2), 6:(2,6), 7:(25,51), 8:(75,301), 9:(-6,0), 10:(1,7), 11:(25,51), 12:(75,126) }
    gene_info = { 1:'Velocity Sense Forward', 2:'Velocity Sense Reverse', 3:'Distance Sense Forward[0]', 4:'Distance Sense Forward[1]', 5:'Distance Sense Reverse[0]', 6:'Distance Sense Reverse[1]', 7:'Distance Range[0]', 8:'Distance Range[1]', 9:'Direction Change Rate[0]', 10:'Direction Change Rate[1]', 11:'Direction Change[0]', 12:'Direction Change[1]' }

    def __init__(self, x, y, cell_image='paramecium.png', frames=2, identity=None, inherit=None, mutation_rate=0.5):
        Cell.__init__(self, x, y, cell_image, frames, identity, inherit, mutation_rate)
        self.velocity = self.trait['vel_sense_f']
        self.prey_success = self.image.get_size()[0]//(self.velocity*2)  #prey capture success
        self.ingest = 4

    def set_trait(self, gene):
        #gene = 1:vel_sense_f, 2:vel_sense_r, 3:dist_sense_f-0, 4:dist_sense_f-1, 5:dist_sense_r-0, 6:dist_sense_r-1, 7:dist-0, 8:dist-1, 9:dist_i-0, 10:dist_i-1, 11:dir_f-0, 12:dir_f-1
        trait = { 'vel_sense_f': gene[1], \
                  'vel_sense_r': gene[2],  \
                  'dist_sense_f': lambda: ( 1 * random.choice((gene[3],gene[4])) ), \
                  'dist_sense_r': lambda: ( 3 * random.choice((gene[5],gene[6])) ), \
                  'dist': lambda: random.randrange(gene[7],gene[8]), \
                  'dir_i': lambda: random.randrange(gene[9],gene[10]), \
                  'dir_f': lambda: random.randrange(gene[11],gene[12]) }
        return trait

    def evolve(self):
        self.evolution()    #evolve

    def sense (self):
        sense = 0
        leading_edge_x, leading_edge_y = self.locate_coordinate(25,self.direction,False)  #watch IndexError?
        try:
            if matrix.toxin_presense:
                if matrix.toxin[leading_edge_x,leading_edge_y] > matrix.toxin[self.x,self.y]:
                    sense = 3
                    return sense
            if (matrix.nutrient[leading_edge_x,leading_edge_y] > matrix.nutrient[self.x,self.y]) or (matrix.trace[leading_edge_x,leading_edge_y] > matrix.trace[self.x,self.y]):
                sense = 1
            else:
                reverse_direction = self.direction_set( self.direction + 180 )
                back_edge_x, back_edge_y = self.locate_coordinate(25,reverse_direction,False)
                if (matrix.nutrient[back_edge_x,back_edge_y] > matrix.nutrient[self.x,self.y]) or (matrix.trace[back_edge_x,back_edge_y] > matrix.trace[self.x,self.y]):
                        sense = 2
        except:
            pass    #skip sense if pass edge (sense=0)
        return sense

    def check_interact_members(self):      #interact with other paramecium
        paramecium_bump = pygame.sprite.spritecollide(self, matrix.cells['paramecium'], False)  #paramecium avoidance
        if len(paramecium_bump) > 1:    #bumping more than self
            for bump in paramecium_bump:    #if not reverse?
                if bump == self:
                    continue
                elif (abs(bump.rect.centerx-self.rect.centerx) < 25 and abs(bump.rect.centery-self.rect.centery) < 25):
                    if not self.interact or (random.random() > 0.99):
                        self.step = 0   #?
                        self.interact = random.randrange(-3,4)
        else:
            self.interact = 0   #not bumping
        if self.interact:
            self.direction = self.direction_set( self.direction + self.interact )
            self.rotate_image = True

    def check_interact(self):
        self.check_interact_members()
        if self.check_edge(self.image.get_width()//2,self.image.get_height() // 2) or self.check_bump_map((self.x,self.y)):
            self.motion_reverse()

    def check_bump_map(self, position):
        if matrix.nutrient[position] > 10000 and random.random() > 0.9:   #check if contacting nutrient peak
            nutrient_bump = True    #increase bump chance?
        else:
            nutrient_bump = False
        return nutrient_bump

    def motion_reverse(self):
        if self.reverse != True:    #reverse again
            self.distance = random.randrange(40,60)
        else:
            self.distance = random.randrange(0,60)
        self.velocity *= -1
        self.direction_adj_f = 0
        self.reverse = True

    def motion(self):
        if not self.reverse:
            if self.sense() == 1:
                self.distance += self.trait['dist_sense_f']()   #evolve = 1 * random.choice((0,1))
                self.velocity = self.trait['vel_sense_f']         #evolve = 3
                if not self.reverse and not self.reverse_redux:
                    self.direction_adj_f = 0
            elif self.sense() == 2:
                self.distance -= self.trait['dist_sense_r']()  #evolve = 3 * random.choice((0,1))
                self.velocity = self.trait['vel_sense_r']       #evolve = 2
            elif self.sense() == 3:     #toxin
                self.velocity = self.trait['vel_sense_f']   #evolve = 3
                self.direction_adj_f = random.randrange(135,180)
        if self.distance <= 0:
            if self.reverse:
                self.velocity = 2
                self.direction_adj_i = random.choice((-3,3))
                self.direction_adj_f = random.randrange(90,135)     #different for bumping nutrient?
                self.distance = random.randrange(50,75)
                self.reverse = False
                self.reverse_redux = True
            else:
                self.distance = self.trait['dist']()  #evolve = random.randrange(50,100)
                self.direction_adj_i = self.trait['dir_i']() #evolve = random.randrange(-2,3)
                self.direction_adj_f = self.trait['dir_f']() #evolve = random.randrange((45,90))
                self.velocity = random.choice((2,2))
        if self.direction_adj_f > 0:
            self.rotate_image = True
            self.direction = self.direction_set( self.direction + self.direction_adj_i )
            self.direction_adj_f -= self.direction_adj_i
        self.distance -= 1

    def growth(self):
        prey_collide = []
        prey_collide.extend( pygame.sprite.spritecollide(self, matrix.cells['bacterium'], False) )
        prey_collide.extend( pygame.sprite.spritecollide(self, matrix.cells['algae'], False) )
        for prey in prey_collide:
            if abs(prey.rect.centerx - self.rect.centerx) < self.prey_success and abs(prey.rect.centery - self.rect.centery) < self.prey_success:
                self.ingest += 1    #evolve
                prey.life = False

    def activity(self):
        self.move()
        self.growth()


class Amoeba(Cell):
    """
    Amoeba species.
    """

    image = None
    count = 0
    minimum = (MATRIX_X*MATRIX_Y)//750000
    maximum = (MATRIX_X*MATRIX_Y)//90000
    id = 0
    evolving = False
    gene = { 1:0, 2:2, 3:0, 4:2, 5:100, 6:200, 7:-1, 8:2 }
    alleles = { 1:(0,2), 2:(2,6), 3:(0,2), 4:(2,6), 5:(10,101), 6:(150,301), 7:(-5,0), 8:(1,6) }
    gene_info = { 1:'Distance Sense Forward[0]', 2:'Distance Sense Forward[1]', 3:'Distance Sense Reverse[0]', 4:'Distance Sense Reverse[1]', 5:'Distance Range[0]', 6:'Distance Range[1]', 7:'Direction Change[0]', 8:'Direction Change[1]' }

    def __init__(self, x, y, cell_image=None, color=1, identity=None, inherit=None, mutation_rate=0.5):
        Cell.__init__(self, x, y, identity=identity, inherit=inherit, mutation_rate=mutation_rate)
        self.step = 0
        self.step_x = 75    # step location in animate movement
        self.step_y = 200
        if color < 1000:
            self.color = color * 1000 * 10
        elif color == 1000:
            self.color = 16600585   #16600585   #1000   #15000000   #color800*1000*10
        if self.species.image == None:
            self.species.screen_amoeba = pygame.Surface((50,50))
            self.species.image = self.species.screen_amoeba
        self.amoeba = numpy.zeros((50,50), 'i')
        for x in xrange(10,40,2):
            for y in xrange(10,40,2):
                self.amoeba[x,y] = self.color
        self.amoebas = numpy.zeros((150,300), 'i')     #amoeba move array with display overlap
        self.amoebas[self.step_x-25:self.step_x+25,self.step_y-25:self.step_y+25] = self.amoeba
        try:
            self.animate = animate.amoeba_animate   #compiled
        except NameError:
            self.animate = self.amoeba_animate
        amoebas_indices = [(x,y) for x in xrange(50) for y in xrange(50)]
        random.shuffle(amoebas_indices)
        self.amoebas_indices = {}
        for i in xrange(100):
            self.amoebas_indices[i] = amoebas_indices[i*25:(i*25)+25]
        self.amoebas_indices_keys = self.amoebas_indices.keys()
        random.shuffle(self.amoebas_indices_keys)
        self.amoebas_index = 0
        for update_count in xrange(50):
            self.move_animate()     #initial walk to form
        self.image, self.rect = self.update_image()
        self.direction = 0
        self.velocity = 2
        self.distance = 300
        self.reverse = False
        self.ingest = 1

    def set_trait(self, gene):
        #gene = 1:dist_sense_f-0, 2:dist_sense_f-1, 3:dist_sense_r-0, 4:dist_sense_r-1, 5:dist-0, 6:dist-1, 7:dir-0, 8:dir-1
        trait = { 'dist_sense_f': lambda: ( 5 * random.randrange(gene[1],gene[2]) ), \
                  'dist_sense_r': lambda: ( 5 * random.randrange(gene[3],gene[4]) ), \
                  'dist': lambda: random.randrange(gene[5],gene[6]), \
                  'dir': lambda: random.randrange(gene[7],gene[8]) }
        return trait

    def evolve(self):
        self.evolution(cycle=5000, division_threshold=5)    #evolve

    def display_tag(self, display=True):
        if display:
            if not self.id_tag:
                label_size = 10
                self.id_tag = print_message.font[label_size].render(str(self.identity), True, (255,0,0))
            imagex,imagey = self.image.get_rect().center
            self.image.blit(self.id_tag, (imagex-3,imagey-3) )

    def sense(self):    #Sensing
        sense = False
        leading_edge_x, leading_edge_y = self.locate_coordinate(25,self.direction,False)  #watch IndexError?
        if matrix.toxin_presense:
            if matrix.toxin[leading_edge_x,leading_edge_y] > matrix.toxin[self.x,self.y]:
                sense = False
                return sense
        if matrix.nutrient[leading_edge_x,leading_edge_y] > matrix.nutrient[self.x,self.y] or matrix.trace[leading_edge_x,leading_edge_y] > matrix.trace[self.x,self.y]:
            sense = True
        return sense

    def check_interact_members(self):
        if random.random() > 0.995:
            amoeba_bump = pygame.sprite.spritecollide(self, matrix.cells['amoeba'], False)
            if len(amoeba_bump) > 1:    #bumping more than self
                for bump in amoeba_bump:    #if not reverse?
                    if bump == self:
                        continue
                    elif (abs(bump.rect.centerx-self.rect.centerx) < 50 and abs(bump.rect.centery-self.rect.centery) < 50):
                        self.interact = random.randrange(150,210)
            else:
                self.interact = 0   #not bumping
            if self.interact:
                self.direction = self.direction_set( self.direction + self.interact )
                self.interact = 0
                self.reverse = True

    def move(self):
        self.velocity = 2
        for i in xrange(self.velocity):
            self.motion()
        self.check_interact_members()
        if matrix.creature_inview(self):
            for i in xrange(self.velocity):
                self.move_animate()
            self.image, self.rect = self.update_image()
        else:
            self.rect.center = ((self.x,self.y))

    def motion(self):
        self.step += 1
        if self.step > 12:
            step_x_pos, step_y_pos = self.locate_coordinate(10, self.direction, change=False)
            if ( matrix.nutrient[step_x_pos, step_y_pos] < 500 or matrix.nutrient[self.x,self.y] >= 500 ) and not self.check_edge(35,35):    #turn at nutrient    #if false, pos_x/pos_y updated?
                self.x, self.y = self.locate_coordinate(1, self.direction)
                self.step = 0
                if matrix.creature_inview(self):
                    self.step_y -= 1    #only update animate move if onscreen
            else:
                self.direction = self.direction_set( self.direction + random.randrange(90,270) )   #need a slower turn
                self.reverse = True
        if self.sense():        #Sensing
            self.distance += self.trait['dist_sense_f']()   #evolve = 5 * random.randrange(0,2)
        else:
            self.distance -= self.trait['dist_sense_r']()   #evolve = 5 * random.randrange(0,2)
        self.distance -= 1
        if self.distance <= 0:
            dir_change = self.trait['dir']()    #evolve = random.randrange(-1,2)
            self.direction = self.direction_set(self.direction + dir_change)
            self.distance = self.trait['dist']()    #evolve = random.randrange(100, 200)

    def move_animate(self):
        if self.reverse == True:
            self.amoeba = self.amoebas[self.step_x-25:self.step_x+25,self.step_y-25:self.step_y+25]
            self.amoebas = numpy.zeros((150,300), 'i')
            self.step_y = 200   #place amoeba at beginning of treadmill
            self.amoeba = numpy.fliplr(self.amoeba)
            self.amoebas[self.step_x-25:self.step_x+25,self.step_y-25:self.step_y+25] = self.amoeba
            self.reverse = False
        if self.step_y < 50:    #when amoeba at end of treadmill
            self.amoeba = self.amoebas[self.step_x-25:self.step_x+25,self.step_y-25:self.step_y+25]
            self.amoebas = numpy.zeros((150,300), 'i')
            self.step_y = 200   #place amoeba at beginning of treadmill
            self.amoebas[self.step_x-25:self.step_x+25,self.step_y-25:self.step_y+25] = self.amoeba
        self.amoebas = self.animate(self.amoebas, self.amoebas_indices[self.amoebas_indices_keys[self.amoebas_index]], self.step_x, self.step_y, self.color)
        self.amoebas_index += 1
        if self.amoebas_index > 99:
            self.amoebas_index = 0
            random.shuffle(self.amoebas_indices_keys)

    def amoeba_animate(self, amoebas, amoebas_indices, step_x, step_y, colr):
        color = colr
        erase = 0
        stepx = step_x - 25
        stepy = step_y - 25
        left = step_x - 15
        right = step_x + 15
        front = step_y - 15
        color_max = color * 30
        for change in range(25):       #generate amoeba movement
            x = amoebas_indices[change][0] + stepx
            y = amoebas_indices[change][1] + stepy
            pt = amoebas[x,y]
            if pt and pt < color_max:
                flux = 0
                for index_x in range(-2, 3):
                    xx = x + index_x
                    for index_y in range(0, abs(index_x)-3, -1):
                        yy = y + index_y
                        if pt > amoebas[xx,yy]:
                            amoebas[xx,yy] += color
                            if y < front:    #only erase trail in range
                                amoebas[xx,yy+42] = erase     #erase trail
                            if x < left:    #only erase sides in range
                                amoebas[xx+42,yy-25] = erase     #erase sides
                                amoebas[xx+42,yy+25] = erase
                            elif x > right:
                                amoebas[xx-42,yy-25] = erase     #erase sides
                                amoebas[xx-42,yy+25] = erase
                            flux += color
                amoebas[x,y] += flux
        return amoebas

    def update_image(self):
        #update_image
        pygame.surfarray.blit_array(self.species.screen_amoeba, self.amoebas[self.step_x-25:self.step_x+25,self.step_y-25:self.step_y+25])
        image = pygame.transform.rotozoom(self.species.screen_amoeba, -self.direction, 1)
        image = image.convert()
        image.set_colorkey((0,0,0), RLEACCEL)
        rect = image.get_rect(center=(self.x,self.y))   #define rect position when offscreen?
        return image, rect

    def growth(self):
        prey_collide = []
        prey_collide.extend( pygame.sprite.spritecollide(self, matrix.cells['bacterium'], False) )
        prey_collide.extend( pygame.sprite.spritecollide(self, matrix.cells['algae'], False) )
        for prey in prey_collide:
            if abs(prey.rect.centerx - self.rect.centerx) < 15 and abs(prey.rect.centery - self.rect.centery) < 15:
                self.ingest += 1
                prey.life = False

    def activity(self):
        self.move()
        self.growth()


class Ciliate(Paramecium):
    """
    Ciliate species.
    Evolved from Paramecium.
    """

    image = None
    count = 0
    minimum = (MATRIX_X*MATRIX_Y)//750000
    maximum = (MATRIX_X*MATRIX_Y)//45000
    id = 0
    evolving = False
    gene = {'File': 'ciliate.dat'}
    alleles = { 1:(2,6), 2:(2,6), 3:(0,2), 4:(2,6), 5:(0,2), 6:(2,6), 7:(25,51), 8:(75,301), 9:(-6,0), 10:(1,7), 11:(25,51), 12:(75,126) }
    gene_info = { 1:'Velocity Sense Forward', 2:'Velocity Sense Reverse', 3:'Distance Sense Forward[0]', 4:'Distance Sense Forward[1]', 5:'Distance Sense Reverse[0]', 6:'Distance Sense Reverse[1]', 7:'Distance Range[0]', 8:'Distance Range[1]', 9:'Direction Change Rate[0]', 10:'Direction Change Rate[1]', 11:'Direction Change[0]', 12:'Direction Change[1]' }

    def __init__(self, x, y, cell_image='ciliate.png', frames=2, identity=None, inherit=None, mutation_rate=0.5):
        Paramecium.__init__(self, x, y, cell_image, frames, identity, inherit, mutation_rate)

    def set_trait(self, gene):
        #gene = 1:vel_sense_f, 2:vel_sense_r, 3:dist_sense_f-0, 4:dist_sense_f-1, 5:dist_sense_r-0, 6:dist_sense_r-1, 7:dist-0, 8:dist-1, 9:dist_i-0, 10:dist_i-1, 11:dir_f-0, 12:dir_f-1
        trait = { 'vel_sense_f': gene[1], \
                  'vel_sense_r': gene[2],  \
                  'dist_sense_f': lambda: ( 1 * random.choice((gene[3],gene[4])) ), \
                  'dist_sense_r': lambda: ( 3 * random.choice((gene[5],gene[6])) ), \
                  'dist': lambda: random.randrange(gene[7],gene[8]), \
                  'dir_i': lambda: random.randrange(gene[9],gene[10]), \
                  'dir_f': lambda: random.randrange(gene[11],gene[12]) }
        return trait


class MatrixInterface(interphase.Interface):
    """
    Interface panel.
    """

    def __init__(self):
        self.tool_type = ['Add_Gradient', 'Add_Toxin', 'Add_Algae', 'Add_Bacterium', 'Add_Paramecium', 'Add_Ciliate', 'Add_Amoeba']
        self.command_type = ['Magnify', 'Track', 'Tag', 'Evolution', 'Set Gene', 'Set ID', 'Save', 'Load', 'Config']
        self.tools = []
        for tool in self.tool_type:
            self.tools.append('__'+tool)
        self.tools.extend(self.command_type)
        self.tips_list = ['Add Gradient', 'Add Toxin', 'Add Algae', 'Add Bacterium', 'Add Paramecium', 'Add Ciliate', 'Add Amoeba', 'Use Magnifier', 'Track Microbe', 'Tag Microbe', 'Evolution Mode', 'Set Gene', 'Set ID', 'Save Microbe', 'Load Microbe', 'Configuration']
        interphase.Interface.__init__(self, position=(250,450), image='panel.png', color=(0,5,10), size=(350,100), moveable=True, position_offset=(0,87), control_image='none', button_image=['button.png'], control_minsize=(35,35), control_size='auto', control_response=100)
        self.input_mode = None
        self.bug_tag = None
        self.gene_select = None
        self.tag_id = ''
        self.info = True
        self.info_update = False
        self.initialize = False

    def add_controls(self):
        self.add(
            identity = 'Control',
            control_type = 'function_select',
            position = (50,50),
            size = 'auto',
            control_list = self.tools,
            icon_list = ['icons.png'],
            tip_list = self.tips_list,
            control_outline = True,
            activated_toggle = False,
            link_activated = False,
            hold_response = 0,
            loop = True,
            label_display = False)
        self.add(
            identity = '__Fix',
            control_type = 'control_toggle',
            position = (315,90),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['!'],
            activated_toggle = False)
        self.add(
            identity = '__Help',
            control_type = 'control_toggle',
            position = (335,90),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['?'])
        self.add(
            identity = '__Label',
            control_type = 'label',
            position = (175,85),
            font_color = (0,120,160),
            control_list = [''])
        self.add(
            identity = '__EvolutionLabel',
            control_type = 'label',
            position = (200,95),
            font_color = (0,120,160),
            control_list = ['Evolution Mode'])
        self.add(
            identity = 'Evolution Mode',
            control_type = 'function_toggle',
            position = (175,30),
            size = 'auto_width',
            control_list = ['Deactivated', 'Activated'],
            tip_list = ['Evolution Deactivated', 'Evolution Activated'],
            link = [ [], ['Evolve'] ])
        self.add(
            identity = 'Evolve',
            control_type = 'control_toggle',
            position = (175,55),
            size = 'auto_width',
            control_list = ['Select'],
            tip_list = ['Species Evolve'],
            activated_toggle = False)
        self.add(
            identity = 'Select Gene',
            control_type = 'control_select',
            position = (230,60),
            size = (25,25),
            reverse = True)
        self.add(
            identity = 'Select Allele',
            control_type = 'control_select',
            position = (230,60),
            size = (25,25),
            control_list = ['__numeric', (1,100)],
            active = False)
        self.add(
            identity = 'Set ID',
            control_type = 'control_select',
            position = (230,60),
            size = (25,25),
            control_list = ['__alphanumeric', 'mixed'],
            tip_list = ['Identity'])
        self.add(
            identity = 'Files',
            control_type = 'control_select',
            position = (165,50),
            size = 'auto_width',
            control_list = ['__filelist', 'data', 'species', '.dat'],
            tip_list = ['Files'])
        self.add(
            identity = 'Query',
            control_type = 'control_select',
            position = (275,60),
            size = (25,25),
            control_list = ['No', 'Yes'],
            tip_list = ['Query'],
            reverse = True,
            active = False)
        self.add(
            identity = 'Info',
            control_type = 'control_toggle',
            position = (135,50),
            control_list = ['ON', 'OFF'],
            tip_list = ['Info Display'])
        self.add(
            identity = 'Tag',
            control_type = 'control_toggle',
            position = (200,50),
            control_list = ['ON', 'OFF'],
            tip_list = ['Tag Display'])
        self.add(
            identity = 'Compass',
            control_type = 'control_toggle',
            position = (265,50),
            control_list = ['ON', 'OFF'],
            tip_list = ['Compass Display'])
        self.add(
            identity = 'ID',
            control_type = 'label',
            position = (35,8),
            control_list = [''],
            active = False)
        self.add(
            identity = 'Genes',
            control_type = 'label',
            position = (184,8),
            control_list = [''],
            active = False)
        self.add(
            identity = 'Fitness',
            control_type = 'label',
            position = (322,8),
            control_list = [''],
            active = False)
        self.add(
            identity = 'Evolving',
            control_type = 'label',
            position = (342,8),
            control_list = ['*'],
            active = False)
        ctrl = self.get_control('Control')
        ctrl.set_link('Evolution', ['Evolution Mode', '__EvolutionLabel'])
        ctrl.set_link('Set Gene', ['Select Gene'])
        ctrl.set_link('Set ID', ['Set ID'])
        ctrl.set_link('Load', ['Files'])
        ctrl.set_link('Save', ['Set ID'])
        ctrl.set_link('Config', ['Info', 'Tag', 'Compass'])

    def set_panel_value(self, control):
        if control in ('Compass', 'Tag', 'Evolution Mode'):
            self.get_control(control).next()

    def display_info(self):
        if (matrix.bug_tag or matrix.evolution) and self.info:
            try:
                if matrix.bug_tag:
                    if self.info_update:
                        self.get_control('ID').set_value('ID:'+str(matrix.bug_tag.identity))
                        if matrix.bug_tag.gene:
                            genes = '/'.join([str(x) for x in matrix.bug_tag.gene.values()])
                            self.get_control('Genes').set_value('Genes:'+genes)
                        self.info_update = False
                if matrix.evolution:
                    if matrix.bug_tag and matrix.bug_tag.species.evolving:
                        fitness = '%0.1f' %matrix.bug_tag.fitness
                        self.get_control('Fitness').set_value(fitness)
            except AttributeError:
                pass

    def info_active(self, setting):
        if not self.info:
            return False
        if setting == True:
            if matrix.bug_tag:
                ctrl = self.get_control('ID','Genes')
                for ctr in ctrl:
                    ctrl[ctr].set_active(True)
            if matrix.evolution:
                self.get_control('Evolving').set_active(True)
                if matrix.bug_tag:
                    self.get_control('Fitness').set_active(True)
            self.info_update = True
        elif setting == False:
            if not matrix.bug_tag:
                ctrl = self.get_control('ID','Genes','Fitness')
                for ctr in ctrl:
                    ctrl[ctr].set_value('')
                    ctrl[ctr].set_active(False)
            if not matrix.evolution:
                self.get_control('Evolving').set_active(False)
                if matrix.bug_tag:
                    self.get_control('Fitness').set_active(False)
        return True

    def set_gene(self, state):
        if matrix.bug_tag and matrix.bug_tag.gene:
            if not self.initialize:
                state.controls['Select Gene'].set_list(matrix.bug_tag.gene.keys())
                state.controls['Select Gene'].set_tip(matrix.bug_tag.gene_info.values())
                state.controls['Select Gene'].set_active(True)
                state.controls['Select Allele'].set_active(False)
                state.controls['__Label'].set_value('Select gene')
                control.tool = 'Track'
                self.gene_select = None
                self.initialize = True
            if not self.gene_select:
                if state.button == 'Select Gene':
                    self.gene_select = int(state.values['Select Gene'])
                    self.allele_select = matrix.bug_set_gene(matrix.bug_tag, self.gene_select, allele=True)
            else:
                if state.controls['__Label'].get_value() == 'Select gene':
                    state.controls['Select Gene'].set_active(False)
                    state.controls['Select Allele'].set_active(True)
                    state.controls['Select Allele'].set_list(['__numeric', (self.allele_select[0], self.allele_select[1]-1)])
                    state.controls['Select Allele'].set_value(matrix.bug_tag.gene[int(state.values['Select Gene'])])
                    state.controls['Select Allele'].set_tip([matrix.bug_tag.gene_info[int(state.values['Select Gene'])]])
                    state.controls['__Label'].set_value('Gene '+str(self.gene_select))
                if state.button == 'Select Allele':
                    matrix.bug_set_gene(matrix.bug_tag, self.gene_select, state.value)
                    state.controls['Select Allele'].set_active(False)
                    state.controls['Select Gene'].set_active(True)
                    state.controls['__Label'].set_value('Select gene')
                    self.gene_select = None
            self.info_update = True
        else:
            if state.controls['__Label'].get_value() != 'Select Microbe':
                state.controls['Select Gene'].set_active(True)
                state.controls['Select Allele'].set_active(False)
                control.tool = 'Track'
                state.controls['__Label'].set_value('Select Microbe')
                state.controls['Select Gene'].remove_list()
                self.initialize = False

    def set_id(self, state):
        if matrix.bug_tag:
            if not self.bug_tag or self.bug_tag is not matrix.bug_tag:
                self.bug_tag = matrix.bug_tag
                pad = ' ' * (3-len(self.tag_id))
                state.controls['__Label'].set_value('ID: ' + pad)
                control.tool = 'Track'
                self.tag_id = ''
            if state.button == 'Set ID':
                self.tag_id = self.tag_id + state.value
                pad = ' ' * (3-len(self.tag_id))
                state.controls['__Label'].set_value('ID: ' + pad + self.tag_id)
            if len(self.tag_id) == 3:
                matrix.bug_set_id(self.bug_tag, self.tag_id)
                self.tag_id = ''
            self.info_update = True
        else:
            control.tool = 'Track'
            state.controls['__Label'].set_value('Select Microbe')

    def file_check(self, filename, path='data'):
        if path:
            filename = os.path.join(path, filename)
        check = os.path.exists(filename)
        return check

    def file_save(self, state, file_root='species', file_ext='.dat', file_num=None):
        if matrix.bug_tag:
            if not self.initialize:
                self.filename = file_root + '_' + self.tag_id + file_ext
                state.controls['__Label'].set_value('Save to ' + self.filename)
                control.tool = 'Track'
                self.initialize = True
            if state.control == 'Set ID' and len(self.tag_id) == 3 and not state.controls['Query'].is_active():
                self.tag_id = ''
                self.filename = file_root + '_' + self.tag_id + file_ext
                state.controls['__Label'].set_value('Save to ' + self.filename)
            if state.button == 'Set ID' and len(self.tag_id) < 3:
                self.tag_id = self.tag_id + state.value
                self.filename = file_root + '_' + self.tag_id + file_ext
                state.controls['__Label'].set_value('Save to ' + self.filename)
                if len(self.tag_id) == 3:
                    self.filename = file_root + '_' + self.tag_id + file_ext
                    if not self.file_check(self.filename):
                        matrix.bug_save(matrix.bug_tag, self.filename)
                        state.controls['__Label'].set_value('Saved ' + self.filename)
                    else:
                        state.controls['__Label'].set_value('Overwrite ' + self.filename + '?')
                        state.controls['Query'].set_active(True)
            elif state.button == 'Query':
                state.controls['Query'].set_active(False)
                if state.value == 'Yes':
                    matrix.bug_save(matrix.bug_tag, self.filename, overwrite=True)
                    state.controls['__Label'].set_value('Saved ' + self.filename)
                elif state.value == 'No':
                    self.tag_id = ''
                    self.filename = file_root + '_' + self.tag_id + file_ext
                    state.controls['__Label'].set_value('Save to ' + self.filename)
        else:
            if not control.tool:
                control.tool = 'Track'
                state.controls['__Label'].set_value('Select Microbe')

    def file_load(self, state):
        if not self.initialize:
            state.controls['Files'].set_list(['__filelist', 'data', 'species', '.dat'])
            self.initialize = True
        if state.button == 'Files':
            self.file_select = state.value
            state.controls['__Label'].set_value('Load ' + self.file_select)
            if self.file_check(self.file_select):
                control.newspecies = self.file_select
                control.tool = 'Load'
            else:
                state.controls['__Label'].set_value(self.file_select + ' not found')

    def quit(self, state=None, cmd=None):
        cancel = False
        if cmd:
            if cmd == 'initialize':
                ctrl = self.get_control()
                ctrl['Control'].set_activated(False)
                ctrl['Control'].set_active(False)
                ctrl['Query'].set_active(True)
                ctrl['__Label'].set_value('Quit?')
                self.set_moveable('Fixed')
                self.input_mode = 'Quit'
            elif cmd == 'cancel':
                cancel = True
        else:
            if state.button == 'Query':
                if state.value == 'Yes':
                    control.quit = True
                elif state.value == 'No':
                    cancel = True
        if cancel:
            ctrl = self.get_control()
            ctrl['Control'].set_active(True)
            ctrl['Query'].set_active(False)
            ctrl['__Label'].set_value('')
            self.set_moveable('Fixed')
            self.input_mode = None

    def input_commands(self, state):
        if self.input_mode == 'Set Gene':
            self.set_gene(state)
        elif self.input_mode == 'Set ID':
            self.set_id(state)
        elif self.input_mode == 'Save':
            self.file_save(state)
        elif self.input_mode == 'Load':
            self.file_load(state)
        elif self.input_mode == 'Quit':
            self.quit(state)

    def update(self):
        interphase.Interface.update(self)
        state = self.get_state()
        control.panel_displayed = state.panel_interact
        if state.control:
            if state.control == 'Control':   
                if state.controls[state.control].is_activated():
                        if state.value[:2] == '__':
                            control.tool = state.value[2:]
                        elif state.value in ('Magnify', 'Track', 'Tag'):
                            control.tool = state.value
                            if state.value in ('Track', 'Tag'):
                                state.controls['__Label'].set_value(state.value+' selection')
                        elif state.value in ('Set Gene', 'Set ID', 'Save', 'Load'):
                            self.input_mode = state.value
                        elif state.value == 'Config':
                            self.set_label_display(True)
                else:
                    control.tool = None
                    self.input_mode = None
                    state.controls['__Label'].set_value('')
                    self.gene_select = None
                    self.tag_id = ''
                    self.bug_tag = None
                    state.controls['Select Gene'].remove_list()
                    state.controls['Select Allele'].set_active(False)
                    self.set_label_display(False)
                    self.initialize = False
            elif state.control == 'Evolution Mode':
                if state.value == 'Activated':
                    matrix.set_evolution(True)
                    self.info_active(True)
                elif state.value == 'Deactivated':
                    matrix.set_evolution(False)
                    self.info_active(False)
                    control.tool = None
            elif state.control == 'Evolve':
                if state.controls[state.control].is_activated():
                    control.tool = state.control
                else:
                    control.tool = None
            elif state.control == 'Info':
                if state.value == 'ON':
                    self.info = True
                    self.info_active(True)
                elif state.value == 'OFF':
                    self.info = False
                    ctrl = self.get_control('ID','Genes','Fitness','Evolving')
                    for ctr in ctrl:
                        ctrl[ctr].set_active(False)
            elif state.control == 'Tag':
                if state.value == 'ON':
                    matrix.set_tag_display(True)
                elif state.value == 'OFF':
                    matrix.set_tag_display(False)
            elif state.control == 'Compass':
                folding = False
                if state.value == 'ON':
                    if not control.compass_folding:
                        if not control.compass_use:
                            control.compass_use = True
                            control.compass_folding = True
                            control.scroll_edge = False
                            matrix.set_screen_update()
                    else:
                        folding = True
                elif state.value == 'OFF':
                    if not control.compass_folding:
                        if control.compass_use:
                            control.compass_use = False
                            control.compass_folding = True
                            control.scroll_edge = True
                            matrix.set_screen_update()
                    else:
                        folding = True
                if folding:
                    state.controls['Compass'].previous()
            elif state.control == '__Fix':
                self.set_moveable()
                self.set_panel_display()
            elif state.control == '__Help':
                self.set_tips_display()
        self.display_info()
        if self.input_mode:
            self.input_commands(state)


class Control(object):
    """
    User control.
    """

    def __init__(self):
        pygame.key.set_repeat(100,10)
        self.tool = None
        self.direction = {K_UP:'north', K_DOWN:'south', K_LEFT:'west', K_RIGHT:'east'}
        self.mouse_x = 0
        self.mouse_y = 0
        self.quit = False
        self.scroll = False
        self.scroll_x = False
        self.scroll_y = False
        self.scroll_timer = 0
        self.scroll_edge = False
        self.compass_display = False
        self.compass_use = True
        x, y = DISPLAY_X-40, DISPLAY_Y-40
        self.compass_rose = pygame.Rect(x-35,y-35,72,72)
        self.compass_rose_bud = pygame.Rect(0,0,10,10)
        self.compass_rose_bud.center = (x,y)
        self.trace1 = [(x-35,y),(x-10,y-10),(x,y-35),(x+10,y-10),(x+35,y),(x+10,y+10),(x,y+35),(x-10,y+10)]
        self.trace2 = [(x-20,y-20),(x,y-10),(x+20,y-20),(x+10,y),(x+20,y+20),(x,y+10),(x-20,y+20),(x-10,y)]
        n = pygame.Rect((0,0),(20,30))
        s = pygame.Rect((0,0),(20,30))
        w = pygame.Rect((0,0),(30,20))
        e = pygame.Rect((0,0),(30,20))
        nw = pygame.Rect((0,0),(20,20))
        ne = pygame.Rect((0,0),(20,20))
        sw = pygame.Rect((0,0),(20,20))
        se = pygame.Rect((0,0),(20,20))
        offset=10
        n.center=(x,y-35+offset)
        s.center=(x,y+35-offset)
        w.center=(x-35+offset,y)
        e.center=(x+35-offset,y)
        nw.center=(x-20+offset,y-20+offset)
        ne.center=(x+20-offset,y-20+offset)
        sw.center=(x-20+offset,y+20-offset)
        se.center=(x+20-offset,y+20-offset)
        self.dir = {'n':n, 's':s, 'w':w, 'e':e, 'nw':nw, 'ne':ne, 'sw':sw, 'se':se}
        self.clock = pygame.time.Clock()
        self.pause = False
        self.compass_folding = False
        self.fold_step = 0
        self.compass_surface = pygame.Surface((50,50))
        self.compass_surface.fill((0,0,0))
        self.panel, self.panel_group = self.define_controls()
        self.panel_displayed = False     #when displayed, ignore click in panel area
        self.newspecies = None  #filename of saved species
        self.tool_activated = False
        self.tool_timer = 0
        self.tool_timer_i = 0

    def define_controls(self):
        panel = MatrixInterface()
        panel_group = pygame.sprite.RenderUpdates(panel)
        return panel, panel_group

    def use_tool(self):
        self.tool_timer += (pygame.time.get_ticks()-self.tool_timer_i)
        if self.tool_timer < 250:
            return
        else:
            self.tool_timer = 0
            self.tool_timer_i = pygame.time.get_ticks()
        self.mouse_x, self.mouse_y = pygame.mouse.get_pos()
        if self.tool == 'Add_Gradient':
            matrix.set_gradient(self.mouse_x, self.mouse_y, gradient_type='Nutrient')
        elif self.tool == 'Add_Toxin':
            matrix.set_gradient(self.mouse_x, self.mouse_y, gradient_type='Toxin')
        elif self.tool == 'Add_Algae':
            matrix.add_creature(Algae, self.mouse_x, self.mouse_y)
        elif self.tool == 'Add_Bacterium':
            matrix.add_creature(Bacterium, self.mouse_x, self.mouse_y)
        elif self.tool == 'Add_Paramecium':
            matrix.add_creature(Paramecium, self.mouse_x, self.mouse_y)
        elif self.tool == 'Add_Amoeba':
            matrix.add_creature(Amoeba, self.mouse_x, self.mouse_y)
        elif self.tool == 'Add_Ciliate':
            matrix.add_creature(Ciliate, self.mouse_x, self.mouse_y)
        elif self.tool == 'Track':
            bug_tag = matrix.bug_track_set(self.mouse_x, self.mouse_y, follow=True)
            self.panel.info_active(True)
            self.panel.initialize = False
            self.tool_activated = False
        elif self.tool == 'Tag':
            bug_tag = matrix.bug_track_set(self.mouse_x, self.mouse_y, follow=False)
            self.panel.info_active(True)
            self.panel.initialize = False
            self.tool_activated = False
        elif self.tool == 'Evolve':
            matrix.species_evolve_set(self.mouse_x, self.mouse_y)
            self.tool_activated = False
        elif self.tool == 'Magnify':
            matrix.zoom_activate(True)
            self.tool_activated = False
        elif self.tool == 'Load':
            if self.newspecies:
                matrix.bug_load(self.newspecies)   #set bug_load tool

    def check_events(self):
        "Monitor keyboard input"
        global matrix
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONDOWN and not self.panel_displayed:
                mousex, mousey = event.pos
                if event.button == 1 and not matrix.zoom_set:
                    if not pygame.key.get_mods() & KMOD_SHIFT:
                        if self.compass_display:
                            if self.compass_rose_bud.collidepoint(mousex,mousey):
                                self.panel.set_moveable('Fixed')
                        else:
                            self.tool_activated = True
                            self.tool_timer = 250
                    else:   #select evolving species
                        matrix.species_evolve_set(mousex, mousey)
                elif event.button == 2:
                    if not matrix.zoom_set:
                        if not matrix.bug_follow and not matrix.scroll_field['x'] and not matrix.scroll_field['y']:
                            matrix.zoom_activate(True)
                    else:
                        matrix.zoom_activate(False)
                elif event.button == 3:
                    if not matrix.zoom_set:
                        self.mouse_x, self.mouse_y = pygame.mouse.get_pos()
                        mod = pygame.key.get_mods()
                        if not mod:
                            bug_tag = matrix.bug_track_set(self.mouse_x, self.mouse_y, follow=True)
                            self.panel.info_active(True)
                            self.panel.initialize = False
                        elif (mod & KMOD_CTRL) and (mod & KMOD_SHIFT):
                            bug_tag = False
                            matrix.bug_remove(self.mouse_x, self.mouse_y)
                        elif mod & KMOD_SHIFT:
                            bug_tag = matrix.bug_track_set(self.mouse_x, self.mouse_y, follow=False)
                            self.panel.info_active(True)
                            self.panel.initialize = False
                        self.panel.bug_tag = None
                elif event.button == 4:
                    if matrix.zoom_set:
                        matrix.zoom_activate(power=1, zoom_reset=False)
                    else:
                        matrix.zoom_activate(True)
                elif event.button == 5:
                    if matrix.zoom_set:
                        matrix.zoom_activate(power=-1)
                    else:
                        matrix.zoom_activate(True)
            elif event.type == MOUSEBUTTONUP:
                if event.button == 1:
                    self.tool_activated = False
            elif event.type == MOUSEMOTION:
                if not matrix.bug_follow and not self.scroll:
                    mousex, mousey = event.pos
                    if self.compass_use and not matrix.zoom_set:
                        if self.compass_rose.collidepoint(mousex,mousey):
                            self.compass_display = True
                        else:
                            self.compass_display = False
                    if self.compass_display and not self.scroll_edge and not matrix.zoom_set:
                        if self.dir['n'].collidepoint(mousex,mousey) or self.dir['nw'].collidepoint(mousex,mousey) or self.dir['ne'].collidepoint(mousex,mousey):
                            matrix.set_scroll('north', 5)
                            self.scroll_y = True
                        elif self.dir['s'].collidepoint(mousex,mousey) or self.dir['sw'].collidepoint(mousex,mousey) or self.dir['se'].collidepoint(mousex,mousey):
                            matrix.set_scroll('south', 5)
                            self.scroll_y = True
                        else:
                            matrix.set_scroll('y', 0)
                            self.scroll_y = False
                        if self.dir['w'].collidepoint(mousex,mousey) or self.dir['nw'].collidepoint(mousex,mousey) or self.dir['sw'].collidepoint(mousex,mousey):
                            matrix.set_scroll('west', 5)
                            self.scroll_x = True
                        elif self.dir['e'].collidepoint(mousex,mousey) or self.dir['ne'].collidepoint(mousex,mousey) or self.dir['se'].collidepoint(mousex,mousey):
                            matrix.set_scroll('east', 5)
                            self.scroll_x = True
                        else:
                            matrix.set_scroll('x', 0)
                            self.scroll_x = False
                        if self.compass_rose_bud.collidepoint(mousex,mousey):
                            matrix.set_scroll('y', 0)
                            matrix.set_scroll('x', 0)
                            self.scroll_y = False
                            self.scroll_x = False
                    else:
                        matrix.set_scroll('y', 0)
                        matrix.set_scroll('x', 0)
                        self.scroll_y = False
                        self.scroll_x = False
                    if self.scroll_edge and not matrix.zoom_set:
                        if mousey < 20:
                            matrix.set_scroll('north', 5)
                            self.scroll_y = True
                        elif mousey > DISPLAY_Y - 20:
                            matrix.set_scroll('south', 5)
                            self.scroll_y = True
                        else:
                            matrix.set_scroll('y', 0)
                            self.scroll_y = False
                        if mousex < 20:
                            matrix.set_scroll('west', 5)
                            self.scroll_x = True
                        elif mousex > DISPLAY_X - 20:
                            matrix.set_scroll('east', 5)
                            self.scroll_x = True
                        else:
                            matrix.set_scroll('x', 0)
                            self.scroll_x = False
                        if self.scroll_x or self.scroll_y:
                            pygame.time.set_timer(pygame.USEREVENT,10)
                        else:
                            pygame.time.set_timer(pygame.USEREVENT,0)
            elif event.type == KEYDOWN:
                if event.key == K_g:
                    self.tool = 'Add_Gradient'
                elif event.key == K_t:
                    self.tool = 'Add_Toxin'
                elif event.key == K_b:
                    if pygame.key.get_mods() & KMOD_SHIFT:
                        matrix.add_creature(Bacterium)
                    else:
                        self.tool = 'Add_Bacterium'
                elif event.key == K_v:
                    if pygame.key.get_mods() & KMOD_SHIFT:
                        matrix.add_creature(Algae)
                    else:
                        self.tool = 'Add_Algae'
                elif event.key == K_p:
                    if pygame.key.get_mods() & KMOD_SHIFT:
                        matrix.add_creature(Paramecium)
                    else:
                        self.tool = 'Add_Paramecium'
                elif event.key == K_a:
                    if pygame.key.get_mods() & KMOD_SHIFT:
                        matrix.add_creature(Amoeba)
                    else:
                        self.tool = 'Add_Amoeba'
                elif event.key == K_o:
                    if pygame.key.get_mods() & KMOD_SHIFT:
                        matrix.add_creature(Ciliate)
                    else:
                        self.tool = 'Add_Ciliate'
                elif event.key == K_e:  #toggle evolution mode
                    matrix.set_evolution()
                    self.panel.set_panel_value('Evolution Mode')
                    if matrix.evolution:
                        self.panel.info_active(True)
                    else:
                        self.panel.info_active(False)
                elif event.key == K_d:  #toggle tag display
                    matrix.set_tag_display()
                    self.panel.set_panel_value('Tag')
                elif event.key == K_i:  #interface panel toggle
                    self.panel.set_moveable('Fixed')
                elif event.key == K_c:     #Use compass
                    if not self.compass_folding:
                        self.compass_use = not self.compass_use
                        self.compass_folding = True
                        self.panel.set_panel_value('Compass')
                    if self.compass_use:
                        self.scroll_edge = False
                    else:
                        self.scroll_edge = True
                    matrix.set_screen_update()
                elif event.key in [K_UP, K_DOWN, K_LEFT, K_RIGHT]:
                    if not self.scroll_x and not self.scroll_y:
                        if not self.scroll:
                            if matrix.zoom_set:
                                matrix.zoom_activate(False)
                            if matrix.bug_follow:
                                matrix.bug_track_remove()
                            self.scroll = True
                        direction = self.direction[event.key]
                        matrix.set_scroll(direction, 5)
                elif event.key == K_x:
                    matrix.bug_track_remove()
                elif event.key == K_z:
                    if not (pygame.key.get_mods() & KMOD_SHIFT):
                        matrix.zoom_activate(True)
                    else:
                        matrix.zoom_activate(False)
                elif event.key == K_q:
                    if pygame.key.get_mods() & KMOD_CTRL:
                        self.panel.quit(cmd='initialize')
                elif event.key in (K_y, K_n):
                    if self.panel.input_mode == 'Quit':
                        if event.key == K_y:
                            self.quit = True
                        elif event.key == K_n:
                            self.panel.quit(cmd='cancel')
                elif event.key == K_TAB:
                    self.pause = True
                elif event.key == K_ESCAPE:
                    matrix.bug_track_remove()
                    matrix.zoom_activate(False)
            elif event.type == KEYUP:
                if event.key in [K_UP, K_DOWN, K_LEFT, K_RIGHT]:
                    direction = self.direction[event.key]
                    matrix.set_scroll(direction, 0)
                    self.scroll = False
            elif event.type == pygame.USEREVENT:
                if ( self.scroll_x or self.scroll_y ) and not pygame.mouse.get_focused():
                    pygame.time.set_timer(pygame.USEREVENT,0)
                    matrix.set_scroll('x', 0)
                    matrix.set_scroll('y', 0)
            elif event.type == QUIT:
                pygame.quit()
                self.quit = True

    def compass(self):
        def fold(point,step,center=self.compass_rose_bud.center):
            point = ( int(point[0]+(center[0]-point[0])*step),int(point[1]+(center[1]-point[1])*step) )
            return point
        if self.compass_use and not self.compass_folding:
            compass1 = self.trace1
            compass2 = self.trace2
            update = False
        elif self.compass_folding:
            update = True
            if self.fold_step >= 0:
                self.fold_step += 0.1
                step = self.fold_step
                if self.fold_step >= 0.9:
                    self.fold_step = -1.0
                    self.compass_folding = False
            else:
                step = abs(self.fold_step)
                self.fold_step += 0.1
                if self.fold_step >= -0.1:
                    self.fold_step = 0
                    self.compass_folding = False
            compass1 = self.trace1[:]
            compass2 = self.trace2[:]
            for point,value in enumerate(self.trace1):
                compass1[point] = fold(value,step)
            for point,value in enumerate(self.trace2):
                compass2[point] = fold(value,step)
        else:
            return False
        if self.compass_display:
            color1 = 60,120,200
            color2 = 40,80,120
        else:
            color1 = 15,30,50
            color2 = 10,20,30
        compass_axis1 = pygame.draw.aalines(matrix.screen,color1,True,compass1,0)
        compass_axis2 = pygame.draw.aalines(matrix.screen,color2,True,compass2,0)
        matrix.update_list.append(compass_axis1)
        matrix.update_list.append(compass_axis2)
        if update:
            matrix.screen_update = True
        return True

    def pause_events(self):
        while self.pause:
            for event in pygame.event.get():
                if event.type == KEYDOWN:
                    if event.key == K_TAB or event.key == K_ESCAPE:
                        self.pause = False
                elif event.type == QUIT:
                    pygame.quit()
                    self.quit = True
                    self.pause = False

    def update(self):
        self.panel_group.update()
        panel_update = self.panel_group.draw(matrix.screen)
        matrix.update_list.extend(panel_update)
        self.compass()
        if testing:
            test()
        self.check_events()
        if self.tool_activated:
            self.use_tool()
        if self.pause:
            self.pause_events()
        self.clock.tick(40)


def load_image(file_name, frames=1, path='data', colorkey=None, errorhandle=True):
    #Modified from PygameChimpTutorial
    full_name = os.path.join(path, file_name)
    try:
        if frames == 1:
            image = pygame.image.load(full_name)
        elif frames > 1:
            images = []
            image = pygame.image.load(full_name)
            width, height = image.get_size()
            width = width // frames
            for frame in xrange(frames):
                frame_num = width * frame
                image_frame = image.subsurface((frame_num,0), (width,height)).copy()
                images.append(image_frame)
            return images
    except pygame.error, message:
        if errorhandle:
            raise SystemExit, message
        else:
            print(message)
            return None
    if image.get_alpha():
        image = image.convert_alpha()
    else:
        image = image.convert()
    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0,0))
        image.set_colorkey(colorkey, RLEACCEL)
    return image

def trig_compute():
    sin_table = {}
    cos_table = {}
    for angle in xrange(0,360):
        angle_rad = angle * math.pi/180
        sin_angle = math.sin(angle_rad)
        cos_angle = math.cos(angle_rad)
        sin_table[angle] = sin_angle
        cos_table[angle] = cos_angle
    return sin_table, cos_table
sin_table, cos_table = trig_compute()

if testing:
    fps_ave = []
    for i in xrange(1000):
        fps_ave.append(0)
def test():
    fps_ave.pop(0)
    fps_ave.append(int(control.clock.get_fps()))
    fps = sum(fps_ave)//len(fps_ave)
    print_message.add("FPS:", fps)
    if matrix.bug_tag:
        try:
            if 1: print_message.add("#:", matrix.bug_tag.species.count)
            if 1: print_message.add("ID:", matrix.bug_tag.identity)
            if 1: print_message.add(matrix.bug_tag.x, matrix.bug_tag.y)
            if 0: print_message.add("S:", matrix.bug_tag.sense())
            if 1: print_message.add("T:", matrix.bug_tag.exist)
            if 1: print_message.add("E:", '%0.1f'%matrix.bug_tag.ingest)
            if 1: print_message.add(matrix.bug_tag.gene.values())
            if 0: print_message.add(matrix.bug_tag.direction)
            if 0: print_message.add(matrix.bug_tag.sense_bacteria)
            if 0: print_message.add(matrix.bug_tag.sensing)
            if 0: print_message.add(matrix.bug_tag.growth_rate)
        except AttributeError:
            pass
    print_message()

def program_options():
    config = {'species_added':None, 'species_evolving':None, 'display_gamma':None}
    try:
        config_file = open('config.ini')
        cfg_setting = [line.strip().split(' ',1) for line in config_file if line[:1].isalpha()]
        cfg_setting = dict(cfg_setting)
        for cfg in config:
            if cfg in cfg_setting:
                config[cfg] = cfg_setting[cfg].strip()
        config_file.close()
    except (IOError, ValueError):
        pass
    program_usage = "%prog [options]"
    program_desc = ("Microbe - Microbial Simulation")
    parser = optparse.OptionParser(usage=program_usage,description=program_desc)
    parser = optparse.OptionParser(version="Microbe "+version)
    parser.set_defaults(evolve=False)
    parser.add_option("--license", dest="license", action="store_true", help="display program license")
    parser.add_option("-d", "--doc", dest="doc", action="store_true", help="display program documentation")
    parser.add_option("-s", dest="species_added", action="store", help="-s algae:bacterium:paramecium:amoeba:ciliate")
    parser.add_option("-e", dest="species_evolving", action="store", help="-e bacterium:paramecium:amoeba:ciliate")
    parser.add_option("-g", dest="display_gamma", action="store", help="-g value (value: 0.5 to 3.0)")
    (options, args) = parser.parse_args()
    if options.license:
        try:
            license_info = open('license.txt')
        except IOError:
            print("GNU General Public License version 3 or later: http://www.gnu.org/licenses/")
            sys.exit()
        for line_no, line in enumerate(license_info):
            print(line),
            if line_no and not line_no % 20:
                answer = raw_input("press enter to continue, 'q' to quit: ")
                if answer == 'q':
                    break
        license_info.close()
        sys.exit()
    if options.doc:
        try:
            documentation = open('readme.txt')
        except IOError:
            print("Documentation not found.")
            sys.exit()
        for line_no, line in enumerate(documentation):
            print(line),
            if line_no and not line_no % 20:
                answer = raw_input("press enter to continue, 'q' to quit: ")
                if answer == 'q':
                    break
        documentation.close()
        sys.exit()
    if options.species_added:
        config['species_added'] = options.species_added
    if options.species_evolving:
        config['species_evolving'] = options.species_evolving
    if options.display_gamma:
        config['display_gamma'] = options.display_gamma
    if config['species_added']:
        config['species_added'] = config['species_added'].lower().split(':')
        config['species_added'] = [sp.strip() for sp in config['species_added']]
    if config['species_evolving']:
        config['species_evolving'] = config['species_evolving'].lower().split(':')
        config['species_evolving'] = [sp.strip() for sp in config['species_evolving']]
    if config['display_gamma']:
        try:
            config['display_gamma'] = float(config['display_gamma'])
        except ValueError:
            config['display_gamma'] = None
    return config

def setup():
    global matrix, control, print_message, gamma
    species = { 'algae':True, 'bacterium':True, 'paramecium':True, 'amoeba':True, 'ciliate':True }
    species_class = { 'algae':Algae, 'bacterium':Bacterium, 'paramecium':Paramecium, 'amoeba':Amoeba, 'ciliate':Ciliate }
    config = program_options()
    if config['display_gamma']:
        gamma = config['display_gamma']
        if gamma > 0.0 and gamma < 0.5:
            gamma = 0.5
        elif gamma > 3.0:
            gamma = 3.0
    else:
        gamma = 0
    if config['species_added']:
        for sp in species:
            if sp not in config['species_added']:
                species[sp] = False
    matrix = Matrix()
    matrix.setup(algae=species['algae'],bacterium=species['bacterium'],paramecium=species['paramecium'],amoeba=species['amoeba'],ciliate=species['ciliate'])
    if config['species_evolving']:
        for sp in species_class:
            if sp in config['species_evolving'] and species_class[sp].gene:
                species_class[sp].evolving = True
                matrix.set_evolution(True)
    control = Control()
    print_message = interphase.Text(matrix.screen)

def main():
    setup()
    while not control.quit:
        if control.clock.get_fps() > 20:
            pygame.display.update(matrix.update_list)
        else:
            pygame.display.flip()
        matrix.update()
        control.update()

if profiling:
    import cProfile
    import pstats
    cProfile.run('main()')
    sys.exit()

if __name__ == '__main__':
    main()

