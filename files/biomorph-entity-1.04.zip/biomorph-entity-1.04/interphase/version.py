#Interphase - Copyright (C) 2009 James Garnon <https://gatc.ca/>
#Released under the MIT License <https://opensource.org/licenses/MIT>


ver = None


def set_ver(version):
    global ver
    ver = version

