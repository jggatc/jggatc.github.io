#Interphase - Copyright (C) 2009 James Garnon <https://gatc.ca/>
#Released under the MIT License <https://opensource.org/licenses/MIT>

engine = None

