Biomorph Entity
https://gatc.ca/projects/biomorph-entity/

Biomorph Entity is a virtual creature simulation coded in Python and Pygame. The source is run with 'python biomorph.py'. Also available are executables that have Python dependencies included, and run with './biomorph' (Linux) or 'biomorph.exe' (Windows). Biomorph Entity is released under the GPL3 License, see LICENSE.txt for further information.

Dependencies:
    Python 2.7+:   https://www.python.org/
    Pygame 1.8+:   https://www.pygame.org/

Command line options:
    -h, --help        show this help message and exit
    -d, --doc         display program documentation
    -g DISPLAY_GAMMA  -g value (value: 0.5 to 3.0)
    -s DISPLAY_SIZE   -s value (value: WIDTHxHEIGHT)
    -c BACKGROUND_COLOR  -c value (value: R,G,B)
    >options can also be set in config.ini

Keyboard shortcuts:
    i:          interface panel toggle
    TAB:        Pause toggle
    CTRL+q:     Quit

