#Biomorph Entity - Copyright (C) 2009
#Released under the GPL3 License

from __future__ import division
import pygame
import interphase


class MatrixInterface(interphase.Interface):

    def __init__(self, matrix):
        self.matrix = matrix
        interphase.Interface.__init__(self, position=(self.matrix.width/2,self.matrix.height-50), image='panel.png', color=(43,50,58), size=(350,100), moveable=True, position_offset=(0,95), button_image=['button.png'], control_image=['control.png'], font_color=(175,180,185), tips_fontcolor=(175,180,185), pointer_interact=True, control_minsize=(20,20), control_size='auto', label_display=True)

    def add_controls(self):
        self.add(
            identity = 'Control',
            control_type = 'function_select',
            position = (50,50),
            size = (40,40),
            control_list = ['__Action', '__Sim'],
            icon_list = ['icon.png', 'restart.png'],
            link = [ ['Biomorph', 'Type', 'Length', 'Width'], ['Restart', 'Exit'] ],
            link_activated = True,
            label_display = False)
        self.add(
            identity = 'Biomorph',
            control_type = 'control_toggle',
            position = (175,30),
            size = 'min_width',
            control_list = ['Biomorph'],
            tip_list = ['Biomorph Generate'],
            control_outline = True,
            activated_toggle = False,
            label_display=False)
        self.add(
            identity = 'Type',
            control_type = 'control_select',
            position = (130,70),
            size = 'min',
            control_list = ['__numeric', (1,4)],
            tip_list = ['Biomorph Type'],
            control_outline = True)
        self.add(
            identity = 'Length',
            control_type = 'control_select',
            position = (175,70),
            size = 'min',
            control_list = ['__numeric', (5,50)],
            tip_list = ['Biomorph Length'],
            control_outline = True)
        self.add(
            identity = 'Width',
            control_type = 'control_select',
            position = (220,70),
            size = 'min',
            control_list = ['__numeric', (1,5)],
            tip_list = ['Biomorph Size'],
            control_outline = True)
        self.add(
            identity = 'Restart',
            control_type = 'control_toggle',
            position = (130,50),
            size = (40,40),
            control_list = ['Restart'],
            tip_list = ['Restart Simulation'],
            label_display = False)
        self.add(
            identity = 'Exit',
            control_type = 'control_toggle',
            position = (230,50),
            size = (40,40),
            control_list = ['Exit'],
            tip_list = ['Exit Simulation'],
            label_display = False)
        self.add(
            identity = '__Fix',
            control_type = 'control_toggle',
            position = (315,90),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['!'],
            control_image = ['none'],
            control_outline = True)
        self.add(
            identity = '__Help',
            control_type = 'control_toggle',
            position = (335,90),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['?'],
            control_image = ['none'],
            control_outline = True)
        controls = self.get_control()
        controls['Type'].set_value(4)
        controls['Length'].set_value(50)
        controls['Width'].set_value(2)

    def update(self):
        interphase.Interface.update(self)
        state = self.get_state()
        self.matrix.control.panel_displayed = state.panel_interact
        if state.control:
            if state.control == 'Control':
                self.matrix.simulation_set()
            elif state.control == 'Biomorph':
                if self.get_control('Biomorph').is_activated():
                    self.matrix.simulation_set('Add Biomorph')
                else:
                    self.matrix.simulation_set()
            elif state.control == 'Type':
                self.matrix.biomorph_type = int(state.value)
            elif state.control == 'Length':
                self.matrix.segment_count = int(state.value)
            elif state.control == 'Width':
                self.matrix.biomorph_size = float(state.value)*0.5
            elif state.control == 'Restart':
                self.get_control('Biomorph').set_activated(False)
                self.matrix.setup(biomorph=False)
            elif state.control == 'Exit':
                control.quit = True
            elif state.control == '__Fix':
                self.set_moveable('Fixed')
            elif state.control == '__Help':
                self.set_tips_display()
        return state


class Control(object):

    def __init__(self, matrix):
        self.matrix = matrix
        pygame.key.set_repeat(100,10)
        self.panel, self.panel_group = self.define_controls()
        self.panel_displayed = False
        self.clock = pygame.time.Clock()
        pygame.event.set_blocked(pygame.MOUSEMOTION)
        self.quit = False

    def define_controls(self):
        panel = MatrixInterface(self.matrix)
        panel_group = pygame.sprite.RenderUpdates(panel)
        return panel, panel_group

    def check_events(self):
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN and not self.panel_displayed:
                button1, button2, button3 = pygame.mouse.get_pressed()
                if event.button == 1:
                    self.matrix.biomorph_select(event.pos)
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_i:    #interface panel toggle
                    self.panel.set_moveable('Fixed')
                elif event.key == pygame.K_TAB:    #pause toggle
                    pause = True
                    while pause:
                        for event in pygame.event.get():
                            if event.type == pygame.KEYDOWN:
                                if event.key == pygame.K_TAB or event.key == pygame.K_ESCAPE:
                                    pause = False
                            elif event.type == pygame.QUIT:
                                pause = False
                                self.quit = True
                        self.clock.tick(40)
                elif event.key == pygame.K_q:         #quit program
                    if pygame.key.get_mods() & pygame.KMOD_CTRL:
                        self.quit = True
            elif event.type == pygame.QUIT:   #quit program
                self.quit = True

    def update(self):
        self.check_events()
        self.panel_group.update()
        self.clock.tick(40)

