#PyJ2D - Copyright (C) 2011 James Garnon

ver =   '0.25'

