#Draw Pad - Copyright (C) 2021 James Garnon <https://gatc.ca/>
#Released under the GPL License https://opensource.org/licenses/GPL-3.0

#version 1.0

platform = None
# __pragma__ ('skip')
import os
if os.name in ('posix', 'nt', 'os2', 'ce', 'riscos'):
    import pygame as pg
    platform = 'pc'
elif os.name == 'java':
    import pyj2d as pg
    platform = 'jvm'
else:
    import pyjsdl as pg
    platform = 'js'
# __pragma__ ('noskip')
if platform is None:
    import pyjsdl as pg
    from pyjsdl.pylib import os
    platform = 'js'


class Canvas(object):

    def __init__(self, display):
        self.display = display
        self.width, self.height = self.display.get_size()
        self.display.fill((238,238,238))
        self.pad = pg.Surface((self.width, self.height))
        self.pad.fill((238,238,238))
        self.update_rects = []
        self.edges = self.set_edges()
        self.colors = ((243,139,160), (173,194,169),
                       (167,197,235), (238,238,238))
        self.color_index = 0
        self.color = self.colors[0]
        self.set_palette()
        self.brushes = pg.sprite.RenderUpdates()
        self.brush = Brush(self)
        self.brushes.add(self.brush)
        self.update_rects.append(self.display.get_rect())
        self.clock = pg.time.Clock()

    def check_input(self):
        quit = False
        for evt in pg.event.get():
            if evt.type == pg.MOUSEBUTTONDOWN and evt.button == 1:
                if self.palette_area.collidepoint(evt.pos):
                    self.color_index += 1
                    if self.color_index > 3:
                        self.color_index = 0
                    self.color = self.colors[self.color_index]
                    self.brush.color = self.color
                    self.set_palette()
                elif pg.key.get_mods() & pg.KMOD_SHIFT:
                    self.clear_pad()
                else:
                    self.brush.paint = True
            elif evt.type == pg.MOUSEBUTTONUP:
                self.brush.paint = False
                self.brush.pre_pos.update(-1.0, -1.0)
            elif evt.type == pg.QUIT:
                quit = True
            return quit

    def set_edges(self):
        w, h = self.width, self.height
        edges = []
        for rect in [(0,0,20,h), (w-20,0,20,h-20),
                     (0,0,w,20), (0,h-20,w,20)]:
            edge_rect = pg.Rect(rect)
            edges.append(edge_rect)
            pg.draw.rect(self.pad, (108,115,126), edge_rect, 0)
        self.display.blit(self.pad, (0,0))
        return edges

    def draw_edges(self):
        for edge_rect in self.edges:
            pg.draw.rect(self.pad, (108,115,126), edge_rect, 0)

    def draw_palette(self):
        self.pad.blit(self.palette, (1, self.height-19))
        self.display.blit(self.palette, (1, self.height-19))

    def clear_pad(self):
        self.display.fill((238,238,238))
        self.pad.fill((238,238,238))
        self.set_edges()
        self.draw_palette()
        self.update_rects.append(self.display.get_rect())

    def set_palette(self):
        self.palette = pg.Surface((18, 18))
        self.palette.fill(self.color)
        pg.draw.rect(self.palette, (0,0,0), (0,0,18,18), 1)
        self.pad.blit(self.palette, (1, self.height-19))
        self.palette_area = self.display.blit(self.palette,
                                             (1, self.height-19))
        self.update_rects.append(self.palette_area)

    def update(self):
        self.brushes.update()
        if self.brush.paint:
            self.draw_edges()
            self.draw_palette()
            for rect in self.brush.strokes:
                self.display.blit(self.pad, (rect.x,rect.y), rect)
            self.update_rects.extend(self.brush.strokes)
            self.update_rects.append(self.palette_area)
        self.brushes.clear(self.display, self.pad)
        rects = self.brushes.draw(self.display)
        self.update_rects.extend(rects)
        pg.display.update(self.update_rects)
        self.update_rects[:] = []
        self.clock.tick(60)


class Brush(pg.sprite.Sprite):

    def __init__(self, canvas):
        pg.sprite.Sprite.__init__(self)
        self.canvas = canvas
        self.width, self.height = 60, 60
        self.radius = self.width // 10
        if platform == 'pc':
            image = os.path.join('data', 'brush.png')
            self.image = pg.image.load(image)
        else:
            self.image = pg.image.load('./data/brush.png')
        self.rect = self.image.get_rect()
        self.position = pg.Vector2(0.0,0.0)
        self.pre_pos = pg.Vector2(-1.0,-1.0)
        self.positions = []
        self.strokes = []
        self.color = self.canvas.color
        self.paint = False

    def draw(self):
        self.strokes[:] = []
        self.positions[:] = []
        if (self.position != self.pre_pos and
            self.pre_pos.x != -1):
            distance = self.position.distance_to(self.pre_pos)
            if distance > (self.radius/4.0):
                pos_num = int(distance / (self.radius/4.0))
                for t in [float(i)/pos_num for i in range(pos_num)]:
                    pos = self.pre_pos.lerp(self.position, t)
                    self.positions.append((int(pos.x), int(pos.y)))
        else:
            self.positions.append((int(self.position.x),
                                   int(self.position.y)))
        for pos in self.positions:
            rect = pg.draw.circle(self.canvas.pad, self.color,
                                 (pos[0], pos[1]), self.radius)
            self.strokes.append(rect)
        self.pre_pos.update(self.position.x, self.position.y)

    def update(self):
        position = pg.mouse.get_pos()
        if position[0] == -1:
            if self.paint:
                self.paint = False
        self.position.update(position[0], position[1])
        self.rect.center = (self.position.x+25,self.position.y-20)
        if self.paint:
            self.draw()


class App(object):

    def __init__(self, display):
        self.canvas = Canvas(display)
        self.quit = False
    
    def run(self):
        self.quit = self.canvas.check_input()
        self.canvas.update()


display = None


def setup():
    global display
    pg.init()
    display = pg.display.set_mode((500, 400))
    pg.display.set_caption('Draw Pad')
    pg.event.set_blocked(pg.MOUSEMOTION)
    pg.mouse.set_cursor((8,8),(0,0),
                        (0,0,0,0,0,0,0,0),(0,0,0,0,0,0,0,0))


def main():
    setup()
    app = App(display)
    while True:
        if app.quit:
            break
        app.run()


def run_js():
    app = App(display)
    pg.set_callback(app)


def main_js():
    setup()
    pg.setup(run_js, ['./data/brush.png'])


if __name__ == '__main__':
    if platform in ('pc', 'jvm'):
        main()
    elif platform == 'js':
        main_js()

