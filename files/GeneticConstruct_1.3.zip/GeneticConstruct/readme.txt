Genetic Construct
Copyright (C) 2010 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.


Genetic Construct version 1.3
Download Site:  http://gatc.ca
Source:         GeneticConstruct.zip
Executable:
    Linux:      GeneticConstruct_exe.tar.gz
    Windows:    GeneticConstruct_exe.zip

Dependencies:
    Python 2.6:         http://www.python.org/
    Pygame 1.8-1.9:     http://www.pygame.org/
    Numpy 1.3-1.5:      http://numpy.scipy.org/

Genetic Construct generates a visual construct of a genetic sequence.
The tool permits the visual exploration of genetic sequence constructs
to discover genetic patterns or structures with biological importance in
gene regulation and protein function. To run type 'python construct.py'
at command line. Also available are executables with Python dependencies
included, run with './construct' (Linux) or 'construct.exe' (Windows).
Program configuration can be set in config.ini, and DNA patterns can be
entered in patterns.ini. DNA sequences can be either txt or fasta files
that are placed in the /sequence subfolder. Two example sequences have
been included that show prominent features in the construct, the
complete sequence of the Human FMR1 gene (NG_007529.fa) obtained from
NCBI Nucleotide database (http://www.ncbi.nlm.nih.gov/nuccore), and the
coding sequence of Human TRO gene (CCDS_43959.fa) obtained from
the CCDS database (http://www.ncbi.nlm.nih.gov/projects/CCDS/). The
program is released under the GPL v3 license.

Control Panel:
1. load sequence
2. shift/pan/zoom construct
3. sequence/pattern search
4. show sequence info/save image
5. exit program

Controls:
u/d/l/r             shift construct
    + SHIFT         hyper shift construct
    + CTRL          pan construct
    + SHIFT+CTRL    hyper pan construct
    + ALT           zoom construct
g/a/t/c             base display
SPACE               reset sequence
]                   sequence repeats increase
]                   sequence repeats decrease
/                   center display
s                   show sequence at cursor
x                   show position at cursor
s + CTRL            save png image
p                   panel toggle
z                   sequence viewer
v + CTRL            sequence viewer paste
h                   help
Mouse 1             pan construct
    +SHIFT          hyper pan construct
    +CTRL           sequence viewer paste
Mouse 2             show position at cursor
Mouse 3             show sequence at cursor

