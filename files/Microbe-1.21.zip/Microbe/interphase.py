#!/usr/bin/env python
from __future__ import division

"""
Interphase
Copyright (C) 2009 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Interphase version 0.7
Download Site: http://gatc.ca

Dependencies:

    Python 2.5:   http://www.python.org/
    PyGame 1.8:   http://www.pygame.org/

Description:

The program adds interface panel functionality to a Pygame application.
Use import in your script, or run separately for a interface panel demo.
"""

import pygame
from pygame.locals import *
import os
import warnings
warnings.filterwarnings("ignore")

class Interface(pygame.sprite.Sprite):
    """
    Interphase
    
    The program adds interface panel functionality to a Pygame application.
    Use import in your script, or run separately for an interface panel demo.
    The demo is coded in interphase_demo.py, and uses InterfaceDemo that is
    subclassed from the Interface Object.
    
    The Interface Object provides several methods to design and utilize an
    interface panel. Use add() to add controls to panel, place into a method
    called add_controls(); if added otherwise call activate() after to
    activate the panel. The Interface class/subclass instance can be added
    to a pygame sprite group that provides methods update/draw/clear to
    update the panel. If the Interface is subclassed, when overriding update()
    make sure to call Interface.update(). The program maintains the update
    of the panel, and changes through the provided methods are updated,
    however, panel_update() can be used to force an update, but usually not
    required. Use get_state() that returns the InterfaceState object. To
    turn the panel off, deactivate() sets state.active to false.


    InterfaceState Object:

    panel:
      - Interface panel (instance panel object)
    controls:
      - Interface controls (dict {id:object} panel controls object)
    panel_active:
      - Panel active (bool panel active)
    panel_interact:
      - Pointer interface interact (bool pointer interact with panel)
    control_interact:
      - Pointer control interact ('id' control interact pointer_move=True)
    button_interact:
      - Pointer button interact ('id' button interact pointer_move=True)
    control:
      - Control selected ('id' selected control)
    button:
      - Button selected ('id' selected button ('id','id_top','id_bottom'))
    value:
      - Control value ('value' current value of selected control)
    values:
      - Panel control values (dict {'id':value} values of all controls)


    Interface methods:

    add()/add_control(), activate(), deactivate(), get_state(), get_value(),
    get_control(), remove_control(), enable_control(), disable_control(),
    set_panel_image(), set_control_image(), set_button_image(), is_active,
    move(), is_moveable(), set_moveable(), is_info_display(), set_panel_display,
    panel_update(), set_info_display(), is_label_display(), set_label_display(),
    is_tips_display(), set_tips_display(), add_info(), clear_info(), update()
    get_position(), get_size().

    InterfaceControl methods:

    get_value(), set_value(), set_list(), get_list(), remove_list(),
    set_link(), set_link_activated(), is_activated, set_activated(),
    get_tip(), set_tip(), is_active(), set_active(), set_control_image(),
    next(), previous().
    """
    def __init__(self, identity='Interface_Panel', position=None, image=None, color=(0,0,0), size=(350,100), screen=(500,500), moveable=False, position_offset=(0,0), move_rate=(5,5), fixed=False, button_image=[], control_image=None, control_minsize=None, control_size='min', function_button='left', control_button='right', font_color=(125,130,135), font_size=10, label_display=False, info_display=False, info_fontsize=10, info_fontcolor=(125,130,135), info_position=(2,0), tips_display=False, tips_fontsize=8, tips_fontcolor=(125,130,135), tips_position=(0,-15), control_response=5, pointer_move=False):
        """
        Interface
        
        Optional Parameters:
        identity: 'id' panel name.
        position: (x,y) panel placement on screen.
            - values < 1 are %screen.
        image: 'image' panel image in data folder.
        color: (r,g,b) panel color.
        size: (w,h) dimension of panel
        screen: (w,h) dimension of screen.
        moveable: bool panel can move.
        position_offset: (x,y) panel move offset.
        move_rate: (x,y) panel move rate.
            - values < 1 are %position_offset.
        fixed: bool panel fixed in place.
        button_image: [] control button image in data folder.
            - ['top','bottom'] images or a composite image
        control_image: [] control background image in data folder.
            - ['image']
        control_minsize: (x,y) minimum control size.
        control_size: '' global control size if control_minsize set.
            - 'auto', 'auto_width': fit items.
            - 'min', 'min_width': fit using control_minsize.
            - 'panel': use exact control_minsize.
        function_button: placement of buttons of function_select.
        control_button: placement of buttons of control_select.
        font_color: (r,g,b) font color of control text.
        font_size: int font size of control text. Size:6,8,10,12,24,32.
        label_display: bool label displayed.
        info_display: bool info text displayed.
        info_fontsize: int font size used for info text.
        info_fontcolor: (r,g,b) font color used for info text.
        info_position: (x,y) position of info text.
        tips_display: bool tip text displayed.
        tips_fontsize: int font size used for tip text.
        tips_fontcolor: (r,g,b) font color used for tip text.
        tips_position: (x,y) position offset of tip text.
        control_response: int control click response.
        pointer_move: bool pointer movement monitored.
        """
        pygame.sprite.Sprite.__init__(self)
        self._id = identity
        self._width, self._height = screen
        self._size = size
        if position:
            pos_x, pos_y = position
            if pos_x < 1:
                pos_x = int(pos_x * self._width)
            if pos_y < 1:
                pos_y = int(pos_y * self._height)
            self._x, self._y = pos_x, pos_y
        else:
            self._x, self._y = self._width//2, self._height//2
        self._moveable = moveable                            #panel moveable
        self._positionx, self._positiony = self._x, self._y     #panel original placement
        self._offsetx, self._offsety = position_offset
        directionx, directiony = move_rate        #panel move speed
        if directionx < 1:
            directionx = int(directionx * abs(self._offsetx))
        if directiony < 1:
            directiony = int(directiony * abs(self._offsety))
        self._directionx, self._directiony = directionx, directiony
        self._color = color
        self._initialized = False
        self._panel_image, self.image, self.rect = self.set_panel_image(image)
        self._controls = {}      #panel controls
        self._control_values = {}
        self._button_image = self.set_button_image(button_image)
        self._control_image = {}
        self._control_image = self.set_control_image(control_image)
        self._control_minsize = control_minsize
        self._control_size = control_size
        self._button_placement = { 'function_select':function_button , 'control_select':control_button }
        self._displayed = True
        self._panel_disabled = False     #disabled on move
        self._display_fixed = fixed      #moveable panel fixed in place
        self._active = True
        self._panel_active = False
        self._panel_display = True     #panel controls display on or toggled with pointer interact
        self._panel_rect = pygame.Rect(self.rect)
        self._font_color = font_color
        self._font_size = font_size
        self._info_display = info_display   #info display toggle
        self._info_displaying = False   #info currently displaying
        self._info = DisplayMsg(self.image)  #info displayed on panel
        self._info.set_font_size(info_fontsize)
        self._info.set_font_color(info_fontcolor)
        self._info.set_font_bgcolor(None)
        self._info.set_position(info_position)
        self._tips_display = tips_display
        self._tips = DisplayMsg(self.image)
        self._tips.set_font_size(tips_fontsize)
        self._tips.set_font_color(tips_fontcolor)
        self._tips.set_font_bgcolor(None)
        self._tips_position = tips_position    #default tips over pointer
        self._control_hover = None    #interact during tips_display
        self._controls_disabled = {}
        self._active_color = (255,0,0)
        self._update_display = True      #update panel display
        self._pause = 0
        self._control_response = control_response   #response speed of control
        self._control_hold = {}     #response speed increase on hold
        self._label_display = label_display  #show control labels
        self._panel_interact = False
        self._pointer_move = pointer_move
        self._update_panel = False
        self._interface_state = None     #interface control state
        self.add_controls()
        self.activate()
    def add_controls(self):
        """Method to overide in subclass for adding controls."""
        pass
    def add(self, identity, control_type, position, **parameters):
        """Add control to panel."""
        panel = self
        interface_control = InterfaceControl(panel, identity, control_type, position, **parameters)
        self._controls[identity] = interface_control
        return interface_control
    def activate(self, activate_panel=True):
        """Panel activation."""
        if activate_panel:
            self._active = True
            self._panel_active = True
            self._panel_disabled = False
            self._activate_controls()
            if not self._initialized:
                if self._moveable:
                    self._x, self._y = self._x+self._offsetx, self._y+self._offsety
                self._initialized = True
            self.panel_update()
        else:
            self.deactivate()
    def deactivate(self):
        """Panel deactivation."""
        self._active = False
        self._panel_disabled = True
    def _activate_controls(self):
        """Panel controls activation."""
        for ctrl in self._controls:
            if self._controls[ctrl].control_type in ('function_select', 'function_toggle'):
                self._controls[ctrl].place = 0
                self._controls[ctrl].value = self._controls[ctrl].listing[self._controls[ctrl].place]
                if self._controls[ctrl].link_activated:
                    for function in self._controls[ctrl].link:
                        for link in self._controls[ctrl].link[function]:
                            if link in self._controls[ctrl].link[self._controls[ctrl].value]:
                                self._controls[link].active = True
                            else:
                                self._controls[link].active = False
                else:
                    for function in self._controls[ctrl].link:
                        for link in self._controls[ctrl].link[function]:
                            self._controls[link].active = False
            self._control_values[ctrl] = self._controls[ctrl].value
    def add_control(self, identity, control_type, position, **parameters):
        """Add control to panel."""
        interface_control = self.add(identity, control_type, position, **parameters)
        return interface_control
    def get_control(self, *control):
        """Retrieve control object. Multiple controls return a dictionary of control objects, and if no parameter given return dictionary of all control objects."""
        if not control:
            return self._controls.copy()
        elif len(control) == 1:
            return self._controls[control[0]]
        ctr = {}
        for ctrl in control:
            ctr[ctrl] = self._controls[ctrl]
        return ctr
    def remove_control(self, *control):
        """Remove control from panel."""
        if control:
            for ctrl in control:
                del self._controls[ctrl]
                del self._control_values[ctrl]
                for item in self._controls:
                    if self._controls[item].control_type in ('function_select', 'function_toggle'):
                        for function in self._controls[item].link:
                            if ctrl in self._controls[item].link[function]:
                                self._controls[item].link[function].remove(ctrl)
        else:
            self._controls.clear()
            self._control_values.clear()
    def enable_control(self, *control):
        """Set control enabled."""
        if not control:
            control = self._controls.keys()
        control_unchanged = []
        for ctrl in control:
            if ctrl in self._controls_disabled:
                self._controls[ctrl].rects = self._controls_disabled[ctrl].copy()
                #panel move - change rect pos or define controls
                del self._controls_disabled[ctrl]
            else:
                control_unchanged.append(ctrl)
        return control_unchanged
    def disable_control(self, *control):
        """Set control disabled."""
        if not control:
            control = self._controls.keys()
        for ctrl in control:
            self._controls_disabled[ctrl] = self._controls[ctrl].rects.copy()
            self._controls[ctrl].rects = {}
    def get_value(self, *control):
        """Retrieve current value of control. Multiple controls return a dictionary of values, and if no parameter given return dictionary of all values."""
        if not control:
            return self._control_values
        elif len(control) == 1:
            return self._control_values[control[0]]
        value = {}
        for ctrl in control:
            value[ctrl] = self._control_values[ctrl]
        return value
    def get_position(self):
        """Retrieve panel position."""
        return self._x, self._y
    def get_size(self):
        """Retrieve panel size."""
        return self._size
    def set_panel_image(self, image=None):
        """Set image used for panel."""
        if image:
            try:
                self._panel_image = load_image(image, errorhandle=False)
            except IOError:
                self._panel_image = pygame.Surface(self._size)
                self._panel_image.fill(self._color)
        else:
            self._panel_image = pygame.Surface(self._size)
            self._panel_image.fill(self._color)
        self.image = self._panel_image.copy()
        self.rect = self.image.get_rect(center=(self._x,self._y))
        return self._panel_image, self.image, self.rect
    def set_control_image(self, control_image=None):
        """Set image used for control."""
        if control_image:
            try:
                self._control_image['bg'] = load_image(control_image[0], errorhandle=False)
            except IOError:
                pass
        else:
            if 'bg' in self._control_image:
                del self._control_image['bg']
        for ctrl in self._controls:
            if not self._control_image:
                self._controls[ctrl].control_outline = True
            else:
                self._controls[ctrl].control_outline = self._controls[ctrl].outline
            self._controls[ctrl].set_buttonlist()
        return self._control_image
    def set_button_image(self, button_image=None):
        """Set image used for buttons."""
        if button_image:
            self._button_image = {}
            button_frames = 2
            if len(button_image) == 1:
                try:
                    images = load_image(button_image[0], button_frames, errorhandle=False)
                    self._button_image['t'] = pygame.transform.smoothscale(images[0], (12,12))
                    self._button_image['b'] = pygame.transform.smoothscale(images[1], (12,12))
                except IOError:
                    self._button_image = None
            else:
                for num, frame in enumerate(['t','b']):
                    try:
                        img = load_image(button_image[num], errorhandle=False)
                        self._button_image[frame] = pygame.transform.smoothscale(img, (12,12))
                    except IOError:
                        self._button_image = None
                        break
        else:
            self._button_image = None
        for ctrl in self._controls:
            self._controls[ctrl].define_buttons(self._controls[ctrl].control_type, self._controls[ctrl].size, self._controls[ctrl].color['normal'], self._controls[ctrl].color['fill'], initialize=False)
        return self._button_image
    def is_active(self):
        """Check whether panel is active."""
        return self._active
    def is_moveable(self, setting=None):
        """Check whether panel is moveable."""
        if not setting:
            return self._moveable
        elif setting == 'Fixed':
            return self._display_fixed
    def set_moveable(self, setting='Toggle', position_offset=None, move_rate=None):
        """Set panel moveable setting."""
        if setting == 'Toggle':
            self._moveable = not self._moveable
            return self._moveable
        elif setting in (True, False):
            self._moveable = setting
            if position_offset:
                self._offsetx, self._offsety = position_offset
            if move_rate:
                self._directionx, self._directiony = move_rate
            return self._moveable
        elif setting == 'Fixed':
            self._display_fixed = not self._display_fixed
            return self._display_fixed
        else:
            return None
    def move(self, x, y):
        """Move panel to new position x,y."""
        self._x, self._y = x, y
        self._panel_rect.center = self._x, self._y
        for ctrl in self._controls:
            control_type = self._controls[ctrl].control_type
            size = self._controls[ctrl].size
            color = self._controls[ctrl].color['normal']
            fill = self._controls[ctrl].color['fill']
            self._controls[ctrl].button, self._controls[ctrl].rects = self._controls[ctrl].define_buttons(control_type, size, color, fill)
        self.panel_update()
    def set_panel_display(self, setting='Toggle'):
        """Set whether panel display toggled with pointer interaction."""
        if setting == 'Toggle':
            self._panel_display = not self._panel_display
            return self._panel_display
        elif setting in (True, False):
            self._panel_display = setting
            return self._panel_display
        else:
            return None
    def is_info_display(self):
        """Check whether info is displayed."""
        return self._info_display
    def set_info_display(self, setting='Toggle'):
        """Set info display setting."""
        if setting == 'Toggle':
            self._info_display = not self._info_display
            return self._info_display
        elif setting in (True, False):
            self._info_display = setting
            return self._info_display
        else:
            return None
    def is_label_display(self):
        """Check whether label is displayed."""
        return self._label_display
    def set_label_display(self, setting='Toggle'):
        """Set label display setting."""
        if setting == 'Toggle':
            self._label_display = not self._label_display
            return self._label_display
        elif setting in (True, False):
            self._label_display = setting
            return self._label_display
        else:
            return None
    def is_tips_display(self):
        """Check whether tips are displayed."""
        return self._tips_display
    def set_tips_display(self, setting='Toggle'):
        """Set tips display setting."""
        if setting == 'Toggle':
            self._tips_display = not self._tips_display
            return self._tips_display
        elif setting in (True, False):
            self._tips_display = setting
            return self._tips_display
        else:
            return None
    def add_info(self, *message_append):
        """Add text to info."""
        self._info.add(*message_append)
        self._info_displaying = True
    def clear_info(self):
        """Clear text from info."""
        self._info.clear_text()
    def get_state(self):
        """Get the state object of the panel."""
        return self._interface_state
    def _display_controls(self):
        """Draws controls on panel.""" 
        if self._panel_active:
            self.image = self._panel_image.copy()
            for ctrl in self._controls:
                if self._controls[ctrl].active:
                    try:
                        for btn in self._controls[ctrl].button_list:
                            rect = self._controls[ctrl].button[btn]()
                    except KeyError:
                        continue
                    try:
                        if not self._controls[ctrl].control_icon or not self._controls[ctrl].value.startswith('__'):
                            self._controls[ctrl].display.add(self._controls[ctrl].value)
                            self.image = self._controls[ctrl].display(self.image)
                        else:
                            try:
                                x,y = self._controls[ctrl].rects[ctrl].center
                                x,y = x - self._panel_rect[0] - (self._controls[ctrl].icon_size[0]//2), y - self._panel_rect[1] - (self._controls[ctrl].icon_size[1]//2)
                                self.image.blit(self._controls[ctrl].control_icon[self._controls[ctrl].value], (x,y))
                            except KeyError:
                                self._controls[ctrl].display.add(self._controls[ctrl].value)
                                self.image = self._controls[ctrl].display(self.image)
                    except AttributeError:  #no value
                        pass
                    if self._label_display and self._controls[ctrl].label_display:
                        if not self._controls[ctrl].label_text.startswith('__'):
                            self._controls[ctrl].label.add(self._controls[ctrl].label_text)
                            self.image = self._controls[ctrl].label(self.image)
                    if self._controls[ctrl].activated and self._controls[ctrl].activated_toggle:
                        if self._controls[ctrl].activated:
                            self._controls[ctrl].activated = False
                            self._controls[ctrl].active_color = self._controls[ctrl].color['normal']
            if self._tips_display:
                if self._panel_interact:
                    mouse_x, mouse_y = pygame.mouse.get_pos()
                    if self._control_hover:
                        if not self._controls[self._control_hover].active or not self._controls[self._control_hover].rects[self._control_hover].collidepoint(mouse_x,mouse_y):
                            self._control_hover = None
                    if not self._control_hover:
                        for ctrl in self._controls:
                            if self._controls[ctrl].active:
                                if self._controls[ctrl].tips:
                                    try:
                                        if self._controls[ctrl].rects[ctrl].collidepoint(mouse_x,mouse_y):
                                            self._control_hover = ctrl
                                            break
                                    except:
                                        if not ctrl in self._controls_disabled:
                                            self._controls[ctrl].tips = None
                                            print('Warning: control tip not found.')
                    try:
                        if self._control_hover:
                            if len(self._controls[self._control_hover].tips) == 1:
                                tip = self._controls[self._control_hover].tips[self._controls[self._control_hover].tips.keys()[0]]
                            else:
                                tip = self._controls[self._control_hover].tips[self._controls[self._control_hover].value]
                            pos = mouse_x-(self._x-(self._size[0]//2)), mouse_y-(self._y-(self._size[1]//2))
                            pos = pos[0]+self._tips_position[0], pos[1]+self._tips_position[1]
                            self._tips.set_position(pos, center=True)
                            self._tips.add(tip)
                            self.image = self._tips(self.image)
                    except:
                        self._controls[ctrl].tips = None
                        print('Warning: control tip not found.')
                else:
                    self._control_hover = None
            if self._info_display:
                if self._info_displaying:
                    if self._info.has_text():
                        self.image = self._info(self.image)
                    else:
                        self._info_displaying = False
            self.rect = self.image.get_rect(center=(self._x,self._y))
    def _display_update(self):
        """Update control panel on display."""
        if self._moveable:
            self._moveable_panel()
        if self._info_displaying:
            self._update_panel = True
        update = self._panel_interaction()
        return update
    def _moveable_panel(self):
        """Update moveable panel."""
        def move_panel(pos_i, pos_f, z, z_dir, rate_x=0, rate_y=0):
            if rate_x:
                rate_x = rate_x*z_dir * z
                rate = rate_x
            else:
                rate_y = rate_y*z_dir * z
                rate = rate_y
            if abs(pos_i-pos_f) > abs(rate):
                self.rect.move_ip((rate_x, rate_y))
                pos_i += rate
                self._panel_disabled = True
            else:
                adj = abs(pos_i-pos_f)
                if rate_x:
                    rate_x = adj*z_dir * z
                else:
                    rate_y = adj*z_dir * z
                self.rect.move_ip((rate_x, rate_y))
                pos_i = pos_f
                self._panel_disabled = False
            return pos_i
        if self._displayed or self._display_fixed:
            if self._offsetx:
                if self._x != self._positionx:
                    z = self._offsetx//abs(self._offsetx)
                    z_dir = -1
                    self._x = move_panel(self._x, self._positionx, z, z_dir, rate_x=self._directionx)
            if self._offsety:
                if self._y != self._positiony:
                    z = self._offsety//abs(self._offsety)
                    z_dir = -1
                    self._y = move_panel(self._y, self._positiony, z, z_dir, rate_y=self._directiony)
        else:
            if self._offsetx:
                if self._x != self._positionx+self._offsetx:
                    z = self._offsetx//abs(self._offsetx)
                    z_dir = 1
                    self._x = move_panel(self._x, self._positionx+self._offsetx, z, z_dir, rate_x=self._directionx)
            if self._offsety:
                if self._y != self._positiony+self._offsety:
                    z = self._offsety//abs(self._offsety)
                    z_dir = 1
                    self._y = move_panel(self._y, self._positiony+self._offsety, z, z_dir, rate_y=self._directiony)
        return self._panel_disabled
    def _move_rect(self, rect):
        """Update rects following panel move."""
        self._panel_rect = self.image.get_rect(center=(self._x,self._y))
        offset_x, offset_y = self._panel_rect[0], self._panel_rect[1]
        rect[0], rect[1] = rect[0]+offset_x, rect[1]+offset_y
        self._controls[ctrl].rects[btn] = rect
        return rect
    def _panel_interaction(self):
        """Check for mouse interaction with panel."""
        pointer_position = pygame.mouse.get_pos()
        if self._displayed:
            if not self.rect.collidepoint(pointer_position):
                self._panel_interact = False
                self._displayed = False
                if not self._panel_display:
                    if self._panel_active:
                        self._panel_active = False
                        self.image = self._panel_image.copy()
        else:
            if self.rect.collidepoint(pointer_position):
                self._panel_interact = True
                self._panel_active = True
                self._displayed = True
        return self._panel_interact
    def _interact(self):
        """Check for mouse interaction with controls."""
        pointer_position = pygame.mouse.get_pos()
        control_interact = None
        button_interact = None
        control_selected = None
        button_selected = None
        if self._displayed and self._panel_active and not self._panel_disabled:
            if self._tips_display and self._control_hover:    #control interaction in tips display
                control_interact, button_interact = self._control_hover, self._control_hover
            else:
                if self._pointer_move:     #detect pointer move interact
                    for ctrl in self._controls:
                        if self._controls[ctrl].active:
                            for rect in self._controls[ctrl].rects:
                                if self._controls[ctrl].rects[rect].collidepoint(pointer_position):
                                    control_interact, button_interact = ctrl, rect
                                    break
            if not self._pause:
                button1,button2,button3 = pygame.mouse.get_pressed()
                if button1:
                    for control in self._controls:
                        if self._controls[control].active:
                            for button in self._controls[control].rects:
                                if button.endswith('_bg'):
                                    continue
                                if self._controls[control].rects[button].collidepoint(pointer_position):
                                    if not self._controls[control].hold_response:
                                        self._pause = self._control_response
                                    else:
                                        if button not in self._control_hold:
                                            self._control_hold[button] = self._controls[control].hold_response
                                            self._pause = self._control_response
                                        else:
                                            if self._control_hold[button]:
                                                self._control_hold[button] -= 1
                                                self._pause = self._control_response
                                            else:
                                                self._pause = 1
                                    control_selected, button_selected = control, button
                                    return control_interact, button_interact, control_selected, button_selected
                else:
                    self._control_hold = {}
            else:
                self._pause -= 1
        return control_interact, button_interact, control_selected, button_selected
    def _control_action(self, control_select):
        """Does control action, returns button pressed and current control value."""
        if control_select:
            for ctrl in self._controls:
                if self._controls[ctrl].active:
                    if control_select in self._controls[ctrl].button:
                        control_value = self._controls[ctrl].action(control_select)
                        return control_value
        return None
    def panel_update(self, force_update=True):
        """Update control panel, determines interaction, does control action."""
        update = self._display_update()
        if update or force_update or self._update_panel:
            self._update_panel = False
            self._display_controls()
            control_interact, button_interact, control_select, button_select = self._interact()
            value = self._control_action(button_select)
            panel = self
            self._interface_state = InterfaceState(panel, control_interact, button_interact, control_select, button_select, value)
        else:
            panel = self
            self._interface_state = InterfaceState(panel)
        return self._interface_state
    def update(self):
        """Update control panel. If overriding in interface subclass, call Interface.update(self)."""
        interface_state = self.panel_update(0)
        return interface_state

class InterfaceControl(object):
    """
    Define panel control.
    """
    def __init__(self, panel, identity, control_type, position, size=None, color=(40,80,120), fill=1, control_outline=None, control_image=None, font_color=None, font_size=None, control_list=[], icon_list=[], tip_list=[], link=None, link_activated=True, activated_color=(0,120,160), activated_toggle=True, label=None, label_display=True, active=True, hold_response=10, loop=False, reverse=False):
        """
        InterfaceControl
        
        Parameters:
            panel: obj panel holding control.
                - auto set by add()
            identity: 'id' control name.
            control_type: 'type' control type.
                - 'function_select', 'function_toggle', 'control_select', 'control_toggle', 'label'
            position: (x,y) control placement on panel. Values < 1 are %panel.
        Optional parameters:
            size: (w,h) control size.
                - 'auto', 'auto_width': fit items.
                - 'min', 'min_width': fit using control_minsize.
                - 'panel': use exact control_minsize.
            color: (r,g,b) control color.
            fill: int button edge width, and 0 filled -1 none.
            control_outline: display control edge.
            control_image: [] control background image in data folder.
                - ['image']. Default: None use panel control_image, ['None'] suppress image.
            font_color: (r,g,b) font color. Overrides panel font_color.
            font_size: int font size - 6, 8, 10, 12, 24, 32. Overrides panel font size.
            control_list: [] option list held by control.
                - numeric: [0] '__numeric', [1] (start,stop,step)
                - alpha: [0] '__alpha', [1] 'upper','lower','mixed'
                - alphanumeric: [0] '__alphanumeric' in list[0], [1] 'upper','lower','mixed'
                - filelist: [0] '__filelist', [1] path, [2] root, [3] ext (default: files in 'data')
            icon_list: [] option icons.
                - replace '__item' in control_list - separate images or a composite image.
            tip_list: [] tip list - single control tip, multiple control list tip.
            link: [] function control link to activate other controls.
            link_activated: bool function control link activated.
            activated_color: (r,g,b) highlight edge color of activated control.
            activated_toggle: bool control activated toggle.
            label: '' supply label to replace 'id' text.
            label_display: bool control label displayed.
            active: bool control active state.
            hold_response: int list change before control response quicken on hold, 0 no change.
            loop: bool option list loop.
            reverse: bool control switches reversed.
        """
        self.id = identity      #control identity
        self.control_type = control_type    #functional type of control
        self.panel = panel      #panel holding control
        self.listing = []   #list item held by control
        self.place = 0      #current place in list
        if not reverse:
            self.button_forward = self.id+'_bottom'
            self.button_reverse = self.id+'_top'
        else:
            self.button_forward = self.id+'_top'
            self.button_reverse = self.id+'_bottom'
        self.control_reverse = False    #control direction reversed
        self.numeric_range = None       #range for numeric control_type
        if not size:
            if not self.panel._control_minsize:
                self.size = 'auto'
            else:
                self.size = self.panel._control_size
        else:
            self.size = size
        self.font_size = font_size
        self.listing, self.value, self.control_icon, self.icon_size, self.size = self.set_listing(control_list, icon_list)
        pos_x, pos_y = position     #control position in panel
        if pos_x < 1:
            pos_x = int(pos_x*self.panel._size[0])
        if pos_y < 1:
            pos_y = int(pos_y*self.panel._size[1])
        pos_x, pos_y = pos_x - (self.size[0]//2), pos_y - (self.size[1]//2)
        self.position = pos_x, pos_y
        if not font_color:
            font_color = self.panel._font_color
        if not font_size:
            font_size = self.panel._font_size
        self.display = self.set_display(self.size, font_color, font_size)
        self.label = self.set_label(self.size, font_color, font_size)
        if label:
            self.label_text = label
        else:
            self.label_text = self.id
        self.label_display = label_display
        self.tips = self.set_tips(tip_list)
        self.color = {'normal':color, 'activated':activated_color, 'fill':fill}
        self.active_color = self.color['normal']
        self.activated_toggle = activated_toggle
        self.control_image = {}
        self.control_image_suppress = False
        if control_image:
            if control_image[0] != 'None':
                self.control_image = self.set_control_image(control_image)
            else:
                self.control_image_suppress = True
        else:
            self.control_image = self.panel._control_image
        if control_outline == None:
            if not self.control_image:
                self.control_outline = True
            else:
                self.control_outline = False
        elif control_outline in (True, False):
            self.control_outline = control_outline
        else:
            print("Warning: control outline value must be True or False.")
            self.control_outline = True
        self.outline = self.control_outline
        self.button, self.rects = self.define_buttons(self.control_type, self.size, color, fill)
        self.loop = loop    #listing loops back
        self.hold_response_set = hold_response
        if self.listing:
            if ( len(self.listing) > self.hold_response_set ) or ( self.listing[0] == '__numeric' and (self.numeric_range[1]-self.numeric_range[0]) > self.hold_response_set ):
                self.hold_response = self.hold_response_set      #response increase with hold
            else:
                self.hold_response = 0
        else:
            self.hold_response = 0
        if link:
            self.link = {}
            for item in self.listing:
                try:
                    self.link[item] = link.pop(0)
                except IndexError:
                    self.link[item] = []
        else:
            self.link = {}
        self.link_activated = link_activated
        self.activated = False
        self.active = active
        self.button_list = self.set_buttonlist()
    def define_buttons(self, control_type, size, color, fill, initialize=True):
        """Define control layout."""
        button = {}
        rects = {}
        if control_type in ('function_select', 'control_select'):
            if self.panel._button_placement[control_type] == 'left':
                x, y = self.position
                x1 = x-8
                y1 = int(y+(0.25*size[1])+4)
                x2 = x-8
                y2 = int(y+(0.75*size[1])-4)
            elif self.panel._button_placement[control_type] == 'right':
                x, y = self.position
                x1 = x+size[0]+8
                y1 = int(y+(0.25*size[1])+4)
                x2 = x+size[0]+8
                y2 = int(y+(0.75*size[1])-4)
        if control_type == 'function_select':
            if not self.control_image:
                button[self.id] = lambda: pygame.draw.rect(self.panel.image, self.active_color, (self.position,size), fill)
            else:
                background = pygame.transform.smoothscale(self.control_image['bg'], size)
                button[self.id+'_bg'] = lambda: self.panel.image.blit(background, self.position)
                button[self.id] = lambda: pygame.draw.rect(self.panel.image, self.active_color, (self.position,size), fill)
            if not self.panel._button_image:
                button[self.id+'_top'] = lambda: pygame.draw.polygon(self.panel.image, color, ((x1,y1-10),(x1-5,y1),(x1+5,y1)), fill)
            else:
                button[self.id+'_top'] = lambda: self.panel.image.blit(self.panel._button_image['t'], (x1-6,y1-12))
            if not self.panel._button_image:
                button[self.id+'_bottom'] = lambda: pygame.draw.polygon(self.panel.image, color, ((x2,y2+10),(x2-5,y2),(x2+5,y2)), fill)
            else:
                button[self.id+'_bottom'] = lambda: self.panel.image.blit(self.panel._button_image['b'], (x2-6,y2))
        elif control_type == 'function_toggle':
            if not self.control_image:
                button[self.id] = lambda: pygame.draw.rect(self.panel.image, self.active_color, (self.position,size), fill)
            else:
                background = pygame.transform.smoothscale(self.control_image['bg'], size)
                button[self.id+'_bg'] = lambda: self.panel.image.blit(background, self.position)
                button[self.id] = lambda: pygame.draw.rect(self.panel.image, self.active_color, (self.position,size), fill)
        elif control_type == 'control_select':
            if not self.control_image:
                button[self.id] = lambda: pygame.draw.rect(self.panel.image, self.active_color, (self.position,size), fill)
            else:
                background = pygame.transform.smoothscale(self.control_image['bg'], size)
                button[self.id+'_bg'] = lambda: self.panel.image.blit(background, self.position)
                button[self.id] = lambda: pygame.draw.rect(self.panel.image, self.active_color, (self.position,size), fill)
            if not self.panel._button_image:
                button[self.id+'_top'] = lambda: pygame.draw.polygon(self.panel.image, color, ((x1,y1-10),(x1-5,y1),(x1+5,y1)), fill)
            else:
                button[self.id+'_top'] = lambda: self.panel.image.blit(self.panel._button_image['t'], (x1-6,y1-12))
            if not self.panel._button_image:
                button[self.id+'_bottom'] = lambda: pygame.draw.polygon(self.panel.image, color, ((x2,y2+10),(x2-5,y2),(x2+5,y2)), fill)
            else:
                button[self.id+'_bottom'] = lambda: self.panel.image.blit(self.panel._button_image['b'], (x2-6,y2))
        elif control_type == 'control_toggle':
            if not self.control_image:
                button[self.id] = lambda: pygame.draw.rect(self.panel.image, self.active_color, (self.position,size), fill)
            else:
                background = pygame.transform.smoothscale(self.control_image['bg'], size)
                button[self.id+'_bg'] = lambda: self.panel.image.blit(background, self.position)
                button[self.id] = lambda: pygame.draw.rect(self.panel.image, self.active_color, (self.position,size), fill)
        elif control_type == 'label':
            button[self.id] = lambda:None
        self.button = button
        if initialize:
            if control_type != 'label':
                for btn in button:
                    if btn not in self.panel._controls_disabled:
                        offset_x, offset_y = self.panel._panel_rect[0], self.panel._panel_rect[1]
                        rect = button[btn]()
                        rect[0], rect[1] = rect[0] + offset_x, rect[1] + offset_y
                        rects[btn] = rect
            return button, rects
    def set_listing(self, control_list=[], icon_list=[], size='auto', case=False):
        """Initiate control option list."""
        self.control_icon = None
        self.icon_size = None
        self.value = ''
        self.place = 0
        if control_list:
            if control_list[0] == '__numeric':
                self.listing = control_list[:1]
                self.numeric_range = []
                try:
                    if len(control_list[1]) == 1:
                        self.numeric_range.append(0)
                        self.numeric_range.append(control_list[1])
                        self.numeric_range.append(1)
                    elif len(control_list[1]) == 2:
                        self.numeric_range.extend(control_list[1])
                        self.numeric_range.append(1)                         
                    elif len(control_list[1]) == 3:
                            self.numeric_range.extend(control_list[1])
                except IndexError:
                    self.numeric_range = [0,100,1]
                self.value = self.numeric_range[0]
                if self.numeric_range[2] < 1:
                    if self.button_forward == self.id+'_top':
                        self.button_forward = self.id+'_bottom'
                    else:
                        self.button_forward = self.id+'_top'
                    if self.button_reverse == self.id+'_bottom':
                        self.button_reverse = self.id+'_top'
                    else:
                        self.button_reverse = self.id+'_bottom'
            elif control_list[0] == '__alpha':
                if not case:
                    try:
                        case = control_list[1]
                    except IndexError:
                        case = 'upper'
                if case == 'upper':
                    char = ' ABCDEFGHIJKLMNOPQRSTUVWXYZ'
                elif case == 'lower':
                    char = ' abcdefghijklmnopqrstuvwxyz'
                elif case == 'mixed':
                    char = ' abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
                self.listing = char
                self.value = self.listing[self.place]
            elif control_list[0] == '__alphanumeric':
                if not case:
                    try:
                        case = control_list[1]
                    except IndexError:
                        case = 'upper'
                if case == 'upper':
                    char = ' ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
                elif case == 'lower':
                    char = ' abcdefghijklmnopqrstuvwxyz0123456789'
                elif case == 'mixed':
                    char = ' abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
                self.listing = char
                self.value = self.listing[self.place]
            elif control_list[0] == '__filelist':
                try:
                    file_path = control_list[1]
                    file_root = control_list[2]
                    file_ext = control_list[3]
                except IndexError:
                    file_path = 'data'
                    file_root = None
                    file_ext = None
                if not file_path:
                    file_path = os.curdir
                file_list = os.listdir(file_path)
                file_list = [item for item in file_list if os.path.isfile(os.path.join(file_path,item))]
                if file_root:
                    file_list = [item for item in file_list if item.startswith(file_root)]
                if file_ext:
                    file_list = [item for item in file_list if item.endswith(file_ext)]
                self.listing = file_list
                self.listing.sort()
                if self.listing:
                    self.value = self.listing[0]
                else:
                    self.listing.append('None')
                    self.value = 'None'
            else:
                for item in control_list:
                    self.listing.append(str(item))
                self.value = self.listing[self.place]
                if icon_list:      #icon in listing
                    listing_icon = []
                    for item in self.listing:
                        if item.startswith('__'):
                            listing_icon.append(item)
                    if listing_icon:
                        self.control_icon, self.icon_size = self.set_listing_icon(listing_icon, icon_list)
        self.panel._control_values[self.id] = self.value
        self.size = self.control_size(self.listing, self.icon_size, self.size, self.font_size)
        return self.listing, self.value, self.control_icon, self.icon_size, self.size
    def set_listing_icon(self, listing_icon, icon_list):
        """Set icons of control list."""
        control_icon = {}
        icon_size = (0,0)
        frames = len(listing_icon)
        if len(icon_list) == 1:
            try:
                images = load_image(icon_list[0], frames, errorhandle=False)
                icon_size = images[0].get_size()
                for num, item in enumerate(listing_icon):
                    control_icon[item] = images[num]
            except IOError:
                control_icon = {}
                icon_size = None
        else:
            for num, item in enumerate(listing_icon):
                try:
                    img = load_image(icon_list[num], errorhandle=False)
                    control_icon[item] = img
                    size = img.get_size()
                    if size[0] > icon_size[0]:
                        icon_size = size
                except IOError:
                    control_icon = {}
                    icon_size = None
                    break
        return control_icon, icon_size
    def set_tips(self, tip_list=None):
        """Set tips of control list."""
        if tip_list:
            self.tips = {}
            if len(tip_list) == 1:
                control_tip = True
            else:
                control_tip = False
            for item in self.listing:
                try:
                    if control_tip:
                        self.tips[item] = tip_list[0]
                    else:
                        self.tips[item] = tip_list.pop(0)
                except IndexError:
                    self.tips[item] = ''
        else:
            self.tips = {}
        return self.tips
    def control_size(self, listing, icon_size, size, font_size):
        """Set control size."""
        if size in ('auto', 'auto_width', 'min', 'min_width'):   #size adjusted to largest string
            text_display = DisplayMsg(self.panel.image)
            text_display.set_font_size(font_size)
            if listing:
                if listing[0] != '__numeric':
                    lst = []
                    for item in listing:
                        if item.startswith('__') and icon_size:
                            continue
                        item = str(item)
                        items = item.split(' ')
                        lst.extend(items)
                    longest_string = 'x'
                    for item in lst:
                        if len(item) > len(longest_string):
                            longest_string = item
                    width, height = text_display.check_size(str(longest_string))
                else:
                    if len(str(self.numeric_range[1])) > len(str(self.numeric_range[0])):
                        longest_string = self.numeric_range[1]
                    else:
                        longest_string = self.numeric_range[0]
                    width, height = text_display.check_size(str(longest_string))
                if size == 'min':
                    if self.panel._control_minsize:
                        if self.panel._control_minsize[0] > width:
                            width = self.panel._control_minsize[0]
                        if self.panel._control_minsize[1] > height:
                            height = self.panel._control_minsize[1]
                elif size == 'min_width':
                    if self.panel._control_minsize:
                        if self.panel._control_minsize[0] > width:
                            width = self.panel._control_minsize[0]
                if size in ('auto', 'min'):
                    if width > height:
                        dim = width
                    else:
                        dim = height
                    size = dim+5, dim+5
                elif size in ('auto_width', 'min_width'):
                    size = width+5, height+5
            elif size == 'panel':
                if self.panel._control_minsize:
                    size = self.panel._control_minsize
                else:
                    size = (20,20)
            else:
                size = (20,20)
        if icon_size:
            if icon_size[0]+5 > size[0]:
                size = icon_size[0]+5, icon_size[1]+5
        return size
    def set_control_image(self, control_image=None):
        """Set image of control."""
        if control_image:
            try:
                if self.control_image:
                    self.control_image = {}
                self.control_image['bg'] = load_image(control_image[0], errorhandle=False)
            except IOError:
                self.control_image = self.panel._control_image
                    
        else:
            if 'bg' in self.control_image:
                del self.control_image['bg']
        if self.panel._initialized:
            self.define_buttons(self.control_type, self.size, self.color['normal'], self.color['fill'], initialize=False)
        return self.control_image
    def set_list(self, control_list, icon_list=None, size='auto', append=False, panel_activate=False):
        """Set control listing of a control."""
        if control_list:
            if control_list[0] not in ('__numeric', '__alpha', '__alphanumeric', '__filelist'):
                if append:
                    if control_list:
                        for item in control_list:
                            self.listing.append(str(item))
                        self.value = self.listing[self.place]
                        self.panel._control_values[self.id] = self.value
                        for item in control_list:
                            if self.link:
                                if item not in self.link:
                                    self.link[item] = []
                            if self.tips:
                                if item not in self.tips:
                                    self.tips[item] = ''
                    if icon_list:      #icon in listing
                        listing_icon = []
                        for item in control_list:
                            if item.startswith('__'):
                                listing_icon.append(item)
                        if listing_icon:
                            control_icon, self.icon_size = self.set_listing_icon(listing_icon, icon_list)
                            self.control_icon.extend(control_icon)
                    self.size = self.control_size(self.listing, self.icon_size, self.size, self.font_size)
                else:
                    self.listing = []
                    self.tips = {}
                    self.link = {}
                    self.set_listing(control_list, icon_list, size)
            else:
                self.listing = []
                self.set_listing(control_list, icon_list, size)
            if self.listing:
                if ( len(self.listing) > self.hold_response_set ) or ( self.listing[0] == '__numeric' and (self.numeric_range[1]-self.numeric_range[0]) > self.hold_response_set ):
                    self.hold_response = self.hold_response_set      #response increase with hold
                else:
                    self.hold_response = 0
            if panel_activate:
                self.panel.activate()     
    def get_list(self):
        """Return control listing."""
        return self.listing
    def remove_list(self, items=None):
        """Remove specified items from control listing, including corresponding tips and links. Passing no parameter removes complete control list."""
        if items == None:
            items = self.listing[:]
        for item in items:
            if item in self.listing:
                self.listing.remove(item)
            if item in self.tips:
                del self.tips[item]
            if item in self.link:
                del self.link[item]
            if item == self.value:
                self.value = ''
                self.panel._control_values[self.id] = self.value
    def set_tip(self, control=None, tip=None):
        """Set tip for a control item. Parameters: control:str, tip:str, or single control_tips:[] - where list contains tip for each control item or one main tip."""
        if control and tip:
            if control in self.listing:
                if not self.tips:
                    for item in self.listing:
                        self.tips[item] = ''
                self.tips[control] = tip
                return True
            else:
                return False
        else:
            self.set_tips(control)
            return True
    def get_tip(self, item=None):
        """Get the tip for a control item, or list of tips if no parameter given. Parameter: item:str"""
        if item:
            if item in self.tips:
                return self.tips[item]
            else:
                return None
        else:
            return self.tips
    def set_link(self, control, link):
        """Set linked controls. Parameters: control:str, link:[]."""
        if control in self.listing:
            if not self.link:
                for item in self.listing:
                    self.link[item] = []
            self.link[control] = link
            return True
        else:
            return False
    def set_link_activated(self, setting='Toggle'):
        """Set whether linked control active immediately or upon control button activation."""
        link_change = False
        if setting == 'Toggle':
            self.link_activated = not self.link_activated
            link_change = True
        elif setting in (True, False):
            self.link_activated = setting
            link_change = True
        if link_change:
            if self.control_type == 'function_select':
                self.check_link(self.id, True)
            return self.link_activated
        else:
            return None
    def is_activated(self):
        """Check whether control is activated."""
        return self.activated
    def set_activated(self, setting='Toggle'):
        """Set control activated."""
        change = False
        if setting == 'Toggle':
            self.activated = not self.activated
            change = True
        elif setting in (True, False):
            self.activated = setting
            change = True
        if change:
            if self.link and not self.link_activated:
                for button in self.link[self.value]:
                    self.panel._controls[button].active = self.activated
            if not self.activated:
                self.active_color = self.color['normal']
            else:
                self.active_color = self.color['activated']
            return self.activated
        else:
            return None
    def set_value(self, value):
        """Set the value of a control."""
        self.value = value
        self.panel._control_values[self.id] = self.value
        self.panel._update_panel = True
    def get_value(self):
        """Get the value of a control."""
        return self.value
    def is_active(self):
        """Check whether a control is active."""
        return self.active
    def set_active(self, setting='Toggle'):
        """Set control active setting."""
        if setting == 'Toggle':
            self.active = not self.active
            return self.active
        elif setting in (True, False):
            self.active = setting
            return self.active
        else:
            return None
    def set_buttonlist(self):
        """List specifying button members of a control. Designations for control 'id': main button:'id', button switches:'id_top'/'id_bottom'."""
        self.button_list = []
        if self.control_type in ('function_select', 'function_toggle', 'control_select', 'control_toggle'):
            if self.control_image:
                self.button_list.append(self.id+'_bg')
                if self.control_outline:
                    self.button_list.append(self.id)
            else:
                if self.control_outline:
                    self.button_list.append(self.id)
            if self.control_type in ('function_select', 'control_select'):
                self.button_list.extend([self.id+'_top', self.id+'_bottom'])
        return self.button_list
    def set_display(self, size, font_color, font_size, position=None, text=None):
        """Initiate control display text."""
        if text:    #set display text
            self.value = text
            self.panel._control_values[self.id] = self.value
        display = DisplayMsg(self.panel.image)
        display.set_font_size(font_size)
        display.set_font_color(font_color)
        display.set_font_bgcolor(None)
        if self.control_type == 'label':
            display.set_position((self.position),center=True)
            return display
        display.split_text = True
        if not position:
            width, height = display.check_size('x')
            position = ( self.position[0]+(size[0]//2), self.position[1]+(size[1]//2)-(height//2) )
        display.set_position((position),center=True)
        return display
    def set_label(self, size, font_color, font_size, position=None, text=None):
        """Initiate control label text."""
        if text:    #set label text
            self.label_text = text
            return
        label = DisplayMsg(self.panel.image)
        label.set_font_size(font_size)
        label.set_font_color(font_color)
        label.set_font_bgcolor(None)
        if self.control_type == 'label':
            label.set_position((self.position[0], self.position[1]-12),center=True)
            return label
        if not position:
            position = ( self.position[0]+(size[0]//2), self.position[1]-12 )
        if not text:
            text = self.id
        label.set_position((position),center=True)
        return label
    def check_link(self, ctrl, activate):
        """Maintain active state of linked controls."""
        control = self.panel._controls[ctrl]
        if control.link:
            if not activate:
                for ctr in control.link[control.value]:
                    self.panel._controls[ctr].set_active(False)
                    self.panel._controls[ctr].set_activated(False)
                    self.check_link(ctr, activate)
            else:
                if (control.control_type == 'function_select' and control.link_activated) or control.control_type == 'function_toggle':
                    for ctr in control.link[control.value]:
                        self.panel._controls[ctr].set_active(True)
                        self.check_link(ctr, activate)
                else:
                    for ctr in control.link[control.value]:
                        self.panel._controls[ctr].set_active(control.activated)
                        self.check_link(ctr, control.activated)
    def next(self):
        """Set value to next in control_list."""
        self.check_link(self.id, False)
        if self.place < len(self.listing)-1:
            self.place += 1
        else:
            self.place = 0
        self.value = self.listing[self.place]
        self.panel._control_values[self.id] = self.value
        if self.is_active():
            self.check_link(self.id, True)
    def previous(self):
        """Set value to previous in control_list."""
        self.check_link(self.id, False)
        if self.place > 0:
            self.place -= 1
        else:
            self.place = len(self.listing)-1
        self.value = self.listing[self.place]
        self.panel._control_values[self.id] = self.value
        if self.is_active():
            self.check_link(self.id, True)
    def action(self, button):
        """Function of control."""
        if self.control_type == 'function_select':
            if button == self.id:
                self.activated = not self.activated
                self.check_link(self.id, self.activated)
            elif button == self.button_forward:
                self.activated = False
                self.check_link(self.id, False)
                if self.place < len(self.listing)-1:
                    self.place += 1
                else:
                    if self.loop:
                        self.place = 0
                    else:
                        self.place = len(self.listing)-1
                self.value = self.listing[self.place]
                self.check_link(self.id, True)
            elif button == self.button_reverse:
                self.activated = False
                self.check_link(self.id, False)
                if self.place > 0:
                    self.place -= 1
                else:
                    if self.loop:
                        self.place = len(self.listing)-1
                    else:
                        self.place = 0
                self.value = self.listing[self.place]
                self.check_link(self.id, True)
        elif self.control_type == 'function_toggle':
            if button == self.id:
                self.check_link(self.id, False)
                self.activated = not self.activated
                if self.place < len(self.listing)-1:
                    self.place += 1
                else:
                    self.place = 0
                self.value = self.listing[self.place]
                self.check_link(self.id, True)
        elif self.control_type == 'control_select':
            if self.listing:
                if self.listing[0] == '__numeric':
                    def greater(val1, val2, direction=1):
                        if val1 > val2:
                            return direction >= 1
                        else:
                            return not (direction >= 1)
                    if button == self.id:
                        self.activated = not self.activated
                    elif button == self.button_reverse:
                        self.activated = False
                        self.value += self.numeric_range[2]
                        if greater(self.value, self.numeric_range[1], self.numeric_range[2]):
                            if self.loop:
                                self.value = self.numeric_range[0]
                            else:
                                self.value = self.numeric_range[1]
                    elif button == self.button_forward:
                        self.activated = False
                        self.value -= self.numeric_range[2]
                        if not greater(self.value, self.numeric_range[0], self.numeric_range[2]):
                            if self.loop:
                                self.value = self.numeric_range[1]
                            else:
                                self.value = self.numeric_range[0]
                else:
                    if button == self.id:
                        self.activated = not self.activated
                        self.value = self.listing[self.place]
                    elif button == self.button_forward:
                        self.activated = False
                        if self.place < len(self.listing)-1:
                            self.place += 1
                        else:
                            if self.loop:
                                self.place = 0
                            else:
                                self.place = len(self.listing)-1
                        self.value = self.listing[self.place]
                    elif button == self.button_reverse:
                        self.activated = False
                        if self.place > 0:
                            self.place -= 1
                        else:
                            if self.loop:
                                self.place = len(self.listing)-1
                            else:
                                self.place = 0
                        self.value = self.listing[self.place]
        elif self.control_type == 'control_toggle':
            if button == self.id:
                self.activated = not self.activated
                if self.place < len(self.listing)-1:
                    self.place += 1
                else:
                    self.place = 0
            self.value = self.listing[self.place]
        if not self.activated:
            self.active_color = self.color['normal']
        else:
            self.active_color = self.color['activated']
        self.panel._control_values[self.id] = self.value
        return self.value

class InterfaceState(object):
    """
    State Object shows current state of control panel.
    """
    def __init__(self, panel, control_interact=None, button_interact=None, control_select=None, button=None, value=None):
        """
        State Object
        
        Parameters:
            panel:              Interface panel
            controls:           Interface controls
            panel_active        Panel active
            panel_interact:     Pointer interface interact
            control_interact:   Pointer control interact
            button_interact:    Pointer button interact
            control:            Control selected
            button:             Button selected
            value:              Control value
            values:             Panel control values

        control_interact, button_interact with pointer_move/tips_display
        """
        self.panel = panel
        self.controls = panel._controls
        self.active = panel._active
        self.panel_interact = panel._panel_interact
        self.control_interact = control_interact
        self.button_interact = button_interact
        self.control = control_select
        self.button = button
        self.value = value
        self.values = panel._control_values

def load_image(filename, frames=1, path='data', colorkey=None, errorhandle=True, errorreport=True):
    #Modified from PygameChimpTutorial
    full_name = os.path.join(path, filename)
    try:
        if frames == 1:
            image = pygame.image.load(full_name)
        elif frames > 1:
            images = []
            image = pygame.image.load(full_name)
            width, height = image.get_size()
            width = width // frames
            for frame in xrange(frames):
                frame_num = width * frame
                image_frame = image.subsurface((frame_num,0), (width,height)).copy()
                images.append(image_frame)
            return images
    except pygame.error, message:
        if errorhandle:
            raise SystemExit, message
        else:
            if errorreport:
                print(message)
            raise IOError
            return None
    if image.get_alpha():
        image = image.convert_alpha()
    else:
        image = image.convert()
    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0,0))
        image.set_colorkey(colorkey, RLEACCEL)
    return image

class DisplayMsg(object):
    """
    Receives messages to display on surface.
    
    Parameters:
        surface: 'surface' destination surface for text.
    """
    initialize = False
    font = None
    def __init__(self, surface):
        self.screen = surface
        x, y = self.screen.get_size()
        self.dimension = {'x':x, 'y':y}
        self.message = None
        self.messages = []
        if not DisplayMsg.initialize:
            pygame.font.init()
            font = pygame.font.match_font('bitstreamverasans, verdana, freesans, arial')
            DisplayMsg.font = { 6:pygame.font.Font(font,6), 8:pygame.font.Font(font,8), 10:pygame.font.Font(font,10), 12:pygame.font.Font(font,12), 24:pygame.font.Font(font,24), 32:pygame.font.Font(font,32) }
            DisplayMsg.initialize = True
        self.font = DisplayMsg.font
        self.x = 0
        self.y = 0
        self.center = False
        self.font_size = 10
        self.font_color = (255,0,0)
        self.font_bgcolor = (0,0,0)
        self.split_text = False
    def __call__(self, surface='default'):
        """Writes text to surface."""
        if surface == 'default':
            self.surface = self.screen
        else:
            self.surface = surface
        self.update()
        return self.surface
    def add(self,*message_append):
        """Add to text."""
        for item in message_append:
            self.message = str(item)
            self.messages.append(self.message)
    def set_position(self, position, center=False):
        """Set position to write text."""
        x, y = position
        if x < self.dimension['x'] and y < self.dimension['y']:
            self.x = x
            self.y = y
            if center:
                self.center = True
            return True
        else:
            return False
    def set_font_size(self, size):
        """Set font size of text."""
        if size in (6, 8, 10, 12, 24, 32):
            self.font_size = size
            return True
        else:
            return False
    def set_font_color(self, color):
        """Set font color of text."""
        self.font_color = color
    def set_font_bgcolor(self, color=None):
        """Set font background color."""
        self.font_bgcolor = color
    def check_size(self, text):
        """Get size required for given text."""
        width, height = self.font[self.font_size].size(text)
        return width, height
    def has_text(self):
        """Check whether contains text."""
        if self.messages:
            return True
        else:
            return False
    def clear_text(self):
        """Clear text."""
        self.message = None
        self.messages = []
    def tprint(self):
        """Print text to surface."""
        if self.messages != []:
            text = " ".join(self.messages)
            if not self.split_text or text.count(' ') == 0:
                if self.font_bgcolor:
                    self.text_surface = self.font[self.font_size].render(text, True, self.font_color, self.font_bgcolor)
                else:
                    self.text_surface = self.font[self.font_size].render(text, True, self.font_color)
                if self.center:
                    center = self.text_surface.get_width()//2
                    x = self.x - center
                else:
                    x = self.x
                text_rect = self.text_surface.get_rect()
                self.surface.blit(self.text_surface, (x,self.y))
            else:
                words = text.count(' ')
                position_y = self.y - (words)*(self.font_size-2)
                texts = text.split(' ')
                for count, text in enumerate(texts):
                    if self.font_bgcolor:
                        self.text_surface = self.font[self.font_size].render(text, True, self.font_color, self.font_bgcolor)
                    else:
                        self.text_surface = self.font[self.font_size].render(text, True, self.font_color)
                    if self.center:
                        center = self.text_surface.get_width()//2
                        x = self.x - center
                        y = position_y + (count*(self.font_size+2))
                    else:
                        x = self.x
                        y = position_y + (count*(self.font_size+2))
                    text_rect = self.text_surface.get_rect()
                    self.surface.blit(self.text_surface, (x,y))
            self.message = None
            self.messages = []
            return text_rect
    def update(self):
        self.tprint()

def main():
    try:
        import interphase_demo
        interphase_demo.demo()
    except ImportError:
        print("Warning: interphase_demo.py not found.")

if __name__ == '__main__':
    main()

