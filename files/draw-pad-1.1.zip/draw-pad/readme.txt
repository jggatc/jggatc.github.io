Draw Pad

Draw Pad is a simple drawing app. It is a demo of the functionality of the Pyjsdl-ts library. The app can run on several platforms, on the PC with Python/Pygame, JVM with Jython/PyJ2D, web browser with Pyjs/Pyjsdl or Transcrypt/Pyjsdl-ts. To use, control draw tool with mouse, set color and clear pad by clicking bottom corner areas.

Instructions to run in various environments for PyJ2D, Pyjsdl, and Pyjsdl-ts can be found on the project website (https://gatc.ca/). For JavaScript compilation using Pyjsdl from the Pyjsdl-ts package, download Pyjsdl-ts (https://gatc.ca/projects/pyjsdl-ts/) and unpack the pyjsdl folder into the script folder. Install Transcrypt (https://www.transcrypt.org/) and use the command 'transcrypt -n draw_demo.py' to compile the Python code to JavaScript in the __target__ folder. The draw_pad.html file can then launch the JavaScript app in a web browser from a local server (python3 -m http.server) or online server. Further information can be found to use Pyjsdl-ts can be found on the project website and including in the Pyjsdl-ts package.

