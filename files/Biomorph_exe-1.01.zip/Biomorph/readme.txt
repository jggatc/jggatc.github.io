Biomorph Entity
Copyright (C) 2009 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Biomorph Entity version 1.01
Download Site: http://gatc.ca
Source:       Biomorph.zip
Executable:
    Linux:      Biomorph_exe.tar.gz
    Windows:    Biomorph_exe.zip

Dependencies:
    Python >2.5:   http://www.python.org/
    PyGame >1.8:   http://www.pygame.org/

To run type 'python biomorph.py' at command line.
Command line options:
    --version         show program's version number and exit
    -h, --help        show this help message and exit
    --license         display program license
    -d, --doc         display program documentation
    -g DISPLAY_GAMMA  -g value (value: 0.5 to 3.0)
    -s DISPLAY_SIZE   -s value (value: WIDTHxHEIGHT)
    -c BACKGROUND_COLOR  -c value (value: R,G,B)
    >options can also be set in config.ini
Also available are executables with Python dependencies
included, and run with './biomorph' (Linux) or 'biomorph.exe' (Windows).

