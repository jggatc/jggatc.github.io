#Interphase Pack - Copyright (C) 2010 James Garnon <https://gatc.ca/>
#Released under the GPL3 License <https://www.gnu.org/licenses/>

import env
if not env.engine:
    import pygame
else:
    pygame = env.engine


class Timer_FPS(object):
    _font = None
    _surf = None

    def __init__(self, count=100):
        if not self._font:
            pygame.font.init()
            fn = pygame.font.get_default_font()
            self._font = pygame.font.Font(fn, 10)
        self._count = count
        self._fps = [0 for i in range(self._count)]
        self._fps_count = 0
        self._antialias = True
        self._color = pygame.Color(100,100,100)
        self._bg_color = pygame.Color(0,0,0)
        self._clock = pygame.time.Clock()
        if not self._surf:
            self._surf = self._font.render(
                '        ', self._antialias, self._color, self._bg_color)

    def get_fps(self):
        return int(sum(self._fps)/self._count)

    def render_fps(self):
        return self._surf

    def update_check(self):
        self.update()
        if self._fps_count == 0:
            return True
        else:
            return False

    def update(self):
        self._clock.tick()
        self._fps[self._fps_count] = int(self._clock.get_fps())
        self._fps_count += 1
        if self._fps_count >= self._count:
            fps = '%6d  ' % int(sum(self._fps)/self._count)
            self._surf = self._font.render(
                fps, self._antialias, self._color, self._bg_color)
            self._fps_count = 0
        return self._surf

