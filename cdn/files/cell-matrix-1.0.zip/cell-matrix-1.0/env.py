#Cell Matrix - Copyright (C) 2015
#Released under the GPL3 License

engine = None
interface = None
platform = None

size = None
color0 = None
color1 = None

