#"""
#Interphase
#Copyright (C) 2009 James Garnon
#"""

from interface import Interface, EVENT
from control import InterfaceControl
from util import Text, load_image
from version import __version__

