#Biomorph Entity - Copyright (C) 2009
#Released under the GPL3 License

from __future__ import division
import pygame

from util import load_image, sin_table, cos_table
import math
import random


class Segment(pygame.sprite.Sprite):
    """Biomorph Segment."""
    images = {}

    def __init__(self, x, y, segment_type, segment_size):
        pygame.sprite.Sprite.__init__(self)
        self.x = x
        self.y = y
        self.pos_x = float(self.x)     #float version
        self.pos_y = float(self.y)
        if not Segment.images:
            segment_num = 1
            for segment_image in ('segment1.png', 'segment2.png', 'segment3.png', 'segment4.png'):
                image_size = {}
                img = load_image(segment_image)
                for size in (0.5,1.0,1.5,2.0,2.5):
                    image = {}
                    for degree in range(0,360,10):
                        image[degree] = pygame.transform.rotozoom(img, -degree, 0.2*size)
                    image_size[size] = image
                Segment.images[segment_num] = image_size
                segment_num += 1
        self.direction = random.randrange(0,360,10)
        self.distance = random.randrange(1,10)
        self.image = Segment.images[segment_type][segment_size][self.direction]
        self.rect = self.image.get_rect(center=(self.x,self.y))
        self.velocity = 1 * segment_size

    def location(self):
        """Moves distance up to 10 steps, then changes direction randomly."""
        if self.distance > 0:
            self.distance -= 1
        else:
            self.direction = random.randrange(360)
            self.distance = random.randrange(1,10)
        self.pos_x += +self.velocity*sin_table[self.direction]
        self.pos_y += -self.velocity*cos_table[self.direction]
        #self.pos_x += +self.velocity*math.sin(self.direction*math.pi/180)
        #self.pos_y += -self.velocity*math.cos(self.direction*math.pi/180)
        self.x, self.y = int(self.pos_x), int(self.pos_y)
        self.rect = self.image.get_rect(center=(self.x,self.y))

    def update(self):
        self.location()


class Biomorph(object):

    def __init__(self, matrix, x, y, segments, biomorph_type, biomorph_size):
        self.matrix = matrix
        self.type = biomorph_type
        self.size = biomorph_size
        self.segment = pygame.sprite.OrderedUpdates()
        self.segments = segments
        self.edge_contact = False
        self.edge_response = 0
        self.velocity =  1 * self.size
        count = 0
        for i in range(self.segments-1):
            if not count:
                x_initial = random.randrange(10, self.matrix.width-50)
                y_initial = random.randrange(10, self.matrix.height-10)
                count = 2
            segment = Segment(x_initial+count*20, y_initial, self.type, self.size)
            self.segment.add(segment)
            count -= 1
        segment = Segment(x, y, self.type, self.size)
        self.segment.add(segment)
        segment.image = Segment.images[self.type][self.size][130]   #first segment

    def molecular_interaction(self):
        segments = []
        for segment in self.segment:
            segments.append(segment)
        segments.reverse()
        for i in range(len(segments)-1):
            try:
                x1 = segments[i].pos_x
                y1 = segments[i].pos_y
                x2 = segments[i+2].pos_x
                y2 = segments[i+2].pos_y
                separation = math.sqrt( math.pow((x1-x2),2) + math.pow((y1-y2),2) )
                if separation < 30 * self.size:
                    mid = ( abs((x1+x2)/2), abs((y1+y2)/2) )
                    x3 = segments[i+1].pos_x
                    y3 = segments[i+1].pos_y
                    mid3 = ( abs((mid[0]+x3)/2), abs((mid[1]+y3)/2) )
                    segments[i+1].pos_x, segments[i+1].pos_y = mid3[0], mid3[1]
                    segments[i+1].x, segments[i+1].y = int(segments[i+1].pos_x), int(segments[i+1].pos_y)
                    segments[i+1].rect.center = (segments[i+1].x, segments[i+1].y)
            except:
                pass
            x1 = segments[i].pos_x
            y1 = segments[i].pos_y
            x2 = segments[i+1].pos_x
            y2 = segments[i+1].pos_y
            separation = math.sqrt( math.pow((x1-x2),2) + math.pow((y1-y2),2) )
            if separation > 11 * self.size:
                if x1 < x2:
                    x1 += self.velocity
                elif x1 > x2:
                    x1 -= self.velocity
                if y1 < y2:
                    y1 += self.velocity
                elif y1 > y2:
                    y1 -= self.velocity
                segments[i].pos_x, segments[i].pos_y = x1, y1
                segments[i].x, segments[i].y = int(segments[i].pos_x), int(segments[i].pos_y)
                segments[i].rect.center = (segments[i].x, segments[i].y)
            elif separation < 9 * self.size:
                if x1 < x2:
                    x1 -= self.velocity
                elif x1 > x2:
                    x1 += self.velocity
                if y1 < y2:
                    y1 -= self.velocity
                elif y1 > y2:
                    y1 += self.velocity
                segments[i].pos_x, segments[i].pos_y = x1, y1
                segments[i].x, segments[i].y = int(segments[i].pos_x), int(segments[i].pos_y)
                segments[i].rect.center = (segments[i].x, segments[i].y)
        try:
            i = (self.segments) - 1
            j = i - 1
            x1 = segments[i].pos_x
            y1 = segments[i].pos_y
            x2 = segments[j].pos_x
            y2 = segments[j].pos_y
            separation = math.sqrt( math.pow((x1-x2),2) + math.pow((y1-y2),2) )
            if separation > 5 * self.size:
                if x1 < x2:
                    x1 += self.velocity
                elif x1 > x2:
                    x1 -= self.velocity
                if y1 < y2:
                    y1 += self.velocity
                elif y1 > y2:
                    y1 -= self.velocity
                segments[i].pos_x, segments[i].pos_y = x1, y1
                segments[i].x, segments[i].y = int(segments[i].pos_x), int(segments[i].pos_y)
                segments[i].rect.center = (segments[i].x, segments[i].y)
        except:
            pass

    def check_edge(self):
        segment_at_edge = pygame.sprite.spritecollide(self.segment.sprites()[self.segments-1], self.matrix.borders, False)
        if segment_at_edge:
            self.edge_contact = True
            self.edge_response = 10

    def interaction(self):
        self.check_edge()
        segments = []
        for segment in self.segment:
            segments.append(segment)
        segments.reverse()
        if self.edge_contact or (pygame.mouse.get_focused() and not self.matrix.control.panel_displayed):
            segment = segments[0]
            x1 = segment.pos_x
            y1 = segment.pos_y
            if self.edge_contact:
                x2,y2 = self.matrix.width//2, self.matrix.height//2
                self.edge_response -= 1
                if not self.edge_response:
                    self.edge_contact = False
            else:
                x2,y2 = pygame.mouse.get_pos()
            separation = math.sqrt( math.pow((x1-x2),2) + math.pow((y1-y2),2) )
            if separation > 25:
                if x1 < x2:
                    x1 += self.velocity
                elif x1 > x2:
                    x1 -= self.velocity
                if y1 < y2:
                    y1 += self.velocity
                elif y1 > y2:
                    y1 -= self.velocity
                segment.pos_x, segment.pos_y = x1, y1
                segment.x, segment.y = int(segment.pos_x), int(segment.pos_y)
                segment.rect.center = (segment.x, segment.y)

    def update(self):
        self.segment.update()
        self.molecular_interaction()
        self.interaction()

