#!/usr/bin/env python
from __future__ import division

"""
Biomorph Entity
Copyright (C) 2009 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

try:
    import pygame
    from pygame import bufferproxy
except ImportError:
    raise ImportError("Pygame module required.")

import random
import math
import os
import sys
import optparse

import interphase

from entity import Biomorph
from interface import Control

test = False
if not test:
    import warnings
    warnings.filterwarnings("ignore")


MATRIX_X = 500
MATRIX_Y = 500
BG_COLOR = (0,0,0)


class Matrix(object):

    def __init__(self, config):
        self.width = config['display_size'][0]
        self.height = config['display_size'][1]
        pygame.display.init()
        pygame.font.init()
        pygame.display.set_caption('Biomorph Entity')
        iconname = os.path.join('data', 'icon.png')
        icon = pygame.image.load(iconname)
        pygame.display.set_icon(icon)
        if config['display_gamma']:
            gamma_set = pygame.display.set_gamma(config['display_gamma'])
        self.screen = pygame.display.set_mode((self.width,self.height))
        if config['display_gamma'] and not gamma_set:   #if prior set_gamma failed
            gamma_set = pygame.display.set_gamma(config['display_gamma'])
        self.borders = self.matrix_borders()
        self.screen_matrix = pygame.display.get_surface()
        self.info = interphase.Text(self.screen)
        self.info.set_font_color((82,96,116))
        self.control_list = []
        self.control = None
        self.screen_base = pygame.Surface((self.width,self.height))
        self.screen_color = config['background_color']
        self.screen_base.fill(self.screen_color)
        self.screen.blit(self.screen_base, (0,0))
        self.update_list = []   #list of object to update display
        self.display_update = False
        self.biomorph_add = False
        self.biomorph_count = 0
        self.segment_count = 50
        self.biomorph_type = 4
        self.biomorph_size = 1.0
        self.biomorphs = { 0.5:{}, 1.0:{}, 1.5:{}, 2.0:{}, 2.5:{} }
        self.biomorph_entity = pygame.sprite.OrderedUpdates()

    def setup(self, biomorph=True):
        self.biomorphs = { 0.5:{}, 1.0:{}, 1.5:{}, 2.0:{}, 2.5:{} }
        self.biomorph_add = False
        if biomorph:
            self.add_biomorph()
        self.display_update = True
        self.update()

    def add_biomorph(self, x=None, y=None, segments=None):
        if x is None:
            x = self.width//2
        if y is None:
            y = self.height//2
        if segments is None:
            segments = self.segment_count
        self.biomorph_count += 1
        biomorph = Biomorph(self, x, y, segments, self.biomorph_type, self.biomorph_size)
        self.biomorphs[self.biomorph_size][self.biomorph_count] = biomorph
        return biomorph

    def simulation_set(self, parameter=None):
        self.biomorph_add = False
        if parameter == 'Add Biomorph':
            self.biomorph_add = not self.biomorph_add

    def biomorph_select(self, position):
        if self.biomorph_add:
            x,y = position
            self.add_biomorph(x,y)

    def matrix_borders(self):
        class Edge(pygame.sprite.Sprite):
            def __init__(self, x, y, dim_x, dim_y, side):
                pygame.sprite.Sprite.__init__(self)
                self.rect = pygame.Rect(x,y,dim_x,dim_y)
                self.side = side
        borders = pygame.sprite.Group()
        borders = pygame.sprite.Group()
        borders.add( Edge(0,0,self.width,1,'n') )
        borders.add( Edge(0,self.height-2,self.width,1,'s') )
        borders.add( Edge(0,0,1,self.height,'w') )
        borders.add( Edge(self.width-2,0,1,self.height,'e') )
        return borders

    def update(self):
        if self.display_update:
            self.screen.blit(self.screen_base, (0,0))
        for biomorph_size in self.biomorphs:
            for biomorph in self.biomorphs[biomorph_size]:
                self.biomorphs[biomorph_size][biomorph].update()
                for segment in self.biomorphs[biomorph_size][biomorph].segment:
                    self.biomorph_entity.add(segment)
        self.biomorph_entity.clear(self.screen_matrix,self.screen_base)
        self.update_list.extend(self.biomorph_entity.draw(self.screen_matrix))
        self.biomorph_entity.empty()


def program_options():
    config = {'display_gamma':None, 'display_size':None, 'background_color':None}
    try:
        conf = {}
        config_file = open('config.ini')
        cfg_setting = [line.strip().split(' ',1) for line in config_file if line[:1].isalpha()]
        cfg_setting = dict(cfg_setting)
        for cfg in config:
            if cfg in cfg_setting:
                conf[cfg] = cfg_setting[cfg].strip()
        config_file.close()
    except (IOError, ValueError):
        pass
    for cfg in conf:
        if cfg == 'display_gamma':
            try:
                config['display_gamma'] = float(conf['display_gamma'])
            except ValueError:
                pass
        elif cfg == 'display_size':
            config['display_size'] = [int(size) for size in conf['display_size'].split('x')]
        elif cfg == 'background_color':
            config['background_color'] = [int(color) for color in conf['background_color'].split(',')]
    program_usage = "%prog [options]"
    program_desc = ("Biomorph Entity")
    parser = optparse.OptionParser(usage=program_usage,description=program_desc)
    parser.add_option("-d", "--doc", dest="doc", action="store_true", help="display program documentation")
    parser.add_option("-g", dest="display_gamma", action="store", help="-g value (value: 0.5 to 3.0)")
    parser.add_option("-s", dest="display_size", action="store", help="-s value (value: WIDTHxHEIGHT)")
    parser.add_option("-c", dest="background_color", action="store", help="-c value (value: R,G,B)")
    (options, args) = parser.parse_args()
    if options.doc:
        try:
            docfile = open('README.txt')
        except IOError:
            print("Documentation not found.")
            sys.exit()
        try:
            import textwrap
            doc = []
            for line in docfile.readlines():
                text = textwrap.wrap(line, 80)
                if text:
                    for l in text:
                        doc.append(l+'\n')
                else:
                    doc.append('\n')
        except ImportError:
            doc = docfile.readlines()
        docfile.close()
        print(''.join(doc))
        sys.exit()
    if options.display_gamma:
        try:
            config['display_gamma'] = float(options.display_gamma)
        except ValueError:
            config['display_gamma'] = None
    if options.display_size:
        config['display_size'] = tuple([int(size) for size in options.display_size.split('x')])
    if options.background_color:
        config['background_color'] = tuple([int(color) for color in options.background_color.split(',')])
    for cfg in config:
        if config[cfg]:
            if cfg == 'display_gamma':
                if config[cfg] < 0.5:
                    config[cfg] = 0.5
                elif config[cfg] > 3.0:
                    config[cfg] = 3.0
            elif cfg == 'display_size':
                for i, size in enumerate(config[cfg]):
                    if size < 100:
                        config[cfg][i] = 100
                    elif size > 1024:
                        config[cfg][i] = 1024
            elif cfg == 'background_color':
                for i, clr in enumerate(config[cfg]):
                    if clr < 0:
                        config[cfg][i] = 0
                    elif clr > 255:
                        config[cfg][i] = 255
    return config


def setup():
    config = program_options()
    if config['display_size'] is None:
        config['display_size'] = (MATRIX_X, MATRIX_Y)
    if config['background_color'] is None:
        config['background_color'] = BG_COLOR
    matrix = Matrix(config)
    control = Control(matrix)
    matrix.control = control
    matrix.setup()
    return matrix, control

matrix, control = setup()


def main():
    while not control.quit:
        matrix.update_list = []
        control.panel_group.clear(matrix.screen,matrix.screen_base)
        control.update()
        matrix.update()
        if control.panel.is_active():
            update_rect = control.panel_group.draw(matrix.screen)
            matrix.update_list.extend(update_rect)
        if not matrix.display_update:
            pygame.display.update(matrix.update_list)
        else:
            matrix.display_update = False
            pygame.display.flip()

if __name__ == '__main__':
    main()

