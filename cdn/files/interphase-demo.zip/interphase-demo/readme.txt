Interphase Demo

The demo.py script can be run as a cross-platform app.

Requires:
Interphase module (http://gatc.ca/projects/interphase/)
Compatible with:
PyJ2D library (http://gatc.ca/projects/pyj2d/)
Pyjsdl library (http://gatc.ca/projects/pyjsdl/)

Specific instructions:


*Desktop*

Dependency:
Interphase 0.87
Python 2.7 (https://www.python.org/)
Pygame 1.9.1 (http://www.pygame.org)

Download Interphase module and unpack in or on path of script folder.
To run, enter 'python demo.py' in terminal.


*JVM*

Dependency:
Interphase 0.87
PyJ2D 0.27
Jython 2.2.1+ (installed or standalone from http://www.jython.org)
JavaVM installed (https://www.java.com/)
Download Interphase and PyJ2D modules and unpack in or on path of script folder.
To run, use 'jython demo.py' or 'java -jar jython.jar demo.py' for standalone interpreter.


*Web Browser*

Dependency:
Interphase 0.87
Pyjsdl 0.21
Pyjs (https://github.com/pyjs/pyjs)
Download Interphase and Pyjsdl modules and unpack in or on path of script folder.
Install Pyjs and use to compile the Python to JavaScript with 'pyjsbuild -O demo.py --dynamic-link -o output'.
For addition information on using Pyjs with Pyjsdl, see guide.txt in the Pyjsdl folder.
The demo app can run in the Web browser locally from demo.html or deployed to a Web server.

