Replicator Machine
Copyright (C) 2009 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Replicator Machine version 1.2
Download Site: http://gatc.ca
Source:       Replicator.zip
Executable:
    Linux:      Replicator_exe.tar.gz
    Windows:    Replicator_exe.zip

Dependencies:
    Python 2.5:   http://www.python.org/
    PyGame 1.8:   http://www.pygame.org/
    Numpy:        http://numpy.scipy.org/
    Psyco:        http://psyco.sourceforge.net/

To run type 'python replicator.py' at command line.
Command line options:
    --version         show program's version number and exit
    -h, --help        show this help message and exit
    --license         display program license
    -d, --doc         display program documentation
    -g DISPLAY_GAMMA  -g value (value: 0.5 to 3.0)
    -m, --mouse       -m for mouse enabled
    >options can also be set in config.ini
Also available are executables with Python dependencies
included, and run with './replicator' (Linux) or 'replicator.exe' (Windows).

Controls:
    UP / KP8            bot forward / scroll up
    DOWN / K_KP2        bot reverse / scroll down
    LEFT / KP4          bot left / scroll left
    RIGHT / KP6         bot right / scroll right
    RCTRL / KP5         bot dampen motion
    x / KP1             bot sleft
    c / KP3             bot sright
    SPACE / KP0         bot shoot
    a / KP_*            bot annihilation pulse
    z / KP_PERIOD       bot vaccine pulse
    LCTRL / KP_ENTER    bot tractor beam
    d                   toggle map display
    v                   add virus (simulation)
    m                   add macrophage (simulation)
    n                   add nanobot (simulation)
    i                   infectious variant (simulation)
    g                   genetic mutation (simulation)
    \                   mouse toggle
    t                   forward thrust
    r                   rotate/strafe switch
    w                   volume up
    s                   volume down
    ]                   increase difficulty level
    TAB                 pause toggle
    ESC                 restart
    h                   control info
    mouse button 1      bot shoot
    mouse button 2      bot tractor beam
    mouse button 3      bot vaccine pulse
    mouse motion        bot strafe

