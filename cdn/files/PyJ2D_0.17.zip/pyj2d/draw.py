"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
from math import pi
from java.awt import Color, BasicStroke
from rect import Rect


class Draw(object):

    def __init__(self):
        self.rad_deg = 180/pi

    def rect(self, surface, color, rect, width=0):
        try:
            x,y,w,h = rect.x, rect.y, rect.width, rect.height
        except AttributeError:
            try:
                x,y,w,h = rect
            except ValueError:
                x,y = rect[0]
                w,h = rect[1]
            rect = Rect(x,y,w,h)
        g = surface.createGraphics()
        R,G,B = color
        g.setColor(Color(R,G,B))       # *tuple unpack jythonc error
        if width:
            g.setStroke(BasicStroke(width))
            g.drawRect(x,y,w,h)
        else:
            g.fillRect(x,y,w,h)
        g.dispose()
        return rect

    def circle(self, surface, color, position, radius, width=0):
        x, y = position
        w, h = 2*radius, 2*radius
        g = surface.createGraphics()
        R,G,B = color
        g.setColor(Color(R,G,B))
        if width:
            g.setStroke(BasicStroke(width))
            g.drawOval(x-radius, y-radius, w, h)
        else:
            g.fillOval(x-radius, y-radius, w, h)
        g.dispose()
        return Rect(x,y,w,h)

    def arc(self, surface, color, rect, start_angle, stop_angle, width=1):
        try:
            x,y,w,h = rect.x, rect.y, rect.width, rect.height
        except AttributeError:
            try:
                x,y,w,h = rect
            except ValueError:
                x,y = rect[0]
                w,h = rect[1]
            rect = Rect(x,y,w,h)
        start_angle = int(start_angle * self.rad_deg)
        stop_angle = int(stop_angle * self.rad_deg)
        x -= w//8
        y -= h//8
        g = surface.createGraphics()
        R,G,B = color
        g.setColor(Color(R,G,B))
        if width:
            g.setStroke(BasicStroke(width))
            g.drawArc(x, y, w, h, start_angle, stop_angle)
        else:
            g.fillArc(x, y, w, h, start_angle, stop_angle)
        g.dispose()
        return rect

    def polygon(self, surface, color, pointlist, width=0):
        g = surface.createGraphics()
        R,G,B = color
        g.setColor(Color(R,G,B))
        xpts = [pt[0] for pt in pointlist]
        ypts = [pt[1] for pt in pointlist]
        npts = len(pointlist)
        xmin = min(xpts)
        xmax = max(xpts)
        ymin = min(ypts)
        ymax = max(ypts)
        if width:
            g.setStroke(BasicStroke(width))
            g.drawPolygon(xpts,ypts,npts)
        else:
            g.fillPolygon(xpts,ypts,npts)
        g.dispose()
        return Rect(xmin,ymin,xmax-xmin+1,ymax-ymin+1)

    def line(self, surface, color, point1, point2, width=1):
        p1x, p1y = point1
        p2x, p2y = point2
        g = surface.createGraphics()
        R,G,B = color
        g.setColor(Color(R,G,B))
        g.setStroke(BasicStroke(width))
        g.drawLine(p1x,p1y,p2x,p2y)
        g.dispose()
        xpts = [pt[0] for pt in (point1,point2)]
        ypts = [pt[1] for pt in (point1,point2)]
        xmin = min(xpts)
        xmax = max(xpts)
        ymin = min(ypts)
        ymax = max(ypts)
        w = xmax-xmin
        h = ymax-ymin
        return Rect(xmin, ymin, w, h)

    def lines(self, surface, color, closed, pointlist, width=1):
        xpoints = [p[0] for p in pointlist]
        ypoints = [p[1] for p in pointlist]
        if closed:
            xpoint, ypoint = xpoints[0], ypoints[0]
            xpoints.append(xpoint)
            ypoints.append(ypoint)
        npoints = len(xpoints)
        g = surface.createGraphics()
        R,G,B = color
        g.setColor(Color(R,G,B))
        g.setStroke(BasicStroke(width))
        g.drawPolyline(xpoints, ypoints, npoints)
        g.dispose()
        xmin = min(xpoints)
        xmax = max(xpoints)
        ymin = min(ypoints)
        ymax = max(ypoints)
        w = xmax-xmin
        h = ymax-ymin
        return Rect(xmin, ymin, w, h)

    def aaline(self, surface, color, point1, point2, blend=1):
        rect = self.line(surface, color, point1, point2, blend)
        return rect

    def aalines(self, surface, color, closed, pointlist, blend=1):
        rect = self.lines(surface, color, closed, pointlist, blend)
        return rect

