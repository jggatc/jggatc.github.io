"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
import env


class Mouse(object):

    def __init__(self):
        self.pos_rel = (0, 0)

    def get_pressed(self):
        try:
            button = env.jframe.event.mousePress.button
        except AttributeError:
            button = None
        return (1==button,2==button,3==button)

    def get_pos(self):
        pos = env.jframe.jpanel.getMousePosition()
        try:
            return (pos.x, pos.y)
        except AttributeError:
            return (-1,-1)

    def get_rel(self):
        pos = self.get_pos()
        rel = (pos[0]-self.pos_rel[0], pos[1]-self.pos_rel[1])
        self.pos_rel = pos
        return rel

    def set_pos(self, pos):
        pass

    def set_visible(self, setting):
        pass

    def get_focused(self):
        pass

    def set_cursor(self):
        pass

    def get_cursor(self):
        pass

