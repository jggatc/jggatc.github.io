"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
from javax.imageio import ImageIO
from java.io import File
from surface import Surface
import env


class Image(object):

    def load(self, img_file, namehint=None):
        try:
            f = env.japplet.class.getResource(img_file.replace('\\','/'))    #java uses /, not os.path Windows \
            if not f:
                raise
        except:
            f = File(img_file)      #make path os independent
        bimage = ImageIO.read(f)
        surf = Surface(bimage)
        return surf

