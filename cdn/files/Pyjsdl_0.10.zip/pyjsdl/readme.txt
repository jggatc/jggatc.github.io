Pyjsdl
Copyright (C) 2013 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Pyjsdl version 0.10
Download Site: http://gatc.ca


Description:
Pyjsdl module is modelled on Pygame/SDL commands that wraps JavaScript functionity including HTML5 canvas. The module permits scripts coded in Python/Pygame to compile to JavaScript using the Pyjs compiler (http://pyjs.org), allowing deployment of JavaScript applications without extensive editing of the script. The current version of the module supports a subset of Pygame functionality.

To use Pyjsdl module, place pyjsdl folder in the script folder or on the module path. Import pyjsdl into the Python script, or use the statement 'import pyjsdl as pygame' to maintain the Pygame commands. During pyjsdl initiation, use the statement pyjsdl.display.setup(run, images) to provide the canvas the main function to execute at a timed interval and program images to preload, where the 'run' function contains statements to be repeated each frame and 'images' is a list of image paths in the form ['./images/img.png']. A web application can be deployed following compilation to JavaScript.

