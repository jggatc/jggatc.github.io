#!/usr/bin/env python

#Pyjsdl App Convert
#Pyjsdl - Python-to-JavaScript Multimedia Framework
#Copyright (C) 2013 James Garnon
#LGPL 2.1+

#Pyjsdl
#Download Site: http://gatc.ca

#Conversion for Pyjsdl with Pyjs -O

#Rect.center -> Rect.__getattr__('center')
#pattern1 = (?P<rect>[0-9A-Za-z]+)\.center
#Rect.center = (0,0) -> Rect.__setattr__('center', (0,0))
#pattern2 = (?P<rect>[0-9A-Za-z]+)\.center\s*[=]\s*(?P<value>[(].+[)])


import re, sys, os


attribute = 'centerx', 'centery', 'center', 'topleft', 'bottomleft', 'topright', 'bottomright', 'midtop', 'midleft', 'midbottom', 'midright', 'top', 'left', 'bottom', 'right', 'size', 'w', 'h'


def get_args():
    try:
        if sys.argv[1] in ('--help', '-h'):
            print "usage: conv infile.py outfile.py"
            sys.exit()
    except IndexError:
        print 'missing file operand'
        sys.exit()
    try:
        infile = sys.argv[1]
        outfile = sys.argv[2]
    except IndexError:
        print 'missing file operand'
        sys.exit()
    return infile, outfile


def load_code(filename):
    code = []
    code_changed = []
    line_changed = []
    iscript = open(filename, 'r')
    for line in iscript:
        code.append(line)
        code_changed.append(line)
    iscript.close()
    return code


def save_code(code, outfile):
    if os.path.exists(outfile):
        while True:
            answer = raw_input(outfile+" exists, overwrite (y/n)? ")
            if answer == 'y':
                break
            elif answer == 'n':
                print "conversion aborted"
                sys.exit()
    f = open(outfile, 'w')
    for line in code:
        f.write(line)
    f.close()
    print "script converted"


def compile_re_pattern():
    pattern_get = {}
    pattern_set = {}
    pattern_set_var1 = {}
    pattern_set_var2 = {}
    for attr in attribute:
        if attr not in ('w', 'h'):
            att = r"(?P<attr>%s)" % attr
        else:
            att = r"(?P<attr>%s|%s|%s)" % ('width', 'height', attr)
        pattern_get[attr] = re.compile(r"(?P<rect>[0-9A-Za-z]+)\."+att)
        pattern_set[attr] = re.compile(r"(?P<rect>[0-9A-Za-z]+)\."+att+r"\s*[=]\s*(?P<value>[(].+[)])")
        pattern_set_var1[attr] = re.compile(r"(?P<rect>[0-9A-Za-z]+)\."+att+r"\s*(\+=|-=/\*=|/=|//=)\s*(.+)")
        pattern_set_var2[attr] = re.compile(r"(?P<rect>[0-9A-Za-z]+)\."+att+r"\s*[=]\s*([^(].+)")
    return pattern_get, pattern_set, pattern_set_var1, pattern_set_var2


def replace_pattern(code, pattern, statement):
    for index, line in enumerate(code):
        if line.lstrip().startswith('#') or not line.rstrip():
            continue
        for attr in attribute:
            if "."+attr not in line:
                continue
            result = pattern[attr].findall(line)
            if result:
                for match in result:
                    if attr in ('w', 'h'):
                        if match[1] in ('width', 'height'):
                            continue
                    if statement == 'setattr':
                        string = match[0] + ".__setattr__('"+match[1]+"', " + match[2]+")"
                    elif statement == 'setattr_var1':
                        string = match[0] + ".__setattr__('"+match[1]+"', " + match[0]+".__getattr__('"+match[1]+"') " + match[2][0] + " " + match[3] + ")"
                    elif statement == 'setattr_var2':
                        string = match[0] + ".__setattr__('"+match[1]+"', " + match[2]+")"
                    elif statement == 'getattr':
                        string = match[0] + ".__getattr__('"+match[1]+"')"
                    line = pattern[attr].sub(string, line, 1)
                code[index] = line
    return code


def confirm_conversion(code, code_original):
    line_convert = []
    line_skip = []
    for i in range(len(code)):
        if code_original[i] != code[i]:
            print i, code_original[i].rstrip()
            print "-->"
            print i, code[i].rstrip()
            print
            while True:
                convert = raw_input("convert (y/n) [y]: ")
                if convert in ('', 'y', 'n'):
                    if convert in ('', 'y'):
                        line_convert.append(i)
                        print 'converted'
                    else:
                        code[i] = code_original[i]
                        line_skip.append(i)
                        print 'not converted'
                    break
            print
            print
    print "line converted: ", line_convert
    print "line skipped: ", line_skip
    return code


def main():
    infile, outfile = get_args()
    code = load_code(infile)
    code_original = code[:]
    pattern_get, pattern_set, pattern_set_var1, pattern_set_var2 = compile_re_pattern()
    code = replace_pattern(code, pattern_set_var1, 'setattr_var1')
    code = replace_pattern(code, pattern_set, 'setattr')
    code = replace_pattern(code, pattern_set_var2, 'setattr_var2')
    code = replace_pattern(code, pattern_get, 'getattr')
    code = confirm_conversion(code, code_original)
    save_code(code, outfile)


if __name__ == '__main__':
    main()

