#!/usr/bin/env python
from __future__ import division

"""
Serpent Duel
Copyright (C) 2010 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Serpent Duel version 1.1
Interphase Pack

Interphase Module
Download Site: http://gatc.ca
"""


import interphase
import pygame
import random


class Matrix(object):
    """
    Serpent Duel enviroment.
    """
    def __init__(self, x, y, screen, background):
        self.x, self.y = x, y
        self.screen = screen
        self.background = background
        self.clock = pygame.time.Clock()
        self.level = 2
        self.speed = 2
        self.mode = {'Serpent1':'USER', 'Serpent2':'-'}
        self.ctrl = {'Pad':'Serpent1', 'Key1':'Serpent1', 'Key2':None}
        self.points = {'Serpent1':0, 'Serpent2':0}
        self.match = 0
        self.auto = False
        self.controls = {
            'Key1': {pygame.K_UP:'U', pygame.K_DOWN:'D', pygame.K_LEFT:'L', pygame.K_RIGHT:'R'},
            'Key2': {pygame.K_q:'U', pygame.K_z:'D', pygame.K_a:'L', pygame.K_s:'R'} }
        self.dirn = {}
        self.dirn['U'] = {'U':'U', 'D':'D', 'L':'L', 'R':'R'}
        self.dirn['D'] = {'U':'D', 'D':'U', 'L':'R', 'R':'L'}
        self.dirn['L'] = {'U':'R', 'D':'L', 'L':'D', 'R':'U'}
        self.dirn['R'] = {'U':'L', 'D':'R', 'L':'U', 'R':'D'}
        self.serpent_control = self.serpent_control_scr
        self.update_rect = []
        self.clear_screen()
        self.active = False

    def start(self):
        """Serpent Duel start."""
        self.treat = pygame.sprite.RenderUpdates()
        self.serpent = {'Serpent1':None, 'Serpent2':None}
        for serpent in self.mode:
            if self.mode[serpent] in ('USER', 'AI'):
                self.serpent_initiate(serpent)
            else:
                self.match = 0
        self.auto = not 'USER' in self.mode.values()
        self.clear_screen()
        for serpent in self.points:
            self.points[serpent] = 0
            interface_panel.set_points(serpent, self.points[serpent])
        self.active = True

    def clear_screen(self):
        """Screen update."""
        self.screen.blit(self.background, (0,0))
        self.draw_edge()
        pygame.display.flip()

    def draw_edge(self):
        """Draw edge around the arena."""
        self.edges = []
        for rect in [ (0,0,self.x,5), (0,self.y-120,self.x,5), (0,0,5,self.y-120), (self.x-5,0,5,self.y-120) ]:
            self.edges.append(pygame.draw.rect(self.screen, (43,50,58), rect, 0))
            self.update_rect.append(rect)

    def set_active(self, state=None, pause=False):
        """Activate Serpent Duel."""
        if state is None:
            self.active = not self.active
        else:
            self.active = state
        if self.active:
            if not pause:
                self.start()

    def set_mode(self, serpent, mode):
        """Set serpent control mode."""
        self.mode[serpent] = mode

    def set_control_mode(self, mode):
        """Set control perspective mode."""
        if mode == 'SCR':
            self.serpent_control = self.serpent_control_scr
        elif mode == 'USR':
            self.serpent_control = self.serpent_control_usr

    def set_difficulty(self, level):
        """Set serpent speed."""
        self.level = level
        self.speed = { 1:1, 2:2, 3:5, 4:10 }[level]

    def set_control(self, serpent, control):
        """Set serpent controls."""
        for ctr in self.ctrl:
            if self.ctrl[ctr] == serpent:
                self.ctrl[ctr] = None
        if control == 'Pad/Key1':
            self.ctrl['Pad'] = serpent
            self.ctrl['Key1'] = serpent
        elif control != '-':
            self.ctrl[control] = serpent

    def serpent_control_scr(self, direction, ctrl='Pad'):
        """Serpent control."""
        try:
            self.serpent[self.ctrl[ctrl]].control(direction)
        except:
            pass

    def serpent_control_usr(self, direction, ctrl='Pad'):
        """Serpent control."""
        try:
            dirn = self.serpent[self.ctrl[ctrl]].direction
            direction = self.dirn[dirn][direction]
            self.serpent[self.ctrl[ctrl]].control(direction)
        except:
            pass

    def serpent_initiate(self, identity):
        """Initiate serpent."""
        if identity == 'Serpent1':
            self.serpent['Serpent1'] = Serpent(self, (self.x//2)+50,(self.y//3)+30, identity, self.speed, self.mode['Serpent1'])
        else:
            self.serpent['Serpent2'] = Serpent(self, (self.x//2)-50,(self.y//3)+30, identity, self.speed, self.mode['Serpent2'])

    def update(self):
        """Serpent Duel update."""
        if self.active:
            if not self.treat and self.serpent and random.random() > 0.95:
                self.treat.add( Treat(self) )
            self.treat.update()
            self.treat.clear(self.screen, self.background)
            self.update_rect.extend( self.treat.draw(self.screen) )
            for serpent in self.serpent:
                if not self.serpent[serpent]:
                    continue
                if not self.serpent[serpent].alive:
                    if not self.match and not self.auto:
                        interface_panel.matrix_activate(False)
                        self.active = False
                    else:
                        self.serpent_initiate(self.serpent[serpent].identity)
                        self.draw_edge()
                self.serpent[serpent].update()
                self.serpent[serpent].segments.clear(self.screen, self.background)
                self.update_rect.extend( self.serpent[serpent].segments.draw(self.screen) )


class Serpent(object):
    """
    Serpent.
    """
    def __init__(self, matrix, x, y, identity, speed, mode):
        self.matrix = matrix
        self.identity = identity
        self.mode = mode
        self.x, self.y = x, y
        self.speed = speed
        self.DIR = { 'U':(0,-1), 'D':(0,1), 'L':(-1,0), 'R':(1,0) }
        self.DEG = { 'U':0, 'D':180, 'L':90, 'R':-90 }
        if self.identity == 'Serpent1':
            self.direction = 'R'
        else:
            self.direction = 'L'
        self.new_direction = None
        self.step, self.growing, self.rate = 0, 0, 0
        self.segments = pygame.sprite.RenderUpdates()
        self.serpent_body = {}
        self.grow(self.x, self.y, self.DIR[self.direction])
        self.serpent_body[0].image = pygame.transform.rotate(self.serpent_body[0].images[self.identity+'_head'], self.DEG[self.direction])
        self.scan_rect = pygame.Rect(0,0,10,10)
        self.pause = 20
        self.active = True
        self.alive = True

    def grow(self, x, y, direction, number=5):
        """Serpent generate."""
        for num in range(0,number*10,10):
            segment = Segment(self.identity, ((x-(direction[0]*num)),(y-(direction[1]*num))), direction, self.speed)
            self.segments.add(segment)
            self.serpent_body[len(self.serpent_body)] = segment

    def control(self, direction):
        """Serpent Control."""
        for dirn in ( ('L','R'),('U','D') ):
            if (direction in dirn) and (self.direction not in dirn):
                self.new_direction = direction
                self.last_move = direction

    def move(self):
        """Serpent move."""
        if self.mode == 'AI':
            self.move_auto()
        self.step += 1
        if self.step >= 10/self.speed:
            for i in range(len(self.serpent_body)-1, 0, -1):
                self.serpent_body[i].direction = self.serpent_body[i-1].direction
            if self.new_direction:
                self.direction = self.new_direction
                self.serpent_body[0].direction = self.DIR[self.direction]
                self.serpent_body[0].image = pygame.transform.rotate(self.serpent_body[0].images[self.identity+'_head'], self.DEG[self.direction])
                self.new_direction = None
            self.step = 0
        self.segments.update()

    def move_auto(self):
        """Serpent automatic move."""
        def collide(direction):
            direction = self.DIR[direction]
            self.scan_rect.center = (self.serpent_body[0].x+(direction[0]*10), self.serpent_body[0].y+(direction[1]*10))
            obstacles = []
            obstacles.append(self.matrix.edges)
            for serpent in self.matrix.serpent:
                if not self.matrix.serpent[serpent]:
                    continue
                obstacles.append( [self.matrix.serpent[serpent].serpent_body[obj].rect for obj in self.matrix.serpent[serpent].serpent_body] )
            collide = False
            for obstacle in obstacles:
                if self.scan_rect.collidelist(obstacle) != -1:
                    collide = True
                    break
            return collide
        try:
            treat = [treat for treat in self.matrix.treat][0]
        except IndexError:
            treat = None
        if treat and not self.new_direction:
            x, y = self.serpent_body[0].x, self.serpent_body[0].y
            if x <= treat.x and y <= treat.y:
                direct = ('R','D')
            elif x <= treat.x and y >= treat.y:
                direct = ('R','U')
            elif x >= treat.x and y <= treat.y:
                direct = ('L','D')
            elif x >= treat.x and y >= treat.y:
                direct = ('L','U')
            if self.direction not in direct:
                new_direction = []
                for direction in direct:
                    if not collide(direction):
                        new_direction.append(direction)
                if new_direction:
                    self.control(random.choice(new_direction))
        if collide(self.direction):
            self.new_direction = None
            new_direction = []
            if self.direction in ('U','D'):
                for direction in ('L','R'):
                    if not collide(direction):
                        new_direction.append(direction)
            elif self.direction in ('L','R'):
                for direction in ('U','D'):
                    if not collide(direction):
                        new_direction.append(direction)
            if new_direction:
                self.control(random.choice(new_direction))

    def growth(self):
        """Serpent growth."""
        if pygame.sprite.spritecollide(self.serpent_body[0], self.matrix.treat, False, pygame.sprite.collide_mask):
            points = 0
            treat = [treat for treat in self.matrix.treat][0]
            if treat.identity == 'Food':
                if self.growing >= 0:
                    self.growing += 5
                else:
                    points += 5
            elif treat.identity == 'Bonus':
                if len(self.serpent_body) > 10 and self.growing >= 0:
                    self.growing = -(len(self.serpent_body)-10)
                    self.rate = 0
                points += 10
            if points:
                self.set_points(points)
            self.matrix.treat.empty()
        if self.growing:
            self.rate += 1
            if self.rate > 10/self.speed:
                points = 0
                if self.growing > 0:
                    tail = self.serpent_body[len(self.serpent_body)-1]
                    self.grow(tail.x-(tail.direction[0]*10), tail.y-(tail.direction[1]*10), tail.direction, number=1)
                    self.growing -= 1
                    points += 1
                else:
                    tail = len(self.serpent_body)-1
                    self.segments.remove(self.serpent_body[tail])
                    del self.serpent_body[tail]
                    self.growing += 1
                    points += 1
                self.rate = 0
                if points:
                    self.set_points(points)

    def set_points(self, points):
        """Set serpent points."""
        self.matrix.points[self.identity] += points
        interface_panel.set_points(self.identity, self.matrix.points[self.identity])
        if self.matrix.match and not self.matrix.auto:
            if self.matrix.points[self.identity] >= self.matrix.match and not self.growing:
                self.matrix.set_active(False)
                interface_panel.matrix_activate(False)

    def collision(self):
        """Check serpent collision."""
        for serpent in self.matrix.serpent:
            if not self.matrix.serpent[serpent]:
                continue
            for segment in pygame.sprite.spritecollide(self.serpent_body[0], self.matrix.serpent[serpent].segments, False, pygame.sprite.collide_mask):
                if segment not in (self.serpent_body[0], self.serpent_body[1]):
                    return True
        if self.serpent_body[0].rect.collidelist(self.matrix.edges) != -1:
            return True
        return False

    def update(self):
        """Serpent update."""
        if self.active:
            self.move()
            self.growth()
            self.active = not self.collision()
            if not self.active:
                self.serpent_body[0].image = pygame.transform.rotate(self.serpent_body[0].images[self.identity+'_ko'], self.DEG[self.direction])
                if (self.matrix.match or self.matrix.auto):
                    if len(self.serpent_body) > 5:
                        penalty = 5+(len(self.serpent_body)//5)
                        if self.matrix.points[self.identity] - penalty < 0:
                            penalty = self.matrix.points[self.identity]
                        self.set_points(-penalty)
        else:
            if not self.matrix.match and not self.matrix.auto:
                self.alive = False
            else:
                self.pause -= 1
                if not self.pause:
                    self.segments.empty()
                    self.alive = False


class Segment(pygame.sprite.Sprite):
    """
    Serpent segment.
    """
    images = None
    def __init__(self, serpent, position, direction=None, speed=0):
        pygame.sprite.Sprite.__init__(self)
        self.type = {'Serpent1':(0,0,255), 'Serpent2':(255,0,0)}
        if not Segment.images:
            Segment.images = {}
            for species in ('Serpent1', 'Serpent2'):
                Segment.images[species] = pygame.Surface((10,10))
                pygame.draw.circle(Segment.images[species], self.type[species], (5,5), 6, 0)
                Segment.images[species].set_colorkey((0,0,0))
                Segment.images[species+'_head'] = Segment.images[species].copy()
                pygame.draw.line(Segment.images[species+'_head'], (0,255,0), (2,2), (0,5), 3)
                pygame.draw.line(Segment.images[species+'_head'], (0,255,0), (7,2), (9,5), 3)
                Segment.images[species+'_ko'] = Segment.images[species].copy()
                pygame.draw.circle(Segment.images[species+'_ko'], (0,255,0), (2,3), 2, 1)
                pygame.draw.circle(Segment.images[species+'_ko'], (0,255,0), (8,3), 2, 1)
        self.x, self.y = position
        self.direction = direction
        self.speed = speed
        self.image = Segment.images[serpent]
        self.rect = self.image.get_rect(center=(self.x,self.y))
        self.mask = pygame.mask.from_surface(self.image)

    def update(self):
        """Serpent segment update."""
        self.x += self.direction[0]*self.speed
        self.y += self.direction[1]*self.speed
        self.rect.center = self.x, self.y


class Treat(pygame.sprite.Sprite):
    """
    Serpent nourishment.
    """
    images = None
    def __init__(self, matrix):
        pygame.sprite.Sprite.__init__(self)
        self.matrix = matrix
        if not Treat.images:
            Treat.images = {}
            Treat.images['Food'] = pygame.Surface((15,15))
            pygame.draw.circle(Treat.images['Food'], (0,255,0), (10,10), 5, 0)
            Treat.images['Food'].set_colorkey((0,0,0))
            Treat.images['Bonus'] = pygame.Surface((15,15))
            pygame.draw.circle(Treat.images['Bonus'], (255,0,0), (10,10), 5, 0)
            pygame.draw.arc(Treat.images['Bonus'], (0,255,0), (-4,0,15,15), 0, 1, 1)
            Treat.images['Bonus'].set_colorkey((0,0,0))
        placed = False
        while not placed:
            x, y = random.randrange(20,self.matrix.x-20), random.randrange(20,self.matrix.y-130)
            self.x, self.y = x, y
            if random.random() > 0.1:
                self.identity = 'Food'
                self.duration = random.randrange(800,2000)
            else:
                self.identity = 'Bonus'
                self.duration = random.randrange(400,800)
            self.duration //= matrix.level
            self.image = Treat.images[self.identity]
            self.rect = self.image.get_rect(center=(x,y))
            self.mask = pygame.mask.from_surface(self.image)
            disrupt = False
            for serpent in self.matrix.serpent:
                if not self.matrix.serpent[serpent]:
                    continue
                if pygame.sprite.spritecollideany(self, self.matrix.serpent[serpent].segments):
                    disrupt = True
                    break
            if not disrupt:
                placed = True

    def update(self):
        """Nourishment update."""
        self.duration -= 1
        if not self.duration:
            self.matrix.treat.remove(self)


def checkevents(matrix,interface_panel):
    """Check user input."""
    quit = False
    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key in matrix.controls['Key1']:
                matrix.serpent_control(matrix.controls['Key1'][event.key], 'Key1')
            elif event.key in matrix.controls['Key2']:
                matrix.serpent_control(matrix.controls['Key2'][event.key], 'Key2')
            elif event.key == pygame.K_SPACE:
                interface_panel.matrix_activate()
        elif event.type == pygame.QUIT:
            quit = True
    return quit


class InterfaceSerpent(interphase.Interface):
    """
    Program interface.
    """
    def __init__(self, matrix):
        interphase.Interface.__init__(self, position=(250,452), size=(350,100), color=(43,50,58),
            moveable=True, position_offset=(0,95), fixed=True, font_color=(175,180,185),
            control_minsize=(30,30), control_size='min', label_display=True)
        self.set_controls()
        self.directions = { 'U':(0,-1), 'D':(0,1), 'L':(-1,0), 'R':(1,0) }
        self.matrix = matrix
        self.mouse_hover = False
        self.mouse_hover_control = None
        self.pause = False
        self.matrix_active = False

    def add_controls(self):
        """Add interface controls."""
        self.add(
            identity = '__Control',
            control_type = 'function_select',
            position = (50,50),
            size = (55,45),
            control_list = ['Control', 'Serpent Options', 'Program Options', 'Exit'],
            link = [ ['Pad', 'U', 'D', 'L', 'R', 'UL', 'UR', 'DL', 'DR', 'PT', 'PB', 'PL', 'PR', 'Start', 'Serpent1_pts', 'Serpent2_pts'], ['Serpent1', 'Serpent2', '__Ctrl1', '__Ctrl2', 'Match', '__Help'], ['Difficulty', 'Mouse', 'Mode', '__Help'] ],
            link_activated = True,
            control_outline = False)
        self.add(
            identity = 'Start',
            control_type = 'control_toggle',
            position = (250,50),
            size = 'min',
            color = (0,20,30),
            font_color = (30,85,95),
            activated_color = (50,70,90),
            control_list = ['Go'],
            activated_toggle = False,
            control_outline = True,
            label_display = False )
        self.add(
            identity = 'Stop',
            control_type = 'control_toggle',
            position = (50,50),
            size = 'min',
            color = (0,20,30),
            font_color = (30,85,95),
            control_list = ['Stop'],
            label_display = False,
            active = False )
        ctr1='Serpent1', (150,38), ['USER','AI', '-'], ['Serpent Controller']
        ctr2='Serpent2', (225,38), ['-', 'AI','USER'], ['Serpent Controller']
        ctr3='__Ctrl1', (150,62), ['Pad/Key1', 'Pad', 'Key1', 'Key2'], ['Panel/UDLR', 'Panel', 'UDLR', 'QZAS']
        ctr4='__Ctrl2', (225,62), ['Key2', 'Pad/Key1', 'Pad', 'Key1'], ['QZAS', 'Panel/UDLR', 'Panel', 'UDLR']
        ctr5='Match', (300,50), ['__numeric', (0,500,100)], ['Match points']
        for ident, pos, ctrl, tip in (ctr1, ctr2, ctr3, ctr4, ctr5):
            self.add(
                identity = ident,
                control_type = 'control_toggle',
                position = pos,
                size = 'min_width',
                control_list = ctrl,
                tip_list = tip,
                loop = True)
        ctr=('U',(175,25),'__^'), ('D',(175,75),'__v'), ('L',(150,50),'__<'), ('R',(200,50),'__>')
        for ident, pos, ctrl in ctr:
            self.add(
                identity = ident,
                control_type = 'control_toggle',
                position = pos,
                size = (25,25),
                control_list = [ctrl],
                color = (0,20,30),
                activated_color = (50,70,90),
                control_outline = True,
                label_display = False,
                control_response = 1000 )
        ctr=('Pad',(175,50),(25,25)), ('UL',(150,25),(25,25)), ('UR',(200,25),(25,25)), ('DL',(150,75),(25,25)), ('DR',(200,75),(25,25)), ('PT',(175,10),(85,5)), ('PB',(175,90),(85,5)), ('PL',(135,50),(5,75)), ('PR',(215,50),(5,75))
        for ident, pos, dim in ctr:
            self.add(
                identity = ident,
                control_type = 'control_toggle',
                position = pos,
                size = dim,
                control_list = [''],
                control_image = 'none',
                control_outline = False,
                label_display = False )
        for ident, pos in ( ('Serpent1_pts',(325,15)), ('Serpent2_pts',(325,33)) ):
            self.add(
                identity = ident,
                control_type = 'control_toggle',
                control_image = 'none',
                size = (41,19),
                color = (25,35,45),
                fill = 2,
                position = pos,
                control_list = [''],
                label_display = False)
        ctr1='Difficulty', 'control_select', (175,50), ['__numeric', (1,4)], ['Difficulty Mode']
        ctr2='Mode', 'control_toggle', (250,30), ['SCR','USR'], ['Screen coordinates', 'Serpent coordinates']
        ctr3='Mouse', 'control_toggle', (250,75), ['OFF','ON'], ['Mouse Hover']
        for ident, ctrl_type, pos, ctrl, tip in (ctr1, ctr2, ctr3):
            self.add(
                identity = ident,
                control_type = ctrl_type,
                position = pos,
                control_list = ctrl,
                tip_list = tip)
        self.add(
            identity = '__Help',
            control_type = 'control_toggle',
            position = (335,85),
            size = 'auto',
            color = (0,20,30),
            font_color = (0,120,160),
            control_outline = True,
            control_list = ['?'] )

    def set_controls(self):
        """Set control specifics."""
        controls = self.get_control()
        controls['Difficulty'].set_value(2)
        controls['__Ctrl2'].set_value('-')
        controls['__Ctrl2'].set_enabled(False)
        controls['Serpent1'].set_label_text(font_color=(0,0,200))
        controls['Serpent2'].set_label_text(font_color=(170,0,0))
        controls['Serpent1_pts'].set_enabled(False)
        controls['Serpent2_pts'].set_enabled(False)
        controls['Match'].set_value('-')
        controls['Match'].set_enabled(False)
        self.control_design()

    def control_design(self):
        """Draw controls."""
        img = pygame.Surface((31,31))
        pygame.draw.polygon(img, (30,85,95), [(0,30),(15,0),(30,30),(0,30)], 0)
        for ctrl, opt, deg in ( ('U','__^',0), ('D','__v',180), ('L','__<',90), ('R','__>',-90) ):
            icon = pygame.transform.rotate(img, deg)
            self.get_control(ctrl).set_list_icon([opt], surface=[icon], color_key=(0,0,0), icon_size=(8,8))
        for ctrl, color in ( ('Serpent1_pts',(0,0,80)), ('Serpent2_pts',(80,0,0)) ):
            img = pygame.Surface((41,19))
            img.fill((10,20,30))
            pygame.draw.rect(img, color, (2,2,38,16), 1)
            self.get_control(ctrl).set_control_image(surface=img)

    def matrix_activate(self, activate=True):
        """Activate Serpent Duel."""
        if not self.get_control('Start').is_active():
            return
        if activate:
            if not self.matrix_active:
                self.get_control('__Control').set_active(False)
                self.get_control('Start').set_activated(True)
                self.get_control('Stop').set_active(False)
                if self.get_control('Serpent1').get_value() == 'USER' or self.get_control('Serpent2').get_value() == 'USER':
                    if not self.is_moveable('Fixed'):
                        self.set_moveable('Fixed')
                else:
                    if self.is_moveable('Fixed'):
                        self.set_moveable('Fixed')
                if not self.pause:
                    self.matrix.set_active(True)
                    self.pause = True
                else:
                    self.matrix.set_active(True, pause=True)
                self.matrix_active = True
            else:
                if not self.is_moveable('Fixed'):
                    self.set_moveable('Fixed')
                self.matrix.set_active(False, pause=True)
                self.get_control('Start').set_activated(False)
                self.get_control('Stop').set_active(True)
                self.matrix_active = False
        else:
            self.matrix.set_active(False)
            self.get_control('Start').set_activated(False)
            self.get_control('Stop').set_active(False)
            self.get_control('__Control').set_active(True)
            if not self.is_moveable('Fixed'):
                self.set_moveable('Fixed')
            self.pause = False
            self.matrix_active = False

    def set_points(self, identity, points):
        """Set points in panel."""
        if self.get_control(identity).get_value() != '-':
            self.get_control(identity+'_pts').set_value(points)
        else:
            self.get_control(identity+'_pts').set_value('')

    def update(self):
        """Interface update."""
        state = interphase.Interface.update(self)
        if state.control:
            if state.control in ('U','D','L','R'):
                self.matrix.serpent_control(state.control)
            elif state.control == 'Start':
                self.matrix_activate()
            elif state.control == 'Stop':
                self.matrix_activate(False)
            elif state.control in ('Serpent1', 'Serpent2'):
                if state.controls['Serpent1'].get_value() == '-' and state.controls['Serpent2'].get_value() == '-':
                    state.value = state.controls[state.control].next()
                if state.value == '-' or state.value == 'AI':
                    self.matrix.set_mode(state.control, state.value)
                    state.controls['__Ctrl'+state.control[-1:]].set_value('-')
                    state.controls['__Ctrl'+state.control[-1:]].set_enabled(False)
                    self.matrix.set_control(state.control, '-')
                else:
                    self.matrix.set_mode(state.control, state.value)
                    state.controls['__Ctrl'+state.control[-1:]].reset(change_index=False)
                    state.controls['__Ctrl'+state.control[-1:]].set_enabled(True)
                    self.matrix.set_control(state.control, state.controls['__Ctrl'+state.control[-1:]].get_value())
                    if state.controls['Serpent1'].get_value() == 'USER' and state.controls['Serpent2'].get_value() == 'USER':
                        for key, ctrl in self.get_control('__Ctrl1', '__Ctrl2').iteritems():
                            if ctrl.get_value() == 'Pad/Key1':
                                ctrl.next()
                                self.matrix.set_control('Serpent'+key[-1:], ctrl.get_value())
                    if state.controls['__Ctrl1'].get_value() == state.controls['__Ctrl2'].get_value():
                        value = state.controls['__Ctrl'+state.control[-1:]].next()
                        if value == 'Pad/Key1':
                            value = state.controls['__Ctrl'+state.control[-1:]].next()
                        self.matrix.set_control(state.control, value)
                ctrl = self.get_control('Serpent1', 'Serpent2')
                if ctrl['Serpent1'].get_value() == 'AI' or ctrl['Serpent2'].get_value() == 'AI':
                    if ctrl['Serpent1'].get_value() == 'AI' and ctrl['Serpent2'].get_value() != 'USER':
                        self.matrix.set_control('Serpent1', 'Pad')
                    elif ctrl['Serpent2'].get_value() == 'AI' and ctrl['Serpent1'].get_value() != 'USER':
                        self.matrix.set_control('Serpent2', 'Pad')
                ctrls = ctrl['Serpent1'].get_value(), ctrl['Serpent2'].get_value()
                if 'USER' not in ctrls or '-' in ctrls:
                    state.controls['Match'].set_value('-')
                    state.controls['Match'].set_enabled(False)
                else:
                    state.controls['Match'].reset(change_index=False)
                    if state.controls['Match'].get_value() == 0:
                        state.controls['Match'].set_value('-')
                    state.controls['Match'].set_enabled(True)
            elif state.control in ('__Ctrl1', '__Ctrl2'):
                if state.controls['Serpent1'].get_value() == 'USER' and state.controls['Serpent2'].get_value() == 'USER':
                    if state.value == 'Pad/Key1':
                        state.value = state.controls[state.control].next()
                    if state.controls['__Ctrl1'].get_value() == state.controls['__Ctrl2'].get_value():
                        state.value = state.controls[state.control].next()
                        if state.value == 'Pad/Key1':
                            state.value = state.controls[state.control].next()
                self.matrix.set_control('Serpent'+state.control[-1:], state.value)
            elif state.control == 'Match':
                if state.value > 0:
                    self.matrix.match = state.value
                else:
                    self.matrix.match = state.value
                    state.controls['Match'].set_value('-')
            elif state.control == 'Mode':
                self.matrix.set_control_mode(state.value)
            elif state.control == 'Difficulty':
                self.matrix.set_difficulty( int(state.value) )
            elif state.control == 'Mouse':
                self.mouse_hover = not self.mouse_hover
                self.set_pointer_interact()
            elif state.control == '__Help':
                self.set_tips_display()
            elif state.control == '__Control':
                if state.button == '__Control' and state.value == 'Exit':
                    self.deactivate()
        elif state.control_interact and self.mouse_hover:
            if state.control_interact != self.mouse_hover_control:
                self.mouse_hover_control = state.control_interact
                if state.control_interact in ('U','D','L','R'):
                    self.matrix.serpent_control(state.control_interact)


def setup(x=500,y=500,screen=None):
    global interface_panel
    pygame.display.init()   #pygame.init()
    pygame.display.set_caption('Serpent Duel')
    if not screen:
        screen = pygame.display.set_mode((x,y))
    background = pygame.Surface((x,y))
    matrix = Matrix(x,y,screen,background)
    interface_panel = InterfaceSerpent(matrix)
    panel = pygame.sprite.RenderUpdates(interface_panel)
    return matrix, panel, interface_panel


def program_exec(matrix, panel, interface_panel):
    matrix.update_rect = []
    matrix.update()
    panel.update()
    quit = checkevents(matrix,interface_panel)
    if interface_panel.is_active() and not quit:
        panel.clear(matrix.screen, matrix.background)
        matrix.update_rect.extend( panel.draw(matrix.screen) )
        pygame.display.update(matrix.update_rect)
        matrix.clock.tick(40)
        run = True
    else:
        run = False
    return run


def main():
    matrix, panel, interface_panel = setup()
    run = True
    while run:
        run = program_exec(matrix, panel, interface_panel)

if __name__ == '__main__':
    main()

