Interphase Pack
Copyright (C) 2010 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Interphase Pack version 1.1
Download Site: http://gatc.ca
Source:        InterphasePack.zip
Executable:
    Linux:      InterphasePack_exe.tar.gz
    Windows:    InterphasePack_exe.zip

Interphase Module
Source:        Interphase.zip

Dependencies:

    Python 2.5:   http://www.python.org/
    Pygame 1.8:   http://www.pygame.org/

Description:

Interphase Pack includes the programs Serpent Duel, Pod Descent, and
Sliding Control Puzzle. The interfaces in the programs were designed
using the Interphase module, which facilitates coding interface panel
functionality for Pygame applications, and the latest version is
available from http://gatc.ca. The source code of the programs,
serpentduel.py, poddescent.py, and slidingcontrol.py, can be used to
demonstrate the module's functionality. The source requires Python
and Pygame to execute, and run with 'python pack.py'. Also available
are executables that have Python dependencies included, and run with
'./pack' (Linux) or 'pack.exe' (Windows). Use config.ini if need to
setup display gamma.

