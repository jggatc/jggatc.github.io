#!/usr/bin/env python

from tests import demo

demo.main()

