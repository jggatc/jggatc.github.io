"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
from java.awt.image import BufferedImage
from surface import Surface


class Surfarray(object):
    def __init__(self):
        self.initialized = False
    def init(self):
        global Numeric
        try:
            import Numeric      #JNumeric
        except ImportError:
            raise ImportError, "JNumeric module is required."
        #JNumeric doesn't work on Jython2.2.1
        #JNumeric updated to work on Jython2.5.2:
        #https://bitbucket.org/zornslemon/jnumeric-ra/
        self.initialized = True
    def use_arraytype(self, mode=None):
        pass
    def blit_array(self, surface, array):
        """
        Generates image pixels from a JNumeric array.
        Arguments include the surface generate the image, and an array of integer colors.
        """
        if not self.initialized:
            self.init()
        w,h = array.shape
        data = Numeric.reshape(array, (1,w*h))[0]
        if not surface.getColorModel().hasAlpha():
            surface.setRGB(0, 0, surface.width, surface.height, data, 0, surface.width)
        else:
            surf = Surface((w,h), BufferedImage.TYPE_INT_RGB)
            surf.setRGB(0, 0, surface.width, surface.height, data, 0, surface.width)
            g2d = surface.createGraphics()
            g2d.drawImage(surf, 0, 0, None)
            g2d.dispose()
        return None

