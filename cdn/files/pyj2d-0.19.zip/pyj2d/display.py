"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
from javax.swing import JFrame, JPanel
from java.awt import Color, Dimension, Toolkit
from java.awt.image import BufferedImage
from java.awt.event import MouseListener
from java.awt.event import MouseMotionListener
from java.awt.event import KeyListener
import pyj2d.event
import pyj2d.surface
import pyj2d.env


class Frame(JFrame, MouseListener, MouseMotionListener, KeyListener):

    def __init__(self, title, size):
        JFrame.__init__(self, title)
        self.setDefaultCloseOperation(self.EXIT_ON_CLOSE)
        self.setResizable(False)
        self.setSize(size[0],size[1])
        self.setDefaultLookAndFeelDecorated(True)
        self.setBackground(Color.BLACK)
        self.jpanel = Panel(size)
        self.getContentPane().add(self.jpanel)
        self.pack()
        self.addMouseListener(self)
        self.addMouseMotionListener(self)
        self.addKeyListener(self)
        self.event = pyj2d.event

    def mousePressed(self, event):
        self.event.mousePress = event
        self.event.updateQueue(event)

    def mouseReleased(self, event):
        self.event.mousePress = None
        self.event.updateQueue(event)

    def mouseEntered(self, event):
        pass

    def mouseExited(self, event):
        self.event.mousePress = None

    def mouseClicked(self, event):
        pass

    def mouseMoved(self, event):
        self.event.updateQueue(event)

    def mouseDragged(self, event):
        pass

    def keyPressed(self, event):
        self.event.updateQueue(event)

    def keyReleased(self, event):
        self.event.updateQueue(event)

    def keyTyped(self, event):
        pass


class Panel(JPanel):

    def __init__(self, size):
        JPanel.__init__(self)
        self.setPreferredSize(Dimension(size[0],size[1]))
        self.surface = pyj2d.surface.Surface(size, BufferedImage.TYPE_INT_RGB)
        self.setBackground(Color.BLACK)

    def paintComponent(self, g2d):
        self.super__paintComponent(g2d)
        g2d.drawImage(self.surface, 0, 0, None)
        try:
            Toolkit.getDefaultToolkit().sync()
        except:
            pass


class Display(object):

    def init(self):
        self.caption = ''
        self.icon = None

    def set_mode(self, size):
        """
        Return a display Surface.
        """
        if pyj2d.env.japplet:
            self.jframe = pyj2d.env.japplet
        else:
            self.jframe = Frame(self.caption, size)
        pyj2d.env.jframe = self.jframe
        self.jpanel = self.jframe.jpanel
        self.surface = self.jpanel.surface
        self.surface._display = self
        self.surface._g2d = self.jpanel.surface.createGraphics()
        self.surface._g2d.setBackground(Color.BLACK)
        self.clear()
        self.jframe.setVisible(True)
        return self.surface

    def get_surface(self):
        """
        Return display Surface.
        """
        return self.surface

    def get_frame(self):
        """
        Return JFrame or JApplet.
        """
        return self.jframe

    def quit(self):
        try:
            self.surface._g2d.dispose()
        except:
            pass

    def get_init(self):
        return True

    def set_caption(self, caption):
        """
        Set display caption.
        """
        self.caption = caption

    def set_icon(self, icon):
        self.icon = icon

    def clear(self):
        """
        Clear display surface.
        """
        w, h = self.surface.getWidth(), self.surface.getHeight()
        self.surface._g2d.setColor(Color.BLACK)
        self.surface._g2d.fillRect(0,0,w,h)

    def flip(self):
        """
        Repaint display.
        """
        self.jpanel.repaint()

    def update(self, rect_list=None):
        """
        Repaint display.
        An optional rect_list to specify regions to repaint.
        """
        try:
            for rect in rect_list:
                try:
                    self.jpanel.repaint(rect.x,rect.y,rect.width,rect.height)
                except AttributeError:
                    self.jpanel.repaint(rect[0],rect[1],rect[2],rect[3])
        except:
            self.jpanel.repaint()

