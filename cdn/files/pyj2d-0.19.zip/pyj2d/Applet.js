<div id="demo">
<script type="text/javascript">// <![CDATA[
document.getElementById('demo').innerHTML = '<applet width="400" height="300" code="Applet.class" archive="http://www.website.com/apps/Pyj2d_Applet.jar,http://www.website.com/apps/apps/jython.jar" alt="To use this applet, you need a Java virtual machine (Java plug-in) for your web browser.">';
// ]]></script>
</div>

