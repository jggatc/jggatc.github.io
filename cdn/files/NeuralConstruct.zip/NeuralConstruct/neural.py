#!/usr/bin/env python
from __future__ import division

"""
Neural Construct
Copyright (C) 2009 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Neural Construct version 1.12
Download Site: http://gatc.ca

Dependencies:
    Python 2.5:   http://www.python.org/
    PyGame 1.8:   http://www.pygame.org/
    Psyco:        http://psyco.sourceforge.net/
"""

import pygame
from pygame.locals import *
from pygame import bufferproxy
import random
import os
import sys
try:
    import psyco
    psyco.full()
except ImportError:
     print("Warning: Psyco module recommended.")
import interphase      #interface control

test = False
if not test:
    import warnings
    warnings.filterwarnings("ignore")

class Matrix(object):
    """
    Generate a matrix of neuron connections responsive to stimuli.
    """
    def __init__(self, width, height, neuron_size=16, neuron_image=None):
        self.matrix_x = width
        self.matrix_y = height
        self.screen = pygame.display.get_surface()
        self.screen_cell = pygame.Surface((width,height))
        self.screen_signal = pygame.display.get_surface()
        self.neurons = pygame.sprite.RenderUpdates()
        self.neuron_select = pygame.sprite.RenderUpdates()  #group of neurons selected
        self.neuron_update = pygame.sprite.RenderUpdates()  #neurons to update
        self.populate_neurons(neuron_size, neuron_image)
        self.network_display = False
        self.neuron_activity_pause = False
        self.show_select = True     #show the selected neurons
        self.neuron_types = True    #show both neuron types or just one type
        self.neuron_displayed = True
        self.panel = InterfaceMatrix((width,height))
        self.panel_group = pygame.sprite.RenderUpdates(self.panel)
        self.panel_display = True
        self.update_list = []   #list of rect to update on display
    def populate_neurons(self, neuron_size, neuron_image):
        if neuron_size == 16:
            z = 10
            zz = 1
        elif neuron_size == 4:
            z = 2
            zz = 5
        matrix_dimension = { 'x':self.matrix_x*zz, 'y':self.matrix_y*zz }
        for x in xrange((self.matrix_x//z)):
            for y in xrange((self.matrix_y//z)):
                neuron_id = (x,y)
                nerve = Neuron(neuron_id, x, y, matrix_dimension, neuron_size, neuron_image)
                self.neurons.add(nerve)
        self.neuron_display()
    def neuron_display(self, neuron=True):
        if neuron:
            self.neuron_displayed = True
            for cell in self.neurons:
                cell.respond = False
                cell.response()
            self.neurons.draw(self.screen_cell)
            self.screen.blit(self.screen_cell,(0,0))
            pygame.display.flip()
        else:
            self.neuron_displayed = False
            self.screen_cell.fill((12,14,19))
            self.screen.blit(self.screen_cell,(0,0))
            pygame.display.flip()
    def empty(self):
        for neuron in self.neurons:
            neuron.kill()
            del neuron
        Neuron.neural_net = {}
        Neuron.image = {}
        Neuron.random_firing = 0
        Neuron.response_speed = 3
        Neuron.refraction_duration = 50
        Neuron.dampening = 0
        Neuron.learning = False
        Neuron.net_termini = (0,0)
        del self.neurons
        del self.neuron_update
        del self.screen
        del self.screen_cell
        del self.screen_signal
        del self.update_list
    def clear_memory(self):
        for neuron in self.neurons:
            neuron.clear_memory()
    def neuron_stimulate(self, x, y):
        for neuron in self.neurons:
            if neuron.rect.collidepoint(x, y):
                neuron.stimuli()
                nerves = pygame.sprite.spritecollide(neuron, self.neurons, False)
                for nerve in nerves:
                    if nerve != self:
                        pass
                break
    def neuron_deactivate(self,x, y, set_neuron=True):
        if set_neuron:
            for neuron in self.neurons:
                if neuron.rect.collidepoint(x, y):
                    neuron.deactivated = True
                    if self.show_select:
                        rect = pygame.draw.circle(self.screen, (255,0,0), neuron.rect.center, 1, 1)
                        pygame.display.update(rect)
                    break
        else:
            for neuron in self.neurons:
                if neuron.rect.collidepoint(x, y):
                    neuron.deactivated = False
                    break
            self.neuron_select.add(neuron)
            self.neuron_select.update()
            rect = self.neuron_select.draw(self.screen_signal)
            pygame.display.update(rect)
            self.neuron_select.remove(neuron)
    def set_net_termini(self, x, y):
        for neuron in self.neurons:
            if neuron.rect.collidepoint(x, y):
                Neuron.net_termini = neuron.identity
                break
    def set_neuron_twitcher(self, x, y, set_neuron=True):
        if set_neuron:
            for neuron in self.neurons:
                if neuron.rect.collidepoint(x, y):
                    neuron.twitcher = True
                    neuron.stimuli()
                    if self.show_select:
                        rect = pygame.draw.circle(self.screen, (255,0,0), neuron.rect.center, 1, 1)
                        pygame.display.update(rect)
                    break
        else:
            for neuron in self.neurons:
                if neuron.rect.collidepoint(x, y):
                    neuron.twitcher = False
                    break
            self.neuron_select.add(neuron)
            self.neuron_select.update()
            rect = self.neuron_select.draw(self.screen_signal)
            pygame.display.update(rect)
            self.neuron_select.remove(neuron)
    def update(self):
        self.update_list = []
        if self.panel_display:
            self.panel_group.clear(self.screen_signal, self.screen_cell)
        if not self.neuron_activity_pause:
            self.neurons.update()
            self.neuron_update.clear(self.screen_signal, self.screen_cell)
            self.update_list.extend(self.neuron_update.draw(self.screen_signal))
            self.neuron_update.empty()
        if self.panel_display:
            self.panel_group.update()
            self.update_list.extend(self.panel_group.draw(self.screen_signal))
        pygame.display.update(self.update_list)

class Neuron(pygame.sprite.Sprite):
    """State of individual neuron."""
    neural_net = {}
    image = {}
    size = 16
    random_firing = 0
    response_speed = 3
    refraction_duration = 50
    dampening = 0
    learning = False        #learn network path
    net_termini = (0,0)     #terminal neuron of a network
    def __init__(self, identity, x, y, matrix_dimension, size=16, neuron_image=None):
        pygame.sprite.Sprite.__init__(self)
        self.identity = identity       #neuron id
        Neuron.neural_net[identity] = self
        Neuron.size = size
        self.size = size
        self.x, self.y = self.nerve_position(x,y)
        self.location = self.x, self.y
        if not Neuron.image:    #load images on first instance
            self.initiate_neuron()
        if neuron_image:
            self.set_neuron(neuron_image)
        self.image = Neuron.image[self.size]['Resting']
        self.rect = self.image.get_rect(center=self.location)
        self.response_type = random.choice(('Response_type1', 'Response_type2'))    #neuron type
        self.image_stimulated = Neuron.image[self.size][self.response_type]
        self.grid = self.grid_network(x,y,matrix_dimension)
        self.response_threshold = 100   #threshold at which will fire
        self.connecting_neurons = []    #list of interconnected neurons
        self.response_stimuli = None    #stimuli to which it responds
        self.sensitized = False         #sensitized to stimuli
        self.respond = False
        self.stimuli_type = self.response_type   #neuron type that stimulates
        self.signal_strength = 100
        self.stimuli_neuron = None  #neuron identity that stimulates
        self.deactivated = False    #neuron unresponsive
        self.twitcher = False   #twitching neuron
        self.count = 0
        self.network = None
    def initiate_neuron(self):
        img_s = {}
        img_l = {}
        image = load_image('cell.png')
        img_s['Resting'] = pygame.transform.smoothscale(image, (4,4))
        img_l['Resting'] = pygame.transform.smoothscale(image, (16,16))
        image = load_image('cell_r1.png')
        img_s['Response_type1'] = pygame.transform.smoothscale(image, (4,4))
        img_l['Response_type1'] = pygame.transform.smoothscale(image, (16,16))
        image = load_image('cell_r2.png')
        img_s['Response_type2'] = pygame.transform.smoothscale(image, (4,4))
        img_l['Response_type2'] = pygame.transform.smoothscale(image, (16,16))
        image = load_image('cell_r3.png')
        img_s['Response_type3'] = pygame.transform.smoothscale(image, (4,4))
        img_l['Response_type3'] = pygame.transform.smoothscale(image, (16,16))
        Neuron.image[4] = img_s
        Neuron.image[16] = img_l
    def set_neuron(self, neuron_image):
        Neuron.image[16]['Resting'] = neuron_image['Resting'].copy()
        Neuron.image[16]['Response_type1'] = neuron_image['Active-1'].copy()
        Neuron.image[16]['Response_type2'] = neuron_image['Active-2'].copy()
        Neuron.image[16]['Response_type3'] = neuron_image['Network'].copy()
        Neuron.image[4]['Resting'] = pygame.transform.smoothscale(neuron_image['Resting'].copy(), (4,4))
        Neuron.image[4]['Response_type1'] = pygame.transform.smoothscale(neuron_image['Active-1'].copy(), (4,4))
        Neuron.image[4]['Response_type2'] = pygame.transform.smoothscale(neuron_image['Active-2'].copy(), (4,4))
        Neuron.image[4]['Response_type3'] = pygame.transform.smoothscale(neuron_image['Network'].copy(), (4,4))
    def nerve_position(self, x, y):
        position_x = int( (x * (self.size*0.75)) + (((y)%2)*(self.size*0.375)) )
        position_y = int( (y * (self.size*0.75)) )
        return position_x, position_y
    def grid_network(self, grid_x, grid_y, dim):
        grid = [(grid_x+x,grid_y+y) for x in [-1,0,1] for y in [-1,0,1] if grid_x+x>-1 and grid_x+x<dim['x']//10 and grid_y+y>-1 and grid_y+y<dim['y']//10]      #adjacent neurons
        random.shuffle(grid)   #randomize order of checking
        return grid
    def signal_conduct(self, normal=True):
        if normal:
            if not self.network:
                for effect in xrange(random.choice((1,8))):
                    next_neuron = random.choice(self.grid)
                    pass_signal = Neuron.neural_net[next_neuron].stimuli(self)
                    if pass_signal:
                        self.signal_strength -= Neuron.dampening
            else:
                if self.identity != Neuron.net_termini:
                    pass_signal = Neuron.neural_net[self.network].stimuli(self)
                else:
                    pass_signal = False
            return pass_signal
        else:
            network = self.grid[:]
            for effect in xrange(random.choice((1,3))):
                while True:
                    try:
                        next_neuron = random.choice(network)
                        network.remove(next_neuron)
                        pass_signal = Neuron.neural_net[next_neuron].stimuli(self)
                        if pass_signal:
                            break
                    except IndexError:
                        return
    def stimuli(self, neuron=None):
        if not self.sensitized and not self.respond:
            if neuron:
                self.stimuli_type = neuron.stimuli_type
                self.stimuli_neuron = neuron.identity
                if neuron.signal_strength > 0:
                    self.signal_strength = neuron.signal_strength
                    self.response_stimuli = True
            else:
                self.stimuli_neuron = None
                self.response_stimuli = True
            return True
        else:
            return False
    def response(self):
        if not self.respond:
            self.image = Neuron.image[self.size]['Resting']
            self.rect = self.image.get_rect(center=self.location)
            self.stimuli_type = self.response_type
            self.signal_strength = 100
            return False
        else:
            if not self.network:
                if matrix.neuron_types:
                    self.image = Neuron.image[self.size][self.stimuli_type]
                else:
                    self.image = Neuron.image[self.size]['Response_type1']
                self.rect = self.image.get_rect(center=self.location)
            else:
                self.image = Neuron.image[self.size]['Response_type3']
                self.rect = self.image.get_rect(center=self.location)
            return True
    def self_firing(self):
        if Neuron.random_firing and random.random() < Neuron.random_firing:
            self.stimuli_neuron = None
            return True
        else:
            return False
    def learn(self):
        if self.identity == Neuron.net_termini and self.respond and self.stimuli_neuron:
            self.network = Neuron.net_termini
            Neuron.neural_net[self.stimuli_neuron].set_network(self.identity)
            self.respond = False
            self.stimuli_neuron = None
            return True
        else:
            return False
    def set_network(self, neuron_id):
        if not self.network:
            self.network = neuron_id
        if self.stimuli_neuron and (self.respond or self.sensitized) and self.identity != Neuron.net_termini:
            Neuron.neural_net[self.stimuli_neuron].set_network(self.identity)
    def clear_memory(self):
        self.network = []
    def update(self):
        if self.deactivated:
            if matrix.show_select:
                rect = pygame.draw.circle(matrix.screen, (255,0,0), self.rect.center, 1, 1)
                matrix.update_list.append(rect)
            return
        if not self.response_stimuli and not Neuron.random_firing and not self.respond and not self.sensitized:
            return
        if matrix.network_display:
            if not self.network:
                return
        if Neuron.learning and self.learn():
            update_neuron = self.response()
            if update_neuron:
                matrix.neuron_update.add(self)
            return
        update_neuron = False
        if ( self.response_stimuli or self.self_firing() ) and not self.respond and not self.sensitized:
            self.response_stimuli = False
            self.respond = True
            self.count = 3
            update_neuron = self.response()
        else:
            self.response_stimuli = False
        if self.respond:
            if self.count == Neuron.response_speed:
                self.signal_conduct()
            self.count -= 1
            if not self.count:
                self.respond = False
                self.sensitized = True
                self.count = Neuron.refraction_duration
                self.response()
        if update_neuron:
            matrix.neuron_update.add(self)
        if self.sensitized:
            self.count -= 1
            if not self.count:
                self.sensitized = False
        if self.twitcher:
            self.stimuli()
            if matrix.show_select:
                rect = pygame.draw.circle(matrix.screen, (255,0,0), self.rect.center, 1, 1)
                matrix.update_list.append(rect)
        return

def load_image(file_name, frames=1, path='data', colorkey=None, errorhandle=True):
    #Modified from PygameChimpTutorial
    full_name = os.path.join(path, file_name)
    try:
        if frames == 1:
            image = pygame.image.load(full_name)
        elif frames > 1:
            images = []
            image = pygame.image.load(full_name)
            width, height = image.get_size()
            width = width // frames
            for frame in xrange(frames):
                frame_num = width * frame
                image_frame = image.subsurface((frame_num,0), (width,height)).copy()
                images.append(image_frame)
            return images
    except pygame.error, message:
        if errorhandle:
            raise SystemExit, message
        else:
            print(message)
            return None
    if image.get_alpha():
        image = image.convert_alpha()
    else:
        image = image.convert()
    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0,0))
        image.set_colorkey(colorkey, RLEACCEL)
    return image

class InterfaceMatrix(interphase.Interface):
    def __init__(self, matrix_size):
        interphase.Interface.__init__(self, position=(matrix_size[0]//2,matrix_size[1]-50), image='panel.png', color=(0,5,10), size=(350,100), moveable=True, position_offset=(0,95), screen=matrix_size, button_image=['button.png'], control_image=['control.png'], control_minsize=(25,25), pointer_move=True, label_display=True)
        self.set_color = False
        self.initialize()
    def add_controls(self):
        self.add(
            identity = '__Control',
            control_type = 'function_select',
            position = (50,50), 
            control_list = ['Neuron Response', 'Neuron Learning', 'Neuron Display', 'Neuron Color', 'Program Help'],
            link = [ ['Response', 'Refraction', 'Firing', 'Dampening'], 
                    ['Learning', 'Memory', 'Network'],
                    ['Neuron', 'Type', 'Selected', 'Pause'],
                    ['Neuron Type', 'RGB', 'Color', '__Set', '__Reset'],
                    ['__Keys'] ])
        self.add(
            identity = '__Neuron_Stimulate',
            control_type = 'control_toggle',
            position = (130,40),
            size = 'auto_width',
            control_list = ['Stimulate', 'Twitcher', 'Deactivate', 'Termini'],
            tip_list = ['Neuron Stimulate', 'Neuron Twitcher', 'Neuron Deactivate', 'Neuron Termini'])
        self.add(
            identity = '__Stimulate_Mod',
            control_type = 'control_toggle',
            position = (130,60),
            size = 'auto_width',
            control_list = ['False', 'True'],
            tip_list = ['Stimulate Mod'])
        self.add(
            identity = 'Firing',
            control_type = 'control_toggle',
            position = (270,35),
            control_list = ['OFF', 'ON'],
            tip_list = ['Random Firing'])
        self.add(
            identity = 'Dampening',
            control_type = 'control_toggle',
            position = (270,75),
            control_list = ['OFF', 'ON'],
            tip_list = ['Signal Dampening'])
        self.add(
            identity = 'Response',
            control_type = 'control_select',
            position = (200,35),
            control_list = ['__numeric', (1,3)],
            tip_list = ['Neuron Response'])
        self.add(
            identity = 'Refraction',
            control_type = 'control_select',
            position = (200,75),
            control_list = ['__numeric', (5,50,5)],
            tip_list = ['Neuron Refraction'])
        self.add(
            identity = 'Learning',
            control_type = 'control_toggle',
            position = (200,35),
            control_list = ['OFF', 'ON'],
            tip_list = ['Learning Mode'])
        self.add(
            identity = 'Network',
            control_type = 'control_toggle',
            position = (200,75),
            control_list = ['OFF', 'ON'],
            tip_list = ['Network Displayed'])
        self.add(
            identity = 'Memory',
            control_type = 'control_toggle',
            position = (270,60),
            size = 'auto_width',
            control_list = ['Clear'],
            tip_list = ['Clear Memory'],
            control_outline = True)
        self.add(
            identity = 'Neuron',
            control_type = 'control_toggle',
            position = (200,35),
            control_list = ['ON', 'OFF'],
            tip_list = ['Neuron Displayed'])
        self.add(
            identity = 'Type',
            control_type = 'control_toggle',
            position = (200,75),
            control_list = ['2', '1'],
            tip_list = ['Neuron Types'])
        self.add(
            identity = 'Selected',
            control_type = 'control_toggle',
            position = (270,35),
            control_list = ['ON', 'OFF'],
            tip_list = ['Neuron Selected'])
        self.add(
            identity = 'Pause',
            control_type = 'control_toggle',
            position = (270,75),
            control_list = ['OFF', 'ON'],
            tip_list = ['Pause Activity'])
        self.add(
            identity = 'Neuron Type',
            control_type = 'control_toggle',
            position = (205,30),
            size = 'auto_width',
            control_list = ['Resting', 'Active-1', 'Active-2', 'Network'],
            tip_list = ['Resting Neuron', 'Active-1 Neuron', 'Active-2 Neuron', 'Network Neuron'],
            label_display = False)
        self.add(
            identity = 'RGB',
            control_type = 'control_toggle',
            position = (275,30),
            control_list = ['R','G','B'],
            tip_list = ['RGB Color'],
            label_display = False)
        self.add(
            identity = 'Color',
            control_type = 'control_select',
            position = (275,60),
            control_list = ['__numeric', (0,255)],
            tip_list = ['Neuron Color'],
            label_display = False)
        self.add(
            identity = '__Reset',
            control_type = 'control_toggle',
            position = (225,85),
            size = 'min_width',
            control_list = ['reset'],
            control_outline = True,
            tip_list = ['Reset Color'],
            label_display = False)
        self.add(
            identity = '__Set',
            control_type = 'control_toggle',
            position = (195,85),
            size = 'min_width',
            control_list = ['set'],
            control_outline = True,
            tip_list = ['Set Color'],
            label_display = False)
        self.add(
            identity = '__Keys',
            control_type = 'control_toggle',
            position = (235,50),
            size = (46,22),
            control_list = ['Controls'],
            tip_list = ['Control Info'])
        self.add(
            identity = '__Fix',
            control_type = 'control_toggle',
            position = (315,90),
            size = 'auto',
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['!'],
            control_image = ['None'],
            control_outline = True)
        self.add(
            identity = '__Help',
            control_type = 'control_toggle',
            position = (335,90),
            size = 'auto',
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['?'],
            control_image = ['None'],
            control_outline = True)
    def initialize(self):
        ctrl = self.get_control()
        ctrl['Response'].set_value(Neuron.response_speed)
        ctrl['Refraction'].set_value(Neuron.refraction_duration)
    def set_panel_value(self, control):
        ctrl = self.get_control()
        if control == 'Response':
            ctrl['Response'].set_value(Neuron.response_speed)
        elif control == 'Refraction':
            ctrl['Refraction'].set_value(Neuron.refraction_duration)
        else:
            ctrl[control].next()
    def update(self):
        """State Object:
            panel:              Interface panel
            controls:           Interface controls
            panel_active        Panel active
            panel_interact:     Pointer interface interact
            control_interact:   Pointer control interact
            button_interact:    Pointer button interact
            control:            Control selected
            button:             Button selected
            value:              Control value
            values:             Panel control values
            control_interact, button_interact when mouse_move=True
        """
        interphase.Interface.update(self)
        state = self.get_state()
        control.panel_displayed = state.panel_interact
        if state.control:
            if state.control == '__Neuron_Stimulate':
                control.tool = 'Neuron_' + state.value
            elif state.control == '__Stimulate_Mod':
                if state.value == 'True':
                    control.tool_mod = True
                else:
                    control.tool_mod = False
            elif state.control == 'Response':
                Neuron.response_speed = int(state.value)
            elif state.control == 'Refraction':
                Neuron.refraction_duration = int(state.value)
            elif state.control == 'Firing':
                if state.value == 'ON':
                    Neuron.random_firing = 0.00005
                else:
                    Neuron.random_firing = 0
            elif state.control == 'Dampening':
                if state.value == 'ON':
                    Neuron.dampening = 1
                else:
                    Neuron.dampening = 0
            elif state.control == 'Learning':
                if state.value == 'ON':
                    Neuron.learning = True
                else:
                    Neuron.learning = False
            elif state.control == 'Memory':
                matrix.clear_memory()
            elif state.control == 'Neuron':
                if state.value == 'ON':
                    matrix.neuron_display(neuron=True)
                else:
                    matrix.neuron_display(neuron=False)
            elif state.control == 'Network':
                if state.value == 'ON':
                    matrix.network_display = True
                else:
                    matrix.network_display = False
            elif state.control == 'Selected':
                matrix.show_select = not matrix.show_select
                matrix.neuron_display()
            elif state.control == 'Type':
                if state.value == '1':
                    matrix.neuron_types = False
                else:
                    matrix.neuron_types = True
            elif state.control == 'Pause':
                if state.value == 'ON':
                    matrix.neuron_activity_pause = True
                else:
                    matrix.neuron_activity_pause = False
            elif state.control == '__Keys':
                control.control_info()
            elif state.control == '__Fix':
                self.set_moveable()
            elif state.control == '__Help':
                self.set_label_display()
                self.set_tips_display()
            elif state.control == '__Set':
                self.set_color = not self.set_color
                control.panel.set_color = not control.panel.set_color
                if self.set_color:
                    control.panel.initialize_color_config()
                    state.controls['Color'].set_value(control.panel.setup_color_config(state.values['Neuron Type'], state.values['RGB']))
                    self.image = control.panel.set_neuron_color(self.image.copy(), neuron_type=state.values['Neuron Type'])
                else:
                    control.panel.set_neuron_image()
        if self.set_color:
            if state.control == 'Color':
                control.panel.neuron_color[state.values['RGB'].lower()] = state.value
            elif state.control == 'RGB':
                state.controls['Color'].set_value(control.panel.neuron_color[state.values['RGB'].lower()])
            elif state.control == 'Neuron Type':
                control.panel.neuron_color = control.panel.neurons_color[state.value]
                state.controls['Color'].set_value(control.panel.neuron_color[state.values['RGB'].lower()])
            elif state.control == '__Reset':
                control.panel.reset_neuron_color(state.values['Neuron Type'])
                state.controls['Color'].set_value(control.panel.neuron_color[state.values['RGB'].lower()])
            if state.control in ('Color', 'RGB', 'Neuron Type', '__Reset'):
                self.image = control.panel.set_neuron_color(self.image.copy(), neuron_type=state.values['Neuron Type'])
            elif state.controls['Color'].is_active():
                self.image = control.panel.set_neuron_color(self.image.copy(), neuron_type=state.values['Neuron Type'], update=False)
        return state

class InterfaceConfig(interphase.Interface):
    def __init__(self):
        interphase.Interface.__init__(self, button_image=['button.png'], control_image=['control.png'], label_display=True)
        self.neuron_pixel_image = None
        self.neuron_pixel_image2 = None
        self.neuron_pixel = None
        self.set_color = False
        self.neuron_color = { 'r':0, 'g':0, 'b':0 }
        self.neuron_image = None
    def add_controls(self):
        self.add(
            identity = 'Control',
            control_type = 'function_select', 
            position = (50,50),
            size = (50,50),
            control_list = ['Matrix Size', 'Neuron Size', 'Neuron Color'],
            link = [['Matrix', '__MatrixWidth', '__MatrixHeight'], ['Neuron'], ['Neuron Type', 'RGB', 'Color', '__Reset']])
        self.add(
            identity = 'Matrix',
            control_type = 'control_toggle',
            position = (195,50),
            size=(50,25),
            control_list = [('500x500'), ('600x600'), ('700x700'), ('800x800')],
            tip_list = ['Matrix Size'])
        self.add(
            identity = '__MatrixWidth',
            control_type = 'control_select',
            position = (140,50),
            size=(25,25),
            control_list = [],
            control_image=['None'],
            control_outline=False)
        self.add(
            identity = '__MatrixHeight',
            control_type = 'control_select',
            position = (208,50),
            size=(25,25),
            control_list = [],
            control_image=['None'],
            control_outline=False)
        self.add(
            identity = 'Neuron',
            control_type = 'control_toggle',
            position = (195,50),
            control_list = ['16x16', '4x4'],
            tip_list = ['Neuron Size'])
        self.add(
            identity = 'Neuron Type',
            control_type = 'control_toggle',
            position = (210,25),
            size = 'auto_width',
            control_list = ['Resting', 'Active-1', 'Active-2', 'Network'],
            tip_list = ['Resting Neuron', 'Active-1 Neuron', 'Active-2 Neuron', 'Network Neuron'])
        self.add(
            identity = 'RGB',
            control_type = 'control_toggle',
            position = (280,25),
            control_list = ['R','G','B'],
            tip_list = ['RGB Color'])
        self.add(
            identity = 'Color',
            control_type = 'control_select',
            position = (280,55),
            control_list = ['__numeric', (0,255)],
            tip_list = ['Neuron Color'])
        self.add(
            identity = '__Reset',
            control_type = 'control_toggle',
            position = (280,82),
            size = 'auto_width',
            control_list = ['reset'],
            control_outline = True,
            tip_list = ['Reset Color'])
        self.add(
            identity = '__Help',
            control_type = 'control_toggle',
            position = (310,10),
            control_list = ['?'])
        self.add(
            identity = '__Exit',
            control_type = 'control_toggle',
            position = (330,10),
            control_list = ['x'])
    def initialize_color_config(self):
        if not self.neuron_image:
            self.neuron_image = { 'Resting':Neuron.image[16]['Resting'].copy(), 'Active-1':Neuron.image[16]['Response_type1'].copy(), 'Active-2':Neuron.image[16]['Response_type2'].copy(), 'Network':Neuron.image[16]['Response_type3'].copy() }
            self.image_original = { 'Resting':Neuron.image[16]['Resting'].copy(), 'Active-1':Neuron.image[16]['Response_type1'].copy(), 'Active-2':Neuron.image[16]['Response_type2'].copy(), 'Network':Neuron.image[16]['Response_type3'].copy() }
            self.neurons_color = { 'Resting': {'r':39,'g':44,'b':56}, 'Active-1': {'r':40,'g':78,'b':42}, 'Active-2': {'r':120,'g':38,'b':40}, 'Network': {'r':87,'g':101,'b':119} }
            self.neurons_color_original = { 'Resting': {'r':39,'g':44,'b':56}, 'Active-1': {'r':40,'g':78,'b':42}, 'Active-2': {'r':120,'g':38,'b':40}, 'Network': {'r':87,'g':101,'b':119} }
    def setup_color_config(self, neuron, rgb_setting):
        self.neuron_pixel_image = self.image_original[neuron].copy()
        self.neuron_pixel_image = self.image_original[neuron].copy()
        self.neuron_pixel_image2 = self.neuron_pixel_image.copy()
        self.neuron_color = self.neurons_color[neuron].copy()
        color_value = self.neuron_color[rgb_setting.lower()]
        return color_value
    def reset_neuron_color(self, neuron_type=None):
        if not neuron_type:
            neuron_type = self.get_control('Neuron Type').get_value()
        self.neuron_image[neuron_type] = self.image_original[neuron_type].copy()
        self.neurons_color[neuron_type] = self.neurons_color_original[neuron_type].copy()
        self.neuron_color = self.neurons_color[neuron_type]
    def set_neuron_color(self, surface=None, neuron_type=None, update=True):
        self.initialize_color_config()
        if not self.set_color:
            ctrl = self.get_control()
            neuron_type = ctrl['Neuron Type'].get_value()
            ctrl['Color'].set_value(self.setup_color_config(neuron_type, ctrl['RGB'].get_value()))
            self.set_color = True
        if not surface:
            surface = self.image
        if update:
            if not neuron_type:
                neuron_type = self.get_control('Neuron Type').get_value()
            self.neuron_pixel_image = self.image_original[neuron_type].copy()
            try:
                self.neuron_pixel = pygame.PixelArray(self.neuron_pixel_image)
            except AttributeError:
                return
            r,g,b = self.neuron_color['r'], self.neuron_color['g'], self.neuron_color['b']
            ro,go,bo = self.neurons_color_original[neuron_type]['r'], self.neurons_color_original[neuron_type]['g'], self.neurons_color_original[neuron_type]['b']
            try:
                self.neuron_pixel.replace((ro,go,bo), (r,g,b), 0.1)
            except AttributeError:
                return 
            clr = []
            for color in (ro,go,bo):
                if color+20 <= 255:
                    color += 20
                    clr.append(color)
            clr = tuple(clr)
            try:
                self.neuron_pixel.replace(clr, (r,g,b), 0.1)
            except AttributeError:
                return
            self.neuron_image[neuron_type] = self.neuron_pixel_image
            self.neurons_color[neuron_type] = self.neuron_color
            self.neuron_pixel_image2 = self.neuron_pixel_image.copy()
            surface.blit(self.neuron_pixel_image2,(200,50))
        else:
            surface.blit(self.neuron_pixel_image2,(200,50))
        return surface
    def set_neuron_image(self):
        Neuron.image[16]['Resting'] = self.neuron_image['Resting'].copy()
        Neuron.image[16]['Response_type1'] = self.neuron_image['Active-1'].copy()
        Neuron.image[16]['Response_type2'] = self.neuron_image['Active-2'].copy()
        Neuron.image[16]['Response_type3'] = self.neuron_image['Network'].copy()
        Neuron.image[4]['Resting'] = pygame.transform.smoothscale(self.neuron_image['Resting'].copy(), (4,4))
        Neuron.image[4]['Response_type1'] = pygame.transform.smoothscale(self.neuron_image['Active-1'].copy(), (4,4))
        Neuron.image[4]['Response_type2'] = pygame.transform.smoothscale(self.neuron_image['Active-2'].copy(), (4,4))
        Neuron.image[4]['Response_type3'] = pygame.transform.smoothscale(self.neuron_image['Network'].copy(), (4,4))
        for neuron in matrix.neurons:
            neuron.image = Neuron.image[Neuron.size]['Resting']
            neuron.rect = neuron.image.get_rect(center=neuron.location)
        matrix.neuron_display()
    def matrix_size(self, button, value):
        size = [int(val) for val in value.split('x')]
        if button == '__MatrixWidth_top':
            size[0] += 10
            if size [0] > 1280:
                size[0] = 1280
        elif button == '__MatrixWidth_bottom':
            size[0] -= 10
            if size [0] < 350:
                size[0] = 350
        elif button == '__MatrixHeight_top':
            size[1] += 10
            if size[1] > 1024:
                size[1] = 1024
        elif button == '__MatrixHeight_bottom':
            size[1] -= 10
            if size[1] < 350:
                size[1] = 350
        size = '%sx%s' %(size[0], size[1])
        self.get_control('Matrix').set_value(size)
    def values(self):
        values = self.get_value('Matrix', 'Neuron')
        for value in values:
            if value == 'Matrix':
                matrix = [int(val) for val in values[value].split('x')]
            elif value == 'Neuron':
                neuron = [int(val) for val in values[value].split('x')][0]
        return matrix, neuron, self.neuron_image
    def update(self):
        interphase.Interface.update(self)
        state = self.get_state()
        if state.control:
            if state.button in ('__MatrixWidth_top', '__MatrixWidth_bottom', '__MatrixHeight_top', '__MatrixHeight_bottom'):
                self.matrix_size(state.button, state.values['Matrix'])
            if state.control == 'Control':
                if state.value == 'Neuron Color':
                    self.set_neuron_color()
            elif state.control == 'Color':
                self.neuron_color[state.values['RGB'].lower()] = state.value
            elif state.control == 'RGB':
                state.controls['Color'].set_value(self.neuron_color[state.values['RGB'].lower()])
            elif state.control == 'Neuron Type':
                self.neuron_color = self.neurons_color[state.value]
                state.controls['Color'].set_value(self.neuron_color[state.values['RGB'].lower()])
            elif state.control == '__Reset':
                neuron_type = state.values['Neuron Type']
                self.neuron_image[neuron_type] = self.image_original[neuron_type].copy()
                self.neurons_color[neuron_type] = self.neurons_color_original[neuron_type].copy()
                self.neuron_color = self.neurons_color[neuron_type]
                state.controls['Color'].set_value(self.neuron_color[state.values['RGB'].lower()])
            elif state.control == '__Help':
                self.set_label_display()
                self.set_tips_display()
            elif state.control == '__Exit':
                self.set_color = False
                self.deactivate()
                return
        if state.control in ('Color', 'RGB', 'Neuron Type', '__Reset'):
            self.set_neuron_color()
        elif state.controls['Color'].is_active():
            self.set_neuron_color(update=False)
        return

class Control(object):
    def __init__(self,parameters):
        self.x, self.y = parameters['x'], parameters['y']
        gamma = parameters['gamma']
        self.initiate(gamma)
        cursor_str = (
          "X      X",
          " X    X ",
          "   XX   ",
          "  X..X  ",
          "  X..X  ",
          "   XX   ",
          " X    X ",
          "X      X"
        )
        my_cursor = pygame.cursors.compile(cursor_str)
        pygame.mouse.set_cursor((8, 8), (0, 0), *my_cursor)
        pygame.key.set_repeat(100,10)
        self.panel, self.panel_group = self.define_controls()
        self.control_list = []
        self.matrix_online = True
        self.screen_backup = None
        self.current_display = { 'x':self.x, 'y':self.y }
        self.matrix_size = (500,500)
        self.neuron_size = 16
        self.neuron_image = None
        self.matrix_reset = False
        self.clock = pygame.time.Clock()
        self.mouse = {'1':0, '2':0, '3':0, 'mod':0}
        self.tools = ['Neuron_Stimulate', 'Neuron_Twitcher', 'Neuron_Deactivate', 'Neuron_Termini']
        self.tool_select = 0
        self.tool = 'Neuron_Stimulate'
        self.tool_mod = False
        self.panel_displayed = False     #when displayed, ignore click in panel area
        self.quit = False
    def define_controls(self):
        panel = InterfaceConfig()
        panel_group = pygame.sprite.RenderUpdates(panel)
        return panel, panel_group
    def initiate(self, gamma=None, init=True):
        if init:
            pygame.display.init()
            pygame.font.init()
            pygame.display.set_caption('Neural Construct')
            iconname = os.path.join('data', 'icon.png')
            icon = pygame.image.load(iconname)
            pygame.display.set_icon(icon)
        if gamma:
            gamma_set = pygame.display.set_gamma(gamma)
        pygame.display.set_mode((self.x,self.y))
        if gamma and not gamma_set:   #if prior set_gamma failed
            gamma_set = pygame.display.set_gamma(gamma)
        self.screen = pygame.display.get_surface()
        self.info = interphase.DisplayMsg(self.screen)
        self.info.set_font_color((82,96,116))
    def opening(self, escape=False):
        global matrix
        if self.matrix_online and not self.screen_backup:
            self.screen_backup = matrix.screen.copy()
            self.mouse = {'1':0, '2':0, '3':0, 'mod':0}
        pygame.event.set_allowed(MOUSEBUTTONUP)
        pygame.event.set_allowed(MOUSEBUTTONDOWN)
        self.menu()
        quit = False
        while not quit:
            self.clock.tick(40)
            for event in pygame.event.get():
                if event.type == KEYDOWN:
                    if event.key == K_ESCAPE:   #resume
                        if self.matrix_online and not self.matrix_reset:
                            self.screen.blit(self.screen_backup, (0,0))
                            self.screen_backup = False
                            pygame.display.flip()
                            return True
                    elif event.key == K_1:
                        self.matrix_initiate()
                        return
                    elif event.key == K_2:
                        self.config()
                    elif event.key == K_3:
                        self.control_info()
                        self.menu()
                    elif event.key == K_4:
                        pygame.quit()
                        sys.exit()
                elif event.type == MOUSEBUTTONDOWN:
                    button1, button2, button3 = pygame.mouse.get_pressed()
                    mouse_x, mouse_y = pygame.mouse.get_pos()
                    for rect_num, rect in enumerate(self.menu_rect):
                        if rect.collidepoint((mouse_x, mouse_y)):
                            if rect_num == 0:
                                self.matrix_initiate()
                                return
                            if rect_num == 1:
                                self.config()
                            if rect_num == 2:
                                self.control_info()
                                self.menu()
                            if rect_num == 3:
                                pygame.quit()
                                sys.exit()
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
    def menu(self):
        x = ((self.x//2)-120)
        y = ((self.y//2)-120)
        menu_list = [ ("Neuromatrix",32,(x+20,y)), ("1. Neuron Simulation",24,(x,y+50)), ("2. Configuration",24,(x,y+100)), ("3. Control",24,(x,y+150)), ("4. Quit",24,(x,y+200)) ]
        self.screen.fill((0,0,0))
        self.menu_rect = [pygame.Rect(item) for item in ( ((x,y+50),(250,24)), ((x,y+100),(250,24)), ((x,y+150),(250,24)), ((x,y+200),(250,24)) )]
        for item in menu_list:
            self.info.add(item[0])
            self.info.set_font_size(item[1])
            self.info.set_position(item[2])
            self.info()
        pygame.display.flip()
        return
    def control_info(self):
        if not self.control_list:
            try:
                controls = open('control.txt', 'r')
                for item in controls:
                    key = item[:16].strip()
                    command = item[16:].strip()
                    control_item = { 'key':key, 'command':command }
                    self.control_list.append(control_item)
                controls.close()
            except IOError:
                return
        if self.matrix_online and not self.screen_backup:
            self.screen_backup = matrix.screen.copy()
        self.screen.fill((0,0,0))
        self.info.set_font_size(12)
        x = ((self.x//2)-150)
        y = ((self.y//2)-170)
        count = y
        for control_item in self.control_list:
            self.info.add(control_item['key'])
            self.info.set_position((x,count))
            self.info()
            self.info.add(control_item['command'])
            self.info.set_position((x+130,count))
            self.info()
            count += 15
        interrupt = False
        count = 0
        while not interrupt:
            if count < 20:
                count += 1
            self.clock.tick(40)
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == KEYDOWN:
                    interrupt = True
                elif pygame.mouse.get_pressed()[0]:
                    if count >= 20:
                        interrupt = True
            pygame.display.flip()
        self.screen.blit(self.screen_backup, (0,0))
        pygame.display.flip()
        return
    def matrix_initiate(self):
        self.x, self.y = self.matrix_size
        self.panel.move(self.x//2, self.y//2)
        if self.matrix_online:
            self.screen_backup = None
            if self.x != self.current_display['x'] or self.y != self.current_display['y']:
                self.initiate(init=False)
                self.current_display = { 'x':self.x, 'y':self.y }
        else:
            self.matrix_online = True
        self.tool = 'Neuron_Stimulate'
        self.matrix_reset = True
    def config(self):
        self.screen_backup = self.screen.copy()
        self.screen.fill((0,0,0))
        pygame.display.flip()
        self.panel.activate()
        interrupt = False
        while not interrupt:
            self.clock.tick(40)
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
            self.panel_group.update()
            if self.panel.is_active():
                update_rect = self.panel_group.draw(self.screen)
                pygame.display.update(update_rect)
            else:
                self.matrix_size, self.neuron_size, self.neuron_image = self.panel.values()
                interrupt = True
        self.screen.blit(self.screen_backup, (0,0))
        pygame.display.flip()
        return
    def check_events(self):
        for event in pygame.event.get():
            if event.type == KEYDOWN:
                if event.key == K_t:
                    self.tool_select += 1
                    if self.tool_select > 3:
                        self.tool_select = 0
                    self.tool = self.tools[self.tool_select]
                    matrix.panel.set_panel_value('__Neuron_Stimulate')
                elif event.key == K_UP:
                    if Neuron.response_speed < 3:
                        Neuron.response_speed += 1
                        matrix.panel.set_panel_value('Response')
                elif event.key == K_DOWN:
                    if Neuron.response_speed > 1:
                        Neuron.response_speed -= 1
                        matrix.panel.set_panel_value('Response')
                elif event.key == K_RIGHT:
                    if Neuron.refraction_duration < 50:
                        Neuron.refraction_duration += 5
                        matrix.panel.set_panel_value('Refraction')
                elif event.key == K_LEFT:
                    if Neuron.refraction_duration > 5:
                        Neuron.refraction_duration -= 5
                        matrix.panel.set_panel_value('Refraction')
                if event.key == K_f:
                    if Neuron.random_firing:
                        Neuron.random_firing = 0
                    else:
                        Neuron.random_firing = 0.00005
                    matrix.panel.set_panel_value('Firing')
                elif event.key == K_d:
                    if not Neuron.dampening:
                        Neuron.dampening = 1
                    else:
                        Neuron.dampening = 0
                    matrix.panel.set_panel_value('Dampening')
                elif event.key == K_l:
                    if not Neuron.learning:
                        Neuron.learning = True
                    else:
                        Neuron.learning = False
                    matrix.panel.set_panel_value('Learning')
                elif event.key == K_e:
                    matrix.clear_memory()
                elif event.key == K_n:
                    matrix.network_display = not matrix.network_display
                    matrix.panel.set_panel_value('Network')
                elif event.key == K_s:
                    matrix.show_select = not matrix.show_select
                    matrix.neuron_display()
                    matrix.panel.set_panel_value('Selected')
                elif event.key == K_a:
                    matrix.neuron_types = not matrix.neuron_types
                    matrix.panel.set_panel_value('Type')
                elif event.key == K_x:
                    if matrix.neuron_displayed:
                        matrix.neuron_display(neuron=False)
                    else:
                        matrix.neuron_display(neuron=True)
                    matrix.panel.set_panel_value('Neuron')
                elif event.key == K_p:
                    matrix.neuron_activity_pause = not matrix.neuron_activity_pause
                    matrix.panel.set_panel_value('Pause')
                elif event.key == K_c:
                    matrix.panel_display = not matrix.panel_display
                    if matrix.panel_display:
                        [panel for panel in matrix.panel][0].activate()
                    else:
                        [panel for panel in matrix.panel][0].deactivate()
                        matrix.screen.blit(matrix.screen_cell,(0,0))
                        pygame.display.flip()
                elif event.key == K_h:    #control info
                    control.control_info()
                elif event.key == K_ESCAPE:
                    self.opening()
            elif event.type == QUIT:   #quit program
                pygame.quit()
                self.quit = True
            elif event.type in (MOUSEBUTTONDOWN, MOUSEBUTTONUP):
                if not self.panel_displayed:
                    button1, button2, button3 = pygame.mouse.get_pressed()
                    self.mouse['1'], self.mouse['2'], self.mouse['3'] = button1, button2, button3
                    self.mouse['mod'] = pygame.key.get_mods()
                else:
                    for setting in ['1','2','3','mod']:
                        self.mouse[setting] = 0
        if self.mouse['1'] or self.mouse['2'] or self.mouse['3']:
            button1, button2, button3, mod = self.mouse['1'], self.mouse['2'], self.mouse['3'], self.mouse['mod']
            if not self.mouse['mod'] and not self.tool_mod:
                activate = True
            else:
                activate = False
            if button1:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                if self.tool == 'Neuron_Stimulate':
                    matrix.neuron_stimulate(mouse_x, mouse_y)
                elif self.tool == 'Neuron_Twitcher':
                    matrix.set_neuron_twitcher(mouse_x, mouse_y, activate)
                elif self.tool == 'Neuron_Deactivate':
                    matrix.neuron_deactivate(mouse_x, mouse_y, activate)
                elif self.tool == 'Neuron_Termini':
                    matrix.set_net_termini(mouse_x, mouse_y)
            elif button2:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                matrix.neuron_stimulate(mouse_x, mouse_y)
            elif button3:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                mod = pygame.key.get_mods()
                if not mod:
                    matrix.set_net_termini(mouse_x, mouse_y)
                elif (mod & KMOD_CTRL):
                    if not (mod & KMOD_SHIFT):
                        matrix.neuron_deactivate(mouse_x, mouse_y)
                    else:
                        matrix.neuron_deactivate(mouse_x, mouse_y, False)
                elif (mod & KMOD_ALT):
                    if not (mod & KMOD_SHIFT):
                        matrix.set_neuron_twitcher(mouse_x, mouse_y)
                    else:
                        matrix.set_neuron_twitcher(mouse_x, mouse_y, False)
    def update(self):
        self.check_events()
        self.clock.tick(40)

def program_options():
    config = {'display_gamma':None}
    try:
        conf = {}
        config_file = open('config.ini')
        cfg_setting = [line.strip().split(' ',1) for line in config_file if line[:1].isalpha()]
        cfg_setting = dict(cfg_setting)
        for cfg in config:
            if cfg in cfg_setting:
                conf[cfg] = cfg_setting[cfg].strip()
        config_file.close()
    except (IOError, ValueError):
        pass
    for cfg in conf:
        if cfg == 'display_gamma':
            try:
                config['display_gamma'] = float(conf['display_gamma'])
            except ValueError:
                pass
    return config

def setup(parameters={'x':500,'y':500}):
    config = program_options()
    if config['display_gamma']:
        gamma = config['display_gamma']
        if gamma > 0.0 and gamma < 0.5:
            gamma = 0.5
        elif gamma > 3.0:
            gamma = 3.0
    else:
        gamma = 0
    parameters['gamma'] = gamma
    control = Control(parameters)
    matrix = Matrix(control.x, control.y)
    return control, matrix

def main():
    global control, matrix
    control, matrix = setup()
    while not control.quit:
        if control.matrix_reset:
            matrix.empty()
            del matrix
            matrix = Matrix(control.x, control.y, control.neuron_size, control.neuron_image)
            control.matrix_reset = False
        matrix.update()
        control.update()

if __name__ == '__main__':
    main()

