"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
import javax.imageio.ImageIO
import java.io.File
import surface
import env


class Image(object):

    def load(self, img_file, namehint=None):
        try:
            f = env.japplet.class.getResource(img_file.replace('\\','/'))    #java uses /, not os.path Windows \
            if not f:
                raise
        except:
            f = java.io.File(img_file)      #make path os independent
        try:
            img = javax.imageio.ImageIO.read(f)
        except IOError:
            print 'Error reading', img_file
        bimage = surface.convert_bufferedimage(img)
        return bimage

