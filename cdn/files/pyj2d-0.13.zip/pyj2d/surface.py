"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
import java.awt.image
from java.util import Hashtable
from rect import Rect


class Surface(java.awt.image.BufferedImage):

    def __init__(self, *arg):
        if len(arg) < 3:
            width, height = arg[0]
            try:
                imageType = arg[1]
            except IndexError:
                imageType = java.awt.image.BufferedImage.TYPE_INT_ARGB
            java.awt.image.BufferedImage.__init__(self, width, height, imageType)
        else:
            try:
                width, height = arg[0]
                imageType = arg[1]
                cm = arg[2]
                java.awt.image.BufferedImage.__init__(self, width, height, imageType, cm)
            except TypeError:
                cm, raster, isRasterPremultiplied, properties = arg
                java.awt.image.BufferedImage.__init__(self, cm, raster, isRasterPremultiplied, properties)
        self._display = None    #display surface
        self._super_surface = None
        self._offset = (0,0)
        self._colorkey = None

    def dispose(self):
        try:
            self._g2d.dispose()
            del self._g2d
        except AttributeError:
            pass

    def get_size(self):
        return (self.getWidth(), self.getHeight())

    def get_width(self):
        return self.getWidth()

    def get_height(self):
        return self.getHeight()

    def get_rect(self, **attr):
        rect = Rect(0, 0, self.getWidth(), self.getHeight())
        for key in attr:
            rect.set_attr(key,attr[key])
        return rect

    def copy(self):
        img_properties = Hashtable()
        keys = self.getPropertyNames()
        if keys != None:
            for key in keys:
                img_properties.put(key,self.getProperty(key))
        surface = Surface(
                          self.getColorModel(),
                          self.getData(),
                          self.isAlphaPremultiplied(),
                          img_properties
                         )
        surface._colorkey = self._colorkey
        return surface

    def subsurface(self, rect):
        surface, surface_rect = self.subarea(rect)
        surface = convert_bufferedimage(surface)
        surface._super_surface = self
        surface._g2d = surface.createGraphics()
        surface._offset = (surface_rect[0],surface_rect[1])
        surface._colorkey = self._colorkey
        return surface

    def subarea(self, rect):
        try:
            x,y,w,h = rect.x, rect.y, rect.width, rect.height
        except AttributeError:
            x,y,w,h = rect
        try:
            subsurface = self.getSubimage(x, y, w, h)
        except java.awt.image.RasterFormatException:
            try:
                clip_rect = self.get_rect().createIntersection( Rect(x, y, w, h) )
                x, y, w, h = clip_rect.x, clip_rect.y, clip_rect.width, clip_rect.height
                subsurface = self.getSubimage(x, y, w, h)
            except:     #rect outside surface
                subsurface = None
        return subsurface, (x,y,w,h)

    def blit(self, surface, position, area=None):
        try:
            x, y = position.x, position.y
        except AttributeError:
            x, y = position[0], position[1]
        try:
            if not area:
                rect = self.get_rect().createIntersection( Rect(x,y,surface.getWidth(),surface.getHeight()) )
                surface_rect = Rect(rect.x, rect.y, rect.width, rect.height)
            else:
                surface, surface_rect = surface.subarea(area)
        except AttributeError:
            return Rect(0,0,0,0)
        try:
            g2d = self._g2d
            surface_graphics = True
        except AttributeError:
            g2d = self.createGraphics()
            surface_graphics = False
        g2d.drawImage(surface, x, y, None)
        if not surface_graphics:
            g2d.dispose()
        return surface_rect

    def blits(self, surfaces):
        try:
            g2d = self._g2d
            for surface in surfaces:
                try:
                    x, y = surface[1].x, surface[1].y
                except AttributeError:
                    x, y = surface[1][0], surface[1][1]
                g2d.drawImage(surface[0], x, y, None)
        except AttributeError:
            g2d = self.createGraphics()
            for surface in surfaces:
                try:
                    x, y = surface[1].x, surface[1].y
                except AttributeError:
                    x, y = surface[1][0], surface[1][1]
                g2d.drawImage(surface[0], x, y, None)
            g2d.dispose()
        return None

    def convert(self, surface):
        return surface

    def convert_alpha(self, surface):
        return surface

    def set_colorkey(self, color, flags=None):
        if self._colorkey:
            r,g,b = self._colorkey
            self.replace_color((r,g,b,0),(r,g,b,255))
            self._colorkey = None
        if color:
            self._colorkey = color
            self.replace_color(color)
        return None

    def get_colorkey(self):
        return self._colorkey

    def replace_color(self, color, new_color=None):
        pixels = self.getRGB(0,0,self.getWidth(),self.getHeight(),None,0,self.getWidth())
        r,g,b = color
        if new_color:
            r2,g2,b2,a2 = new_color
        else:
            r2,g2,b2,a2 = color[0],color[1],color[2],0
        for i, pixel in enumerate(pixels):
            if pixel == java.awt.Color(r,g,b).getRGB():
                pixels[i] = java.awt.Color(r2,g2,b2,a2).getRGB()
        self.setRGB(0,0,self.getWidth(),self.getHeight(),pixels,0,self.getWidth())

    def get_at(self, pos):
        x,y = pos       #*tuple unpack error in jython applet
        color = java.awt.Color(self.getRGB(x,y))
        return color.getRed(), color.getGreen(), color.getBlue()

    def set_at(self, pos, color):
        RGB = color
        return self.setRGB(pos[0],pos[1],java.awt.Color(R,G,B))

    def fill(self, color=(0,0,0), rect=None):
        try:
            g2d = self._g2d
            surface_graphics = True
        except AttributeError:
            g2d = self.createGraphics()
            surface_graphics = False
        if not rect:
            x, y, w, h = 0, 0, self.getWidth(), self.getHeight()
        else:
            try:
                x,y,w,h = rect.x, rect.y, rect.width, rect.height
            except AttributeError:
                x,y,w,h = rect
        r,g,b = color
        g2d.setColor(java.awt.Color(r,g,b))
        g2d.fillRect(x,y,w,h)
        if not surface_graphics:
            g2d.dispose()

    def get_parent(self):
        return self._super_surface   #if delete, delete subsurface...

    def get_offset(self):
        return self._offset


def convert_bufferedimage(bi):
    img_properties = Hashtable()
    keys = bi.getPropertyNames()
    if keys != None:
        for key in keys:
            img_properties.put(key,bi.getProperty(key))
    surface = Surface(
                      bi.getColorModel(),
                      bi.getRaster(),
                      bi.isAlphaPremultiplied(),
                      img_properties
                     )
    return surface

