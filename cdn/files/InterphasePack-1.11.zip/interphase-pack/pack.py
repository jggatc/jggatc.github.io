#!/usr/bin/env python
from __future__ import division

"""
Interphase Pack
Copyright (C) 2010 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Interphase Pack version 1.11

Interphase Module
Download Site: http://gatc.ca
"""


import interphase
import serpentduel
import poddescent
import slidingcontrol
import pygame


class Interface(interphase.Interface):
    """
    Interphase Pack interface.
    """
    def __init__(self, screen, background):
        interphase.Interface.__init__(self, identity='Pack', position=(250,452), size=(350,100),
            color=(43,50,58), moveable=False, position_offset=(0,95), control_minsize=(35,35))
        self.get_control('Pack').set_active(True)
        self.get_control('Control').set_active(False)
        self.get_control('Serpent').set_active(False)
        self.set_pointer_interact(True)
        self.screen = screen
        self.background = background
        pygame.display.flip()
        self.program = None
        self.puzzle = False
        self.puzzle_panel = None
        
        self.update_rect = []

    def add_controls(self):
        """Add interface controls."""
        self.add(
            identity = 'Control',
            control_type = 'function_select',
            position = (50,50), size = (55,45),
            control_list = ['Serpent Duel', 'Pod Descent', 'Sliding Control', 'Exit'],
            link = [ ['Serpent'], ['Pod'], ['Puzzle'] ])
        self.add(identity='Pack', control_type='control_toggle', position=(175,50), control_list=['Interphase Pack'], size=(100,50))
        self.add(identity='Serpent', control_type='control_toggle', position=(175,50), control_list=['Start'])
        self.add(identity='Pod', control_type='control_toggle', position=(175,50), control_list=['Start'])
        self.add(identity='Puzzle', control_type='control_toggle', position=(175,50), control_list=['Start', 'Stop'])

    def pack_exec(self):
        if self.program == 'Sliding Control':
            self.puzzle_exec()
        elif self.program == 'Serpent Duel':
            self.deactivate()
            self.program_exec(serpentduel)
            self.activate()
        elif self.program == 'Pod Descent':
            self.deactivate()
            self.program_exec(poddescent)
            self.activate()

    def program_exec(self, program):
        """Execute programs."""
        self.screen.blit(self.background, (0,0))
        pygame.display.flip()
        matrix, panel, interface_panel = program.setup(screen=self.screen)
        run = True
        while run:
            run = program.program_exec(matrix, panel, interface_panel)
        self.program = None
        pygame.display.set_caption('Interphase Pack')
        self.screen.blit(self.background, (0,0))
        pygame.display.flip()

    def puzzle_setup(self):
        if not self.puzzle:
            self.puzzle = True
            self.puzzle_panel = pygame.sprite.RenderUpdates(slidingcontrol.Interface(self.screen))
            pygame.display.set_caption('Sliding Control')
            self.get_control('Control').set_active(False)
        else:
            self.puzzle = False
            self.puzzle_panel = None
            self.program = None
            pygame.display.set_caption('Interphase Pack')
            self.get_control('Control').set_active(True)
            self.screen.blit(self.background, (0,0))
            pygame.display.flip()

    def puzzle_exec(self):
        self.puzzle_panel.update()
        self.puzzle_panel.clear(self.screen, self.background)
        update_rect = self.puzzle_panel.draw(self.screen)
        pygame.display.update(update_rect)

    def update(self):
        """Interface update."""
        state = interphase.Interface.update(self)
        if state.control:
            if state.control == 'Serpent':
                self.program = 'Serpent Duel'
            elif state.control == 'Pod':
                self.program = 'Pod Descent'
            elif state.control == 'Puzzle':
                self.program = 'Sliding Control'
                self.puzzle_setup()
            elif state.control == 'Control':
                if state.button == 'Control' and state.value == 'Exit':
                    self.deactivate()
        elif state.control_interact:
            if state.control_interact == 'Pack':
                state.controls['Pack'].set_active(False)
                state.controls['Control'].set_active(True)
                state.controls['Serpent'].set_active(True)
                self.set_pointer_interact(False)
                self.set_moveable(True)


def program_options():
    config = {'display_gamma':None}
    try:
        conf = {}
        config_file = open('config.ini')
        cfg_setting = [line.strip().split(' ',1) for line in config_file if line[:1].isalpha()]
        cfg_setting = dict(cfg_setting)
        for cfg in config:
            if cfg in cfg_setting:
                conf[cfg] = cfg_setting[cfg].strip()
        config_file.close()
    except (IOError, ValueError):
        pass
    for cfg in conf:
        if cfg == 'display_gamma':
            try:
                config['display_gamma'] = float(conf['display_gamma'])
            except ValueError:
                pass
    return config


def setup(x=500,y=500):
    pygame.display.init()   #pygame.init()
    pygame.display.set_caption('Interphase Pack')
    config = program_options()
    if config['display_gamma']:
        gamma_set = pygame.display.set_gamma(config['display_gamma'])
    screen = pygame.display.set_mode((x,y))
    if config['display_gamma'] and not gamma_set:
        gamma_set = pygame.display.set_gamma(config['display_gamma'])
    background = pygame.Surface((x,y))
    clock = pygame.time.Clock()
    return screen, background, clock


def main():
    screen, background, clock = setup()
    interface_panel = Interface(screen,background)
    panel = pygame.sprite.RenderUpdates(interface_panel)
    run = True
    while run:
        interface_panel.update_rect = []
        panel.update()
        if interface_panel.is_active() and pygame.QUIT not in [evt.type for evt in pygame.event.get()]:
            panel.clear(interface_panel.screen,interface_panel.background)
            interface_panel.update_rect.extend(panel.draw(interface_panel.screen))
            pygame.display.update(interface_panel.update_rect)
            clock.tick(40)
        else:
            run = False
        if interface_panel.program:
            interface_panel.pack_exec()

if __name__ == '__main__':
    main()

