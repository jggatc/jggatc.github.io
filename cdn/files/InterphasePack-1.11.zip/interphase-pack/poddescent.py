#!/usr/bin/env python
from __future__ import division

"""
Pod Descent
Copyright (C) 2010 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Pod Descent version 1.11
Interphase Pack

Interphase Module
Download Site: http://gatc.ca
"""


import interphase
import pygame
import math
import random


class Matrix(object):
    """
    Pod Descent environment.
    """
    def __init__(self, x, y, screen, background):
        self.x, self.y = x, y
        self.screen = screen
        self.background = background
        pygame.display.flip()
        self.clock = pygame.time.Clock()
        self.update_rect = []
        self.difficulty = 1
        self.gravity = 1.6
        self.active = False

    def start(self):
        """Pod start."""
        self.pod_obj = pygame.sprite.RenderUpdates()
        self.pod = Pod(self, random.randrange(100,400),-50, self.difficulty)
        self.pod_obj.add ( self.pod )
        self.mountain = pygame.sprite.RenderUpdates()
        self.mountain.add( Mountain(250,360+50, self.difficulty) )
        self.background.fill( {1.6:(0,0,0), 3.7:(10,8,6), 9.8:(5,8,16), 24.8:(15,4,1)}[self.gravity] )
        self.mountain.draw(self.background)
        self.update_rect.append(self.screen.blit(self.background, (0,0)))
        self.screen.blit(self.background, (0,0))
        pygame.display.flip()
        self.performance = 0
        self.active = True

    def set_active(self, state=True):
        """Activate Pod Descent."""
        self.active = state
        if self.active:
            self.start()

    def set_difficulty(self, difficulty, value):
        """Set task difficulty."""
        if difficulty == 'Difficulty':
            self.difficulty = int(value)
        elif difficulty == 'Gravity':
            self.gravity = float(value)

    def control(self, action):
        """Pod control."""
        try:
            self.pod.control(action)
        except AttributeError:
            pass

    def report(self):
        """Pod gauges."""
        try:
            self.pod.gauges['Alt'] = 377-self.pod.y
            self.pod.gauges['Y-Vel'] = '% .2f'%self.pod.velocity
            self.pod.gauges['X-Vel'] = '% .2f'%self.pod.velocity_l
            self.pod.gauges['Power'] = '%.2f'%self.pod.throttle
            self.pod.gauges['Fuel'] = '%.1f'%self.pod.fuel
            self.pod.gauges['Landed'] = self.pod.landed
            self.pod.gauges['Performance'] = '%.1f'%self.performance
            interface_panel.set_gauge(self.pod.gauges)
        except AttributeError:
            pass

    def update(self):
        """Pod Descent update."""
        try:
            if not self.pod.gauges['Landed']:
                self.pod_obj.update()
                self.pod_obj.clear(self.screen, self.background)
                self.update_rect.extend( self.pod_obj.draw(self.screen) )
                self.report()
        except AttributeError:
            if self.active:
                self.start()


class Pod(pygame.sprite.Sprite):
    """
    Pod ship.
    """
    image = None
    def __init__(self,matrix,x,y,difficulty):
        pygame.sprite.Sprite.__init__(self)
        self.matrix = matrix
        self.x, self.y = x, y
        self.pos_x, self.pos_y = float(x), float(y)
        if not Pod.image:
            Pod.image = pygame.Surface((50,50))
            pts = [( 24+math.cos(angle*math.pi/180)*17, 20+math.sin(angle*math.pi/180)*17 ) for angle in range(0,360,45)]
            pygame.draw.polygon(Pod.image, (10,20,40), pts)
            pygame.draw.lines(Pod.image, (15,60,90), True, pts)
            pygame.draw.aalines(Pod.image, (20,40,80), True, [(24,40),(19,23),(3,49),(17,22),(24,40),(31,22),(46,49),(29,23)])
            Pod.image.set_colorkey((0,0,0), pygame.RLEACCEL)
        self.image = Pod.image
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect(center=(self.x,self.y))
        self.velocity = 0.0
        self.velocity_l = random.choice((1.0,-1.0))
        self.rotate = 0
        self.thrust = {'U':False,'L':False,'R':False}
        self.throttle = 1.0
        self.thrust_lag = 0
        self.fuel = 100.0
        self.engine_thrust = 25.0*math.log10(self.matrix.gravity)
        self.side_thrust = 5.0*math.log10(self.matrix.gravity)
        self.gauges = {'Alt':0, 'Y-Vel':0.0, 'X-Vel':0.0, 'Power':0.0, 'Fuel':0.0, 'Landed':False, 'Performance':0.0}
        self.landed = False
        self.crash = False
        self.ground = 377

    def location(self):
        """Pod location calcution."""
        self.velocity += (self.matrix.gravity*(1.0/40))
        if (self.thrust['U'] or self.thrust_lag) and self.fuel and not self.crash and not self.rotate:
            self.velocity -= (self.engine_thrust*self.throttle*(1.0/40))    #fps40
            if self.thrust_lag > 0:
                self.thrust_lag -= 1
            if self.thrust['U']:
                self.thrust_lag = 10
                self.thrust['U'] = False
            self.fuel -= (0.05*self.matrix.difficulty*math.pow(self.throttle,3))
            if self.fuel < 0:
                self.fuel = 0
        if (self.thrust['L'] or self.thrust['R']) and self.fuel and not self.crash and not self.rotate:
            if self.thrust['L']:
                thrust = -self.side_thrust
                self.thrust['L'] = False
            elif self.thrust['R']:
                thrust = self.side_thrust
                self.thrust['R'] = False
            self.velocity_l += (thrust*self.throttle*(1.0/40))
            self.fuel -= (0.01*self.matrix.difficulty*math.pow(self.throttle,2))
            if self.fuel < 0:
                self.fuel = 0
        self.pos_x += (self.velocity_l/10.0)  #scale 10
        self.x = int( round(self.pos_x) )
        self.pos_y += (self.velocity/10.0)  #scale 10
        self.y = int( round(self.pos_y) )
        if self.y >= self.ground:
            if (self.velocity > 3+(self.matrix.gravity/10.0) or self.rotate) and not self.crash:
                self.velocity = -(self.velocity/2.0)
                self.pos_y -= 1.0
                self.y = int(self.pos_y)
                self.rotate += ( self.velocity_l + ({True:1,False:-1}[self.velocity_l>=0]*abs(self.velocity/10)) )
                self.ground = 390+int(abs(self.velocity/5))
                self.crash = True
            else:
                self.landed = True
                self.matrix.performance = ((not self.crash)*(self.matrix.difficulty*10)) + (not self.crash)*(self.fuel) + ((not self.crash)*self.matrix.gravity) + (((2*(3+(self.matrix.gravity/10.0)))-self.velocity)*10)
                self.matrix.active = False
        self.rect = self.image.get_rect(center=(self.x, self.y))

    def collision(self):
        """Pod collision determination."""
        if pygame.sprite.spritecollide(self, self.matrix.mountain, False, pygame.sprite.collide_mask) and not self.rotate:
            self.rotate += ( self.velocity_l + ({True:1,False:-1}[self.velocity_l>=0]*abs(self.velocity/10)) )
        if self.rotate:
            self.rotate += ( self.velocity_l + ({True:1,False:-1}[self.velocity_l>=0]*abs(self.velocity/10)) )
            self.image = pygame.transform.rotate(Pod.image, -self.rotate)
            self.rect = self.image.get_rect(center=(self.x, self.y))

    def control(self, thrust):
        """Pod controls."""
        if thrust in ('U','L','R'):
            self.thrust[thrust] = True
        else:
            self.throttle += {'Dec':-0.002,'Inc':0.002}[thrust]
            if self.throttle < 0.0:
                self.throttle = 0.0
            elif self.throttle > 1.0:
                self.throttle = 1.0

    def update(self):
        """Location update."""
        self.location()
        self.collision()


class Mountain(pygame.sprite.Sprite):
    """
    Mountain terrain.
    """
    def __init__(self,x,y,difficulty=1):
        pygame.sprite.Sprite.__init__(self)
        self.mountain = []
        plain_i = random.randrange(20,480-((10-difficulty)*10),10)
        plain = [plain_i+(i*10) for i in range(10-difficulty)]
        self.mountain.extend( ((499,179),(0,179)) )
        for ptx in range(0,501,10):
            if ptx not in plain:
                self.mountain.append((ptx,random.randrange(0,75)))
            else:
                self.mountain.append( (ptx,80) )
        self.image = pygame.Surface((500,180))
        pygame.draw.polygon(self.image, (49,54,58), self.mountain)
        pygame.draw.aalines(self.image, (40,80,120), True, self.mountain)
        self.image.set_colorkey((0,0,0))
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect(center=(x,y))


class Interface(interphase.Interface):
    """
    Program interface.
    """
    def __init__(self, matrix):
        interphase.Interface.__init__(self, position=(250,452), size=(350,100), color=(43,50,58),
            label_display=True, font_color=(175,180,185), control_minsize=(35,35), control_size='min')
        self.set_controls()
        self.control_design()
        self.matrix = matrix
        self.matrix_active = False

    def add_controls(self):
        """Add interface controls."""
        #Main Control
        self.add(identity = '__Control', control_type='function_select', position=(50,50), size=(55,45),
            control_list = ['Control', 'Options', 'Exit'],
            link = [ ['Start', 'U', 'L', 'R', 'Dec', 'Inc', 'X-Vel', 'Y-Vel', 'Alt', 'Fuel', 'Power', 'Performance'], ['Difficulty','Gravity'] ])
        #Start Pod Control
        self.add(identity='Start', control_type='control_toggle', position=(250,50), size='auto',
            color=(0,20,30), font_color=(0,120,160), control_list=['Pod'], label_display=False)
        #Stop Pod Control
        self.add(identity='Stop', control_type='control_toggle', position=(50,50), size='auto',
            color=(0,20,30), font_color=(0,120,160), control_list=['Exit'], label_display=False, active=False)
        #Pod Controls
        ctr=('U',(175,40),'__^'),('L',(150,40),'__<'),('R',(200,40),'__>'),('Dec',(162,65),'<'),('Inc',(188,65),'>')
        for ident, pos, ctrl in ctr:
            self.add(identity=ident, control_type='control_toggle', position=pos, control_list=[ctrl],
                label_display=False, control_response=20, control_outline=True, size=(25,25), font_color=(30,85,95))
        #Pod Performance Label Control
        self.add(identity='Performance', control_type='control_toggle', position=(305,52), color=(0,20,30),
            fill=0, font_color=(255,255,255), control_list=[''], size=(43,16), control_image='none')
        #Pod Gauges Label Controls
        for pos, ident in enumerate(['X-Vel', 'Y-Vel', 'Alt', 'Fuel', 'Power']):
            self.add(identity=ident, control_type='control_toggle', position=(pos*50+75,17), color=(0,20,30),
                fill=0, font_color=(255,255,255), control_list=[''], size=(43,16), control_image='none')
        #Setting Controls
        ctr1=('Difficulty', 'control_select', (160,50), ['__numeric',(1,4)])
        ctr2=('Gravity', 'control_toggle', (230,50), ['1.6','3.7','9.8','24.8'])
        for ident, ctype, pos, ctrl in (ctr1, ctr2):
            self.add(identity=ident, control_type=ctype, position=pos, control_list=ctrl, size='min')

    def control_design(self):
        """Draw pod controls."""
        img = pygame.Surface((31,31))
        pygame.draw.polygon(img, (30,85,95), [(0,30),(15,0),(30,30),(0,30)], 0)
        for ctrl, opt, dim, deg in ( ('U','__^',(10,10),0), ('L','__<',(8,8),90), ('R','__>',(8,8),-90) ):
            icon = pygame.transform.rotate(img, deg)
            self.get_control(ctrl).set_list_icon([opt], surface=[icon], color_key=(0,0,0), icon_size=dim)

    def set_controls(self):
        """Set control specifics."""
        for ctrl in ('X-Vel', 'Y-Vel', 'Alt', 'Fuel', 'Power', 'Performance'):
            self.get_control(ctrl).set_label_text(font_color=(0,0,0), font_size=8)
            self.get_control(ctrl).set_enabled(False)

    def set_gauge(self, gauges):
        """Set pod gauges."""
        for ident in ('X-Vel', 'Y-Vel', 'Alt', 'Fuel', 'Power'):
            if self.get_control(ident).get_value() != gauges[ident]:
                self.get_control(ident).set_value(gauges[ident])
        if gauges['Landed']:
            self.get_control('Performance').set_value(gauges['Performance'])
            for ctrl in ('Start', 'Stop', 'Performance'):
                self.get_control(ctrl).set_active(True)

    def update(self):
        """Interface update."""
        state = interphase.Interface.update(self)
        if state.control:
            if state.control in ('U', 'L', 'R', 'Dec', 'Inc'):
                self.matrix.control(state.control)
            elif state.control == 'Start':
                for ctrl in ('__Control', 'Start', 'Stop', 'Performance'):
                    self.get_control(ctrl).set_active(False)
                self.matrix.set_active()
                self.matrix_active = True
            elif state.control == 'Stop':
                self.get_control('Stop').set_active(False)
                self.get_control('__Control').set_active(True)
            elif state.control in ('Difficulty', 'Gravity'):
                self.matrix.set_difficulty(state.control, state.value)
            elif state.control == '__Control':
                if state.button == '__Control' and state.value == 'Exit':
                    self.deactivate()


def setup(x=500,y=500,screen=None):
    global interface_panel
    pygame.display.init()   #pygame.init()
    pygame.display.set_caption('Pod Descent')
    if not screen:
        screen = pygame.display.set_mode((x,y))
    background = pygame.Surface((x,y))
    matrix = Matrix(x,y,screen,background)
    interface_panel = Interface(matrix)
    panel = pygame.sprite.RenderUpdates(interface_panel)
    return matrix, panel, interface_panel


def program_exec(matrix, panel, interface_panel):
    matrix.update_rect = []
    matrix.update()
    panel.update()
    if interface_panel.is_active() and pygame.QUIT not in [evt.type for evt in pygame.event.get()]:
        panel.clear(matrix.screen, matrix.background)
        matrix.update_rect.extend( panel.draw(matrix.screen) )
        pygame.display.update(matrix.update_rect)
        matrix.clock.tick(40)
        run = True
    else:
        run = False
    return run


def main():
    matrix, panel, interface_panel = setup()
    run = True
    while run:
        run = program_exec(matrix, panel, interface_panel)

if __name__ == '__main__':
    main()

