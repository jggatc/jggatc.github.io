#!/usr/bin/env python
from __future__ import division

"""
Sliding Control Puzzle
Copyright (C) 2009 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Sliding Control Puzzle version 1.3
Interphase Pack

Interphase Module
Download Site: http://gatc.ca
"""


import interphase
import pygame
import random


class Interface(interphase.Interface):
    """
    Puzzle interface.
    """
    def __init__(self, display):
        self.puzzle_initiate()
        interphase.Interface.__init__(self, identity='Interface_Puzzle', position=(0.5,0.5),
            color=(23,30,38), size=(180,180), screen=display.get_size(), font_color=(175,180,185),
            tips_fontcolor=(255,255,255), tips_display=True)
        self.puzzle_outline()

    def add_controls(self):
        """Add interface controls."""
        positions = [pos for pos in self.grid_positions if pos != self.grid_blank]
        for index, pos in enumerate(positions):
            self.add(
                identity = str(index+1),
                control_type = 'control_toggle',
                position = ((pos[0]*self.grid_size[0])+self.grid_xy[0], (pos[1]*self.grid_size[1])+self.grid_xy[1]),
                size = self.grid_size,
                color = (14,20,27),
                fill = 2,
                control_list = [str(index+1)],
                label_display = False)
        self.add(
            identity = 'Start',
            control_type = 'control_toggle',
            position = (150,150),
            size = self.grid_size,
            color = (14,20,27),
            control_list = ['Go'],
            font_color=(255,255,255),
            label_display = False)

    def puzzle_initiate(self):
        """Initiate puzzle."""
        self.grid_positions = [(y,x) for x in xrange(4) for y in xrange(4)]
        self.grid = {}
        for index, pos in enumerate(self.grid_positions):
            self.grid[pos] = str(index+1)
        self.grid_blank = (3,3)
        self.grid_size = (40,40)
        self.grid_xy = (30,30)
        self.control_move = None
        self.move_offset = None
        self.move_rate = self.grid_size[0]//4
        self.move_step = 0
        self.last_move = None
        self.count = 0
        self.grid_timer = 0
        self.grid_initialize = False
        self.puzzle_solving = False

    def puzzle_outline(self):
        """Draw outline around puzzle controls."""
        panel_image = self.get_panel_image(change=True)
        pygame.draw.rect(panel_image, (14,20,27), (10,10,160,160), 2)
        self.panel_update()

    def init(self):
        """Shuffle puzzle controls."""
        ctrl = self.get_control()
        next = {}
        ids = [str(i) for i in range(1,16)]
        try:
            ids.remove(self.last_move)
        except ValueError:
            pass
        random.shuffle(ids)
        for id in ids:
            pos = (ctrl[id].position[0]-self.grid_xy[0]+(ctrl[id].size[0]//2))//ctrl[id].size[0], (ctrl[id].position[1]-self.grid_xy[1]+(ctrl[id].size[1]//2))//ctrl[id].size[1]
            if (pos[0] == self.grid_blank[0] and abs(pos[1]-self.grid_blank[1]) == 1) or (pos[1] == self.grid_blank[1] and abs(pos[0]-self.grid_blank[0]) == 1):
                break
        self.last_move = id
        self.control_move = id
        self.move_offset = (self.grid_blank[0]*self.move_rate - pos[0]*self.move_rate, self.grid_blank[1]*self.move_rate - pos[1]*self.move_rate)
        self.grid_blank = pos
        self.count += 1
        if self.count > 100 and self.grid_blank == (3,3):
            self.count = 0
            return True
        else:
            return False

    def puzzle(self, state):
        """Slide puzzle controls."""
        ctrl = self.get_control(state.control)
        pos = (ctrl.position[0]-self.grid_xy[0]+(ctrl.size[0]//2))//ctrl.size[0], (ctrl.position[1]-self.grid_xy[1]+(ctrl.size[1]//2))//ctrl.size[1]
        if (pos[0] == self.grid_blank[0] and abs(pos[1]-self.grid_blank[1]) == 1) or (pos[1] == self.grid_blank[1] and abs(pos[0]-self.grid_blank[0]) == 1):
            self.move_offset = (self.grid_blank[0]*self.move_rate - pos[0]*self.move_rate, self.grid_blank[1]*self.move_rate - pos[1]*self.move_rate)
            self.control_move = state.control
            self.grid_blank = pos

    def puzzle_final(self):
        """Check if puzzle is complete."""
        controls = self.get_control()
        success = True
        for ctrl_id in xrange(1,16):
            id = str(ctrl_id)
            pos = (controls[id].position[0]-self.grid_xy[0]+(controls[id].size[0]//2))//controls[id].size[0], (controls[id].position[1]-self.grid_xy[1]+(controls[id].size[1]//2))//controls[id].size[1]
            if controls[id].value != self.grid[pos]:
                success = False
                break
        return success

    def move(self):
        """Puzzle control move."""
        if self.move_step < 4:
            self.move_control(self.control_move, offset=self.move_offset)
            self.move_step += 1
            complete = False
        else:
            self.control_move = None
            self.move_step = 0
            complete = True
        return complete

    def update(self):
        """Puzzle update."""
        state = interphase.Interface.update(self)
        if state.control == 'Start':
            self.get_control('Start').set_active(False)
            self.grid_initialize = True
        if self.grid_initialize:
            if self.control_move:
                self.move()
                return
            complete = self.init()
            if complete:
                self.grid_initialize = False
                self.puzzle_solving = True
                self.grid_timer = pygame.time.get_ticks()
        if self.puzzle_solving:
            if self.control_move:
                complete = self.move()
                if complete:
                    success = self.puzzle_final()
                    if success:
                        self.puzzle_solving = False
                        time = ( pygame.time.get_ticks() - self.grid_timer ) // 1000
                        control_start = self.get_control('Start')
                        control_start.set_value(str(time)+'s')
                        control_start.set_active(True)
                return
            else:
                if state.control:
                    self.puzzle(state)
            return


def puzzle():
    pygame.display.init()   #pygame.init()
    pygame.display.set_caption('Sliding Control')
    screen = pygame.display.set_mode((220,220))
    background = pygame.Surface((220,220))
    pygame.display.flip()
    clock = pygame.time.Clock()
    interface_panel = Interface(screen)
    panel = pygame.sprite.RenderUpdates(interface_panel)
    run_puzzle = True
    while run_puzzle:
        panel.update()
        panel.clear(screen,background)
        update_rect = panel.draw(screen)
        pygame.display.update(update_rect)
        clock.tick(40)
        for event in pygame.event.get():
            if event.type==pygame.QUIT or (event.type==pygame.KEYDOWN and event.key==pygame.K_ESCAPE):
                run_puzzle = False


def main():
    puzzle()

if __name__ == '__main__':
    main()

