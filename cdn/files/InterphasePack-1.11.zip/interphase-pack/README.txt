Interphase Pack
Version 1.11
http://gatc.ca/projects/interphase-pack/

Interphase Pack includes the programs Serpent Duel, Pod Descent, and Sliding Control Puzzle. The interfaces in the programs were designed using the Interphase module, which facilitates coding interface panel functionality for Pygame applications. The source code of the programs (serpentduel.py, poddescent.py, and slidingcontrol.py) can be used to
demonstrate the module's functionality. The source requires Python and Pygame and run with 'python pack.py'. Also available are executables that have Python dependencies included, and run with './pack' (Linux) or 'pack.exe' (Windows). Use config.ini if need to setup display gamma.

Interphase Pack is released under the GPL3 License, see LICENSE.txt for further information.

Module included:
Interphase:         http://gatc.ca/projects/interphase/

Dependencies:
Python 2.5+:        http://www.python.org/
Pygame 1.8+:        http://www.pygame.org/

