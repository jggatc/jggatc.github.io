#!/usr/bin/env python
from __future__ import division

"""
Replicator Machine
Copyright (C) 2009 James Garnon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Replicator Machine version 1.2
Download Site: http://gatc.ca

Dependencies:
    Python 2.5:   http://www.python.org/
    PyGame 1.8:   http://www.pygame.org/
    Numpy:        http://numpy.scipy.org/
    Psyco:        http://psyco.sourceforge.net/
"""

version = '1.2'

try:
    import pygame
    from pygame.locals import *
    from pygame import bufferproxy
    import numpy
except ImportError:
    raise ImportError, "Pygame and Numpy modules are required."
try:
    import psyco
    psyco.full()
except ImportError:
    print("Warning: Psyco module recommended.")
import interphase
import random
import math
import os
import sys
import optparse

test = False
if not test:
    import warnings
    warnings.filterwarnings("ignore")

MATRIX_X = 1000
MATRIX_Y = 1000
DISPLAY_X = 500
DISPLAY_Y = 500

class Matrix(object):
    def __init__(self):
        pygame.init()
        pygame.display.set_caption('Replicator Machine')
        iconname = os.path.join('data', 'icon.png')
        icon = pygame.image.load(iconname)
        pygame.display.set_icon(icon)
        if config['display_gamma']:
            gamma_set = pygame.display.set_gamma(config['display_gamma'])
        self.screen = pygame.display.set_mode((DISPLAY_X,DISPLAY_Y))
        if config['display_gamma'] and not gamma_set:   #if prior set_gamma failed
            gamma_set = pygame.display.set_gamma(config['display_gamma'])
        pygame.surfarray.use_arraytype('numpy')
        self.borders = self.matrix_borders()
        self.overlap = 50     #screen field overlap
        self.field_x = (MATRIX_X//2)-(DISPLAY_X//2)   #for field scroll
        self.field_y = (MATRIX_Y//2)
        self.virus = pygame.sprite.RenderUpdates()
        self.virus_add = False
        self.virus_count = 0
        self.virus_count_i = ((MATRIX_X*MATRIX_Y)//40000)
        self.virus_variant = 1
        self.virus_mutation = False
        self.screen_matrix = pygame.display.get_surface()
        self.creatures = pygame.sprite.OrderedUpdates()
        self.info = interphase.DisplayMsg(self.screen)
        self.info.set_font_color((82,96,116))
        self.control_list = []
        self.volume = 0.3   #v1.2
        self.ending = False
        self.signal_lost = load_sound("signal_lost.ogg")
        self.level = 1  #difficulty level
        self.bot = pygame.sprite.GroupSingle()
        self.projectiles = pygame.sprite.RenderUpdates()    #projectile group
        self.cells = pygame.sprite.OrderedUpdates()      #cell group
        self.infected_cell = pygame.sprite.RenderUpdates()      #cells infected with virus
        self.replicating_cell = pygame.sprite.RenderUpdates()   #cells replicating for regrowth
        self.resting_cell = pygame.sprite.RenderUpdates()   #cells not infected or replicating
        self.areas, self.area_rect, self.area_cell = self.matrix_rect()     #regions
        self.area_scan = 0
        self.cells_new = pygame.sprite.OrderedUpdates()
        self.screen_base = pygame.Surface((DISPLAY_X,DISPLAY_Y))
        self.base_image = load_image('base.png')
        self.screen_base.blit(self.base_image, (0,0))
        self.screen.blit(self.screen_base, (0,0))
        self.macs = pygame.sprite.RenderUpdates()
        self.macrophage_count = 0
        self.macrophage_count_i = ((MATRIX_X*MATRIX_Y)//250000)
        self.cell_count = 0
        self.cell_count_i = (MATRIX_X//50) * (MATRIX_Y//50)
        self.cell_map = numpy.ones((MATRIX_X//50,MATRIX_Y//50), 'i')      #v1.2
        self.cell_randomized = []   #randomized list of cells
        pygame.mixer.set_num_channels(132)   #lack of channels cause crash
        self.scroll_left = 0
        self.scroll_right = 0
        self.scroll_up = 0
        self.scroll_down = 0
        self.scroll = False
        self.edge_check_count = 0   #interval to check virus at edge
        self.update_list = []   #list of object to update display
        self.display_update = False   #update cells on screen
        self.macrophage_activated = False   #macrophages activated by vaccine pulse
        self.map_surface = pygame.Surface((20,20))
        self.map_surface_zoom = pygame.Surface((60,60))
        self.cell_map2 = numpy.ones((MATRIX_X//50,MATRIX_Y//50), 'i')   #v1.2
        self.cell_map2.fill(0x232835)
        pygame.surfarray.blit_array(self.map_surface, self.cell_map2)
        self.map_surface_zoom = pygame.transform.smoothscale(self.map_surface, (60,60))
        self.map_update = 0
        self.life_surface = pygame.Surface((60,5))
        self.check_count = 0
        self.check_rate = 10
        self.simulation = False
        self.cell = None
        self.warp = 0
        self.warp_speed = 20
        self.warp_time = 0
        self.warp_distance = 0
        self.warp_engaged = False
        self.destination = False
        self.map_display = True
        self.screen_temp = pygame.Surface((DISPLAY_X,DISPLAY_Y))
        self.screen_temp2 = pygame.Surface((DISPLAY_X,DISPLAY_Y))
        self.endgame_move = 0
        self.stage = 1      #three stages of outbreak before infection irradicated
    def opening(self, escape=False):
        self.menu()
        quit = False
        while not quit:
            control.clock.tick(40)
            for event in pygame.event.get():
                if (event.type == QUIT):
                    control.quit = True
                    quit = True
                elif (event.type == KEYDOWN) and (event.key == K_ESCAPE):   #resume
                    if escape:
                        self.display_update = True
                        return True
                elif (event.type == KEYDOWN) and (event.key == K_1):
                    self.setup()
                    quit = True
                elif (event.type == KEYDOWN) and (event.key == K_2):
                    self.setup(simulation=True)
                    quit = True
                elif (event.type == KEYDOWN) and (event.key == K_3):
                    self.control_info()
                    self.menu()
                elif (event.type == KEYDOWN) and (event.key == K_4):
                    control.quit = True
                    quit = True
    def menu(self):
        menu_list = [ ("Replicator Machine",32,(100,100)), ("1. Battle",24,(180,200)), ("2. Simulation",24,(180,250)), ("3. Control",24,(180,300)), ("4. Quit",24,(180,350)) ]
        self.screen.fill((0,0,0))
        for item in menu_list:
            self.info.add(item[0])
            self.info.set_font_size(item[1])
            self.info.set_position(item[2])
            self.info()
        pygame.display.flip()
        return
    def control_info(self):
        if not self.control_list:
            try:
                controls = open('control.txt', 'r')
                for item in controls:
                    key = item[:20].strip()
                    command = item[20:].strip()
                    control_item = { 'key':key, 'command':command }
                    self.control_list.append(control_item)
                controls.close()
            except IOError:
                return
        self.screen.fill((0,0,0))
        self.info.set_font_size(12)
        count = 30
        for control_item in self.control_list:
            self.info.add(control_item['key'])
            self.info.set_position((100,count))
            self.info()
            self.info.add(control_item['command'])
            self.info.set_position((230,count))
            self.info()
            count += 15
        interrupt = False
        while not interrupt:
            control.clock.tick(40)
            for event in pygame.event.get():
                if event.type == QUIT:
                    control.quit = True
                elif event.type == KEYDOWN:
                    interrupt = True
            pygame.display.flip()
        return
    def setup(self, level=1, simulation=False):
        if simulation:
            self.simulation = True
            pygame.event.set_grab(False)
            control.panel.initialize()
        else:
            self.simulation = False
            if control.mouse_enabled:
                pygame.event.set_grab(True)
        pygame.mixer.stop()     #v1.2
        self.cells.empty()
        self.resting_cell.empty()
        self.infected_cell.empty()
        self.replicating_cell.empty()
        self.virus.empty()
        self.virus.empty()
        self.macs.empty()
        self.bot.empty()
        self.projectiles.empty()
        self.creatures.empty()
        for area in self.area_cell:      #empty cell regional grouping
            self.area_cell[area].empty()
        self.field_x = (MATRIX_X//2)-(DISPLAY_X//2)   #for field scroll
        self.field_y = (MATRIX_Y//2)
        self.cell_count = 0
        self.virus_count = 0
        self.macrophage_count = 0
        self.macrophage_activated = False
        self.virus_variant = 1
        self.virus_mutation = False
        self.level = 1
        self.stage = 1
        self.ending = False
        self.cell_map = numpy.ones((MATRIX_X//50,MATRIX_Y//50) , 'i')   #v1.2
        for y in xrange(MATRIX_X//50):
            for x in xrange(MATRIX_Y//50):
                self.add_creature('Cell', (x,y))
        if not simulation:
            for i in xrange(self.macrophage_count_i):
                self.add_creature('Macrophage')
            self.add_creature('Nanobot')
        infected_cells = random.sample(self.resting_cell.sprites(), self.virus_count_i)
        for cell in infected_cells:
            cell.infect_set(virus_variant=self.level, infect_time=random.randrange(490))
            self.cell_state(cell, 'infected')
        self.virus_count = self.virus_count_i
        self.cell_map2 = numpy.ones((MATRIX_X//50,MATRIX_Y//50), 'i')   #v1.2
        self.cell_map2.fill(0x232835)
        pygame.surfarray.blit_array(self.map_surface, self.cell_map2)
        self.map_surface_zoom = pygame.transform.smoothscale(self.map_surface, (60,60))
        self.display_update = True
        self.matrix_update()
    def simulation_set(self, parameter):
        if not self.simulation:
            return
        if parameter == 'Variant Switch':
            if self.virus_variant < 4:
                self.virus_variant += 1
                for virus in self.virus:
                    virus.variant = self.virus_variant
                for cell in self.infected_cell:
                    cell.virus_variant = self.virus_variant
        elif parameter == 'Mutation Operational':
            self.virus_mutation = not self.virus_mutation
        elif parameter == 'Virus Addition':
            self.add_creature('Virus')
        elif parameter == 'Macrophage Addition':
            self.add_creature('Macrophage')
        elif parameter == 'Nanobot Addition':
            self.add_creature('Nanobot')
    def level_set(self):
        if not self.simulation:
            if self.level < 3:
                self.level += 1
                for cell in self.infected_cell:
                    cell.virus_variant += 1
    def endgame_check(self):
        if self.simulation:
            return False
        if not self.ending:
            if not (self.bot.sprite and self.virus_count > 0):
                self.ending = True
                if self.bot.sprite:
                    if self.stage < 3:
                        self.stage += 1
                        self.endgame_move = 1
                        return True
                    else:
                        self.endgame_move = 100
                        return True
                else:
                    self.endgame_move = -1
                    return True
            else:
                return False
        else:
            return True
    def endgame(self):
        if self.endgame_move == 1:
            gathering_signal = self.endgame_sequence('Gathering Signal')
            if gathering_signal:
                self.endgame_move = 2
        elif self.endgame_move == 2:
            gathering = self.endgame_sequence('Gathering')
            if gathering:
                self.endgame_move = 3
        elif self.endgame_move == 3:
            warp_initiate = self.endgame_sequence('Warp Initiate')
            if warp_initiate:
                self.endgame_move = 4
        elif self.endgame_move == 4:
            warp_engage = self.endgame_sequence('Warp')
            if warp_engage:
                self.endgame_move = 5
        elif self.endgame_move == 5:
            destination = self.endgame_sequence('Transwarp')
            if destination:
                self.endgame_move = 6
        elif self.endgame_move == 6:
            finale = self.endgame_sequence('Finale')
            if finale:
                self.endgame_move = 0
        elif self.endgame_move == 100:
            gathering_signal = self.endgame_sequence('Gathering Signal')
            if gathering_signal:
                self.endgame_move = 0
                self.endgame_sequence('Pandemic Averted')
        elif self.endgame_move == -1:
            signal_lost = self.endgame_sequence('Signal Lost')
            if signal_lost:
                self.endgame_move = 0
    def endgame_sequence(self, phase):
        if phase == 'Gathering Signal':
            if not self.bot.sprite.vaccine_released:
                if not self.bot.sprite.vaccine_pulse_load:
                    self.bot.sprite.vaccine_pulse_load = True
                self.matrix_update()
                return False
            else:
                self.bot.sprite.tractor_beam = True
                self.bot.sprite.tractor_beam_captured = True
                for mac in self.macs:
                    mac.activate_count = 1000
                    mac.girth = 100
                    mac.tractor_beam = True
                self.matrix_update()
                return True
        elif phase == 'Gathering':
            for mac in self.macs:   #behind bot
                if mac.y < self.bot.sprite.y+50:
                    mac.pos_y += 2
                    mac.y = int(mac.pos_y)
            self.matrix_update()
            for mac in self.macs:
                if ((mac.y>self.bot.sprite.y and mac.y<self.bot.sprite.y+150) or (mac.y >= MATRIX_Y-50)) and (mac.x>self.bot.sprite.x-150 and mac.x<self.bot.sprite.x+150):
                    inplace = True
                else:
                    inplace = False
                    break
            if inplace:
                self.warp_engaged = True
                self.bot.sprite.rotate = 0
                self.bot.sprite.bot_velocity = 0
                self.bot.sprite.velocity = 0
                self.bot.sprite.velocity_l = 0
                self.bot.sprite.velocity_r = 0
                self.bot.sprite.toggle_forward = False
                self.bot.sprite.toggle_reverse = False
                self.bot.sprite.toggle_motion = False
                self.bot.sprite.toggle_left = False
                self.bot.sprite.toggle_right = False
                self.bot.sprite.toggle_strafeleft = False
                self.bot.sprite.toggle_straferight = False
                self.map_display = False
                return True
            else:
                return False
        elif phase == 'Warp Initiate':
            for y in xrange(MATRIX_X//50):
                for x in xrange(MATRIX_Y//50):
                    cell = (Cell(x,y))
                    self.cells_new.add(cell)
            field_x = (MATRIX_X//2)-(DISPLAY_X//2)
            field_y = (MATRIX_Y//2)
            self.screen_temp.blit(self.base_image, (0,0))
            self.creatures.add(self.cells_new.sprites())
            for bug in self.creatures:       #adjust display location
                bug.rect.centerx -= field_x
                bug.rect.centery -= field_y
            self.creatures.draw(self.screen_temp)
            for bug in self.creatures:       #restore location
                bug.rect.centerx += field_x
                bug.rect.centery += field_y
            self.creatures.empty()
            infected_cells = random.sample(self.cells_new.sprites(), self.virus_count_i)
            for cell in infected_cells:
                if self.level < 3:
                    variant = self.level+1
                else:
                    variant = self.level
                cell.infect_set(virus_variant=variant, infect_time=random.randrange(490))
            self.screen_temp2.blit(self.base_image, (0,0))
            self.cells_new.update()
            self.creatures.add(self.cells_new.sprites())
            for bug in self.creatures:       #adjust display location
                bug.rect.centerx -= field_x
                bug.rect.centery -= field_y
            self.creatures.draw(self.screen_temp2)
            for bug in self.creatures:       #restore location
                bug.rect.centerx += field_x
                bug.rect.centery += field_y
            self.creatures.empty()
            return True
        elif phase == 'Warp':
            scroll = self.matrix_scroll('u',self.warp_speed)
            if scroll:
                self.warp_distance += self.warp_speed
                self.bot.sprite.pos_y -= self.warp_speed
                self.bot.sprite.y -= self.warp_speed
                for mac in self.macs:
                    mac.pos_y -= self.warp_speed
                    mac.y -= self.warp_speed
                if self.bot.sprite.direction >= 10:
                    if self.bot.sprite.direction < 180:
                        self.bot.sprite.direction -= 10
                    else:
                        self.bot.sprite.direction += 10
                else:
                    self.bot.sprite.direction = 0
                self.matrix_update()
                return False
            else:
                self.field_y += self.warp_distance
                self.bot.sprite.pos_y += self.warp_distance
                self.bot.sprite.y += self.warp_distance
                for mac in self.macs:
                    mac.pos_y += self.warp_distance
                    mac.y += self.warp_distance
                self.warp_distance = 0
                if self.field_x < (MATRIX_X//2)-(DISPLAY_X//2):       #adjust position to next level
                    field_adjust_x = ((MATRIX_X//2)-(DISPLAY_X//2)) - self.field_x
                elif self.field_x > (MATRIX_X//2)-(DISPLAY_X//2):
                    field_adjust_x = ((MATRIX_X//2)-(DISPLAY_X//2)) - self.field_x
                else:
                    field_adjust_x = 0
                field_adjust_y = (MATRIX_Y//2) - self.field_y
                self.field_x += field_adjust_x
                self.field_y += field_adjust_y
                self.bot.sprite.pos_x += field_adjust_x
                self.bot.sprite.x = int(self.bot.sprite.pos_x)
                self.bot.sprite.pos_y += field_adjust_y
                self.bot.sprite.y = int(self.bot.sprite.pos_y)
                for mac in self.macs:
                    mac.pos_x += field_adjust_x
                    mac.x = int(mac.pos_x)
                    mac.pos_y += field_adjust_y
                    mac.y = int(mac.pos_y)
                return True
        elif phase == 'Transwarp':
            if self.warp_time <= 5:
                self.warp += self.warp_speed
                if self.warp <= DISPLAY_Y:
                    self.screen.blit(self.screen_base, (0,self.warp), (0,0,DISPLAY_X,DISPLAY_Y-self.warp))
                    if not self.destination:
                        self.screen.blit(self.screen_temp, (0,0), (0,DISPLAY_Y-self.warp,DISPLAY_X,self.warp))
                    else:
                        self.screen.blit(self.screen_temp2, (0,0), (0,DISPLAY_Y-self.warp,DISPLAY_X,self.warp))
                    if self.bot.sprite.direction >= 10:
                        if self.bot.sprite.direction < 180:
                            self.bot.sprite.direction -= 10
                        else:
                            self.bot.sprite.direction += 10
                    else:
                        self.bot.sprite.direction = 0
                    self.bot.update()
                    self.macs.update()
                    self.creatures.add([creature for creature in self.macs])
                    self.creatures.add(self.bot.sprite)
                    for bug in self.creatures:       #adjust display location
                        bug.rect.centerx -= self.field_x
                        bug.rect.centery -= self.field_y
                    self.creatures.draw(self.screen)
                    for bug in self.creatures:       #restore location
                        bug.rect.centerx += self.field_x
                        bug.rect.centery += self.field_y
                    self.creatures.empty()
                    self.display_update = True
                else:
                    self.warp = 0
                    self.warp_time += 1
                    if self.warp_time == 1:
                        self.screen_base = self.screen_temp.copy()
                    elif self.warp_time == 5:
                        self.destination = True
                return False
            else:
                self.warp = 0
                self.warp_time = 0
                self.destination = False
                self.display_update = True
                return True
        elif phase == 'Finale':
            self.cells.empty()
            self.resting_cell.empty()
            self.infected_cell.empty()
            self.replicating_cell.empty()
            self.virus.empty()
            self.cell_count = 0
            self.virus_count = 0
            for area in self.area_cell:
                self.area_cell[area].empty()
            self.cells = self.cells_new.copy()
            for cell in self.cells:
                self.cell_state(cell, 'resting')
                if cell.isinfect:
                    self.cell_state(cell, 'infected')
                self.cell_count += 1
            self.cell_map = numpy.ones((MATRIX_X//50,MATRIX_Y//50), 'i')    #v1.2
            self.cell_map2 = numpy.ones((MATRIX_X//50,MATRIX_Y//50), 'i')   #v1.2
            self.cell_map2.fill(0x101219)
            pygame.surfarray.blit_array(self.map_surface, self.cell_map2)
            self.map_surface_zoom = pygame.transform.smoothscale(self.map_surface, (60,60))
            self.virus_count = self.virus_count_i
            self.cells_new.empty()
            self.bot.sprite.life_force = 100
            self.bot.sprite.tractor_beam = False
            self.bot.sprite.tractor_beam_captured = None
            self.bot.sprite.velocity_max = 6.0
            for mac in self.macs:
                mac.activation_state = 0
                mac.tractor_beam = False
            self.macrophage_activated = False
            self.display_update = True
            self.map_display = True
            self.matrix_update()
            self.ending = False
            self.warp_engaged = False
            if self.level < 3:
                self.level += 1
            return True
        elif phase =='Pandemic Averted':  #After three stages of infection, bot vaccine programming complete
            while self.cell_count < self.cell_count_i:
                self.update_list = []    #rect list to be updated on display
                self.matrix_update()
                if not self.display_update:
                    pygame.display.update(self.update_list)
                else:
                    pygame.display.flip()
                    self.display_update = False
                control.update()
            else:
                self.opening()
        elif phase == 'Signal Lost':
            pygame.mixer.stop()
            self.signal_lost.set_volume(self.volume)    #v1.2
            self.signal_lost.play(-1)
            pygame.time.delay(500)
            interrupt = False
            for update in xrange(100):
                for i in xrange(5000):
                    size = random.randrange(1,3)
                    x = random.randrange(DISPLAY_X-1)
                    y = random.randrange(DISPLAY_Y-1)
                    pygame.draw.circle(self.screen_matrix, (225,225,225), (x,y), size, 0)
                pygame.display.flip()
                control.clock.tick(40)
                self.screen_matrix.fill((10,10,10))
                if interrupt:
                    break
                for event in pygame.event.get():
                    if event.type == QUIT:
                        control.quit = True
                    elif event.type == KEYDOWN:
                        if update > 25:
                            interrupt = True
            self.signal_lost.stop()
            self.opening()
            return True
    def set_volume(self):
        Nanobot.shot_sound.set_volume(self.volume)  #v1.2
        Macrophage.sound.set_volume(self.volume)    #v1.2
    def matrix_borders(self):
        class Edge(pygame.sprite.Sprite):
            def __init__(self, x, y, dim_x, dim_y, side):
                pygame.sprite.Sprite.__init__(self)
                self.rect = pygame.Rect(x,y,dim_x,dim_y)
                self.side = side
        borders = pygame.sprite.Group()
        borders.add( Edge(0,0,MATRIX_X,1,'n') )
        borders.add( Edge(0,MATRIX_Y-2,MATRIX_X,1,'s') )
        borders.add( Edge(0,0,1,MATRIX_Y,'w') )
        borders.add( Edge(MATRIX_X-2,0,1,MATRIX_Y,'e') )
        return borders
    def matrix_rect(self):  #matrix divided into regions
        """Areas: rect: (250,250) position: (0,0), (250,0), (500,0), (750,0), (0,250), (250,250), (500,250), (750,250), (0,500), (250,500), (500,500), (750,500), (0,750), (250,750), (500,750), (750,750)"""
        class Area_rect(pygame.sprite.Sprite):
            def __init__(self, position, size):
                pygame.sprite.Sprite.__init__(self)
                self.position = position
                self.rect = pygame.Rect(position,size)
        areas = []
        area_rect = pygame.sprite.Group()
        area_cell = {}
        for y in xrange(0,MATRIX_Y,250):
            for x in xrange(0,MATRIX_X,250):
                areas.append((x,y))
                area_rect.add( Area_rect((x,y),(250,250)) )
                area_cell[(x,y)] = pygame.sprite.Group()
        return areas, area_rect, area_cell
    def cell_area_position(self, cell_group):
        area_cell = pygame.sprite.groupcollide(self.area_rect, cell_group, False, False)
        for area, cells in area_cell.iteritems():
            for cell in cells:
                if area.rect.collidepoint((cell.x,cell.y)):
                    self.area_cell[area.position].add(cell)
                    cell.area_position = area.position
    def cell_state(self, cell, state):
        if state == 'resting':
            self.resting_cell.add(cell)
            cell_group = pygame.sprite.GroupSingle(cell)
            self.cell_area_position(cell_group)
            cell_group.empty()
        elif state == 'replicating':
            self.replicating_cell.add(cell)     #add to replicating cell group for updating
            self.resting_cell.remove(cell)
        elif state == 'infected':
            self.infected_cell.add(cell)
            self.resting_cell.remove(cell)     #remove for transfer to infected_cell
            self.replicating_cell.remove(cell)
            self.area_cell[cell.area_position].remove(cell)
    def add_creature(self, creature, location=None):
        new_creature = None
        if creature == 'Virus':
            if ( self.virus_count < self.virus_count_i*100 ):
                if not location:
                    x_initial = random.randrange(10, MATRIX_X-10)
                    y_initial = random.randrange(10, MATRIX_Y-10)
                else:
                    x_initial, y_initial = location
                if not self.simulation:
                    virus_variant = matrix.level
                else:
                    virus_variant = self.virus_variant
                new_creature = Virion(x_initial, y_initial, variant=virus_variant)
                self.virus.add(new_creature)
                self.virus_count += 1
        elif creature == 'Cell':
            if not location:
                x_initial = random.randrange(100, MATRIX_X-100)
                y_initial = random.randrange(100, MATRIX_Y-100)
            else:
                x_initial, y_initial = location               
            new_creature = Cell(x_initial, y_initial)
            self.cells.add(new_creature)
            self.cell_state(new_creature, 'resting')
            self.cell_count += 1
        elif creature == 'Macrophage':
            if ( self.macrophage_count < self.macrophage_count_i*100 ):
                if not location:
                    x_initial = random.randrange(100, MATRIX_X-100)
                    y_initial = random.randrange(100, MATRIX_Y-100)
                else:
                    x_initial, y_initial = location               
                new_creature = Macrophage(x_initial, y_initial)
                self.macs.add(new_creature)
                self.macrophage_count += 1
        elif creature == 'Nanobot':
            if not location:
                x_initial, y_initial = 250+self.field_x,250+self.field_y
            else:
                x_initial, y_initial = location
            new_creature = Nanobot(x_initial, y_initial)
            self.bot.add(new_creature)
        return new_creature
    def remove_creature(self, creature, obj):
        if creature == 'Virus':
            obj.kill()
            self.virus_count -= 1
        elif creature == 'Cell':
            obj.kill()
            self.cell_count -= 1
    def matrix_map(self):
        self.map_update += 1
        if self.map_update > 10:
            self.cell_map2 = numpy.where(self.cell_map==1, 0x232835, 0x000000)
            pygame.surfarray.blit_array(self.map_surface, self.cell_map2)
            self.map_surface_zoom = pygame.transform.smoothscale(self.map_surface, (60,60))
            self.map_update = 0
        map_surface = self.map_surface_zoom.copy()
        map_surface.lock()
        for virus in self.virus:
            pygame.draw.circle(map_surface, virus.color, (virus.x//(MATRIX_X//60), virus.y//(MATRIX_Y//60)), 0, 0)
        map_surface.unlock()
        for mac in self.macs:
            map_surface.blit(mac.imagex, ((mac.x//(MATRIX_X//60))-4, (mac.y//(MATRIX_Y//60))-4))
        map_surface.lock()
        for projectile in self.projectiles:
            pygame.draw.circle(map_surface, 0x59abe5, (projectile.x//(MATRIX_X//60), projectile.y//(MATRIX_Y//60)), 0, 0)
        map_surface.unlock()
        try:
            w, h = self.bot.sprite.imagex[self.bot.sprite.direction].get_size()
            map_surface.blit(self.bot.sprite.imagex[self.bot.sprite.direction], ((self.bot.sprite.x//(MATRIX_X//60))-(w//2), (self.bot.sprite.y//(MATRIX_Y//60))-(h//2)))
        except AttributeError:  #no bot
            pass
        map_rect = self.screen_matrix.blit(map_surface, (430,430))
        pygame.draw.rect(self.screen_matrix, 0x0f1215, (429,429,62,62), 2)
        try:
            life_force = self.bot.sprite.life_force
            life_line = int((life_force/100)*60)   #bot life force
            self.life_surface.fill(0x680000)
            if life_force > 25:
                self.life_surface.fill(0x73d74b, (0,0,life_line,5))
            else:
                if random.random() > 0.2:
                    self.life_surface.fill(0x73d74b, (0,0,life_line,5))
                else:
                    self.life_surface.fill(0x680000, (0,0,life_line,5))
            life_rect = self.screen_matrix.blit(self.life_surface, (430,492))
            pygame.draw.rect(self.screen_matrix, 0x0f1215, (429,491,62,7), 2)
        except AttributeError:
            life_rect = None
        return map_rect, life_rect
    def matrix_scroll(self, direction, field_change=10):
        if direction == 'u':
            if self.field_y >= field_change:
                self.field_y -= field_change
                self.display_update = True
                return True
            else:
                return False
        elif direction == 'd':
            if self.field_y <= MATRIX_Y-DISPLAY_Y-field_change:
                self.field_y += field_change
                self.display_update = True
                return True
            else:
                return False
        elif direction == 'l':
            if self.field_x >= field_change:
                self.field_x -= field_change
                self.display_update = True
                return True
            else:
                return False
        elif direction == 'r':
            if self.field_x <= MATRIX_X-DISPLAY_X-field_change:
                self.field_x += field_change
                self.display_update = True
                return True
            else:
                return False
    def bot_scroll(self):
        if self.bot.sprite:
            if self.bot.sprite.rect.centerx < self.field_x+10 and not self.scroll_left:
                self.scroll_left = 25
            elif self.bot.sprite.rect.centerx > self.field_x+DISPLAY_X-10 and not self.scroll_right:
                self.scroll_right = 25
            if self.bot.sprite.rect.centery < self.field_y+10 and not self.scroll_up:
                self.scroll_up = 25
            elif self.bot.sprite.rect.centery > self.field_y+DISPLAY_Y-10 and not self.scroll_down:
                self.scroll_down = 25
            if self.scroll_left or self.scroll_right or self.scroll_up or self.scroll_down:
                self.scroll = True
            else:
                self.scroll = False
            if self.scroll_left:
                if self.field_x - 10 >= 0:
                    self.field_x -= 10
                    self.scroll_left -= 1
                else:
                    self.scroll_left = 0
            elif self.scroll_right:
                if self.field_x + 10 <= MATRIX_X-DISPLAY_X:
                    self.field_x += 10
                    self.scroll_right -= 1
                else:
                    self.scroll_right = 0
            if self.scroll_up:
                if self.field_y - 10 >= 0:
                    self.field_y -= 10
                    self.scroll_up -= 1
                else:
                    self.scroll_up = 0
            elif self.scroll_down:
                if self.field_y + 10 <= MATRIX_Y-DISPLAY_Y:
                    self.field_y += 10
                    self.scroll_down -= 1
                else:
                    self.scroll_down = 0
            return self.scroll
    def cell_map_update(self, position, state):
        """State of positions in cell map. State 0:Empty, 1:Fill, 2:Hold."""
        self.cell_map[position] = state
    def infection_check(self):
        event_onscreen = False
        area = self.areas[self.area_scan]
        cell_collide = pygame.sprite.groupcollide(self.area_cell[area], self.virus, False, False)
        for cell, viruses in cell_collide.iteritems():
            for virus in viruses:
                if not virus.infecting:
                    isinfect = cell.infection(virus)
                    if isinfect:
                        self.cell_state(cell, 'infected')
                        if cell.rect.centerx > 0+self.field_x-self.overlap//5 and cell.rect.centerx < DISPLAY_X+self.field_x+self.overlap//5 and cell.rect.centery > 0+self.field_y-self.overlap//5 and cell.rect.centery < DISPLAY_Y+self.field_y+self.overlap//5:
                            event_onscreen = True    #only update if onscreen
                        if not self.simulation:
                            mutation = virus.mutate()
                        else:
                            if self.virus_mutation:
                                mutation = virus.mutate()
                            else:
                                mutation = False
                        if not mutation:
                            variant = virus.variant
                        else:
                            variant = virus.variant + 1
                        cell.virus_variant = variant
                        virus.infecting = True     #virus infecting cell
                        self.virus.remove(virus)   #virus count unchanged
                        break
        self.area_scan += 1
        if self.area_scan > 15:
            self.area_scan = 0
        return event_onscreen
    def infected_cell_check(self):
        event_onscreen = False
        for cell in self.infected_cell:
            if cell.rip:
                virus_variant = cell.virus_variant
                cell.virus_variant = None
                progeny = Virion.variants[virus_variant]['progeny']
                for i in xrange(progeny):
                    x_initial = cell.rect.centerx
                    y_initial = cell.rect.centery
                    self.virus.add(Virion(x_initial, y_initial, virus_variant))
                self.virus_count += progeny-1    #less one for infected virus
                if cell.rect.centerx > 0+self.field_x-self.overlap//5 and cell.rect.centerx < DISPLAY_X+self.field_x+self.overlap//5 and cell.rect.centery > 0+self.field_y-self.overlap//5 and cell.rect.centery < DISPLAY_Y+self.field_y+self.overlap//5:
                    event_onscreen = True
                self.remove_creature('Cell', cell)
        return event_onscreen
    def cell_regrowth_check(self):
        event_onscreen = False
        for cell in self.replicating_cell:
            if cell.isgrown:
                cell.isgrown = False
                new_cell = self.add_creature('Cell', location=(cell.grow_grid[0],cell.grow_grid[1]))
                if new_cell.rect.centerx > 0+self.field_x-self.overlap//5 and new_cell.rect.centerx < DISPLAY_X+self.field_x+self.overlap//5 and new_cell.rect.centery > 0+self.field_y-self.overlap//5 and new_cell.rect.centery < DISPLAY_Y+self.field_y+self.overlap//5:
                    event_onscreen = True
                self.replicating_cell.remove(cell)
                self.resting_cell.add(cell)    #transfer back to resting cell
        return event_onscreen
    def cell_check(self):
        try:
            cell = self.cell_randomized.pop()   #check cells occasionally, trigger cell regrowth programming
            if cell in self.resting_cell:
                check_regrowth_initialized = cell.update()
                if check_regrowth_initialized:          #cell initiated regrowth
                    self.cell_state(cell, 'replicating')
        except IndexError:
            self.cell_randomized = self.resting_cell.sprites()
            random.shuffle(self.cell_randomized)
    def matrix_update(self):
        if self.bot_scroll():
            self.display_update = True
        try:
            if self.bot.sprite.vaccine_released:
                self.display_update = True
        except AttributeError:
            pass

        event_onscreen = self.infection_check()
        if event_onscreen:
            self.display_update = True

        if self.check_count > self.check_rate:
            self.cell_check()
            event_onscreen = self.infected_cell_check()
            if event_onscreen:
                self.display_update = True
            event_onscreen = self.cell_regrowth_check()
            if event_onscreen:
                self.display_update = True

        self.infected_cell.update()
        self.replicating_cell.update()

        if self.display_update:
            for bug in self.cells:
                if bug.rect.centerx > 0+self.field_x-self.overlap and bug.rect.centerx < DISPLAY_X+self.field_x+self.overlap and bug.rect.centery > 0+self.field_y-self.overlap and bug.rect.centery < DISPLAY_Y+self.field_y+self.overlap:
                    self.creatures.add(bug)
            self.screen.blit(self.base_image, (0,0))
            self.screen_base.blit(self.base_image, (0,0))
            for bug in self.creatures:       #adjust display location
                bug.rect.centerx -= self.field_x
                bug.rect.centery -= self.field_y
            self.creatures.draw(self.screen_base)
            for bug in self.creatures:       #restore location
                bug.rect.centerx += self.field_x
                bug.rect.centery += self.field_y
            self.creatures.empty()

        self.virus.update()
        if self.check_count > 10:
            virus_at_edge = pygame.sprite.groupcollide(self.virus, self.borders, False, False)
            if virus_at_edge:
                for vir in virus_at_edge:
                    vir.check_edge(virus_at_edge[vir])
            self.check_count = 0
        else:
            self.check_count += 1
        for bug in self.virus:
            if bug.rect.centerx > 0+self.field_x-self.overlap//5 and bug.rect.centerx < DISPLAY_X+self.field_x+self.overlap//5 and bug.rect.centery > 0+self.field_y-self.overlap//5 and bug.rect.centery < DISPLAY_Y+self.field_y+self.overlap//5:
                self.creatures.add(bug)      #draw cells that appear onscreen, with display overlap/5

        self.macs.update()
        for bug in self.macs:
            if bug.rect.centerx > 0+self.field_x-self.overlap*2 and bug.rect.centerx < DISPLAY_X+self.field_x+self.overlap*2 and bug.rect.centery > 0+self.field_y-self.overlap*2 and bug.rect.centery < DISPLAY_Y+self.field_y+self.overlap*2:
                self.creatures.add(bug)

        self.bot.update()
        if self.bot.sprite:
            if self.bot.sprite.rect.centerx > 0+self.field_x-self.overlap//5 and self.bot.sprite.rect.centerx < DISPLAY_X+self.field_x+self.overlap//5 and self.bot.sprite.rect.centery > 0+self.field_y-self.overlap//5 and self.bot.sprite.rect.centery < DISPLAY_Y+self.field_y+self.overlap//5:
                self.creatures.add(self.bot.sprite)      #draw cells that appear onscreen, with display overlap/5

        self.projectiles.update()
        for obj in self.projectiles:
            if obj.rect.centerx > 0+self.field_x-self.overlap//5 and obj.rect.centerx < DISPLAY_X+self.field_x+self.overlap//5 and obj.rect.centery > 0+self.field_y-self.overlap//5 and obj.rect.centery < DISPLAY_Y+self.field_y+self.overlap//5:
                self.creatures.add(obj)      #draw cells that appear onscreen, with display overlap/5

        for bug in self.creatures:       #adjust display location
            bug.rect.centerx -= self.field_x
            bug.rect.centery -= self.field_y
        self.creatures.clear(self.screen_matrix,self.screen_base)
        self.update_list.extend(self.creatures.draw(self.screen_matrix))
        for bug in self.creatures:       #restore location
            bug.rect.centerx += self.field_x
            bug.rect.centery += self.field_y
        self.creatures.empty()

        try:
            if self.bot.sprite.vaccine_pulse_load:
                pygame.draw.circle(self.screen_matrix, (255,0,0), (self.bot.sprite.x-self.field_x, self.bot.sprite.y-self.field_y), 50, 1)
            elif self.bot.sprite.vaccine_released:
                pygame.draw.circle(self.screen_matrix, (255,0,0), self.bot.sprite.vaccine_location, 701-self.bot.sprite.vaccine_released, 1)
                self.bot.sprite.vaccine_released -= 50
        except AttributeError:
            pass

        if self.map_display:
            map_rect, life_rect = self.matrix_map()
            if map_rect:
                self.update_list.append(map_rect)
            if life_rect:
                self.update_list.append(life_rect)
    def update(self):
        if not self.endgame_check():
            self.matrix_update()
        else:
            self.endgame()
        if test:
            report()

class Nanobot(pygame.sprite.Sprite):
    """Bot combats the viral infection by shooting energy projectiles. Each virus shot yields viral biomaterial that will be used to generate a nanobot-generated vaccine. Release of the vaccine pulse activates macrophage towards the virus. Bot can generate a tractor beam to tow macrophage. Bot generates a field to reduce immune detection, and if lost all macrophage will attack the bot as a foreign invader. Bot power is derived from the lifeforce of cells, and restoration of power will diminish with the decrease in cells."""
    image = {}
    images = {}
    shot_sound = None
    def __init__(self,x,y):
        pygame.sprite.Sprite.__init__(self)
        self.x = x      #location in matrix
        self.y = y
        self.pos_x = float(self.x)     #float version
        self.pos_y = float(self.y)
        self.pos_x_previous = self.pos_x
        self.pos_y_previous = self.pos_y
        if not Nanobot.image:  #load images on first instance
            img = load_image('bot.png')
            for degree in xrange(0,360):
                Nanobot.image[degree] = pygame.transform.rotozoom(img, -degree, 0.5)
            image = load_image('bots.png')
            width, height = image.get_size()
            frames = 11
            image_width = width // frames
            z = range(-5,6)
            for frame in xrange(frames):
                frame_num = image_width * frame
                image_frame = image.subsurface((frame_num,0), (image_width,height)).copy()
                Nanobot.images[z[frame]] = image_frame
            Nanobot.shot_sound = load_sound("shot_fx.ogg")
            Nanobot.shot_sound.set_volume(matrix.volume)    #v1.2
        self.image = Nanobot.image[0]
        self.rect = self.image.get_rect(center=(self.x,self.y))
        self.frame = 0
        self.imagex = {}
        for degree in xrange(0,360):
            w, h = Nanobot.image[degree].get_size()
            self.imagex[degree] = pygame.transform.smoothscale(Nanobot.image[degree], (w//8,h//8))
        self.shot = Nanobot.shot_sound
        self.distance = 0
        self.direction = 0
        self.direction_previous = 0
        self.direction_change = False
        self.rotate = False
        self.velocity = 0       #forward velocity
        self.velocity_l = 0     #strafe left
        self.velocity_r = 0     #strafe right
        self.rotate = 0         #image rotation - none = 0, ccr = -1, cr =1
        self.rotate_count = 0
        self.gun_timer = 0
        self.toggle_forward = False     # toggle controls
        self.toggle_reverse = False
        self.toggle_motion = False
        self.toggle_left = False
        self.toggle_right = False
        self.toggle_strafeleft = False
        self.toggle_straferight = False
        self.toggle_shot = False
        self.vaccine_pulse = False    #vaccine pulse
        self.vaccine_pulse_load = False
        self.annihilation_pulse = False   #annihilation pulse   #v1.2
        self.tractor_beam = False   #tractor beam
        self.tractor_beam_captured = None   #captured held in tractor beam
        self.velocity_max = 6.0     #velocity
        self.velocity_thrust = 3.0  #coasting velocity
        self.velocity_spurt = 8.0   #spurt velocity
        self.bot_velocity = 0.0     #nanobot velocity
        self.bot_rotate = 0.0       #nanobot rotation
        self.control_entry = None
        self.life_force = 100.0     #energy from cell lifeforce
        self.shield_energized = True  #cloaking shield
        self.weapon_energized = True  #weapon charge
        self.antigen = 0    #viral antigen to generate antibody and activate macrophage
        self.antigen_required = 10  #amount biomaterial required for vaccine generation
        self.vaccine_released = 0   #vaccine released
        self.vaccine_location = ()  #vaccine release location
    def locate_coordinate(self,step,direction,change=True):
        """Calculates coordiate following step in a given direction from starting postion self.pos_x, self.pos_y. If change is True changes self.pos_x/self.pos_y, otherwise just return calculated position."""
        x = self.pos_x
        y = self.pos_y
        x += +step*sin_table[direction]     #x += +step*math.sin(direction*math.pi/180)
        y += -step*cos_table[direction]     #y += -step*math.cos(direction*math.pi/180)
        if change:
            self.pos_x = x
            self.pos_y = y
        return int(x), int(y)
    def direction_set(self, direction):
        if direction >= 360:
            direction -= 360
        elif direction < 0:
            direction += 360
        return direction
    def location(self):
        def check_edge():
            centerx, centery = self.rect.center
            if centerx < 25 or centerx > MATRIX_X-25 or centery <= 25 or centery >= MATRIX_Y-25:
                return True
            else:
                return False
        if self.toggle_forward:
            self.bot_velocity += 0.1
            if self.bot_velocity > self.velocity_max:
                self.bot_velocity = self.velocity_max
        if self.toggle_reverse:
            if self.bot_velocity > -3.0:
                self.bot_velocity -= 0.1
        elif self.bot_velocity < 0.0:
            self.bot_velocity += 0.05
        if self.toggle_motion:
            if self.bot_velocity > 0.0:
                self.bot_velocity -= 0.1
            if self.bot_velocity < 0.0:
                self.bot_velocity += 0.1
        if self.bot_velocity > self.velocity_thrust:
            self.bot_velocity -= 0.02
        if self.toggle_left:
            self.bot_rotate -= (1.0*abs(self.bot_rotate/20.0)+0.5)
            if self.bot_rotate < -5.0:
                self.bot_rotate = -5.0
            if self.bot_rotate < -1.0 and self.bot_rotate > -4.0:
                if self.bot_velocity < self.velocity_spurt:
                    self.bot_velocity += 0.1
            if self.frame > -5:
                self.frame -= 1
                self.rotate = True
        if self.toggle_right:
            self.bot_rotate += (1.0*abs(self.bot_rotate/20.0)+0.5)
            if self.bot_rotate > 5.0:
                self.bot_rotate = 5.0
            if self.bot_rotate > 1.0 and self.bot_rotate < 4.0:
                if self.bot_velocity < self.velocity_spurt:
                    self.bot_velocity += 0.1
            if self.frame < 5:
                self.frame += 1
                self.rotate = True
        if not self.toggle_left and not self.toggle_right:
            if self.bot_rotate:
                if self.bot_rotate < -1.0:
                    self.bot_rotate -= (self.bot_rotate/20.0)
                    if self.frame < 0:
                        self.frame += 1
                        self.rotate = True
                elif self.bot_rotate > 1.0:
                    self.bot_rotate -= (self.bot_rotate/20.0)
                    if self.frame > 0:
                        self.frame -= 1
                        self.rotate = True
                else:
                    self.bot_rotate = 0.0
            else:
                if self.frame != 0:
                    if self.frame > 0:
                        self.frame -= 1
                    else:
                        self.frame += 1
                    self.rotate = True
        if self.control_entry:
            if self.control_entry[0] == 'rotate':
                self.control(rotate=self.control_entry[1])
            elif self.control_entry[0] == 'strafe':
                self.control(strafe=self.control_entry[1])
            elif self.control_entry[0] == 'thrust':
                self.control(thrust=self.control_entry[1])
            self.control_entry = None
        self.velocity = self.bot_velocity
        self.direction = self.direction_set( self.direction + int(self.bot_rotate) )
        self.x, self.y = self.locate_coordinate(self.velocity, self.direction)
        if self.toggle_strafeleft and self.velocity_l < 3:
            self.velocity_l += 0.1
            direction = self.direction_set( self.direction - 90 )
            self.x, self.y = self.locate_coordinate(self.velocity_l, direction)
        elif self.velocity_l > 0:
            self.velocity_l -= 0.05
            direction = self.direction_set( self.direction - 90 )
            self.x, self.y = self.locate_coordinate(self.velocity_l, direction)
        if self.toggle_straferight and self.velocity_r < 3:
            self.velocity_r += 0.1
            direction = self.direction_set( self.direction + 90 )
            self.x, self.y = self.locate_coordinate(self.velocity_r, direction)
        elif self.velocity_r > 0:
            self.velocity_r -= 0.05
            direction = self.direction_set( self.direction + 90 )
            self.x, self.y = self.locate_coordinate(self.velocity_r, direction)
        if self.direction != self.direction_previous:
            self.direction_change = True
        else:
            self.direction_change = False
        if self.direction_change or self.rotate:
            if self.frame == 0:
                self.image = Nanobot.image[self.direction]
            else:
                self.image = pygame.transform.rotate(Nanobot.images[self.frame], -self.direction)
            self.direction_previous = self.direction
            self.rotate = False
        self.rect = self.image.get_rect(center=(self.x, self.y))
        if check_edge():
            self.pos_x = self.pos_x_previous
            self.pos_y = self.pos_y_previous
            self.direction = self.direction_set( self.direction + random.choice((-1,1)) )
        else:
            self.pos_x_previous = self.pos_x
            self.pos_y_previous = self.pos_y
    def control(self, rotate=0, strafe=0, thrust=False):
        if rotate:
            if rotate < -2:
                rotate = -2
            elif rotate > 2:
                rotate = 2
            if rotate < 0:
                self.bot_rotate += rotate
                if self.bot_rotate < -5.0:
                    self.bot_rotate = -5.0
                if self.bot_rotate < -1.0 and self.bot_rotate > -4.0:
                    if self.bot_velocity < self.velocity_spurt:
                        self.bot_velocity += 0.1
                if self.frame > -5:
                    self.frame -= 1
                    self.rotate = True
            elif rotate > 0:
                self.bot_rotate += rotate
                if self.bot_rotate > 5.0:
                    self.bot_rotate = 5.0
                if self.bot_rotate > 1.0 and self.bot_rotate < 4.0:
                    if self.bot_velocity < self.velocity_spurt:
                        self.bot_velocity += 0.1
                if self.frame < 5:
                    self.frame += 1
                    self.rotate = True
        elif strafe:
            if strafe < 0:
                self.velocity_l += -strafe
                if self.velocity_l > 3:
                    self.velocity_l = 3
            elif strafe > 0:
                self.velocity_r += strafe
                if self.velocity_r > 3:
                    self.velocity_r = 3
        elif thrust:
            if self.velocity_thrust < 3.01:
                self.velocity_thrust = 3.01
                self.bot_velocity = 3.01
            elif self.velocity_thrust == 3.01:
                self.velocity_thrust = self.velocity_max
                self.bot_velocity = self.velocity_max
            else:
                self.velocity_thrust = 3.01
                self.bot_velocity = 3.01
    def shove(self, x, y):   #push bot
        if self.x > x:
            distance_x = +2.0
        elif self.x < x:
            distance_x = -2.0
        else:
            distance_x = 0
        if self.y > y:
            distance_y = +2.0
        elif self.y < y:
            distance_y = -2.0
        else:
            distance_y = 0
        self.pos_x += distance_x
        self.x = int(self.pos_x)
        self.pos_y += distance_y
        self.y = int(self.pos_y)
        if random.random() > 0.5 - (0.1*matrix.level):  #drains life force from bot
            damage = -1 * matrix.level    #level inc. difficulty
            self.condition(damage)
    def activate_tool(self, select):
        if select == 'Vaccine Pulse':
            if self.vaccine_pulse_load:
                self.vaccine_pulse = True
        elif select =='Annihilation Pulse':     #v1.2
            if self.vaccine_pulse_load:
                self.annihilation_pulse = True            
        elif select == 'Tractor Beam':
            if not self.tractor_beam:
                self.tractor_beam = True
            else:
                self.tractor_beam = False
                self.tractor_beam_captured = None
                self.velocity_max = 6.0
                self.velocity_spurt = 8.0
    def shoot(self):
        if self.toggle_shot:
            if self.weapon_energized:
                if self.gun_timer == 0:
                    self.shot.play()    #v1.2
                    x1 = self.pos_x +20*math.sin((self.direction+45)*math.pi/180)
                    y1 = self.pos_y -20*math.cos((self.direction+45)*math.pi/180)
                    x2 = self.pos_x +20*math.sin((self.direction-45)*math.pi/180)
                    y2 = self.pos_y -20*math.cos((self.direction-45)*math.pi/180)
                    direction1 = self.direction_set( self.direction - 3 )
                    direction2 = self.direction_set( self.direction + 3 )
                    matrix.projectiles.add(Projectile(x1, y1, direction1, self.velocity))
                    matrix.projectiles.add(Projectile(x2, y2, direction2, self.velocity))
                    self.gun_timer = 5
                    self.life_force -= 1.0
                else:
                    if self.gun_timer > 0:
                        self.gun_timer -= 1
            else:
                self.toggle_shot = False
        if not self.toggle_shot:
            self.gun_timer = 0
        if self.vaccine_pulse:    #vaccine pulse
            self.shot.play()
            for mac in matrix.macs:
                mac.activation(stimuli=True)
            matrix.macrophage_activated = True
            self.vaccine_pulse = False
            self.vaccine_pulse_load = False
            self.vaccine_location = (self.x-matrix.field_x,self.y-matrix.field_y)
            self.vaccine_released = 700
        if self.annihilation_pulse:     #v1.2
            self.shot.play()
            for direction in xrange(0,360,5):
                matrix.projectiles.add(Projectile(self.x, self.y, direction, self.velocity, 'annihilation'))
            self.annihilation_pulse = False
            self.vaccine_pulse_load = False
        if self.tractor_beam:   #tractor beam
            if not self.tractor_beam_captured:
                mac_interact = pygame.sprite.spritecollide(self, matrix.macs, False)
                for mac in mac_interact:
                    if (abs(mac.rect.centerx-self.rect.centerx) < 50 and abs(mac.rect.centery-self.rect.centery) < 50):
                        self.tractor_beam_captured = mac
                        break
                if self.tractor_beam_captured:
                    self.tractor_beam_captured.tractor_beam = True
                    self.velocity_max = 2.0
                    self.velocity_spurt = 2.0
                else:
                    self.tractor_beam = False
    def vaccine(self):
        """Bot collects biomaterial to make vaccine."""
        if self.antigen < ( self.antigen_required * matrix.level ):   #level inc. difficulty
            if not self.vaccine_pulse_load and not matrix.macrophage_activated:  
                self.antigen += 1
        else:
            self.vaccine_pulse_load = True
            self.antigen = 0
            self.antigen_required = random.randrange(10,21)
    def condition(self, damage=0):
        """Energy derived from cell population, drained by Mac attack but can slowly regain level."""
        if self.life_force < matrix.cell_count/4.0:
            self.life_force += ( 0.05 + (matrix.cell_count/8000.0) )    #recovery slower if less cells
        if damage:
            self.life_force -= 1
        if self.life_force > 20:    #immunity shield
            self.shield_energized = True
        else:
            self.shield_energized = False
        if self.life_force > 10:
            self.weapon_energized = True
        else:
            self.weapon_energized = False
        if self.life_force > 0:
            return True
        else:
            return False    #bot destroyed
    def update(self):
        if self.condition():
            self.location()
            self.shoot()
        else:
            matrix.bot.remove(self)

class Projectile(pygame.sprite.Sprite):
    """Energy projectiles shot by bot."""
    image = None
    mask = None
    def __init__(self,x,y,direction,distance_adj,weapon_type='projectile'):
        pygame.sprite.Sprite.__init__(self)
        self.x = int(x)
        self.y = int(y)
        self.pos_x = x
        self.pos_y = y
        self.direction = direction
        self.velocity = 12
        self.distance = 15 + distance_adj
        self.weapon_type = weapon_type      #v1.2
        if not Projectile.image:    #load images on first instance
            image = load_image('projectile.png')
            Projectile.image = pygame.transform.smoothscale(image, (3,3))
            Projectile.mask = pygame.mask.from_surface(Projectile.image)
        self.image = Projectile.image
        self.rect = self.image.get_rect(center=(self.x, self.y))
        self.mask = Projectile.mask
        self.arming = 4      #travel short distance before arming
    def locate_coordinate(self,step,direction,change=True):
        """Calculates coordiate following step in a given direction from starting postion self.pos_x, self.pos_y. If change is True changes self.pos_x/self.pos_y, otherwise just return calculated position."""
        x = self.pos_x
        y = self.pos_y
        x += +step*sin_table[direction]     #x += +step*math.sin(direction*math.pi/180)
        y += -step*cos_table[direction]     #y += -step*math.cos(direction*math.pi/180)
        if change:
            self.pos_x = x
            self.pos_y = y
        return int(x), int(y)
    def location(self):
        self.x, self.y = self.locate_coordinate(self.velocity, self.direction)
        self.rect = self.image.get_rect(center=(self.x,self.y))
        self.distance -= 1
        if self.distance <= 0:
            matrix.projectiles.remove(self)
            self.kill()
    def armed(self):
        if not self.arming:
            return True
        else:
            self.arming -= 1
            return False
    def hit(self):
        hit_target = False
        hits = pygame.sprite.spritecollide(self, matrix.virus, False)
        for target in hits:
            target.damage()     #virus shot
            if self.weapon_type == 'projectile':    #v1.2
                try:
                    matrix.bot.sprite.vaccine()     #viral biomaterial to make vaccine
                except:
                    pass
            hit_target = True
            return hit_target       #return on single virus hit
        if self.weapon_type == 'projectile':    #v1.2
            hits = pygame.sprite.spritecollide(self, matrix.macs, False, pygame.sprite.collide_mask)
            for target in hits:
                target.shot = True
                hit_target = True
                return hit_target   #return on single macrophage hit
        return hit_target
    def update(self):
        self.location()
        if self.armed():
            if self.hit() and self.weapon_type == 'projectile':     #v1.2
                matrix.projectiles.remove(self)

class Virion(pygame.sprite.Sprite):
    """Virus moves erratically, and infects cells for division."""
    variants = { 1:{'progeny':2,'lifespan':1000,'color':0xe1cf00},
                 2:{'progeny':3,'lifespan':666,'color':0xff8e00},
                 3:{'progeny':4,'lifespan':500,'color':0xf93003},
                 4:{'progeny':5,'lifespan':400,'color':0xc0c0c0} }
    images = {}
    mask = None
    def __init__(self, x, y, variant):
        pygame.sprite.Sprite.__init__(self)
        self.variant = variant    #virus variant
        self.x = x
        self.y = y
        self.pos_x = float(self.x)     #float version
        self.pos_y = float(self.y)
        if not Virion.images:  #load images on first instance
            variant = 1
            for virus_image in ('virus1.png', 'virus2.png', 'virus3.png', 'virus4.png'):
                image = {}
                img = load_image(virus_image)
                for degree in xrange(0,360):
                    image[degree] = pygame.transform.rotozoom(img, -degree, 0.2)
                    Virion.images[variant] = image
                variant += 1
            Virion.mask = pygame.mask.from_surface(pygame.transform.smoothscale(Virion.images[1][0],(20,20)))
        self.direction = random.randrange(360)
        self.distance = random.randrange(1,10)
        self.direction_roll = self.direction
        self.roll = random.choice((-3,-2,-1,1,2,3))
        self.image = Virion.images[self.variant][self.direction]
        self.rect = self.image.get_rect(center=(self.x,self.y))
        self.mask = Virion.mask
        self.velocity = 1
        self.infecting = False     #infecting cell
        self.life_force = 2
        self.life_span = Virion.variants[self.variant]['lifespan'] * random.choice((1,2))
        self.progeny = Virion.variants[self.variant]['progeny']
        self.color = Virion.variants[self.variant]['color']
    def location(self):
        """Moves distance up to 10 steps, then changes direction randomly."""
        if self.distance > 0:
            self.distance -= 1
        else:
            self.direction = random.randrange(360)
            self.distance = random.randrange(1,10)
        self.pos_x += +self.velocity*sin_table[self.direction]
        self.pos_y += -self.velocity*cos_table[self.direction]
        #self.pos_x += +self.velocity*math.sin(self.direction*math.pi/180)
        #self.pos_y += -self.velocity*math.cos(self.direction*math.pi/180)
        self.x, self.y = int(self.pos_x), int(self.pos_y)
        self.direction_roll += (1*self.roll)
        if self.direction_roll >= 360:
            self.direction_roll -= 360
        elif self.direction_roll < 0:
            self.direction_roll += 360
        self.image = Virion.images[self.variant][self.direction_roll]
        self.rect = self.image.get_rect(center=(self.x,self.y))
    def check_edge(self, borders):
        """Check if virus enters border rects."""
        for border in borders:
            if border.side == 'n':
                self.direction = 180
                self.distance = 10
            elif border.side == 's':
                self.direction = 0
                self.distance = 10
            elif border.side == 'w':
                self.direction = 90
                self.distance = 10
            elif border.side == 'e':
                self.direction = 270
                self.distance = 10
    def shove(self, x, y):      #push virus
        if self.x > x:
            distance_x = +1.0
        elif self.x < x:
            distance_x = -1.0
        else:
            distance_x = 0
        if self.y > y:
            distance_y = +1.0
        elif self.y < y:
            distance_y = -1.0
        else:
            distance_y = 0
        self.pos_x += distance_x
        self.x = int(self.pos_x)
        self.pos_y += distance_y
        self.y = int(self.pos_y)
    def mutate(self):
        if self.variant > 3:
            return False
        mutation = random.random() > 0.95
        return mutation
    def damage(self):
        self.life_force -= 1
        if self.life_force < 0:
            self.life_force = 0
    def condition(self):
        self.life_span -= 1
        if not self.life_span:
            self.life_force = 0
    def update(self):
        self.condition()
        if self.life_force:
            self.location()
        else:
            matrix.remove_creature('Virus', self)   #lifespan reached naturally or being shot

class Cell(pygame.sprite.Sprite):
    """Members of the class cell will form a monolayer. Update will happen occasionally. Cells can be infected by the virus. When the virus complete replication cycle, cell will die. Growth of cells will be contact inhibited, and if neighbouring cells die, selected adjacent cells will begin growth cycle so as to divide, whereupon the new cell will move to injured area for healing."""
    image = None
#    sound = None
    def __init__(self,x,y):
        pygame.sprite.Sprite.__init__(self)
        self.x = int( (x * 50.6) + 13 + (((y)%2)*15) )  #location in matrix
        self.y = int( (y * 50.6) + 13 + (((x)%2)*15) )
        self.grid_x = x
        self.grid_y = y
        self.grid = [(self.grid_x+x,self.grid_y+y) for x in [-1,0,1] for y in [-1,0,1] if self.grid_x+x>-1 and self.grid_x+x<MATRIX_X//50 and self.grid_y+y>-1 and self.grid_y+y<MATRIX_Y//50]    #checking adjacent cells
        random.shuffle(self.grid)   #randomize order of checking
        self.grow_grid = ()         #growth for healing
        if not Cell.image:  #load images on first instance
            Cell.image = load_image('cell.png')
            Cell.image2 = load_image('cell_infect.png')
        self.image = Cell.image
        self.rect = self.image.get_rect(center=(self.x,self.y))
        self.area_position = ()     #region location
        self.isinfect = False
        self.isgrow = False
        self.isgrown = False
        self.rip = False
        self.infect_count = 0
        self.virus_variant = None
        self.grow_count = 0
        self.infect_time = 500
        self.grow_time = 500
    def infection(self, virus):
        """Checks whether virus gains infection, if so, set cell is infected, and disable if was growing. Returns isinfect and previous isgrown states. If virus is none, sets cell to infection state."""
        isinfect = False
        if not self.isinfect and not self.rip and not virus.infecting and virus.life_force:
            if virus.rect.collidepoint(self.rect.center):
                isinfect = True
                self.isinfect = True
                if self.isgrow or self.isgrown:
                    self.isgrow = False
                    self.isgrown = False
                    matrix.cell_map_update((self.grow_grid[0],self.grow_grid[1]), 0)    #restore to empty
                    self.grow_grid = ()
                self.image = Cell.image2
                self.rect = self.image.get_rect(center=(self.x,self.y))
        return isinfect
    def infect_set(self, virus_variant, infect_time=500):
        self.isinfect = True
        self.virus_variant = virus_variant
        self.infect_time = infect_time
        self.image = Cell.image2
        self.rect = self.image.get_rect(center=(self.x,self.y))
    def infected(self):
        if self.isinfect:
            if not self.rip:
                self.infect_count += 1
                if self.infect_count > self.infect_time:
                    self.infect_count = 0
                    self.rip = True
                    matrix.cell_map_update((self.grid_x,self.grid_y), 0)   #grid empty
    def regrowth(self):
        if not self.isinfect and not self.rip and not self.isgrow and not self.isgrown:
            for cell_next in self.grid:
                if not matrix.cell_map[cell_next[0],cell_next[1]]:
                    self.isgrow = True
                    self.grow_grid = cell_next
                    matrix.cell_map_update((cell_next[0],cell_next[1]), 2)   #grid reserved from regrowth
                    break
            if self.isgrow:
                return self
            else:
                return None
    def growth(self):
        if self.isgrow:
            if not self.isgrown:
                self.grow_count += 1
                if self.grow_count > self.grow_time:
                    self.grow_count = 0
                    self.isgrow = False
                    matrix.cell_map_update((self.grow_grid[0],self.grow_grid[1]), 1)     #grid regrown
                    self.isgrown = True
    def update(self):
        if self.isinfect:
            self.infected()
            return None
        elif self.isgrow:
            self.growth()
            return None
        else:
            check_regrowth_initialized = self.regrowth()
            return check_regrowth_initialized

class Macrophage(pygame.sprite.Sprite):
    """Macrophages will help control infection by engulfing viruses. As they consume virus, they will grow. If grow too large on virus, will trigger cell aberration causing macrophage to attack bot. Bot will suffer drain of life energy. Bot will be able to make vaccines, which will be able to activate macrophages in their activity and their homing ability towards viruses."""
    images = {}
    masks = {}
    sound = None
    area = {}
    def __init__(self,x,y):
        pygame.sprite.Sprite.__init__(self)
        self.x = x
        self.y = y
        self.pos_x = float(self.x)     #float version
        self.pos_y = float(self.y)
        if not Macrophage.images:
            image = load_image("macrophage.png")
            size = (100,100)
            while size[0] <= 150:
                img = pygame.transform.smoothscale(image, size)
                Macrophage.images[size[0]] = img
                Macrophage.masks[size[0]] = pygame.mask.from_surface(img)
                size = tuple(x+1 for x in size)
            Macrophage.sound = load_sound("macrophage_sound.ogg")
            Macrophage.sound.set_volume(matrix.volume)      #v1.2
            class Area(pygame.sprite.Sprite):
                def __init__(self, x, y, rect, expand):
                    pygame.sprite.Sprite.__init__(self)
                    self.x = x
                    self.y = y
                    self.rect = rect
                    self.rect.size = tuple(axis+expand for axis in rect.size)
            area_rect = image.get_rect()
            Macrophage.area['s'] = Area(x,y,area_rect,expand=300)   #radar - short, medium, and long range
            Macrophage.area['m'] = Area(x,y,area_rect,expand=500)
            Macrophage.area['l'] = Area(x,y,area_rect,expand=700)
        self.size = (100,100)
        self.image = Macrophage.images[self.size[0]]
        self.rect = self.image.get_rect(center=(self.x,self.y))
        self.mask = Macrophage.masks[self.size[0]]
        self.imagex = pygame.transform.smoothscale(self.image,(8,8))
        self.macrophage_sound = Macrophage.sound
        self.delay = 6
        self.pause = 0
        self.direction = random.randrange(360)
        self.distance = random.randrange(100,200)
        self.velocity = 1
        self.grow = 0
        self.growing = 0
        self.speed = 0.3
        self.attack = False
        self.attack_count = 0
        self.dormant_count = 0  #time since last virus
        self.girth = 100
        self.tracking = False   #tracking virus
        self.target = None
        self.sound = False      #macrophage sounding
        self.channel = None     #sound channel
        self.shot = False   #if shot
        self.tractor_beam = False   #bot tractor beam
        self.activated = False  #vaccine activation
        self.activate_count = 0 #activation duration
        self.activation_state = 0
        self.zip = 1    #speed increase with activation
        self.area = Macrophage.area     #radar
    def locate_coordinate(self,step,direction,change=True):
        """Calculates coordiate following step in a given direction from starting postion self.pos_x, self.pos_y. If change is True changes self.pos_x/self.pos_y, otherwise just return calculated position."""
        x = self.pos_x
        y = self.pos_y
        x += +step*sin_table[direction]
        y += -step*cos_table[direction]
        #x += +step*math.sin(direction*math.pi/180)
        #y += -step*math.cos(direction*math.pi/180)
        if change:
            self.pos_x = x
            self.pos_y = y
        return int(x), int(y)
    def direction_set(self, direction):
        if direction >= 360:
            direction -= 360
        elif direction < 0:
            direction += 360
        return direction
    def check_edge(self):   #edge check
        if self.x < 50 or self.x > MATRIX_X-50 or self.y < 50 or self.y > MATRIX_X-50:
            self.direction = random.randrange(360)
            if self.x < 50:
                self.x = 50
            elif self.x > MATRIX_X-50:
                self.x = MATRIX_X-50
            if self.y < 50:
                self.y = 50
            elif self.y > MATRIX_Y-50:
                self.y = MATRIX_Y-50
            self.pos_x, self.pos_y = float(self.x), float(self.y)
    def sense_virus(self, long_range=False):
        """Check for target in range around macrophage."""
        def check_inrange(virus_list, x, y, radius):
            if not virus_list:
                return None
            virus_target = None
            for virus in virus_list:
                x1 = x
                y1 = y
                x2 = virus.x
                y2 = virus.y
                separation = numpy.sqrt( numpy.power((x1-x2),2) + numpy.power((y1-y2),2) )
                if separation < radius:      #find closest target
                    virus_target = virus
                    radius = separation
            return virus_target
        target = None
        size = self.rect.size
        separation_target = 200 - ((matrix.level-1)*25)
        self.area['s'].rect.center = (self.x, self.y)
        virus_detected = pygame.sprite.spritecollide(self.area['s'], matrix.virus, False)
        target = check_inrange(virus_detected, self.x, self.y, separation_target)
        if not target and long_range:
            separation_target = 400 - ((matrix.level-1)*50)
            self.area['m'].rect.center = (self.x, self.y)
            virus_detected = pygame.sprite.spritecollide(self.area['m'], matrix.virus, False)
            target = check_inrange(virus_detected, self.x, self.y, separation_target)
        if not target and long_range and (matrix.level < 2):
            separation_target = 600
            self.area['l'].rect.center = (self.x, self.y)
            virus_detected = pygame.sprite.spritecollide(self.area['l'], matrix.virus, False)
            target = check_inrange(virus_detected, self.x, self.y, separation_target)
        return target
    def check_interact(self):
        interact = None
        bot_bump = pygame.sprite.spritecollide(self, matrix.bot, False, pygame.sprite.collide_mask)  #bot avoidance
        if bot_bump and not self.attack:
            bot = bot_bump[0]
            interact = (bot.rect.centerx, bot.rect.centery)
            return interact
        macs_bump = pygame.sprite.spritecollide(self, matrix.macs, False)  #macrophage avoidance
        for mac in macs_bump:
            if mac == self:
                continue
            elif (abs(mac.rect.centerx-self.rect.centerx) < 65 and abs(mac.rect.centery-self.rect.centery) < 65):
                interact = (mac.rect.centerx, mac.rect.centery)
        return interact
    def avoidance(self, mac_interact, amount=1.0):
        mac_x, mac_y = mac_interact
        self.direction = self.direction_set( self.direction + random.randrange(90,270) )
        if random.random() < 0.5:
            if self.rect.centerx > mac_x:
                self.pos_x += amount
                self.x = int(self.pos_x)
            else:
                self.pos_x -= amount
                self.x = int(self.pos_x)
        else:
            if self.rect.centery > mac_y:
                self.pos_y += amount
                self.y = int(self.pos_y)
            else:
                self.pos_y -= amount
                self.y = int(self.pos_y)
    def move(self):
        mac_interact = self.check_interact()
        if mac_interact:
            self.avoidance(mac_interact)
        self.x, self.y = self.locate_coordinate(self.speed*self.zip, self.direction)
        self.distance -= 1
        if self.distance <= 0:
            self.distance = random.randrange(100, 200)
            self.direction = self.direction_set( self.direction + random.randrange(-45,46) )
    def track(self):
        mac_interact = self.check_interact()
        if mac_interact:
            self.avoidance(mac_interact)
        if random.random() > 0.5:
            if self.target.x > self.x:
                self.pos_x += self.velocity*self.zip
            else:
                self.pos_x -= self.velocity*self.zip
        else:
            if self.target.y > self.y:
                self.pos_y += self.velocity*self.zip
            else:
                self.pos_y -= self.velocity*self.zip
        self.x = int(self.pos_x)
        self.y = int(self.pos_y)
    def growth(self):
        virus_collide = pygame.sprite.spritecollide(self, matrix.virus, False, pygame.sprite.collide_mask)
        for prey in virus_collide:
            if not self.attack:
                matrix.remove_creature('Virus', prey)
                if not self.activated:
                    self.grow += 1      #grow with virus consumption
                self.dormant_count = 0
            else:
                prey.shove(self.x, self.y)
    def go_berserk(self, calm=False):   #excess virus causes malignant macrophage
        self.attack_count += 1
        if self.attack_count > 500:
            self.attack_count = 0
            if random.random() > (0.4 + (0.1*matrix.level)):
                calm = True
        if ( calm and matrix.bot.sprite.shield_energized ) or not matrix.bot.sprite or matrix.ending:
            self.attack = False
            self.attack_count = 0
            self.activated = True
            self.activate_count = 1000  #trigger end of activation
            self.girth = 100
            return
        if not self.sound:
            self.channel = self.macrophage_sound.play(-1)
            self.sound = True
        x1 = self.x
        y1 = self.y
        x2 = matrix.bot.sprite.x
        y2 = matrix.bot.sprite.y
        d = numpy.sqrt( numpy.power((x1-x2),2) + numpy.power((y1-y2),2) )
        if d <= 800:
            vol = 1.0 - (d/800)
        else:
            vol = 0.0
        self.channel.set_volume(vol)
        mac_interact = self.check_interact()
        if mac_interact:
            self.avoidance(mac_interact, amount=4.0)
        mistaken = 0.1
        if random.random() > mistaken:   #mistaken direction
            vel = random.randrange(1,6)
            mistake = 1
        else:
            vel = random.randrange(1,3)
            mistake = -1
        if random.random() > 0.5:
            if matrix.bot.sprite.x > self.x:
                self.x += vel*mistake
            else:
                self.x -= vel*mistake
        else:
            if matrix.bot.sprite.y > self.y:
                self.y += vel*mistake
            else:
                self.y -= vel*mistake
        self.pos_x = float(self.x)
        self.pos_y = float(self.y)
        if abs(self.x-matrix.bot.sprite.x)<65 and abs(self.y-matrix.bot.sprite.y)<65:
            matrix.bot.sprite.shove(self.x, self.y)
    def condition(self):
        if self.shot:
            self.macrophage_sound.play()
            if not self.attack:
                if not matrix.ending:
                    self.grow += 1      #attack if shot too much
            else:
                if random.random() > 0.95:
                    self.go_berserk(calm=True)     #attack stops if shot enough
            self.shot = False
        if not self.activated and not self.attack and not matrix.ending:
            try:
                if not matrix.bot.sprite.shield_energized:
                    self.grow += 1
            except AttributeError:      #no bot
                pass
            self.dormant_count += 1
            if self.dormant_count > 500:
                self.dormant_count = 0
                if random.random() > (0.8 - (0.1*matrix.level)):
                    self.grow += 1
    def captured(self):
        if not matrix.bot.sprite:   #no bot
            self.tractor_beam = False
            return
        if not matrix.bot.sprite.tractor_beam:
            self.tractor_beam = False
        else:
            x1 = self.x
            y1 = self.y
            x2 = matrix.bot.sprite.pos_x
            y2 = matrix.bot.sprite.pos_y
            bot_reverse_direction = self.direction_set( matrix.bot.sprite.direction + 180 )
            x2 += +25*sin_table[bot_reverse_direction]     #coordinate behind bot
            y2 += -25*cos_table[bot_reverse_direction]
            separation = numpy.sqrt( numpy.power((x1-x2),2) + numpy.power((y1-y2),2) )
            if separation > 100:     #hold macrophage in tractor beam
                if separation > 125:
                    speed = 3
                elif separation > 100:
                    speed = 2
                if self.x < x2:
                    self.x += speed
                elif self.x > x2:
                    self.x -= speed
                if self.y < y2:
                    self.y += speed
                elif self.y > y2:
                    self.y -= speed
                self.pos_x, self.pos_y = float(self.x), float(self.y)
                self.rect.center = (self.x, self.y)
    def activation(self, stimuli=False):
        if stimuli:
            if self.attack:
                self.attack = False
                self.girth = 100
            self.activated = True
            return
        if not self.sound:
            if not self.activate_count:
                self.sound = True
                self.channel = self.macrophage_sound.play(-1)
        else:
            try:
                x1 = self.x
                y1 = self.y
                x2 = matrix.bot.sprite.x
                y2 = matrix.bot.sprite.y
                d = numpy.sqrt( numpy.power((x1-x2),2) + numpy.power((y1-y2),2) )
                if d <= 800:
                    vol = 1.0 - (d/800)
                else:
                    vol = 0.0
                self.channel.set_volume(vol)
            except AttributeError:  #no bot
                pass
        if not self.activate_count:
            self.activation_state = 1
            self.zip = 2
        if self.activate_count == 1000:
            self.activation_state = -1
            if self.sound:
                self.channel.stop()    #stop sound channel
                self.sound = False
            self.zip = 1
        self.activate_count += 1
        if not self.activation_state:
            self.tracking = False
            self.activate_count = 0
            self.activated = False
            matrix.macrophage_activated = False
    def shape_shift(self):
        def shift(size,change=1):
            size = tuple(x+change for x in size)
            self.image = Macrophage.images[size[0]]
            self.rect = self.image.get_rect(center=(self.x,self.y))
            self.mask = Macrophage.masks[size[0]]
            return size
        if not self.activated:
            self.pause += 1
            if self.pause >= self.delay:
                self.pause = 0
                if self.grow > ( 3 - matrix.level ) or self.growing:  #level inc. difficulty
                    if self.size[0] < 150:      #macrophage growth
                        self.size = shift(self.size)
                        self.girth = self.size[0]
                        self.grow = 0
                        self.growing += 1
                        if self.growing > 5:
                            self.growing = 0
                    else:
                        if matrix.bot.sprite:  #if bot exists
                            if not self.activated:
                                self.attack = True  #macrophage attack when large
                                self.grow = 0
                                self.growing = 0
        else:
            if self.activation_state == 1:
                self.grow = 0
                self.growing = 0
                if self.size[0] < 150:
                    self.size = shift(self.size)
            elif self.activation_state == -1:
                if self.size[0] > self.girth:
                    self.size = shift(self.size,change=-1)
                else:
                    self.activation_state = 0
                    self.girth = self.size[0]
        self.rect.center = (self.x, self.y)
    def update(self):
        self.check_edge()
        self.condition()
        if not self.attack:     #peaceful macrophage
            if self.activated:  #activated macrophage
                self.activation()
            if self.tractor_beam:
                self.captured()
            if self.tracking:
                if self.target.alive():
                    self.track()
                else:
                    self.tracking = False
            else:
                if not self.activated:
                    self.target = self.sense_virus()
                else:
                    self.target = self.sense_virus(long_range=True)
                if self.target:
                    self.tracking = True
                else:
                    self.move()    #no virus in vicinity
        else:   #aggressive macrophage
            self.go_berserk()   #anti-bot
        self.growth()
        self.shape_shift()

def load_image(file_name, frames=1, path='data', colorkey=None, errorhandle=True):
    #Modified from PygameChimpTutorial
    full_name = os.path.join(path, file_name)
    try:
        if frames == 1:
            image = pygame.image.load(full_name)
        elif frames > 1:
            images = []
            image = pygame.image.load(full_name)
            width, height = image.get_size()
            width = width // frames
            for frame in xrange(frames):
                frame_num = width * frame
                image_frame = image.subsurface((frame_num,0), (width,height)).copy()
                images.append(image_frame)
            return images
    except pygame.error, message:
        if errorhandle:
            raise SystemExit, message
        else:
            print(message)
            return None
    if image.get_alpha():
        image = image.convert_alpha()
    else:
        image = image.convert()
    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0,0))
        image.set_colorkey(colorkey, RLEACCEL)
    return image

def load_sound(file_name):      #http://www.linuxjournal.com/article/7694
    class No_Sound:
        def play(self): pass
    if not pygame.mixer or not pygame.mixer.get_init():
        return No_Sound()
    full_name = os.path.join('data', file_name)
    if os.path.exists(full_name):
        sound = pygame.mixer.Sound(full_name)
    else:
        msg = 'File does not exist: '+full_name
        print(msg)
        return No_Sound
    return sound

def trig_compute():
    sin_table = {}
    cos_table = {}
    for angle in xrange(0,360):
        angle_rad = angle * math.pi/180
        sin_angle = math.sin(angle_rad)
        cos_angle = math.cos(angle_rad)
        sin_table[angle] = sin_angle
        cos_table[angle] = cos_angle
    return sin_table, cos_table
sin_table, cos_table = trig_compute()

class MatrixInterface(interphase.Interface):
    def __init__(self):
        interphase.Interface.__init__(self, position=(250,450), image='panel.png', color=(43,50,58), size=(350,100), moveable=True, position_offset=(0,95), button_image=['button.png'], control_image=['control.png'], font_color=(175,180,185), tips_fontcolor=(175,180,185), pointer_move=True, control_minsize=(20,20), control_size='auto')
    def add_controls(self):
        self.add(
            identity = 'Control',
            control_type = 'function_select',
            position = (50,50),
            size = (40,40),
            control_list = ['__Compass', '__Action', '__Sim'],
            icon_list = ['control_compass.png', 'control_virus.png', 'control_restart.png'],
            link = [ ['Compass', 'N', 'S', 'W', 'E', 'NW', 'NE', 'SW', 'SE'], ['Virus', 'Macrophage', 'Variant', 'Mutation'], ['Restart', 'Exit'] ],
            link_activated = True,
            label_display = False)
        self.add(
            identity = 'Compass',
            control_type = 'control_toggle',
            position = (175,50),
            size = 'min',
            control_list = [''],
            label_display = False)
        for ident, tip, img, pos in ( ('N',['North'],['control_n.png'],(175,25)), ('S',['South'],['control_s.png'],(175,75)), ('W',['West'],['control_w.png'],(150,50)), ('E',['East'],['control_e.png'],(200,50)) ):
            self.add(
                identity = ident,
                control_type = 'control_toggle',
                position = pos,
                size = 'min',
                control_list = [''],
                tip_list = tip,
                control_image = img,
                label_display = False,
                control_response = 0)
        for ident, tip, pos in ( ('NW',['North-West'],(150,25)), ('NE',['North-East'],(200,25)), ('SW',['South-West'],(150,75)), ('SE',['South-East'],(200,75)) ):
            self.add(
                identity = ident,
                control_type = 'control_toggle',
                position = pos,
                size = 'min',
                control_list = [''],
                tip_list = tip,
                label_display = False,
                control_response = 0)
        self.add(
            identity = 'Virus',
            control_type = 'control_toggle',
            position = (130,35),
            size = 'min_width',
            control_list = ['Virus'],
            tip_list = ['Add Virus'],
            control_outline = True,
            control_response = 1)
        self.add(
            identity = 'Macrophage',
            control_type = 'control_toggle',
            position = (130,65),
            size = 'min_width',
            control_list = ['Macrophage'],
            tip_list = ['Add Macrophase'],
            control_outline = True)
        self.add(
            identity = 'Variant',
            control_type = 'control_toggle',
            position = (230,35),
            size = 'min_width',
            control_list = ['Variant 1', 'Variant 2', 'Variant 3', 'Variant 4'],
            tip_list = ['Virus Variant'],
            split_text = False,
            control_outline = True)
        self.add(
            identity = 'Mutation',
            control_type = 'control_toggle',
            position = (230,65),
            size = 'min_width',
            control_list = ['Mutation OFF', 'Mutation ON'],
            tip_list = ['Toggle Mutation'],
            split_text = False,
            control_outline = True)
        self.add(
            identity = 'Restart',
            control_type = 'control_toggle',
            position = (130,50),
            size = (40,40),
            control_list = ['Restart'],
            tip_list = ['Restart Simulation'])
        self.add(
            identity = 'Exit',
            control_type = 'control_toggle',
            position = (230,50),
            size = (40,40),
            control_list = ['Exit'],
            tip_list = ['Exit Simulation'])
        self.add(
            identity = '__Fix',
            control_type = 'control_toggle',
            position = (315,90),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['!'],
            control_image = ['None'],
            control_outline = True)
        self.add(
            identity = '__Help',
            control_type = 'control_toggle',
            position = (335,90),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['?'],
            control_image = ['None'],
            control_outline = True)
    def initialize(self):
        controls = self.get_control('Control', 'Variant', 'Mutation')
        for control in controls:
            controls[control].reset()
        self.enable_control('Variant')
    def update(self):
        """
        State Object
            panel:              Interface panel
            controls:           Interface controls
            panel_active        Panel active
            panel_interact:     Pointer interface interact
            control_interact:   Pointer control interact
            button_interact:    Pointer button interact
            control:            Control selected
            button:             Button selected
            value:              Control value
            values:             Panel control values
        """
        interphase.Interface.update(self)
        state = self.get_state()
        if state.control:
            if state.control == 'N':
                matrix.matrix_scroll('u')
            elif state.control == 'S':
                matrix.matrix_scroll('d')
            elif state.control == 'W':
                matrix.matrix_scroll('l')
            elif state.control == 'E':
                matrix.matrix_scroll('r')
            elif state.control == 'NW':
                matrix.matrix_scroll('u')
                matrix.matrix_scroll('l')
            elif state.control == 'NE':
                matrix.matrix_scroll('u')
                matrix.matrix_scroll('r')
            elif state.control == 'SW':
                matrix.matrix_scroll('d')
                matrix.matrix_scroll('l')
            elif state.control == 'SE':
                matrix.matrix_scroll('d')
                matrix.matrix_scroll('r')
            elif state.control == 'Map':
                matrix.map_display = (not matrix.map_display)
                matrix.display_update = True
            elif state.control == 'Virus':
                matrix.simulation_set('Virus Addition')
            elif state.control == 'Macrophage':
                matrix.simulation_set('Macrophage Addition')
            elif state.control == 'Nanobot':
                matrix.simulation_set('Nanobot Addition')
            elif state.control == 'Variant':
                matrix.simulation_set('Variant Switch')
                if state.value == 'Variant 4':
                    self.disable_control('Variant')
            elif state.control == 'Mutation':
                matrix.simulation_set('Mutation Operational')
            elif state.control == 'Restart':
                matrix.setup(simulation=True)
            elif state.control == 'Exit':
                resume = matrix.opening(escape=True)
                if resume:
                    matrix.update()
            elif state.control == '__Fix':
                self.set_moveable()
            elif state.control == '__Help':
                self.set_tips_display()
        return state

class Control(object):
    def __init__(self):
        pygame.key.set_repeat(100,10)
        if config['mouse_enabled']:
            self.mouse_enabled = True
            pygame.event.set_grab(True)
            pygame.mouse.set_visible(False)
            pygame.mouse.set_pos([DISPLAY_X//2,DISPLAY_Y//2])
            pygame.event.set_allowed([MOUSEBUTTONDOWN,MOUSEBUTTONUP,MOUSEMOTION])
        else:
            self.mouse_enabled = False
            pygame.event.set_grab(False)
            pygame.mouse.set_visible(True)
            pygame.event.set_blocked([MOUSEBUTTONDOWN,MOUSEBUTTONUP,MOUSEMOTION])
        self.panel, self.panel_group = self.define_controls()
        self.rotate_control = True  #strafe/rotate control toggle
        self.clock = pygame.time.Clock()
        self.quit = False
    def define_controls(self):
        panel = MatrixInterface()
        panel_group = pygame.sprite.RenderUpdates(panel)
        return panel, panel_group
    def check_events(self):
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONDOWN:
                button1, button2, button3 = pygame.mouse.get_pressed()
                if event.button == 1:    #bot shoot
                    try:
                        matrix.bot.sprite.toggle_shot = True
                    except AttributeError: pass
                elif event.button == 2:   #bot tractor beam
                    try:
                        matrix.bot.sprite.activate_tool('Tractor Beam')
                    except AttributeError: pass
                elif event.button == 3:   #bot vaccine/annihilation pulse
                    if pygame.key.get_mods() & KMOD_SHIFT:   #bot annihilation pulse    #v1.2
                        try:
                            matrix.bot.sprite.activate_tool('Annihilation Pulse')
                        except AttributeError: pass
                    else:
                        try:
                            matrix.bot.sprite.activate_tool('Vaccine Pulse')
                        except AttributeError: pass
            elif event.type == MOUSEBUTTONUP:
                button1, button2, button3 = pygame.mouse.get_pressed()
                if event.button == 1:    #bot shoot
                    try:
                        matrix.bot.sprite.toggle_shot = False
                    except AttributeError: pass
            elif event.type == pygame.MOUSEMOTION:
                x,y = pygame.mouse.get_rel()
                if x:
                    try:
                        if self.rotate_control:
                            matrix.bot.sprite.control_entry = ('rotate', x/10.0)
                        else:
                            matrix.bot.sprite.control_entry = ('strafe', x/10.0)
                    except AttributeError: pass
            elif event.type == KEYDOWN:
                if event.key == K_UP or event.key == K_KP8:   #bot forward
                    try:
                        if not matrix.warp_engaged:
                            matrix.bot.sprite.toggle_forward = True
                    except AttributeError:
                        matrix.matrix_scroll('u')
                    except AttributeError: pass
                elif event.key == K_DOWN or event.key == K_KP2:    #bot reverse
                    try:
                        if not matrix.warp_engaged:
                            matrix.bot.sprite.toggle_reverse = True
                    except AttributeError:
                        matrix.matrix_scroll('d')
                elif event.key == K_LEFT or event.key == K_KP4:    #bot left
                    try:
                        if not matrix.warp_engaged:
                            matrix.bot.sprite.toggle_left = True
                    except AttributeError:
                        matrix.matrix_scroll('l')
                elif event.key == K_RIGHT or event.key == K_KP6:   #bot right
                    try:
                        if not matrix.warp_engaged:
                            matrix.bot.sprite.toggle_right = True
                    except AttributeError:
                        matrix.matrix_scroll('r')
                elif event.key == K_RCTRL or event.key == K_KP5:    #bot dampen motion
                    try:
                        matrix.bot.sprite.toggle_motion = True
                    except AttributeError: pass
                elif event.key == K_x or event.key == K_KP1:    #bot sleft
                    try:
                        if not matrix.warp_engaged:
                            matrix.bot.sprite.toggle_strafeleft = True
                    except AttributeError: pass
                elif event.key == K_c or event.key == K_KP3:   #bot sright
                    try:
                        if not matrix.warp_engaged:
                            matrix.bot.sprite.toggle_straferight = True
                    except AttributeError: pass
                elif event.key == K_SPACE or event.key == K_KP0:    #shoot
                    try:
                        matrix.bot.sprite.toggle_shot = True
                    except AttributeError: pass
                elif event.key == K_a or event.key == K_KP_PERIOD:   #bot annihilation pulse    #v1.2
                    try:
                        matrix.bot.sprite.activate_tool('Annihilation Pulse')
                    except AttributeError: pass
                elif event.key == K_z or event.key == K_KP_MULTIPLY:   #bot vaccine pulse
                    try:
                        matrix.bot.sprite.activate_tool('Vaccine Pulse')
                    except AttributeError: pass
                elif event.key == K_LCTRL or event.key == K_KP_ENTER:   #bot tractor beam   #v1.2
                    try:
                        matrix.bot.sprite.activate_tool('Tractor Beam')
                    except AttributeError: pass
                elif event.key == K_d:    #toggle map display
                    matrix.map_display = (not matrix.map_display)
                    matrix.display_update = True
                elif event.key == K_v:    #add virus
                    matrix.simulation_set('Virus Addition')
                elif event.key == K_m:    #add macrophage
                    matrix.simulation_set('Macrophage Addition')
                elif event.key == K_n:      #add nanobot
                    matrix.simulation_set('Nanobot Addition')
                elif event.key == K_i:    #infectious variant
                    matrix.simulation_set('Variant Switch')
                elif event.key == K_g:      #genetic mutation
                    matrix.simulation_set('Mutation Operational')
                elif event.key == K_BACKSLASH:  #mouse toggle
                    if self.mouse_enabled:
                        self.mouse_enabled = False
                        pygame.event.set_grab(False)
                        pygame.mouse.set_visible(True)
                        pygame.event.set_blocked([MOUSEBUTTONDOWN,MOUSEBUTTONUP,MOUSEMOTION])
                    else:
                        self.mouse_enabled = True
                        pygame.event.set_grab(True)
                        pygame.mouse.set_visible(False)
                        pygame.mouse.set_pos([DISPLAY_X//2,DISPLAY_Y//2])
                        pygame.event.set_allowed([MOUSEBUTTONDOWN,MOUSEBUTTONUP,MOUSEMOTION])
                elif event.key == K_t:  #forward thrust
                    try:
                        matrix.bot.sprite.control_entry = ('thrust', True)
                    except AttributeError: pass
                elif event.key == K_r:  #rotate/strafe switch
                    self.rotate_control = not self.rotate_control
                elif event.key == K_w:    #volume up        #v1.2
                    matrix.volume += 0.1
                    if matrix.volume > 0.9:
                        matrix.volume = 1.0
                    matrix.set_volume()
                elif event.key == K_s:    #volume down      #v1.2
                    matrix.volume -= 0.1
                    if matrix.volume < 0.1:
                        matrix.volume = 0.0
                    matrix.set_volume()
                elif event.key == K_RIGHTBRACKET:   #increase difficulty level
                    matrix.level_set()
                elif event.key == K_TAB:    #pause toggle
                    if not matrix.warp_engaged:
                        pause = True
                        pygame.event.set_grab(False)
                        while pause:
                            for event in pygame.event.get():
                                if event.type == KEYDOWN:
                                    if event.key == K_TAB or event.key == K_ESCAPE:
                                        pause = False
                                        if self.mouse_enabled:
                                            pygame.event.set_grab(True)
                                elif event.type == QUIT:
                                    pause = False
                                    self.quit = True
                            self.clock.tick(40)
                elif event.key == K_ESCAPE:     #restart
                    if not matrix.warp_engaged:
                        resume = matrix.opening(escape=True)
                        if resume:
                            matrix.update()
                elif event.key == K_h:    #control info
                    if not matrix.warp_engaged:
                        matrix.control_info()
                        matrix.display_update = True
                        matrix.update()
            elif event.type == KEYUP:
                if event.key == K_UP or event.key == K_KP8:    #move bot forward
                    try:
                        matrix.bot.sprite.toggle_forward = False
                    except AttributeError: pass
                elif event.key == K_DOWN or event.key == K_KP2:    #move bot reverse
                    try:
                        matrix.bot.sprite.toggle_reverse = False
                    except AttributeError: pass
                elif event.key == K_LEFT or event.key == K_KP4:    #move bot left
                    try:
                        matrix.bot.sprite.toggle_left = False
                    except AttributeError: pass
                elif event.key == K_RIGHT or event.key == K_KP6:   #move bot right
                    try:
                        matrix.bot.sprite.toggle_right = False
                    except AttributeError: pass
                elif event.key == K_RCTRL or event.key == K_KP5:    #move bot dampen motion
                    try:
                        matrix.bot.sprite.toggle_motion = False
                    except AttributeError: pass
                elif event.key == K_x or event.key == K_KP1:    #move bot sleft
                    try:
                        matrix.bot.sprite.toggle_strafeleft = False
                    except AttributeError: pass
                elif event.key == K_c or event.key == K_KP3:   #move bot sright
                    try:
                        matrix.bot.sprite.toggle_straferight = False
                    except AttributeError: pass
                elif event.key == K_SPACE or event.key == K_KP0:    #bot shoot
                    try:
                        matrix.bot.sprite.toggle_shot = False
                    except AttributeError: pass
            elif event.type == QUIT:   #quit program
                self.quit = True
    def update(self):
        self.check_events()
        self.panel_group.update()
        self.clock.tick(40)

def program_options():
    config = {'display_gamma':None, 'mouse_enabled':False}
    try:
        conf = {}
        config_file = open('config.ini')
        cfg_setting = [line.strip().split(' ',1) for line in config_file if line[:1].isalpha()]
        cfg_setting = dict(cfg_setting)
        for cfg in config:
            if cfg in cfg_setting:
                conf[cfg] = cfg_setting[cfg].strip()
        config_file.close()
    except (IOError, ValueError):
        pass
    for cfg in conf:
        if cfg == 'display_gamma':
            try:
                config['display_gamma'] = float(conf['display_gamma'])
            except ValueError:
                pass
        elif cfg == 'mouse_enabled':
            if conf[cfg].lower() == 'true':
                config['mouse_enabled'] = True
    program_usage = "%prog [options]"
    program_desc = ("Replicator Machine")
    parser = optparse.OptionParser(usage=program_usage,description=program_desc)
    parser = optparse.OptionParser(version="Replicator Machine "+version)
    parser.add_option("--license", dest="license", action="store_true", help="display program license")
    parser.add_option("-d", "--doc", dest="doc", action="store_true", help="display program documentation")
    parser.add_option("-g", dest="display_gamma", action="store", help="-g value (value: 0.5 to 3.0)")
    parser.add_option("-m", "--mouse", dest="mouse_enabled", action="store_true", help="-m for mouse enabled")
    (options, args) = parser.parse_args()
    if options.license:
        try:
            license_info = open('license.txt')
        except IOError:
            print("GNU General Public License version 3 or later: http://www.gnu.org/licenses/")
            sys.exit()
        for line_no, line in enumerate(license_info):
            print(line),
            if line_no and not line_no % 20:
                try:
                    answer = raw_input("press enter to continue, 'q' to quit: ")
                except:
                    sys.exit()
                if answer == 'q':
                    break
        license_info.close()
        sys.exit()
    if options.doc:
        try:
            documentation = open('readme.txt')
        except IOError:
            print("Documentation not found.")
            sys.exit()
        for line_no, line in enumerate(documentation):
            print line,
            if line_no and not line_no % 20:
                try:
                    answer = raw_input("press enter to continue, 'q' to quit: ")
                except:
                    sys.exit()
                if answer == 'q':
                    break
        documentation.close()
        sys.exit()
    if options.display_gamma:
        try:
            gamma = float(options.display_gamma)
            if gamma > 0.0 and gamma < 0.5:
                gamma = 0.5
            elif gamma > 3.0:
                gamma = 3.0
            config['display_gamma'] = gamma
        except ValueError:
            config['display_gamma'] = None
    if options.mouse_enabled:
        config['mouse_enabled'] = True
    return config

def report():
    print_message.add("FPS:", int(control.clock.get_fps()))
    print_message.add("Cell:", matrix.cell_count)
    print_message.add("Virus:", matrix.virus_count)
    try:
        print_message.add("Virus:", matrix.bot.sprite.bot_velocity)
        print_message.add("Virus:", matrix.bot.sprite.bot_rotate)
    except:
        pass
    print_message()

config = program_options()
matrix = Matrix()
control = Control()
print_message = interphase.DisplayMsg(matrix.screen)
matrix.opening()

def main():
    while not control.quit:
        matrix.update_list = []
        if matrix.simulation:
            control.panel_group.clear(matrix.screen,matrix.screen_base)
        control.update()
        matrix.update()
        if matrix.simulation:
            if control.panel.is_active():
                update_rect = control.panel_group.draw(matrix.screen)
                matrix.update_list.extend(update_rect)
        if not matrix.display_update:
            pygame.display.update(matrix.update_list)
        else:
            matrix.display_update = False
            pygame.display.flip()

if __name__ == '__main__':
    main()

