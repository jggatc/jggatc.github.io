#!/usr/bin/env python
from __future__ import division

"""
Interphase Demo

Interphase Module
Download Site: http://gatc.ca
"""

import interphase
import pygame
from pygame.locals import *
import sys

class InterfaceDemo(interphase.Interface):
    def __init__(self):
        self.pygame_initiate()
        interphase.Interface.__init__(self, position=(250,450), image='panel.png', color=(43,50,58), size=(350,100), moveable=True, position_offset=(0,95), button_image=['button.png'], control_image=['control.png'], font_color=(175,180,185), tips_fontcolor=(175,180,185), pointer_move=True, control_minsize=(25,25), control_size='auto')
        self.control_image_set = True
        self.doc_initialized = False
        self.doc_browse = False
        self.doc = 0
        self.doc_place = 0
        self.doc_change = False
        self.panic = False
        self.panic_time = 0
        self.panic_toggle = False
    def add_controls(self):
        self.add(
            identity = 'Control',
            control_type = 'function_select',
            position = (50,50),
            size = 'auto',
            control_list = ['__Function 1', '__Function 2', 'Exit'],
            icon_list = ['control_icons.png'],
            tip_list = ['Control Panel 1', 'Control Panel 2', 'Click to Exit'],
            link = [ ['Select1'], ['Setting1', 'Setting2', 'Files'], ['Panic'] ],
            link_activated = True,
            control_outline = True)
        self.add(
            identity = 'Select1',
            control_type = 'function_toggle',
            position = (150,50),
            size = 'min',
            control_list = ['ON', 'OFF'],
            tip_list = ['Interface Panel'],
            link = [ ['Select2'], [] ])
        self.add(
            identity = 'Select2',
            control_type = 'control_toggle',
            position = (200,50),
            size = 'min',
            control_list = ['G', 'A', 'T', 'C'],
            tip_list = ['Toggle'])
        self.add(
            identity = 'Setting1',
            control_type = 'control_select',
            position = (230,30),
            size = 'min',
            control_list = ['__alphanumeric'],
            tip_list = ['Alphanumeric'],
            loop = True)
        self.add(
            identity = 'Setting2',
            control_type = 'control_select',
            position = (230,70),
            size = 'min',
            control_list = ['__numeric', (0,42)],
            tip_list = ['Numeric'])
        self.add(
            identity = 'Files',
            control_type = 'control_select',
            position = (140,50),
            size = 'auto_width',
            control_list = ['__filelist', 'data', '', 'png'],
            tip_list = ['Files'])
        self.add(
            identity = '__Fix',
            control_type = 'control_toggle',
            position = (295,15),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['!'],
            activated_toggle = False)
        self.add(
            identity = '__Link',
            control_type = 'control_toggle',
            position = (315,15),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['*'])
        self.add(
            identity = '__Help',
            control_type = 'control_toggle',
            position = (335,15),
            color = (0,20,30),
            font_color = (0,120,160),
            control_list = ['?'])
        self.add(
            identity = '__Position',
            control_type = 'label',
            position = (335,98),
            control_list = [])
        self.add(
            identity = "Previous",
            control_type = 'control_toggle',
            position = (240,30),
            size = (25,25),
            control_list = ['<'],
            label_display = False,
            active = False)
        self.add(
            identity = "Next",
            control_type = 'control_toggle',
            position = (240,50),
            size = (25,25),
            control_list = ['>'],
            label_display = False,
            active = False)
        self.add(
            identity = "Esc",
            control_type = 'control_toggle',
            position = (240,70),
            size = (25,25),
            control_list = ['Esc'],
            label_display = False,
            active = False)
        self.add(
            identity = "Panic",
            control_type = 'control_toggle',
            position = (175,50),
            size = (40,40),
            control_list = ['Panic'],
            tip_list = ["Don't press"],
            control_image = ['control2.png'],
            label_display = False)
    def pygame_initiate(self):
        pygame.init()
        pygame.display.set_caption('Interphase')
        self.screen = pygame.display.set_mode((500,500))
        self.background = pygame.Surface((500,500))
        self.screen_doc = pygame.Surface((500,400))
        self.clock = pygame.time.Clock()
    def documentation(self, action='read'):
        if not self.doc_initialized:
            self.doc_info = interphase.DisplayMsg(self.screen_doc)
            self.doc_info.set_font_size(12)
            self.doc_info.set_font_color((82,96,116))
            self.interface_doc = []
            for doc in (interphase.Interface.__doc__, interphase.Interface.__init__.__doc__, interphase.InterfaceControl.__init__.__doc__):
                document = doc.splitlines()
                document = [line.strip() for line in document]
                page = []
                null_line = 0
                for line in document:
                    if not line:
                        null_line += 1
                    else:
                        null_line = 0
                    if null_line < 2:
                        page.append(line)
                    else:
                        self.interface_doc.append(page)
                        page = []
                        null_line = 0
                if page:
                    self.interface_doc.append(page)
            self.doc_initialized = True
        page_length = 25
        if action == 'initialize':
            self.doc = 0
            self.doc_place = 0
            self.doc_change = True
        elif action == 'Previous':
            if self.doc_place > 0:
                self.doc_place -= page_length
                if self.doc_place < 0:
                    self.doc_place = 0
            else:
                if self.doc > 0:
                    self.doc -= 1
                    self.doc_place = 0
                    adjust = False
                    while not adjust:
                        if self.doc_place + page_length < len(self.interface_doc[self.doc])-1:
                            self.doc_place += page_length
                        else:
                            adjust = True
            self.doc_change = True
        elif action == 'Next':
            if self.doc_place + page_length < len(self.interface_doc[self.doc])-1:
                self.doc_place += page_length
            else:
                if self.doc < len(self.interface_doc)-1:
                    self.doc += 1
                    self.doc_place = 0
            self.doc_change = True
        elif action == 'Esc':
            self.screen_doc.fill((0,0,0))
            rect = self.screen.blit(self.screen_doc, (0,0))
            pygame.display.update(rect)
            return
        if self.doc_change:
            count = 10
            lines = 0
            self.screen_doc.fill((0,0,0))
            for line in self.interface_doc[self.doc][self.doc_place:]:
                self.doc_info.add(line)
                self.doc_info.set_position((10,count))
                surface = self.doc_info()
                count += 15
                lines += 1
                if lines == page_length:
                    lines = 0
                    count = 5
                    break
            self.doc_change = False
        rect = self.screen.blit(self.screen_doc, (0,0))
        pygame.display.update(rect)
    def update(self):
        """
        State Object
            panel:              Interface panel
            controls:           Interface controls
            panel_active        Panel active
            panel_interact:     Pointer interface interact
            control_interact:   Pointer control interact
            button_interact:    Pointer button interact
            control:            Control selected
            button:             Button selected
            value:              Control value
            values:             Panel control values
        """
        interphase.Interface.update(self)
        state = self.get_state()
        if state.control:
            if state.control == 'Select1':
                if state.value == 'ON':
                    self.set_panel_image('panel.png')
                elif state.value == 'OFF':
                    self.set_panel_image(None)
            elif state.control == '__Fix':
                self.set_moveable()
                if self.control_image_set:
                    self.set_control_image(None)
                    self.set_button_image(None)
                    self.control_image_set = False
                else:
                    self.set_control_image(['control.png'])
                    self.set_button_image(['button.png'])
                    self.control_image_set = True
            elif state.control == '__Link':
                state.controls['Control'].set_link_activated()
            elif state.control == '__Help':
                if state.controls['Panic'].is_active():
                    if state.controls['Panic'].get_value() == 'Panic':
                        state.controls['Panic'].set_list(["Don't Panic"])
                        state.controls['Panic'].set_value("Don't Panic")
                        state.controls['Panic'].set_tip("Don't Panic","Press for help")
                else:
                    self.set_info_display()
                    self.set_label_display()
                    self.set_tips_display()
            elif state.control == 'Panic':
                if state.controls['Panic'].get_value() == 'Panic':
                    if not self.panic:
                        self.panic = True
                        self.panic_time = 20
                        self.disable_control('__Fix', '__Link', '__Help')
                        self.set_moveable(False)
                    else:
                        if not self.panic_time:
                            self.panic_time = 20
                            state.controls['Panic'].set_list(["Don't Panic"])
                            state.controls['Panic'].set_tip("Don't Panic","Don't press!!!")
                            self.panic = False
                else:
                    if not self.panic_time:
                        if not self.is_moveable():
                            self.move(250,450)
                            self.set_moveable(True)
                            state.controls['Panic'].set_tip("Don't Panic","Press for help")                     
                            self.enable_control('__Fix', '__Link', '__Help')
                        for control in ('Previous', 'Next', 'Esc'):
                            state.controls[control].set_active(True)
                        self.panel_update()
                        self.documentation('initialize')
                        self.doc_browse = True
            elif state.control in ('Previous', 'Next', 'Esc'):
                if self.doc_browse:
                    self.documentation(state.control)
                    if state.control == 'Esc':
                        for control in ('Previous', 'Next', 'Esc'):
                            state.controls[control].set_active(False)
                        self.doc_browse = False
            elif state.control == 'Control':
                if state.controls['Panic'].is_active():
                    if not self.is_tips_display():
                        self.set_tips_display(True)
                        self.panic_toggle = True
                else:
                    if self.doc_browse:
                        self.documentation('Esc')
                        for control in ('Previous', 'Next', 'Esc'):
                            state.controls[control].set_active(False)
                        self.doc_browse = False
                    if self.panic_toggle:
                        self.set_tips_display()
                        self.panic_toggle = False
                if state.button == 'Control' and state.value == 'Exit':
                    if not self.panic:
                        self.deactivate()
        if self.panic:
            if state.panel_interact:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                x, y = self.get_position()
                if x > mouse_x:
                    x += 5
                else:
                    x -= 5
                if x < 175: x += 5
                elif x > 325: x -= 5
                if y > mouse_y: 
                    y += 5
                else:
                    y -= 5
                if y < 50: y += 5
                elif y > 450: y -= 5
                self.move(x, y)
        if self.panic_time > 0:
            self.panic_time -= 1
        if self.doc_browse:
            self.documentation()
        if state.panel_interact:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            x, y = self.get_position()
            size = self.get_size()
            pos = mouse_x - x + (size[0]//2), mouse_y - y + (size[1]//2)
            state.controls['__Position'].set_value(pos)
        else:
            if state.controls['__Position'].get_value():
                state.controls['__Position'].set_value('')
        if self.is_info_display():
            if state.control_interact:
                self.add_info(state.control_interact, ':')
                self.add_info(state.values[state.control_interact])
                if state.button:
                    self.add_info(state.button)
        return state

def demo():
    interface_panel = InterfaceDemo()
    panel = pygame.sprite.RenderUpdates(interface_panel)
    run_demo = True
    while run_demo:
        panel.update()
        if interface_panel.is_active():
            panel.clear(interface_panel.screen,interface_panel.background)
            update_rect = panel.draw(interface_panel.screen)
            pygame.display.update(update_rect)
        else:
            pygame.quit()
            sys.exit()
        interface_panel.clock.tick(40)
        for event in pygame.event.get():
            if event.type==QUIT or (event.type==KEYDOWN and event.key==K_ESCAPE):
                pygame.quit()
                sys.exit()

def main():
    demo()

if __name__ == '__main__':
    main()

