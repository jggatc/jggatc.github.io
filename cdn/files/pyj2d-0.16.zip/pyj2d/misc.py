"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division


class Mask(object):
    def __init(self):
        pass
    def from_surface(self, surface):
        return None
mask = Mask()


class Surfarray(object):
    def use_arraytype(self, mode='numpy'):
        pass
surfarray = Surfarray()

