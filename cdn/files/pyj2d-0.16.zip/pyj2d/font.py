"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
from java.awt import Font as JFont
from java.awt import Color, BasicStroke, RenderingHints, GraphicsEnvironment
from java.awt.image import BufferedImage
import surface


initialized = False
surf = None
g2d = None


def init():
    global surf, g2d, initialized
    surf = surface.Surface((1,1), BufferedImage.TYPE_INT_RGB)
    g2d = surf.createGraphics()
    initialized = True

def quit():
    g2d.dispose()
    g2d = None
    surf = None
    initialized = False

def get_init():
    return initialized

def get_default_font():
    return 'Arial'

def get_fonts():
    GraphicsEnv = GraphicsEnvironment.getLocalGraphicsEnvironment()
    return GraphicsEnv.getAvailableFontFamilyNames()

def match_font(name, bold=False, italic=False):
    pass

class Font(JFont):

    def __init__(self, name, size, style=None):
        self.fontname = 'Arial'
        self.fontsize = size
        if not style:
            self.fontstyle = JFont.PLAIN
        else:
            if style['bold'] and style['italic']:
                self.fontstyle = JFont.BOLD | JFont.ITALIC
            elif style['bold']:
                self.fontstyle = JFont.BOLD
            elif style['italic']:
                self.fontstyle = JFont.ITALIC
        JFont.__init__(self,self.fontname,self.fontstyle,self.fontsize)
        self.font = self
        g2d.setFont(self.font)
        self.fontMetrics = g2d.getFontMetrics()
        self.underline = False

    def render(self, text, antialias, color, background=None):
        w,h = self.size(text)
        surf = surface.Surface((w,h), BufferedImage.TYPE_INT_ARGB)
        g2d = surf.createGraphics()
        if background:
            R,G,B = background
            g2d.setColor(Color(R,G,B))
            g2d.fillRect(0,0,w,h)
        g2d.setFont(self.font)
        if antialias:
            g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON)
        R,G,B = color
        g2d.setColor(Color(R,G,B))
        g2d.drawString(text,2,h//1.25+2)
        if self.underline:
            g2d.setStroke(BasicStroke(1))
            g2d.drawLine(2,h-4,w-3,h-4)
        g2d.dispose()
        return surf

    def size(self, text):       #use getBounds
        x = self.fontMetrics.stringWidth(text) + 4
        y = self.fontMetrics.getHeight() + 4
        return (x, y)

    def set_underline(self, setting=True):
        self.underline = setting

    def get_underline(self):
        return self.underline

    def set_bold(self, setting=True):
        if setting:
            if self.font.isItalic():
                self.font = self.deriveFont(JFont.BOLD + JFont.ITALIC)
            else:
                self.font = self.deriveFont(JFont.BOLD)
        else:
            if self.font.isItalic():
                self.font = self.deriveFont(JFont.ITALIC)
            else:
                self.font = self

    def get_bold(self):
        return self.font.isBold()

    def set_italic(self, setting=True):     #redo metrics
        if setting:
            if self.font.isBold():
                self.font = self.deriveFont(JFont.BOLD + JFont.ITALIC)
            else:
                self.font = self.deriveFont(JFont.ITALIC)
        else:
            if self.font.isBold():
                self.font = self.deriveFont(JFont.BOLD)
            else:
                self.font = self

    def get_italic(self):
        return self.font.isItalic()

    def metrics(self):
        pass

    def get_linesize(self):
        pass

    def get_height(self):
        return self.fontMetrics.getHeight()

    def get_ascent(self):
        pass

    def get_descent(self):
        pass


class SysFont(Font):

    def __init__(self, name, size, bold=False, italic=False):
        if bold or italic:
            self._style = {'bold':bold, 'italic':italic}
        else:
            self._style = None
        Font.__init__(self,name,size,self._style)

    def set_bold(self, setting=True):
        if setting:
            if self.font.isItalic():
                self.font = self.deriveFont(JFont.BOLD + JFont.ITALIC)
            else:
                self.font = self.deriveFont(JFont.BOLD)
        else:
            if self.font.isItalic():
                self.font = self.deriveFont(JFont.ITALIC)
            else:
                if self._style:
                    self.font = self.deriveFont(JFont.PLAIN)
                else:
                    self.font = self

    def set_italic(self, setting=True):
        if setting:
            if self.font.isBold():
                self.font = self.deriveFont(JFont.BOLD + JFont.ITALIC)
            else:
                self.font = self.deriveFont(JFont.ITALIC)
        else:
            if self.font.isBold():
                self.font = self.deriveFont(JFont.BOLD)
            else:
                if self._style:
                    self.font = self.deriveFont(JFont.PLAIN)
                else:
                    self.font = self

