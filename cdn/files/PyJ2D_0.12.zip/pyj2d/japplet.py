"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

instance = None

