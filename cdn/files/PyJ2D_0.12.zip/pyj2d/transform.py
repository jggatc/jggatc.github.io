"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
import math
import java.awt
import java.awt.geom
from surface import convert_bufferedimage


class Transform(object):

    def __init__(self):
        self.deg_rad = math.pi/180

    def rotate(self, image, degree):
        at = java.awt.geom.AffineTransform()
        angle = -degree*self.deg_rad
        at.rotate(angle, image.getWidth()//2, image.getHeight()//2)
        bio = java.awt.image.AffineTransformOp(at, java.awt.image.AffineTransformOp.TYPE_BILINEAR)
        bi = bio.filter(image, None)
        newImage = convert_bufferedimage(bi)
        try:
            newImage._colorkey = image.colorkey
        except AttributeError:
            pass
        return newImage

    def rotozoom(self, image, degree, size):
        newImage = self.rotate(image, degree)
        return newImage

