"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
import java.lang
import java.awt.event.MouseEvent
import locals
import time


class Event(object):
    def __init__(self):
        self.eventQueue = [None] * 256      #max 256: Error: Event queue full
        self.eventNum = 0
        self.eventQueueTmp = [None] * 256   #used when main queue is locked
        self.eventNumTmp = 0
        self.eventAllowed = []
        self.eventBlocked = []
        self.queueLock = False
        self.queueAccess = False
        self.timer = time.Clock()
    def lock(self):
        self.queueLock = True   #block next event access
        while self.queueAccess:      #complete current event access
            java.lang.Thread.sleep(1)       #~should be via separate Java event thread
    def unlock(self):
        self.queueLock = False
    def updateQueue(self, event):
        self.queueAccess = True
        if not self.queueLock:
            if self.eventNumTmp:
                 self.appendMerge()
            self.append(event)
        else:
            self.appendTmp(event)
        self.queueAccess = False
    def append(self, event):
        try:
            self.eventQueue[self.eventNum] = event
            self.eventNum += 1
        except IndexError:
            raise 'Error: Event queue full'
    def appendTmp(self, event):
        try:
            self.eventQueueTmp[self.eventNumTmp] = event
            self.eventNumTmp += 1
        except IndexError:
            raise 'Error: Event queue full'
    def appendMerge(self):
        for i in range(self.eventNumTmp):
            self.append( self.eventQueueTmp[i] )
            self.eventQueueTmp[i] = None
        self.eventNumTmp = 0
    def pump(self):
        pass
    def get(self, eventType=None):
        self.lock()
        if not eventType:
            queue = [ self.JEvent(event) for event in self.eventQueue[0:self.eventNum] ]
            for i in range(self.eventNum):
                self.eventQueue[i] = None
            self.eventNum = 0
        else:
            pass
        self.unlock()
        return queue
    def poll(self):
        self.lock()
        try:
            evt = self.eventQueue.pop(0)
            self.eventNum -= 1
            self.eventQueue.append(None)
        except IndexError:
            evt = locals.NOEVENT
        self.unlock
        return evt
    def wait(self):
        while True:
            try:
                self.lock()
                evt = self.eventQueue.pop(0)
                self.eventNum -= 1
                self.eventQueue.append(None)
                self.unlock()
                return evt
            except IndexError:
                self.unlock()
                java.lang.Thread.sleep(10)
    def peek(self, eventType):
        pass
    def clear(self, eventType=None):
        self.lock()
        for i in range(self.eventNum):
            self.eventQueue[i] = None
        self.eventNum = 0
        self.unlock()
    def event_name(self, eventType):
        pass
    def set_blocked(self, eventType):
        pass
    def set_allowed(self, eventType):
        pass
    def get_blocked(self, eventType):
        if eventType in eventBlocked:
            return True
        else:
            return False
    def set_grab(self):
        pass
    def get_grab(self):
        pass
    def post(self, event):
        self.lock()
        self.append(event)
    class Event(object):
        def __init__(self, eventType, attr=None, **kw_attr):
            self.type = eventType
            try:
                for name in attr:
                    self.__setattr__(self, name, attr[name])
            except TypeError:
                for name in kw_attr:
                    self.__setattr__(self, name, kw_attr[name])
        def __setattr__(self, name, value):
            if hasattr(self, name):
                raise AttributeError, "Attributes are read-only."
            object.__setattr__(self, name, value)
    class JEvent(object):
        __slots__ = ['event']
        jevt = {java.awt.event.MouseEvent.MOUSE_PRESSED: locals.MOUSEBUTTONDOWN, java.awt.event.MouseEvent.MOUSE_RELEASED: locals.MOUSEBUTTONUP, java.awt.event.MouseEvent.MOUSE_MOVED: locals.MOUSEMOTION}
        def __init__(self, event):
            object.__setattr__(self, "event", event)
        def __getattr__(self, attr):
            if attr == 'type':
                return self.jevt[self.event.getID()]
            elif attr == 'button':
                return self.event.getButton()
            elif attr == 'pos':
                return ( self.event.getX(),self.event.getY() )
        def __setattr__(self, name, value):
            raise AttributeError, "Attributes are read-only."
        def getEvent(self):
            return self.event

