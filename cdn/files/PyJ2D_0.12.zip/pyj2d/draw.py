"""
PyJ2D
Copyright (C) 2011 James Garnon
"""

from __future__ import division
import math
import java.awt
from rect import Rect


class Draw(object):

    def __init__(self):
        self.rad_deg = 180/math.pi

    def rect(self, surface, color, rect, fill):
        try:
            x,y,w,h = rect.x, rect.y, rect.width, rect.height
        except AttributeError:
            x,y,w,h = rect
            rect = Rect(x,y,w,h)
        g = surface.createGraphics()
        R,G,B = color
        g.setColor(java.awt.Color(R,G,B))       # *tuple unpack jythonc error
        g.fillRect(x,y,w,h)
        g.dispose()
        return rect

    def circle(self, surface, color, position, radius, fill):
        x, y = position
        w, h = 2*radius, 2*radius
        g = surface.createGraphics()
        R,G,B = color
        g.setColor(java.awt.Color(R,G,B))
        g.fillOval(x-radius, y-radius, w, h)
        g.dispose()
        return Rect(x,y,w,h)

    def arc(self, surface, color, rect, start_angle, stop_angle, width=1):
        try:
            x,y,w,h = rect.x, rect.y, rect.width, rect.height
        except AttributeError:
            x,y,w,h = rect
            rect = Rect(x,y,w,h)
        start_angle = int(start_angle * self.rad_deg)
        stop_angle = int(stop_angle * self.rad_deg)
        x -= w//8
        y -= h//8
        g = surface.createGraphics()
        R,G,B = color
        g.setColor(java.awt.Color(R,G,B))
        g.setStroke(java.awt.BasicStroke(width))
        g.drawArc(x, y, w, h, start_angle, stop_angle)
        g.dispose()
        return rect

    def polygon(self):
        pass

    def line(self, surface, color, point1, point2, width):
        p1x, p1y = point1
        p2x, p2y = point2
        g = surface.createGraphics()
        R,G,B = color
        g.setColor(java.awt.Color(R,G,B))
        g.setStroke(java.awt.BasicStroke(width))
        g.drawLine(p1x,p1y,p2x,p2y)
        g.dispose()

    def lines(self, surface, color, closed, pointlist, width=1):
        xpoints = [p[0] for p in pointlist]
        ypoints = [p[1] for p in pointlist]
        if closed:
            xpoint, ypoint = xpoints[0], ypoint[0]
            xpoints.append(xpoint)
            ypoints.append(ypoint)
        npoints = len(xpoints)
        g = surface.createGraphics()
        R,G,B = color
        g.setColor(java.awt.Color(R,G,B))
        g.setStroke(java.awt.BasicStroke(width))
        g.drawPolyline(xpoints, ypoints, npoints)
        g.dispose()

    def aaline(self):
        self.line()

    def aalines(self):
        self.lines()

