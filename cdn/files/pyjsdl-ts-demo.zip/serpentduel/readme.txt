Serpenduel Duel Demo

Pyjsdl module is modelled on Pygame/SDL commands that wraps JavaScript functionality including HTML5 canvas. The Pyjsdl module in the Pyjsdl-ts package (https://gatc.ca/projects/pyjsdl-ts) permits scripts coded in Python/Pygame to compile to JavaScript using the Transcrypt compiler (https://www.transcrypt.org), allowing deployment of JavaScript applications without extensive editing of the script. The Serpent Duel demo can run on the desktop with Python/Pygame and in the browser with Transcrypt/Pyjsdl.

To run in the Web browser, the only requirements are Transcrypt and Pyjsdl. Install Transcrypt following instructions on its Web site. Download the Pyjsdl-ts package and unpack the pyjsdl folder in the demo folder. Use the command 'transcrypt -n serpentduel.py' that compiles the Python code to JavaScript in the __target__ folder. Launch serpentduel.html in the Web browser from a Web server or local server using 'python3 -m http.server' and browse to localhost:8000.

