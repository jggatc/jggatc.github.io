#!/usr/bin/env python
""" pygame.examples.chimp

This simple example is used for the line-by-line tutorial
that comes with pygame. It is based on a 'popular' web banner.
Note there are comments here, but for the full explanation,
follow along in the tutorial.
"""

#Example modified for Pysdl (marked with ###)

# Import Modules
import os, sys      ###
try:
    import pygame as pg
    from pygame.compat import geterror
    engine = 'pygame'
    print('\nUse Pyjs to compile script with Pyjsdl library:')
    print('pyjsbuild -O --enable-descriptor-proto %s' % sys.argv[0])
except ImportError:
    import pyjsdl as pg    ###pyjsdl import
    geterror = lambda:sys.exc_info()[1]
    pg.sprite.RenderPlain = pg.sprite.Group
    engine = 'pyjsdl'
#import os
#import pygame as pg
#from pygame.compat import geterror

if not pg.font:
    print("Warning, fonts disabled")
if not pg.mixer:
    print("Warning, sound disabled")

if engine == 'pygame':      ###public files added to pyjs build
    main_dir = os.path.split(os.path.abspath(__file__))[0]
    data_dir = os.path.join(main_dir, "public/data")
elif engine == 'pyjsdl':
    main_dir = ''
    data_dir = os.path.join(main_dir, "data")
#main_dir = os.path.split(os.path.abspath(__file__))[0]
#data_dir = os.path.join(main_dir, "data")


# functions to create our resources
def load_image(name, colorkey=None):
    name = name.split('.')[0] + '.png'      ###bmp>png
    fullname = os.path.join(data_dir, name)
    try:
        image = pg.image.load(fullname)
    except pg.error:
        print("Cannot load image:", fullname)
        raise SystemExit(str(geterror()))
    image = image.convert()
    if colorkey is not None:
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey, pg.RLEACCEL)
    return image, image.get_rect()


def load_sound(name):
    class NoneSound:
        def play(self):
            pass

    if not pg.mixer or not pg.mixer.get_init():
        return NoneSound()
    fullname = os.path.join(data_dir, name)
    try:
        sound = pg.mixer.Sound(fullname)
    except pg.error:
        print("Cannot load sound: %s" % fullname)
        raise SystemExit(str(geterror()))
    return sound


# classes for our game objects
class Fist(pg.sprite.Sprite):
    """moves a clenched fist on the screen, following the mouse"""

    def __init__(self):
        pg.sprite.Sprite.__init__(self)  # call Sprite initializer
        self.image, self.rect = load_image("fist.bmp", -1)
        self.punching = 0

    def update(self):
        """move the fist based on the mouse position"""
        pos = pg.mouse.get_pos()
        self.rect.midtop = pos
        if self.punching:
            self.rect.move_ip(5, 10)

    def punch(self, target):
        """returns true if the fist collides with the target"""
        if not self.punching:
            self.punching = 1
            hitbox = self.rect.inflate(-5, -5)
            return hitbox.colliderect(target.rect)

    def unpunch(self):
        """called to pull the fist back"""
        self.punching = 0


class Chimp(pg.sprite.Sprite):
    """moves a monkey critter across the screen. it can spin the
       monkey when it is punched."""

    def __init__(self):
        pg.sprite.Sprite.__init__(self)  # call Sprite intializer
        self.image, self.rect = load_image("chimp.bmp", -1)
        screen = pg.display.get_surface()
        self.area = screen.get_rect()
        self.rect.topleft = 10, 10
        self.move = 9
        self.dizzy = 0

    def update(self):
        """walk or spin, depending on the monkeys state"""
        if self.dizzy:
            self._spin()
        else:
            self._walk()

    def _walk(self):
        """move the monkey across the screen, and turn at the ends"""
        newpos = self.rect.move((self.move, 0))
        if not self.area.contains(newpos):
            if self.rect.left < self.area.left or self.rect.right > self.area.right:
                self.move = -self.move
                newpos = self.rect.move((self.move, 0))
                self.image = pg.transform.flip(self.image, 1, 0)
            self.rect = newpos

    def _spin(self):
        """spin the monkey image"""
        center = self.rect.center
        self.dizzy = self.dizzy + 12
        if self.dizzy >= 360:
            self.dizzy = 0
            self.image = self.original
        else:
            rotate = pg.transform.rotate
            self.image = rotate(self.original, self.dizzy)
        self.rect = self.image.get_rect(center=center)

    def punched(self):
        """this will cause the monkey to start spinning"""
        if not self.dizzy:
            self.dizzy = 1
            self.original = self.image


#globals    ###globals shared between callbacks
screen = background = clock = None
whiff_sound = punch_sound = chimp = fist = allsprites = None
start = going = True


def pause():    ###pause animation when cursor off canvas
    global start
    pos = pg.mouse.get_pos()
    if start and pos != (-1,-1):
        start = False
    if not start and pos == (-1,-1) and not chimp.dizzy:
        pg.time.wait(100)
        return True
    else:
        return False


def setup():    ###
#def main():
    """this function is called when the program starts.
       it initializes everything it needs, then runs in
       a loop until the function returns."""
    # Initialize Everything
    pg.init()
    if engine == 'pyjsdl':
        pg.mixer.init(11025, size=-16, channels=2, buffer=1024) ###mixer init
    screen = pg.display.set_mode((468, 60))
    pg.display.set_caption("Monkey Fever")
    pg.mouse.set_visible(0)

    # Create The Backgound
    background = pg.Surface(screen.get_size())
    background = background.convert()
    background.fill((250, 250, 250))

    # Put Text On The Background, Centered
    if pg.font:
        if engine == 'pygame':   ###
            font = pg.font.Font(None, 36)
        elif engine =='pyjsdl':
            font = pg.font.Font(None, 24)
#        font = pg.font.Font(None, 36)
        text = font.render("Pummel The Chimp, And Win $$$", 1, (10, 10, 10))
        textpos = text.get_rect(centerx=background.get_width() / 2)
        background.blit(text, textpos)

    # Display The Background
    screen.blit(background, (0, 0))
    pg.display.flip()
    return screen, background

def prerun():   ###
    # Prepare Game Objects
    global clock, whiff_sound, punch_sound, chimp, fist, allsprites
    ###globals shared between callbacks
    clock = pg.time.Clock()
    if engine == 'pygame':
        whiff_sound = load_sound('whiff-st.wav')
        punch_sound = load_sound('punch-st.wav')
    elif engine == 'pyjsdl':
        whiff_sound = load_sound('whiff-st.mp3')    ###mono>stereo; wav>mp3
        punch_sound = load_sound('punch-st.mp3')
#    whiff_sound = load_sound("whiff.wav")
#    punch_sound = load_sound("punch.wav")
    chimp = Chimp()
    fist = Fist()
    allsprites = pg.sprite.RenderPlain((fist, chimp))
    if engine == 'pyjsdl':
        pg.set_callback(run)   ###set run callback function

def run():      ###
    # Main Loop
    global going    ###globals shared between callbacks
    going = True
#    while going:      ###callback replaces loop
    clock.tick(60)

        # Handle Input Events
    for event in pg.event.get():
        if event.type == pg.QUIT:
            going = False
        elif event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE:
            going = False
        elif event.type == pg.MOUSEBUTTONDOWN:
            if fist.punch(chimp):
                punch_sound.play()  # punch
                chimp.punched()
            else:
                whiff_sound.play()  # miss
        elif event.type == pg.MOUSEBUTTONUP:
            fist.unpunch()

    if not going:   ###
        pg.quit()
        return

    if pause():     ###
        return

    allsprites.update()

    # Draw Everything
    screen.blit(background, (0, 0))
    allsprites.draw(screen)
    pg.display.flip()

#    pg.quit()      ###

def main():      ###
    global screen, background, going    ###globals shared between callbacks
    screen, background = setup()
    if engine == 'pygame':
        prerun()
        while going:
            run()
    elif engine == 'pyjsdl':
        pg.setup(prerun, ['./data/chimp.png', './data/fist.png'])   ###
        ###setup prerun callback function for image preloading


# Game Over


# this calls the 'main' function when this script is executed
if __name__ == "__main__":
    main()
