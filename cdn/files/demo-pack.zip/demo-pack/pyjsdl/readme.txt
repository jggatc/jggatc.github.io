Pyjsdl Demos


Example scripts are derived from Pygame examples included in the pygame package (https://www.pygame.org/) and are public domain. The examples scripts can run with Pyjs compiler and Pyjsdl or with Python2+ interpreter and Pygame. Refer to script code for modifications required for Pygame examples to run under Pyjsdl.


Dependency:
Pyjsdl v0.24 (https://gatc.ca/projects/pyjsdl/)
Pyjs (installed from https://github.com/pyjs/pyjs)


Instructions:
Download Pyjsdl and unpack into script folder or on path. Install Pyjs compiler using the instructions provided on the Pyjs Github site. Refer to guide.txt in Pyjsdl folder for further information. Pyjs can compile with pyjsbuild in strict (-S) mode that provides greater adherence to Python and optimized (-O) mode that reduces adherence for better performance. The --dynamic-link option can be used to reduce build size and share JavaScript lib between apps. When using different pyjsbuild options use -o option to change build output folder. The examples were modified for optimized mode that lack access to property attributes such as rect.center unless compiled with the --enable-descriptor-proto option. Use the following commands to compile: 

[pyjs_path]/bin/pyjsbuild -O aliens.py --dynamic-link --enable-descriptor-proto
[pyjs_path]/bin/pyjsbuild -O chimp.py --dynamic-link --enable-descriptor-proto
[pyjs_path]/bin/pyjsbuild -O stars.py --dynamic-link --enable-descriptor-proto

Compilation of the examples provides JavaScript apps that can be run in the Web browser, run the main HTML in the output folder. Media files from the public folder were transferred to the output folder during compilation. The apps can be run locally in the browsers using either 'python2 -m SimpleHTTPServer 8000' or 'python3 -m http.server' and browse to localhost:8000. The apps were tested with Firefox/Chrome in Linux and Firefox/Chrome/IE in Win7, Chrome may require launching with --allow-file-access-from-files option to run local files, or set up a local server. The app can be deployed to a server to run on the Web.

