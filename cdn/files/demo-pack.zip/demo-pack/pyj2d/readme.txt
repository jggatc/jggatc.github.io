PyJ2D Demos


Example scripts are derived from Pygame examples included in the pygame package (https://www.pygame.org/) and are public domain. The examples scripts can run with Jython interpreter and PyJ2D or with Python2+ interpreter and Pygame. Refer to script code for modifications required for Pygame examples to run under PyJ2D.


Dependency:
PyJ2D v0.30 (https://gatc.ca/projects/pyj2d/)
Jython v2.2.1+ (installed or standalone from http://www.jython.org)
JavaVM installed (https://www.java.com/)


Instructions:
Download PyJ2D and unpack into script folder or on path. Download Jython, and either install or place Jython standalone into script folder or on path. The examples can run with Jython2.2.1 or later. To run script with Jython standalone, use the command 'java -jar jython.jar script.py'. To run with Jython installed, use the command 'jython script.py'.

